package com.secureconnect.app.ui.screens.home

import com.secureconnect.app.vpn.VpnState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ConnectionUiPolicyTest {
    @Test fun stoppingNeverAllowsNewStartOrCancel() {
        val model = ConnectionUiPolicy.resolve(VpnState.Stopping, pending = true, connecting = true)
        assertEquals(ConnectionAction.NONE, model.action)
        assertFalse(model.enabled)
        assertFalse(model.connected)
    }

    @Test fun blockedTunnelIsNotMisrepresentedAsConnected() {
        val model = ConnectionUiPolicy.resolve(VpnState.Blocked, pending = false, connecting = false)
        assertTrue(model.blocked)
        assertFalse(model.connected)
        assertEquals(ConnectionAction.DISCONNECT, model.action)
    }

    @Test fun verifiedConnectedStateOverridesStaleSearchFlags() {
        val model = ConnectionUiPolicy.resolve(VpnState.Connected, pending = true, connecting = true)
        assertTrue(model.connected)
        assertFalse(model.busy)
        assertEquals(ConnectionAction.DISCONNECT, model.action)
    }

    @Test fun pendingScanCanBeCancelledWithoutStartingVpnService() {
        val model = ConnectionUiPolicy.resolve(VpnState.Idle, pending = true, connecting = false)
        assertEquals(ConnectionAction.CANCEL_SEARCH, model.action)
        assertTrue(model.busy)
    }

    @Test fun validationCanBeCancelled() {
        val model = ConnectionUiPolicy.resolve(VpnState.Validating, pending = false, connecting = true)
        assertEquals(ConnectionAction.CANCEL_CONNECTION, model.action)
    }

    @Test fun idleAndErrorPermitExplicitRetry() {
        assertEquals(ConnectionAction.CONNECT,
            ConnectionUiPolicy.resolve(VpnState.Idle, false, false).action)
        assertEquals(ConnectionAction.CONNECT,
            ConnectionUiPolicy.resolve(VpnState.Error("timeout"), false, false).action)
    }
}
