package com.secureconnect.app.vpn

/**
 * Stable auto-selection for publicly shared servers.
 *
 * A single fast speed-test must not defeat a server which has delivered stable
 * connectivity for hours. Scores only rank ALREADY qualified candidates;
 * they never turn an untested public configuration into a verified reserve.
 * Success/failure counters are device-local observations, not server uptime SLAs.
 */
object ServerStabilityPolicy {
    const val FAILURES_TO_QUARANTINE = 2
    const val MAX_OBSERVATIONS = 1_000
    // Several callbacks from one broken TCP/TLS probe must not count as
    // independent failures and evict the last known good backup instantly.
    const val FAILURE_DEBOUNCE_MS = 60_000L
    // A small score difference is not worth renegotiating live video sessions.
    const val KEEP_CURRENT_WITHIN_POINTS = 7.0

    fun shouldKeepCurrent(currentScore: Double, challengerScore: Double): Boolean =
        currentScore.isFinite() && challengerScore.isFinite() &&
            currentScore + KEEP_CURRENT_WITHIN_POINTS >= challengerScore

    fun countNewFailure(nowMs: Long, previousFailureAtMs: Long): Boolean =
        previousFailureAtMs <= 0L || nowMs < previousFailureAtMs ||
            nowMs - previousFailureAtMs >= FAILURE_DEBOUNCE_MS
    private const val DAY_MS = 24L * 60L * 60L * 1_000L

    fun remainsReady(consecutiveFailures: Int): Boolean =
        consecutiveFailures in 0 until FAILURES_TO_QUARANTINE

    /** Bayesian smoothing avoids giving a new node 100% reliability after one probe. */
    fun confidence(successes: Int, totalFailures: Int): Double {
        val ok = successes.coerceIn(0, MAX_OBSERVATIONS)
        val bad = totalFailures.coerceIn(0, MAX_OBSERVATIONS)
        return (ok + 3.0) / (ok + bad + 6.0)
    }

    fun score(
        pingMs: Int,
        downMbps: Double,
        upMbps: Double,
        successes: Int,
        totalFailures: Int,
        consecutiveFailures: Int,
        lastSuccessAtMs: Long,
        nowMs: Long
    ): Double {
        val pingScore = if (pingMs in 1..100) (100.0 - pingMs) / 100.0 else 0.0
        val down = downMbps.takeIf { it.isFinite() && it > 0 } ?: 0.0
        val up = upMbps.takeIf { it.isFinite() && it > 0 } ?: 0.0
        val speedScore = 20.0 * (down.coerceAtMost(15.0) / 15.0) +
            8.0 * (up.coerceAtMost(3.0) / 3.0)
        val stalePenalty = if (lastSuccessAtMs <= 0L || lastSuccessAtMs > nowMs) 8.0
            else 8.0 * ((nowMs - lastSuccessAtMs).toDouble() / DAY_MS).coerceIn(0.0, 1.0)
        return 54.0 * confidence(successes, totalFailures) +
            18.0 * pingScore + speedScore -
            15.0 * consecutiveFailures.coerceIn(0, FAILURES_TO_QUARANTINE) - stalePenalty
    }
}
