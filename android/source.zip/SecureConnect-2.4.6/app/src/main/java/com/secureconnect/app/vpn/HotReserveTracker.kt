package com.secureconnect.app.vpn

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/** In-memory only: a hot certificate MUST NOT survive process or network changes. */
object HotReserveTracker {
    data class Health(val id: String, val verifiedAtMs: Long, val networkKey: String)
    private val lock = Any()
    private val lastPassed = LinkedHashMap<String, Health>()
    private var currentNetwork: String? = null
    private val _status = MutableStateFlow("Горячий резерв: 0/3")
    val status = _status.asStateFlow()

    fun reset() = synchronized(lock) {
        lastPassed.clear()
        currentNetwork = null
        _status.value = "Горячий резерв: 0/3"
    }

    fun onNetwork(key: String?) = synchronized(lock) {
        if (key != currentNetwork) {
            currentNetwork = key
            lastPassed.clear()
            _status.value = "Горячий резерв: 0/3 · смена сети"
        }
    }

    fun passed(id: String, key: String, nowMs: Long = System.currentTimeMillis()) = synchronized(lock) {
        if (key == currentNetwork) lastPassed[id] = Health(id, nowMs, key)
        lastPassed.entries.removeIf { it.key != id && !HotReservePolicy.fresh(nowMs, it.value.verifiedAtMs) }
        update(nowMs)
    }

    fun failed(id: String, nowMs: Long = System.currentTimeMillis()) = synchronized(lock) {
        lastPassed.remove(id)
        update(nowMs)
    }

    fun readyIdsForNetwork(key: String?, nowMs: Long = System.currentTimeMillis()): List<String> =
        synchronized(lock) { if (key != null && key == currentNetwork) readyIds(nowMs) else emptyList() }

    fun readyIds(nowMs: Long = System.currentTimeMillis()): List<String> = synchronized(lock) {
        lastPassed.values.asSequence().filter { it.networkKey == currentNetwork &&
            HotReservePolicy.fresh(nowMs, it.verifiedAtMs) }
            .sortedByDescending { it.verifiedAtMs }.take(HotReservePolicy.TARGET).map { it.id }.toList()
    }

    private fun update(now: Long) {
        _status.value = "Горячий резерв: ${readyIds(now).size}/${HotReservePolicy.TARGET} (HTTPS ≤20мин; при переходе перепроверяется)"
    }
}
