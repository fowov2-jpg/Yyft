package com.secureconnect.app.vpn

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DeadCandidatePolicyTest {
    @Test fun controlSiteVideoFailuresAreNotMarkedTransportDead() {
        assertTrue(DeadCandidateStore.videoOnlyFailure("YouTube HTTP 403"))
        assertTrue(DeadCandidateStore.videoOnlyFailure("Скорость резерва не подтверждена"))
        assertFalse(DeadCandidateStore.videoOnlyFailure("SOCKS handshake timed out"))
        assertFalse(DeadCandidateStore.videoOnlyFailure(null))
    }

    @Test fun retryMemoryIsBounded() {
        assertTrue(DeadCandidateStore.TRANSPORT_COOLDOWN_MS <= 60L * 60_000L)
        assertTrue(DeadCandidateStore.VIDEO_COOLDOWN_MS < DeadCandidateStore.TRANSPORT_COOLDOWN_MS)
    }
}
