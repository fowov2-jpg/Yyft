package com.secureconnect.app.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.ServiceCompat
import com.secureconnect.app.AppRunController
import com.secureconnect.app.TaskPresenceMonitor
import com.secureconnect.app.data.local.ServerStore
import com.secureconnect.app.data.local.WorkingServerStore
import com.secureconnect.app.data.model.Server
import com.secureconnect.app.data.remote.ConfigParser
import com.secureconnect.app.data.model.ServerTransport
import com.secureconnect.app.util.ResourceGovernor
import java.net.Inet4Address
import java.util.LinkedHashSet
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * VpnService: TUN + Xray.
 * Kill Switch: при обрыве ядра TUN остаётся с маршрутами full-tunnel, а Xray останавливается,
 * поэтому трафик не уходит напрямую до явного отключения пользователем.
 */
class XrayVpnService : VpnService() {

    @Volatile
    private var pfd: ParcelFileDescriptor? = null

    private val operationLock = Any()
    // Process-global generation prevents delayed work from an old Service instance
    // from stopping or committing state into a newer START_STICKY instance.
    private val operationGeneration = GLOBAL_OPERATION_GENERATION
    private val handoverSerial = AtomicLong(0L)

    @Volatile private var activeConfig: String? = null
    @Volatile private var activeRawLink: String? = null
    @Volatile private var activeHost: String? = null
    @Volatile private var activeServer: Server? = null

    private val mainHandler = Handler(Looper.getMainLooper())
    private val taskMonitor by lazy {
        TaskPresenceMonitor(this, mainHandler) { AppRunController.closed(this) }
    }
    private val periodicTasks by lazy {
        VpnPeriodicTasks(
            schedule = { task, delayMs -> mainHandler.postDelayed(task, delayMs) },
            cancel = { task -> mainHandler.removeCallbacks(task) }
        )
    }
    /** All samples happen in this service, including when the Activity is minimized. */
    private val trafficSampleInFlight = AtomicBoolean(false)
    private val openAiTlsInFlight = AtomicBoolean(false)
    private val openAiTlsPending = AtomicBoolean(false)
    private var previousSampleAtNs = 0L
    private var previousSampleGeneration = -1L
    private var lastRateNotificationAtMs = -1L
    @Volatile private var foregroundActive = false
    /** Ensures two task-owned services cannot stop the same tunnel twice. */
    private val taskShutdownStarted = AtomicBoolean(false)
    @Volatile private var notificationStatus = "Подключение…"

    private val trafficTicker = object : Runnable {
        override fun run() {
            if (AppRunController.mayRun(this@XrayVpnService) &&
                VpnController.state.value == VpnState.Connected && pfd != null &&
                uiVisible && isScreenInteractive()) {
                if (trafficSampleInFlight.compareAndSet(false, true)) {
                    ResourceGovernor.workerExecutor.execute {
                        // The core generation can change during automatic failover.
                        val generation = XrayCore.currentGeneration()
                        val sample = runCatching { XrayCore.queryTrafficSample("proxy,sc-hot-1,sc-hot-2,sc-hot-3") }
                            .getOrDefault(XrayCore.TrafficSample(0L, 0L))
                        val sampledAtNs = System.nanoTime()
                        mainHandler.post {
                            trafficSampleInFlight.set(false)
                            if (foregroundActive && pfd != null &&
                                VpnController.state.value == VpnState.Connected &&
                                generation >= 0L && XrayCore.currentGeneration() == generation) {
                                val elapsed = if (previousSampleGeneration == generation) {
                                    sampledAtNs - previousSampleAtNs
                                } else 0L
                                previousSampleGeneration = generation
                                previousSampleAtNs = sampledAtNs
                                VpnController.trafficRate.value = VpnTrafficDisplay.calculate(
                                    sample.downlinkBytes, sample.uplinkBytes, elapsed
                                )
                                // The status notification is not a realtime chart.
                                // Updating RemoteViews every five seconds wastes IPC.
                                val nowMs = android.os.SystemClock.elapsedRealtime()
                                if (lastRateNotificationAtMs < 0L ||
                                    nowMs - lastRateNotificationAtMs >=
                                    BatteryAwarePolicy.NOTIFICATION_RATE_INTERVAL_MS) {
                                    lastRateNotificationAtMs = nowMs
                                    refreshNotification()
                                }
                            } else {
                                clearTrafficRate()
                            }
                        }
                    }
                }
            } else {
                clearTrafficRate()
            }
            periodicTasks.reschedule(this,
                BatteryAwarePolicy.trafficIntervalMs(isScreenInteractive(), uiVisible))
        }
    }

    private fun isScreenInteractive(): Boolean =
        getSystemService(PowerManager::class.java)?.isInteractive != false

    private fun clearTrafficRate() {
        previousSampleAtNs = 0L
        previousSampleGeneration = -1L
        if (VpnController.trafficRate.value != VpnTrafficRate.ZERO) {
            VpnController.trafficRate.value = VpnTrafficRate.ZERO
        }
    }
    private val recoveryInProgress = AtomicBoolean(false)
    /** Cancels stale background recovery when a newer manual/service action wins. */
    private val recoverySerial = AtomicLong(0L)
    private val recoveryRetryCount = AtomicInteger(0)
    private val recoveryRetrySerial = AtomicLong(0L)
    private val watchdogFailures = AtomicInteger(0)
    private val watchdogHighLatency = AtomicInteger(0)
    private val watchdogSerial = AtomicLong(0L)
    private val watchdogProbeInProgress = AtomicBoolean(false)
    private val lastQualityRecoveryAtMs = AtomicLong(0L)
    private val noUnderlyingNetworkSinceMs = AtomicLong(0L)
    private val guardianFailedUntilMs = ConcurrentHashMap<String, Long>()
    @Volatile private var watchdogAlternate = false

    private val watchdogRunnable = object : Runnable {
        override fun run() {
            if (
                VpnController.autoRecoveryEnabled &&
                VpnController.state.value == VpnState.Connected &&
                !recoveryInProgress.get()
            ) {
                runWatchdogProbe()
            }
            periodicTasks.reschedule(this,
                BatteryAwarePolicy.watchdogIntervalMs(isScreenInteractive()))
        }
    }

    private val speedProbeInFlight = AtomicBoolean(false)
    private val speedProbeSerial = AtomicLong(0L)
    private val lastSlowReserveReplacementAtMs = AtomicLong(0L)
    @Volatile private var speedTriggerMbps: Double? = null
    // A slow first connection is usable, not final. Keep looking for a proven
    // fast reserve after the UI has already reported Connected.
    @Volatile private var pendingQualityUpgrade: AutoQualityUpgradePolicy.Pending? = null
    private val lastQualityUpgradeAttemptAtMs = AtomicLong(0L)
    private val securityMonitor by lazy { AutomaticSecurityMonitor(this) }
    private fun inspectSecurity() {
        if (!AppRunController.mayRun(this)) return
        securityMonitor.inspect(tunPresent = pfd != null, serverPresent = activeServer != null)
    }
    private val securityTicker = object : Runnable {
        override fun run() {
            inspectSecurity()
            periodicTasks.reschedule(this,
                BatteryAwarePolicy.securityIntervalMs(isScreenInteractive()))
        }
    }
    private val qualityUpgradeTicker = object : Runnable {
        override fun run() {
            tryUpgradeFromFreshReserve()
            periodicTasks.reschedule(this, 
                if (pendingQualityUpgrade != null) AutoQualityUpgradePolicy.POLL_INTERVAL_MS
                else BatteryAwarePolicy.DISCOVERY_PAUSE_MS)
        }
    }

    /** A quality problem must wake the selector now, not after the idle 30-min tick. */
    private fun wakeQualityUpgradeTicker() {
        mainHandler.post {
            mainHandler.removeCallbacks(qualityUpgradeTicker)
            periodicTasks.reschedule(qualityUpgradeTicker, 1_500L)
        }
    }

    /** No network probes here: only consult the already certified reserve cache.
     *  The scanner is independent and populates it without interrupting the VPN. */
    private fun tryUpgradeFromFreshReserve() {
        val pending = pendingQualityUpgrade ?: return
        val current = activeServer ?: return
        if (current.id != pending.serverId || pfd == null ||
            VpnController.state.value != VpnState.Connected ||
            !VpnController.autoRecoveryEnabled || !AppRunController.mayRun(this) ||
            isPowerSaveActive() || recoveryInProgress.get() || !hasUnderlyingInternetNetwork() ||
            getSharedPreferences("sc_settings", MODE_PRIVATE)
                .getString("connection_mode_v1", "AUTO") == ConnectionMode.MANUAL.name) return

        val ready = WorkingServerStore.activeRecords(this)
            .asSequence().filter { it.server.id != current.id }
            .filter { r -> AutoQualityUpgradePolicy.isWorthSwitching(
                pending, r.effectivePingMs(), r.verifiedDownloadMbps, r.verifiedUploadMbps
            ) }
            .sortedWith(compareByDescending<WorkingServerStore.Record> {
                it.stabilityScore(System.currentTimeMillis())
            }.thenBy { it.effectivePingMs() })
            .firstOrNull()

        if (ready == null) {
            // Keep the live tunnel, keep looking. A future scanner success wakes
            // this cheap local check instead of waiting for another 5min test.
            VpnController.qualityUpgradeStatus.value = "searching · current slow · waiting for certified reserve"
            return
        }
        val now = System.currentTimeMillis()
        val previousAttempt = lastQualityUpgradeAttemptAtMs.get()
        if (!AutoQualityUpgradePolicy.canAttempt(now, previousAttempt)) return
        if (!lastQualityUpgradeAttemptAtMs.compareAndSet(previousAttempt, now)) return
        speedTriggerMbps = pending.downloadMbps
        VpnController.qualityUpgradeStatus.value = "checking certified replacement"
        VpnController.emitEvent("Speed: найден проверенный быстрый резерв " +
            "${ready.server.country} (↓${String.format(java.util.Locale.US, "%.1f", ready.verifiedDownloadMbps)} " +
            "↑${String.format(java.util.Locale.US, "%.1f", ready.verifiedUploadMbps)} " +
            "RTT=${ready.effectivePingMs()}мс); проверяю перед переходом")
        scheduleAutomaticRecovery("низкая скорость 5/1 Мбит/с", qualityOnly = true)
    }

    private val speedTicker = object : Runnable {
        override fun run() {
            // No throughput probes while reconnecting, using battery saver, or
            // offline. A fully connected service owns this independently of UI.
            if (VpnController.state.value == VpnState.Connected && pfd != null &&
                AppRunController.mayRun(this@XrayVpnService) &&
                !recoveryInProgress.get() &&
                BatteryAwareRuntime.read(this@XrayVpnService).heavyTestsAllowed &&
                hasUnderlyingInternetNetwork()) {
                runPeriodicSpeedProbe()
            }
            periodicTasks.reschedule(this, BatteryAwarePolicy.HEAVY_TEST_INTERVAL_MS)
        }
    }

    private val lastAutomaticVideoTestAtMs = ConcurrentHashMap<String, Long>()
    private val automaticVideoRetestDelayMs = 30L * 60_000L

    private val videoPageProbeInFlight = AtomicBoolean(false)

    /** Lightweight YouTube homepage check, independent of costly speed uploads. */
    private fun checkVideoPageInBackground(serverId: String) {
        if (VpnController.state.value != VpnState.Connected || activeServer?.id != serverId || pfd == null) return
        val candidate = activeServer ?: return
        val proof = WorkingServerStore.activeRecord(this, serverId)
        if (proof != null && FastConnectPolicy.canReuseCertifiedQuality(
                proof.server.rawLink == candidate.rawLink,
                proof.youtubeVerifiedAtMs, proof.speedVerifiedAtMs, System.currentTimeMillis()
            )) return
        if (speedProbeInFlight.get() || !videoPageProbeInFlight.compareAndSet(false, true)) return
        val generation = operationGeneration.get()
        ResourceGovernor.workerExecutor.execute {
            try {
                if (generation != operationGeneration.get() || activeServer?.id != serverId ||
                    VpnController.state.value != VpnState.Connected) return@execute
                VpnController.videoQualityStatus.value = "Проверяется YouTube"
                val page = YouTubePageProbe.checkActive()
                if (generation == operationGeneration.get() && activeServer?.id == serverId &&
                    !speedProbeInFlight.get() &&
                    VpnController.state.value == VpnState.Connected) {
                    VpnController.videoQualityStatus.value = when {
                        page.passed -> "YouTube доступен · скорость не измерена"
                        page.verdict == YouTubePageProbe.Verdict.BLOCKED -> "YouTube недоступен"
                        else -> "Доступность YouTube не подтверждена"
                    }
                }
            } finally {
                videoPageProbeInFlight.set(false)
            }
        }
    }

    /** Strict reserve certification AFTER a usable VPN has been established.
     *  This must never delay the user's initial Internet connection. */
    private fun certifyActiveQuality(
        serverId: String,
        measuredConnectMs: Int,
        measuredHttpsMs: Int,
        userInitiated: Boolean = false,
        automaticInitial: Boolean = false
    ) {
        if (VpnController.state.value != VpnState.Connected || activeServer?.id != serverId || pfd == null) return
        if (!AppRunController.mayRun(this) || recoveryInProgress.get()) return
        if (automaticInitial) {
            val selected = activeServer ?: return
            val previous = WorkingServerStore.activeRecord(this, serverId)
            if (previous != null && FastConnectPolicy.canReuseCertifiedQuality(
                    sameConfiguration = previous.server.rawLink == selected.rawLink,
                    youtubeVerifiedAtMs = previous.youtubeVerifiedAtMs,
                    speedVerifiedAtMs = previous.speedVerifiedAtMs,
                    nowMs = System.currentTimeMillis()
                )) {
                VpnController.videoQualityStatus.value = "Подтверждено ранее"
                VpnController.videoAutoCheckBusy.value = false
                return
            }
        }
        if ((!userInitiated && !automaticInitial &&
                !WorkingPoolPolicy.qualifiesRtt(measuredConnectMs)) ||
            (measuredHttpsMs <= 0 && !automaticInitial) ||
            (!userInitiated && !automaticInitial &&
                !BatteryAwareRuntime.read(this).heavyTestsAllowed)) {
            // A small TLS/HTML check can still report availability on battery.
            // Never upload/download large speed payloads on metered mobile data.
            checkVideoPageInBackground(serverId)
            return
        }
        // A flapping public endpoint must not trigger 2.5 MB of 4G traffic
        // every time it reconnects. New routes are still tested once.
        if (automaticInitial) {
            val now = android.os.SystemClock.elapsedRealtime()
            val prior = lastAutomaticVideoTestAtMs[serverId]
            if (prior != null && now >= prior && now - prior < automaticVideoRetestDelayMs) {
                VpnController.videoQualityStatus.value = "Видео · повторный тест отложен для экономии батареи"
                VpnController.videoAutoCheckBusy.value = false
                return
            }
        }
        if (!speedProbeInFlight.compareAndSet(false, true)) return
        if (automaticInitial) {
            val now = android.os.SystemClock.elapsedRealtime()
            lastAutomaticVideoTestAtMs.entries.removeAll { now - it.value > automaticVideoRetestDelayMs }
            lastAutomaticVideoTestAtMs[serverId] = now
        }
        if (userInitiated) VpnController.videoManualCheckBusy.value = true
        if (automaticInitial) VpnController.videoAutoCheckBusy.value = true
        if (userInitiated || automaticInitial) VpnController.speedTestResult.value = null
        val generation = operationGeneration.get()
        val serial = speedProbeSerial.incrementAndGet()
        ResourceGovernor.workerExecutor.execute {
            try {
                if (!speedProbeIsCurrent(generation, serverId, serial)) return@execute
                // VPN was already announced ready after HTTPS. Video confirmation
                // is independent, and this test runs only on charging/unmetered
                // conditions to avoid draining the user's mobile data.
                // A generic HTTPS probe alone never certifies YouTube quality.
                VpnController.videoQualityStatus.value =
                    if (automaticInitial) "Проверяем YouTube и скорость · автоматически"
                    else "Проверяется"
                val startedAtMs = android.os.SystemClock.elapsedRealtime()
                val youtube = YouTubePageProbe.checkActive()
                if (!speedProbeIsCurrent(generation, serverId, serial)) return@execute
                if (!youtube.passed) {
                    VpnController.videoQualityStatus.value =
                        if (youtube.verdict == YouTubePageProbe.Verdict.BLOCKED)
                            "YouTube недоступен" else "YouTube не проверен"
                    VpnController.emitEvent(
                        "YouTube не подтверждён; VPN остаётся подключён"
                    )
                    if (automaticInitial &&
                        youtube.verdict == YouTubePageProbe.Verdict.BLOCKED) {
                        pendingQualityUpgrade = AutoQualityUpgradePolicy.Pending(
                            serverId, Double.NaN, Double.NaN, youtubeBlocked = true
                        )
                        VpnController.qualityUpgradeStatus.value = "searching · youtube blocked"
                        ServerScanner.requestRecoveryWindow()
                        wakeQualityUpgradeTicker()
                        mainHandler.post { tryUpgradeFromFreshReserve() }
                    }
                    return@execute
                }
                if (automaticInitial) {
                    // A single bounded first-connect test is deliberately allowed
                    // on mobile data. No repeated uploads, no manual button.
                    // If YouTube consumed the time budget, keep the usable VPN up
                    // and show an honest unknown video result.
                    if (android.os.SystemClock.elapsedRealtime() - startedAtMs >= 12_000L) {
                        VpnController.videoQualityStatus.value = "YouTube доступен · скорость не измерена"
                        return@execute
                    }
                    val first = VpnSpeedTester.measureDownloadOnly()
                    if (!speedProbeIsCurrent(generation, serverId, serial)) return@execute
                    VpnController.speedTestResult.value = VpnSpeedTester.formatVideoDownload(first)
                    if (FastConnectPolicy.videoSuitable(youtube.passed, first.downloadMbps)) {
                        VpnController.videoQualityStatus.value = "Авто 720p · скорость подходит"
                        return@execute
                    }
                    val firstDownload = first.downloadMbps
                    if (firstDownload == null) {
                        VpnController.videoQualityStatus.value = "Видео · скорость не измерена"
                        return@execute
                    }
                    if (android.os.SystemClock.elapsedRealtime() - startedAtMs >= 12_000L) {
                        VpnController.videoQualityStatus.value = "Видео · требуется повторный замер"
                        return@execute
                    }
                    // Two slow real transfers on the exact active video route
                    // avoid penalizing a working VPN for one CDN hiccup.
                    val second = VpnSpeedTester.measureDownloadOnly()
                    if (!speedProbeIsCurrent(generation, serverId, serial)) return@execute
                    VpnController.speedTestResult.value = VpnSpeedTester.formatVideoDownload(second)
                    val secondDownload = second.downloadMbps
                    if (secondDownload != null &&
                        secondDownload < VpnSpeedPolicy.MIN_DOWNLOAD_MBPS) {
                        WorkingServerStore.demoteSpeedQuality(this@XrayVpnService, serverId)
                        pendingQualityUpgrade = AutoQualityUpgradePolicy.Pending(
                            serverId,
                            minOf(firstDownload, secondDownload),
                            null // upload was not measured; compare only download
                        )
                        VpnController.videoQualityStatus.value = "Низкая скорость · ищем резерв"
                        VpnController.qualityUpgradeStatus.value = "searching · automatic 720p"
                        ServerScanner.requestRecoveryWindow()
                        wakeQualityUpgradeTicker()
                        mainHandler.post { tryUpgradeFromFreshReserve() }
                    } else if (secondDownload != null &&
                        secondDownload >= VpnSpeedPolicy.MIN_DOWNLOAD_MBPS) {
                        VpnController.videoQualityStatus.value = "Скорость нестабильна"
                    } else {
                        VpnController.videoQualityStatus.value = "Видео · скорость не измерена"
                    }
                    return@execute
                }
                val first = VpnSpeedTester.measure()
                if (!speedProbeIsCurrent(generation, serverId, serial)) return@execute
                VpnController.videoQualityStatus.value = when {
                    FastConnectPolicy.videoSuitable(youtube.passed, first.downloadMbps) ->
                        "Скорость подтверждена"
                    first.downloadMbps != null && first.downloadMbps < VpnSpeedPolicy.MIN_DOWNLOAD_MBPS ->
                        "Низкая скорость"
                    else -> "Нет замера скорости"
                }
                if (first.verdict != VpnSpeedPolicy.Verdict.PASS) {
                    VpnController.emitEvent("Фоновая квалификация: скорость пока не подтверждена; VPN остаётся подключён")
                    VpnController.speedTestResult.value = VpnSpeedTester.format(first)
                    // Watching 720p primarily depends on download. Do not
                    // switch a good video path for a slow UPLOAD alone.
                    val lowDownload = first.downloadMbps?.let {
                        it < VpnSpeedPolicy.MIN_DOWNLOAD_MBPS
                    } == true
                    if (!lowDownload && first.downloadMbps != null &&
                        first.downloadMbps >= VpnSpeedPolicy.MIN_DOWNLOAD_MBPS) {
                        VpnController.videoQualityStatus.value = "Загрузка для видео подходит"
                    }
                    if (userInitiated && lowDownload) {
                        // One CDN fluctuation is not proof of a slow route.
                        // A user-requested test is allowed on metered networks,
                        // but still sends only two bounded payload samples.
                        val confirmation = VpnSpeedTester.measure()
                        if (!speedProbeIsCurrent(generation, serverId, serial)) return@execute
                        VpnController.speedTestResult.value = VpnSpeedTester.format(confirmation)
                        val downloadStillSlow = confirmation.downloadMbps?.let {
                            it < VpnSpeedPolicy.MIN_DOWNLOAD_MBPS
                        } == true
                        if (downloadStillSlow) {
                            WorkingServerStore.demoteSpeedQuality(this@XrayVpnService, serverId)
                            pendingQualityUpgrade = AutoQualityUpgradePolicy.Pending(
                                serverId,
                                minOf(first.downloadMbps!!, confirmation.downloadMbps!!),
                                minOf(first.uploadMbps ?: 0.0, confirmation.uploadMbps ?: 0.0)
                            )
                            VpnController.videoQualityStatus.value = "Низкая скорость"
                            VpnController.qualityUpgradeStatus.value = "searching · video too slow"
                            VpnController.emitEvent("Видео: две проверки показали скорость ниже цели; ищу качественный резерв")
                            ServerScanner.requestRecoveryWindow()
                            wakeQualityUpgradeTicker()
                            mainHandler.post { tryUpgradeFromFreshReserve() }
                        } else {
                            VpnController.videoQualityStatus.value = "Скорость нестабильна"
                        }
                    } else if (first.verdict == VpnSpeedPolicy.Verdict.SLOW && !userInitiated) {
                        scheduleEarlySpeedProbe(generation, serverId)
                    }
                    return@execute
                }
                val second = VpnSpeedTester.measure()
                if (!speedProbeIsCurrent(generation, serverId, serial)) return@execute
                VpnController.speedTestResult.value = VpnSpeedTester.format(second)
                if (FastConnectPolicy.canCertifyYouTubeReserve(
                        youtubeVerified = youtube.passed,
                        throughputQualified = VpnSpeedPolicy.qualifiesStandby(first, second)
                    )) {
                    val selected = VpnController.activeServer.value ?: return@execute
                    if (selected.id != serverId) return@execute
                    WorkingServerStore.recordSuccess(
                        this@XrayVpnService, selected, measuredConnectMs, measuredHttpsMs,
                        youtubeVerified = true, speedVerified = true,
                        downloadMbps = minOf(first.downloadMbps!!, second.downloadMbps!!),
                        uploadMbps = minOf(first.uploadMbps!!, second.uploadMbps!!)
                    )
                    VpnController.videoQualityStatus.value = "Подтверждено"
                    VpnController.emitEvent("Резерв 720p подтверждён: ${selected.country}, " +
                        "↓${String.format(java.util.Locale.US, "%.2f", minOf(first.downloadMbps!!, second.downloadMbps!!))} " +
                        "↑${String.format(java.util.Locale.US, "%.2f", minOf(first.uploadMbps!!, second.uploadMbps!!))} Мбит/с")
                    ServerScanner.requestRecoveryWindow()
                    wakeQualityUpgradeTicker()
                } else {
                    VpnController.videoQualityStatus.value =
                        if (second.verdict == VpnSpeedPolicy.Verdict.SLOW) "Низкая скорость"
                        else "Скорость не подтверждена повторно"
                    VpnController.emitEvent("Фоновая квалификация резерва: нужны 2×5/1 Мбит/с; соединение не прерываю")
                    if (second.verdict == VpnSpeedPolicy.Verdict.SLOW)
                        scheduleEarlySpeedProbe(generation, serverId)
                }
            } catch (t: Exception) {
                VpnController.emitEvent("Тест качества видео не завершился: ${t.javaClass.simpleName}")
                if (userInitiated && speedProbeIsCurrent(generation, serverId, serial)) {
                    VpnController.videoQualityStatus.value = "Тест не завершён"
                }
            } finally {
                // An old test must never clear the progress indicator or mutex
                // of a newer Xray generation after an automatic handover.
                if (speedProbeSerial.get() == serial && operationGeneration.get() == generation) {
                    if (userInitiated) VpnController.videoManualCheckBusy.value = false
                    if (automaticInitial) VpnController.videoAutoCheckBusy.value = false
                    speedProbeInFlight.set(false)
                }
            }
        }
    }

    private val earlySpeedProbeScheduled = AtomicBoolean(false)
    private fun scheduleEarlySpeedProbe(generation: Long, serverId: String) {
        if (!earlySpeedProbeScheduled.compareAndSet(false, true)) return
        mainHandler.postDelayed({
            earlySpeedProbeScheduled.set(false)
            if (operationGeneration.get() == generation && activeServer?.id == serverId &&
                VpnController.state.value == VpnState.Connected &&
                AppRunController.mayRun(this) && BatteryAwareRuntime.read(this).heavyTestsAllowed) {
                runPeriodicSpeedProbe()
            }
        }, VpnSpeedPolicy.CONFIRM_DELAY_MS)
    }

    private fun refreshVideoStatusForActiveRoute() {
        val current = activeServer
        val proof = current?.let { WorkingServerStore.activeRecord(this, it.id) }
        val valid = current != null && proof != null &&
            FastConnectPolicy.canReuseCertifiedQuality(
                sameConfiguration = current.rawLink == proof.server.rawLink,
                youtubeVerifiedAtMs = proof.youtubeVerifiedAtMs,
                speedVerifiedAtMs = proof.speedVerifiedAtMs,
                nowMs = System.currentTimeMillis()
            )
        VpnController.videoQualityStatus.value =
            if (valid) "Подтверждено ранее" else "Не проверено"
    }

    private fun isPowerSaveActive(): Boolean =
        getSystemService(PowerManager::class.java)?.isPowerSaveMode == true

    private fun runPeriodicSpeedProbe() {
        if (!speedProbeInFlight.compareAndSet(false, true)) return
        val generation = operationGeneration.get()
        val serverId = activeServer?.id
        val testSerial = speedProbeSerial.incrementAndGet()
        if (serverId == null) {
            speedProbeInFlight.set(false)
            return
        }
        ResourceGovernor.workerExecutor.execute {
            var confirmationQueued = false
            try {
                val first = VpnSpeedTester.measure()
                if (!speedProbeIsCurrent(generation, serverId, testSerial)) return@execute
                VpnController.speedTestResult.value = VpnSpeedTester.format(first)
                VpnController.emitEvent("Speed (эко-проверка): ${VpnSpeedTester.format(first)}")
                if (first.verdict == VpnSpeedPolicy.Verdict.PASS) {
                    // Once a node is marked slow, ONE good sample is not enough
                    // to cancel the search; require two independent recoveries.
                    if (pendingQualityUpgrade?.serverId == serverId) {
                        confirmationQueued = true
                        mainHandler.postDelayed({
                            if (speedProbeIsCurrent(generation, serverId, testSerial)) {
                                ResourceGovernor.workerExecutor.execute confirmHealthy@{
                                    try {
                                        val second = VpnSpeedTester.measure()
                                        if (!speedProbeIsCurrent(generation, serverId, testSerial)) return@confirmHealthy
                                        if (second.verdict == VpnSpeedPolicy.Verdict.PASS) {
                                            pendingQualityUpgrade = null
                                            VpnController.qualityUpgradeStatus.value = "inactive · current speed recovered"
                                            VpnController.emitEvent("Speed: два замера подтвердили восстановление скорости; замена не нужна")
                                        }
                                    } finally {
                                        speedProbeInFlight.set(false)
                                    }
                                }
                            } else speedProbeInFlight.set(false)
                        }, VpnSpeedPolicy.CONFIRM_DELAY_MS)
                    }
                    return@execute
                }
                if (first.verdict != VpnSpeedPolicy.Verdict.SLOW) return@execute

                // Avoid switching on one CDN slowdown or simultaneous user download.
                // The delayed confirmation uses at most one extra small transfer.
                confirmationQueued = true
                mainHandler.postDelayed({
                    if (speedProbeIsCurrent(generation, serverId, testSerial)) {
                        ResourceGovernor.workerExecutor.execute confirm@{
                            try {
                                val second = VpnSpeedTester.measure()
                                if (!speedProbeIsCurrent(generation, serverId, testSerial)) return@confirm
                                VpnController.speedTestResult.value = VpnSpeedTester.format(second)
                                VpnController.emitEvent("Speed подтверждение: ${VpnSpeedTester.format(second)}")
                                if (VpnSpeedPolicy.shouldFailover(first.verdict, second.verdict)) {
                                    // Keep the tunnel alive but demote measured-slow nodes
                                    // from the STRICT полного резерва quality tier, so the scanner fills
                                    // the empty slot without tearing down the video session.
                                    WorkingServerStore.demoteSpeedQuality(this@XrayVpnService, serverId)
                                    pendingQualityUpgrade = AutoQualityUpgradePolicy.Pending(
                                        serverId, minOf(first.downloadMbps ?: Double.POSITIVE_INFINITY,
                                            second.downloadMbps ?: Double.POSITIVE_INFINITY),
                                        minOf(first.uploadMbps ?: Double.POSITIVE_INFINITY,
                                            second.uploadMbps ?: Double.POSITIVE_INFINITY)
                                    )
                                    ServerScanner.requestRecoveryWindow()
                                    wakeQualityUpgradeTicker()
                                    VpnController.qualityUpgradeStatus.value = "searching · confirmed slow"
                                    VpnController.emitEvent("Speed: подтверждена низкая скорость; " +
                                        "VPN остаётся включённым, поиск более быстрого резерва продолжается")
                                    mainHandler.post { tryUpgradeFromFreshReserve() }
                                }
                            } finally {
                                speedProbeInFlight.set(false)
                            }
                        }
                    } else speedProbeInFlight.set(false)
                }, VpnSpeedPolicy.CONFIRM_DELAY_MS)
            } finally {
                if (!confirmationQueued) speedProbeInFlight.set(false)
            }
        }
    }

    private fun speedProbeIsCurrent(generation: Long, serverId: String, serial: Long): Boolean =
        speedProbeSerial.get() == serial && operationGeneration.get() == generation &&
            activeServer?.id == serverId && VpnController.state.value == VpnState.Connected &&
            pfd != null && AppRunController.mayRun(this)

    private val networkLock = Any()
    private val underlyingNetworks = LinkedHashSet<Network>()
    private var connectivityManager: ConnectivityManager? = null
    private var networkCallbackRegistered = false
    private var sawInitialUnderlyingNetwork = false

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            val first = synchronized(networkLock) {
                underlyingNetworks += network
                val wasFirst = !sawInitialUnderlyingNetwork
                sawInitialUnderlyingNetwork = true
                wasFirst
            }
            val outageStartedAt = noUnderlyingNetworkSinceMs.getAndSet(0L)
            publishUnderlyingNetworks()
            // Notify the scanner immediately; otherwise a sleeping catalogue
            // loop may wait minutes after a Wi-Fi/mobile handover.
            ServerScanner.request()
            if (outageStartedAt > 0L) {
                val outageSeconds = ((System.currentTimeMillis() - outageStartedAt) / 1_000L).coerceAtLeast(0L)
                VpnController.emitEvent("Guardian: физическая сеть вернулась после ${outageSeconds}с")
            }

            val state = VpnController.state.value
            if (
                VpnController.autoRecoveryEnabled &&
                state == VpnState.Connecting &&
                pfd != null
            ) {
                recoveryRetrySerial.incrementAndGet()
                VpnController.emitEvent("Guardian: физическая сеть появилась, восстанавливаю текущий туннель")
                if (recoveryInProgress.get()) {
                    VpnController.emitEvent("Guardian: recovery уже выполняется на новой физической сети")
                } else if (!activeConfig.isNullOrBlank()) {
                    scheduleHandoverReload(allowConnecting = true)
                } else {
                    scheduleAutomaticRecovery("физическая сеть снова доступна", qualityOnly = false)
                }
            } else if (!first && state == VpnState.Connected) {
                scheduleHandoverReload()
            }
        }

        override fun onLost(network: Network) {
            val noNetworksLeft = synchronized(networkLock) {
                underlyingNetworks -= network
                underlyingNetworks.isEmpty()
            }
            publishUnderlyingNetworks()
            ServerScanner.request()

            if (noNetworksLeft && pfd != null) {
                watchdogSerial.incrementAndGet()
                watchdogFailures.set(0)
                watchdogHighLatency.set(0)
                noUnderlyingNetworkSinceMs.compareAndSet(0L, System.currentTimeMillis())
                if (
                    VpnController.state.value == VpnState.Connected ||
                    VpnController.state.value == VpnState.Validating
                ) {
                    VpnController.state.value = VpnState.Connecting
                }
                showForeground("Ожидание физической сети…")
                VpnController.emitEvent(
                    "Guardian: физическая сеть потеряна; проверки и перебор серверов приостановлены до появления сети"
                )
                return
            }

            if (VpnController.state.value == VpnState.Connected) {
                scheduleHandoverReload()
            }
        }

        override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
            if (networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)) {
                synchronized(networkLock) { underlyingNetworks += network }
                noUnderlyingNetworkSinceMs.set(0L)
                publishUnderlyingNetworks()
                if (Build.VERSION.SDK_INT >= 29) {
                    val signal = networkCapabilities.signalStrength
                    if (signal != Int.MIN_VALUE && signal <= WEAK_SIGNAL_DBM) {
                        requestImmediateWatchdog("слабый сигнал ${signal}dBm")
                    }
                }
            }
        }
    }

    /** When packages appear while connected, refresh the Android UID routing rules. */
    private val packageChangedReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (VpnController.state.value != VpnState.Connected &&
                VpnController.state.value !is VpnState.Blocked) return
            val changedPackage = intent.data?.schemeSpecificPart ?: return
            val settings = AppRoutingStore(this@XrayVpnService).load()
            // Installing an unrelated app doesn't change the default full-tunnel rule.
            // Avoid interrupting Xray unnecessarily during bulk package updates.
            val affectsPolicy = changedPackage in settings.directPackages() ||
                changedPackage in settings.included ||
                changedPackage in settings.forceVpn
            if (!affectsPolicy) return
            // Coalesce bursts of package updates to avoid repeatedly stopping Xray.
            mainHandler.removeCallbacks(refreshAppRoutes)
            mainHandler.postDelayed(refreshAppRoutes, 1_500L)
        }
    }
    private val refreshAppRoutes = Runnable {
        if (VpnController.state.value == VpnState.Connected ||
            VpnController.state.value is VpnState.Blocked) {
            startService(Intent(this, XrayVpnService::class.java)
                .setAction(ACTION_UPDATE_APP_ROUTING))
        }
    }

    override fun onCreate() {
        super.onCreate()
        liveService = java.lang.ref.WeakReference(this)

        // Service state must not depend on the Activity/ViewModel being alive.
        // Reload persisted safety settings when Android recreates this foreground
        // service in a fresh process.
        getSharedPreferences(ServerStore.SETTINGS_PREFS, android.content.Context.MODE_PRIVATE).let { prefs ->
            VpnController.killSwitchEnabled = prefs.getBoolean("kill_switch", true)
            VpnController.autoRecoveryEnabled = prefs.getBoolean("auto_recovery", true)
        }

        // An OEM may recreate a sticky service after the user dismissed its task.
        // Do not even start health checks/network callbacks for a closed task.
        if (!AppRunController.mayRun(this) || AppRunController.shutdownPending(this)) {
            VpnController.autoRecoveryEnabled = false
            return
        }
        ServerScanner.acquire(this, this)
        registerNetworkMonitor()
        val packageEvents = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(packageChangedReceiver, packageEvents, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(packageChangedReceiver, packageEvents)
        }
        periodicTasks.start(
            watchdogRunnable to BatteryAwarePolicy.watchdogIntervalMs(isScreenInteractive()),
            trafficTicker to BatteryAwarePolicy.trafficIntervalMs(isScreenInteractive(), uiVisible),
            speedTicker to BatteryAwarePolicy.HEAVY_TEST_INTERVAL_MS,
            qualityUpgradeTicker to BatteryAwarePolicy.DISCOVERY_PAUSE_MS,
            securityTicker to 8_000L
        )
    }

    private fun invalidateAsyncWorkForCommand(resetRetryCount: Boolean = true) {
        pendingQualityUpgrade = null
        speedTriggerMbps = null
        VpnController.qualityUpgradeStatus.value = "inactive"
        lastQualityUpgradeAttemptAtMs.set(0L)
        speedProbeSerial.incrementAndGet()
        speedProbeInFlight.set(false)
        VpnController.videoAutoCheckBusy.value = false
        recoverySerial.incrementAndGet()
        recoveryRetrySerial.incrementAndGet()
        watchdogSerial.incrementAndGet()
        handoverSerial.incrementAndGet()
        watchdogFailures.set(0)
        watchdogHighLatency.set(0)
        if (resetRetryCount) recoveryRetryCount.set(0)
    }

    /**
     * Native StopLoop may block inside gomobile. Never execute it on Android's main
     * service thread. The generation guard prevents an old queued stop from killing
     * a newer Xray instance started after this command.
     */
    private fun stopCoreForGeneration(generation: Long) {
        val stop = Runnable {
            if (operationGeneration.get() == generation) {
                XrayCore.stop()
            }
        }
        if (Looper.myLooper() == Looper.getMainLooper()) {
            ResourceGovernor.workerExecutor.execute(stop)
        } else {
            stop.run()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Reject queued prechecks / stale START requests while the dismissed task
        // is being torn down, even if a new Activity has already been opened.
        if (AppRunController.shutdownPending(this) &&
            intent?.action != ACTION_STOP &&
            intent?.action != ACTION_STOP_FROM_NOTIFICATION &&
            intent?.action != ACTION_STOP_FROM_TASK) {
            invalidateAsyncWorkForCommand()
            val generation = operationGeneration.incrementAndGet()
            stopVpn(intentional = true, generation = generation)
            return START_NOT_STICKY
        }
        // Safety net when the foreground service stays alive after task removal.
        taskMonitor.start()
        if (!AppRunController.mayRun(this) &&
            intent?.action != ACTION_STOP &&
            intent?.action != ACTION_STOP_FROM_NOTIFICATION &&
            intent?.action != ACTION_STOP_FROM_TASK) {
            invalidateAsyncWorkForCommand()
            clearRecoverableSession()
            stopSelfResult(startId)
            return START_NOT_STICKY
        }
        if (intent == null) {
            // START_STICKY restart after process/service reclamation. Restore only a
            // previously active session and only while VPN permission is still
            // granted. Server secrets remain in the existing private server cache.
            if (restorePersistedSession()) {
                return START_STICKY
            }

            invalidateAsyncWorkForCommand()
            val generation = operationGeneration.incrementAndGet()
            synchronized(operationLock) {
                stopCoreForGeneration(generation)
                closeTun()
                VpnController.state.value = VpnState.Idle
                foregroundActive = false
                clearTrafficRate()
                ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            }
            stopSelfResult(startId)
            return START_NOT_STICKY
        }

        when (intent.action) {
            ACTION_RECONCILE_STATE -> {
                // Never display a synthetic Connected state: a real TUN and an active
                // server must already exist, otherwise restore the session explicitly.
                if (pfd != null && activeServer != null) {
                    val server = activeServer!!
                    VpnController.activeServer.value = server
                    if (VpnController.state.value == VpnState.Idle ||
                        VpnController.state.value == VpnState.Connecting) {
                        // The process/UI lost its state; do not claim Connected until
                        // a fresh data-path validation confirms the live Xray tunnel.
                        VpnController.validatingServerId = server.id
                        VpnController.state.value = VpnState.Validating
                        val generation = operationGeneration.get()
                        ResourceGovernor.workerExecutor.execute {
                            validateRestoredSession(server, generation)
                        }
                    }
                } else if (!restorePersistedSession()) {
                    VpnController.activeServer.value = null
                    VpnController.state.value = VpnState.Idle
                    stopSelfResult(startId)
                }
            }
            ACTION_STOP, ACTION_STOP_FROM_NOTIFICATION, ACTION_STOP_FROM_TASK -> {
                VpnController.speedTestResult.value = null
                // Only an explicit notification action must also cancel ViewModel
                // prechecks/reconnect. Internal ACTION_STOP is used during normal
                // candidate switching and must not cancel the new connection.
                if (intent.action == ACTION_STOP_FROM_NOTIFICATION ||
                    intent.action == ACTION_STOP_FROM_TASK) {
                    VpnController.stopRequestSerial.value = VpnController.stopRequestSerial.value + 1L
                }
                clearTrafficRate()
                // Invalidate every pending START/recovery/watchdog/handover first.
                invalidateAsyncWorkForCommand()
                val generation = operationGeneration.incrementAndGet()
                // Publish Idle only after closeTun() inside stopVpn(), not when
                // the Activity first begins shutting down.
                stopVpn(intentional = true, generation = generation)
            }
            ACTION_CHECK_OPENAI_TLS -> {
                scheduleOpenAiTlsCheck()
            }
            ACTION_CERTIFY_QUALITY -> {
                val serverId = intent.getStringExtra(EXTRA_SERVER_ID).orEmpty()
                certifyActiveQuality(
                    serverId,
                    intent.getIntExtra(EXTRA_QUALITY_CONNECT_MS, 0),
                    intent.getIntExtra(EXTRA_QUALITY_HTTPS_MS, 0),
                    automaticInitial = intent.getBooleanExtra(EXTRA_AUTO_VIDEO_CHECK, false)
                )
            }
            ACTION_CHECK_VIDEO_NOW -> {
                // The user explicitly requested a bounded throughput test.
                // Automatic/background probes remain disabled on metered networks.
                val selected = activeServer
                if (selected != null && pfd != null && VpnController.state.value == VpnState.Connected &&
                    !VpnController.videoManualCheckBusy.value) {
                    val record = WorkingServerStore.record(this, selected.id)
                        ?.takeIf { it.server.rawLink == selected.rawLink }
                    val rtt = record?.effectivePingMs()?.takeIf { it > 0 }
                        ?: selected.ping.takeIf { it > 0 } ?: 1
                    val https = record?.ewmaHttpsMs?.toInt()?.takeIf { it > 0 } ?: 1
                    certifyActiveQuality(selected.id, rtt, https, userInitiated = true)
                }
            }
            ACTION_START -> {
                VpnController.speedTestResult.value = null
                invalidateAsyncWorkForCommand()
                val config = intent.getStringExtra(EXTRA_CONFIG)
                if (config.isNullOrBlank()) {
                    operationGeneration.incrementAndGet()
                    fail("Нет конфигурации", null)
                } else {
                    val generation = operationGeneration.incrementAndGet()
                    startVpn(
                        config = config,
                        rawLink = intent.getStringExtra(EXTRA_RAW_LINK),
                        host = intent.getStringExtra(EXTRA_HOST),
                        server = serverFromIntent(intent),
                        generation = generation
                    )
                }
            }
            ACTION_UPDATE_APP_ROUTING -> {
                when (VpnController.state.value) {
                    VpnState.Connected -> {
                        val config = activeConfig
                        if (config != null && activeServer != null) {
                            invalidateAsyncWorkForCommand()
                            val generation = operationGeneration.incrementAndGet()
                            startVpn(
                                config = config,
                                rawLink = activeRawLink,
                                host = activeHost,
                                server = activeServer,
                                generation = generation,
                                serviceOwnsValidation = true,
                                recreateTun = true
                            )
                        }
                    }
                    is VpnState.Blocked -> {
                        invalidateAsyncWorkForCommand()
                        val generation = operationGeneration.incrementAndGet()
                        ResourceGovernor.workerExecutor.execute {
                            synchronized(operationLock) {
                                if (operationGeneration.get() == generation) {
                                    runCatching {
                                        val newPfd = establishTun(blocked = true)
                                        val oldPfd = pfd
                                        pfd = newPfd
                                        runCatching { oldPfd?.close() }
                                    }.onFailure {
                                        // Keep the previous blocked TUN if rebuilding failed.
                                        VpnController.emitEvent("Фильтр приложений: не удалось обновить Kill Switch: ${it.message}")
                                    }
                                }
                            }
                        }
                    }
                    else -> { /* The establishing TUN will read the latest preferences. */ }
                }
            }
            ACTION_BLOCK -> {
                invalidateAsyncWorkForCommand()
                val generation = operationGeneration.incrementAndGet()
                fail(
                    intent.getStringExtra(EXTRA_ERROR) ?: "Рабочий сервер не найден",
                    generation
                )
            }
        }
        return when (intent.action) {
            ACTION_START, ACTION_UPDATE_APP_ROUTING, ACTION_CERTIFY_QUALITY,
            ACTION_CHECK_VIDEO_NOW, ACTION_CHECK_OPENAI_TLS -> START_STICKY
            ACTION_RECONCILE_STATE -> if (pfd != null) START_STICKY else START_NOT_STICKY
            ACTION_BLOCK -> if (VpnController.killSwitchEnabled) START_STICKY else START_NOT_STICKY
            else -> START_NOT_STICKY
        }
    }

    private fun startVpn(
        config: String,
        rawLink: String?,
        host: String?,
        server: Server?,
        generation: Long,
        serviceOwnsValidation: Boolean = false,
        recreateTun: Boolean = false
    ) {
        // Refuse a quarantined server BEFORE stopping the old Xray controller or
        // creating a TUN. The dialog, not an automatic recovery, owns consent.
        if (server != null && TlsRiskStore.isRisky(this, server.id) &&
            !TlsRiskStore.isExplicitlyApproved(server.id)) {
            VpnController.riskyCandidate.value = server
            VpnController.emitEvent("TLS риск: этот сервер доступен только по отдельному согласию")
            return
        }
        try {
            showForeground("Подключение…")
        } catch (t: Throwable) {
            fail("Не удалось запустить foreground service: ${t.message ?: t.javaClass.simpleName}", generation)
            return
        }
        VpnController.state.value = VpnState.Connecting

        ResourceGovernor.workerExecutor.execute start@{
            var validateInService = false
            synchronized(operationLock) {
                if (operationGeneration.get() != generation) return@start

                try {
                    // Failover/reconnect changes only the Xray core. Recreating Android's
                    // VPN interface for every candidate tears down the OS VPN network and
                    // makes apps observe a needless connectivity flap. Keep one TUN fd for
                    // the whole VPN session and reuse it while reloading Xray.
                    XrayCore.stop()
                    if (recreateTun) {
                        // Establish the replacement before closing the old TUN, so the
                        // application routes are not deliberately unprotected in between.
                        val newPfd = establishTun()
                        val oldPfd = pfd
                        pfd = newPfd
                        runCatching { oldPfd?.close() }
                    }
                    val activePfd = pfd ?: establishTun().also { pfd = it }

                    if (operationGeneration.get() != generation) {
                        XrayCore.stop()
                        return@start
                    }

                    // AUTO only: embed up to three separately qualified outbounds into ONE
                    // native core. New flows can fail over through its observer
                    // without stopLoop/startLoop or recreating Android's TUN.
                    val autoMode = getSharedPreferences("sc_settings", MODE_PRIVATE)
                        .getString("connection_mode_v1", "AUTO") == ConnectionMode.AUTO.name
                    val riskActive = server != null && TlsRiskStore.isRisky(this@XrayVpnService, server.id)
                    if (riskActive && !TlsRiskStore.isExplicitlyApproved(server!!.id)) {
                        throw SecurityException("Сервер с ошибкой TLS запрещён без согласия пользователя")
                    }
                    // On battery / mobile data run only ONE native Xray route.
                    // Service-level recovery retains the saved server history,
                    // but native observatory and three additional outbound
                    // health probes stay off until charging + unmetered Wi-Fi.
                    val cheapBackground = BatteryAwareRuntime.read(this@XrayVpnService).heavyTestsAllowed
                    val readyHot = if (autoMode && !riskActive && server != null && cheapBackground) {
                        EmbeddedWarmRoutes.select(server, WorkingServerStore.activeServers(this@XrayVpnService))
                            .filter { TlsRiskStore.eligibleForAutomaticUse(this@XrayVpnService, it.id) &&
                                XrayConfigBuilder.buildProbe(it) != null }
                    } else emptyList()
                    // Source may itself be the previously enriched config
                    // (service restart / routing change). MANUAL must never
                    // accidentally inherit automatic balancer routing.
                    val singleConfig = EmbeddedWarmRoutes.singleRoute(config)
                    val runningConfig = if (readyHot.isNotEmpty())
                        EmbeddedWarmRoutes.augment(singleConfig, readyHot) else singleConfig
                    val startedConfig = if (runningConfig != singleConfig) {
                        try {
                            XrayCore.start(runningConfig, activePfd.fd, this@XrayVpnService, generation)
                            runningConfig
                        } catch (t: Throwable) {
                            // A new Xray routing feature must NEVER disable an
                            // otherwise supported, working single-node VPN.
                            XrayCore.stop()
                            VpnController.emitEvent("Xray: встроенный резерв не поддержан ядром; " +
                                "перехожу к обычному VPN: ${t.javaClass.simpleName}")
                            XrayCore.start(singleConfig, activePfd.fd, this@XrayVpnService, generation)
                            singleConfig
                        }
                    } else {
                        XrayCore.start(singleConfig, activePfd.fd, this@XrayVpnService, generation)
                        singleConfig
                    }
                    val embedded = startedConfig.contains(EmbeddedWarmRoutes.BALANCER_TAG)
                    if (embedded) {
                        EmbeddedWarmRoutes.activated(startedConfig, readyHot)
                        VpnController.emitEvent("Xray: настроены резервные маршруты; " +
                            "проверка раз в ${EmbeddedWarmRoutes.OBSERVE_INTERVAL_SECONDS}с на зарядке и Wi-Fi")
                    } else EmbeddedWarmRoutes.clear()
                    activeConfig = startedConfig
                    activeRawLink = rawLink
                    activeHost = host
                    activeServer = server
                    server?.let(::persistRecoverableSession)

                    // A native shutdown/status callback may have failed the connection during start.
                    // Never move to validation after that callback has already changed state.
                    if (VpnController.state.value != VpnState.Connecting) {
                        if (operationGeneration.get() == generation) {
                            XrayCore.stop()
                            closeTun()
                        }
                        return@start
                    }

                    // STOP may arrive while native start is in progress. Because XrayCore.start()
                    // is synchronized, the stop waits for it and this guard closes the just-started core.
                    if (operationGeneration.get() != generation) {
                        XrayCore.stop()
                        closeTun()
                        VpnController.state.value = VpnState.Idle
                        return@start
                    }

                    // Xray is alive, but "process started" is not sufficient evidence that
                    // the selected outbound can actually move Internet traffic. MainViewModel
                    // will run a real data-path health-check through the local SOCKS inbound.
                    VpnController.validatingServerId = server?.id
                    VpnController.state.value = VpnState.Validating
                    showForeground("Проверка трафика…")
                    validateInService = serviceOwnsValidation && server != null
                } catch (t: Throwable) {
                    if (operationGeneration.get() == generation) {
                        val detail = t.message ?: t.javaClass.simpleName
                        if (
                            serviceOwnsValidation &&
                            VpnController.autoRecoveryEnabled &&
                            pfd != null
                        ) {
                            VpnController.state.value = VpnState.Connecting
                            VpnController.emitEvent(
                                "Guardian: Xray не восстановился после перезапуска ($detail); запускаю failover"
                            )
                            scheduleAutomaticRecovery(
                                reason = "ошибка Xray после перезапуска: $detail",
                                qualityOnly = false
                            )
                        } else {
                            fail(detail, generation)
                        }
                    } else {
                        XrayCore.stop()
                        closeTun()
                    }
                }
            }

            if (validateInService && server != null && operationGeneration.get() == generation) {
                validateRestoredSession(server, generation)
            }
        }
    }

    /** Apply the same app allow/deny rules to live VPN and Kill Switch TUNs. */
    private fun establishTun(blocked: Boolean = false): ParcelFileDescriptor {
        val builder = Builder()
            .setSession(if (blocked) "SecureConnect KillSwitch" else "SecureConnect")
            .setMtu(1280)
            .setBlocking(true)
            .addAddress("10.10.14.1", 30)
            .addAddress("fd00:1:1::1", 126)
            .addRoute("0.0.0.0", 0)
            .addRoute("::", 0)

        if (!blocked) {
            builder.addDnsServer("1.1.1.1")
                .addDnsServer("9.9.9.9")
                .addDnsServer("8.8.8.8")
        }
        // Package visibility is complete (QUERY_ALL_PACKAGES). The policy is
        // resolved against the real installed set before touching the builder.
        val routingStore = AppRoutingStore(this)
        val routingSnapshot = routingStore.load()
        val installedPackageIds = routingStore.installedPackageNames()
        // Android 16/OEM package visibility can under-enumerate installed apps in a
        // service. For the exclusion mode, ask VpnService.Builder directly: it
        // validates each package and throws NameNotFoundException if absent.
        val candidates = if (routingSnapshot.mode == AppVpnMode.EXCLUDE_SELECTED)
            installedPackageIds + routingSnapshot.directPackages() + RussianApps.defaultDirectPackages + packageName
        else installedPackageIds
        val routingRule = routingSnapshot.forInstalledPackages(candidates, packageName)
        var appliedCount = 0
        val appliedExcluded = linkedSetOf<String>()
        when (routingRule) {
            is AppRoutingRule.DenyVpn -> {
                for (pkg in routingRule.packages) {
                    try {
                        builder.addDisallowedApplication(pkg)
                        appliedCount++
                        appliedExcluded.add(pkg)
                    } catch (_: android.content.pm.PackageManager.NameNotFoundException) {
                        // The application was uninstalled after package enumeration.
                    }
                }
            }
            is AppRoutingRule.AllowVpn -> {
                for (pkg in routingRule.packages) {
                    try {
                        builder.addAllowedApplication(pkg)
                        appliedCount++
                    } catch (_: android.content.pm.PackageManager.NameNotFoundException) {
                        // The application was uninstalled after package enumeration.
                    }
                }
                check(appliedCount > 0) {
                    "Выбранные приложения были удалены; выберите другое приложение для VPN"
                }
            }
        }
        // Keep Android's metered-by-default VPN policy (API 29+).
        // Explicit setMetered(false) falsely advertises unlimited data on LTE.
        val established = builder.establish()
            ?: throw IllegalStateException("Система не создала VPN-интерфейс (нет разрешения?)")
        // Include both package-manager visibility and Builder-accepted entries in
        // the denominator. Never hide a failed rule behind a misleading 0/0 count.
        val installedRussian = installedPackageIds.intersect(RussianApps.defaultDirectPackages) +
            appliedExcluded.intersect(RussianApps.defaultDirectPackages)
        // Report Android Builder-accepted package rules, not merely saved preferences.
        val excludedRussian = when (routingRule) {
            is AppRoutingRule.DenyVpn -> appliedExcluded.intersect(installedRussian).size
            is AppRoutingRule.AllowVpn -> installedRussian.size -
                installedRussian.count { it in routingRule.packages }
        }
        VpnController.appliedAppRouting.value =
            "${routingSnapshot.mode}, applied=$appliedCount, russianDirect=$excludedRussian/${installedRussian.size}, " +
                "catalog=${RussianApps.defaultDirectPackages.size}, blockedTun=$blocked"
        VpnController.emitEvent("Фильтр приложений применён: ${VpnController.appliedAppRouting.value}")
        return established
    }

    /** intentional = пользователь нажал «Отключить»; иначе Kill Switch может удержать TUN. */

    /** Native callback: the active Xray controller stopped outside our explicit STOP path. */
    internal fun onCoreCallback(generation: Long, method: String, code: Int, message: String?) {
        if (method != "shutdown" && !(method == "onemitstatus" && message?.contains("core stopped", ignoreCase = true) == true)) {
            return
        }

        // Native callbacks can arrive synchronously from startLoop()/stopLoop().
        // Never wait for operationLock on the gomobile callback thread: the caller
        // may itself hold that lock while waiting for the native method to return.
        if (operationGeneration.get() != generation) return
        val detail = message?.takeIf { it.isNotBlank() } ?: "Core shutdown (code=$code)"
        ResourceGovernor.workerExecutor.execute callback@{
            synchronized(operationLock) {
                if (operationGeneration.get() != generation) return@synchronized
                if (recoveryInProgress.get()) return@synchronized
                val state = VpnController.state.value
                if (state == VpnState.Connected && VpnController.autoRecoveryEnabled && pfd != null) {
                    VpnController.emitEvent("Guardian: Xray остановился, запускаю автоматический failover")
                    VpnController.state.value = VpnState.Connecting
                    scheduleAutomaticRecovery("Xray остановился: $detail", qualityOnly = false)
                } else if (state == VpnState.Connected || state == VpnState.Connecting || state == VpnState.Validating) {
                    fail("Xray остановился: $detail", generation)
                }
            }
        }
    }

    /** One bounded trust/hostname probe per new connected core; never a 5-minute poll. */
    private fun scheduleOpenAiTlsCheck() {
        if (pfd == null || VpnController.state.value != VpnState.Connected ||
            !AppRunController.mayRun(this)) return
        if (!openAiTlsInFlight.compareAndSet(false, true)) {
            // The previous TLS handshake may still finish after a route switch.
            // Check the new generation once instead of silently losing this request.
            openAiTlsPending.set(true)
            return
        }
        val generation = operationGeneration.get()
        VpnController.openAiTlsStatus.value = "TLS ChatGPT: проверяю защищённое соединение…"
        val serverId = activeServer?.id
        ResourceGovernor.workerExecutor.execute {
            try {
                val outcome = OpenAiTlsProbe.checkActive()
                if (operationGeneration.get() != generation || pfd == null ||
                    VpnController.state.value != VpnState.Connected || activeServer?.id != serverId) return@execute
                VpnController.openAiTlsStatus.value = outcome.status
                // Diagnose the probe result immediately; no manual refresh needed.
                mainHandler.post { inspectSecurity() }
                when (outcome.verdict) {
                    OpenAiTlsPolicy.Verdict.VERIFIED -> {
                        // SOCKS tests use the selected primary. A passing TLS
                        // test clears only that primary, not the backup pool.
                        if (serverId != null)
                            TlsRiskStore.clearOnVerified(this@XrayVpnService, serverId)
                        VpnController.emitEvent("ChatGPT TLS: цепочка и имя хоста проверены (pinning отдельно)")
                    }
                    OpenAiTlsPolicy.Verdict.CERTIFICATE_ERROR -> {
                        // Active TLS checks use health-socks, pinned to the
                        // primary outbound even when warm alternates are present.
                        // A certificate failure cannot implicate untested backups.
                        listOfNotNull(serverId).forEach {
                            TlsRiskStore.markRisk(this@XrayVpnService, it)
                        }
                        VpnController.emitEvent("Безопасность: возможная подмена HTTPS через VPN. " +
                            "Маршруты изолированы. Проверка сертификатов остаётся включённой")
                        ServerScanner.requestRecoveryWindow()
                        if (pfd != null) {
                            // Never wait for a manual certificate-risk approval:
                            // quarantine the route, stop Xray but retain the blocking
                            // TUN, then automatically try ONLY eligible reserves.
                            VpnController.riskyCandidate.value = null
                            mainHandler.post {
                                if (operationGeneration.get() == generation && pfd != null &&
                                    VpnController.state.value == VpnState.Connected) {
                                    val stopGeneration = operationGeneration.incrementAndGet()
                                    fail("Ошибка сертификата TLS; ищу безопасный резерв", stopGeneration)
                                    inspectSecurity()
                                    if (VpnController.state.value == VpnState.Blocked) {
                                        scheduleAutomaticRecovery("TLS-сертификат не подтверждён", qualityOnly = false)
                                    }
                                }
                            }
                        }
                    }
                    OpenAiTlsPolicy.Verdict.UNAVAILABLE ->
                        VpnController.emitEvent("ChatGPT TLS: результат неопределённый; " +
                            "ошибка сети не приравнивается к подмене сертификата")
                }
            } finally {
                openAiTlsInFlight.set(false)
                if (openAiTlsPending.getAndSet(false)) scheduleOpenAiTlsCheck()
            }
        }
    }

    private fun stopVpn(intentional: Boolean, generation: Long) {
        EmbeddedWarmRoutes.clear()
        VpnController.openAiTlsStatus.value = "TLS ChatGPT: VPN остановлен"

        if (intentional) {
            clearRecoverableSession()
            // An approval never persists after the live tunnel is intentionally stopped.
            // Preserve it only when a TLS-risk dialog is currently pending for one retry.
            if (VpnController.riskyCandidate.value == null) TlsRiskStore.clearApprovals()
        }
        synchronized(operationLock) {
            stopCoreForGeneration(generation)
            activeConfig = null
            activeRawLink = null
            activeHost = null
            activeServer = null
            VpnController.activeServer.value = null
            VpnController.validatingServerId = null
            watchdogFailures.set(0)
            watchdogHighLatency.set(0)
            recoveryRetryCount.set(0)
            recoveryRetrySerial.incrementAndGet()
            if (!intentional && VpnController.killSwitchEnabled && pfd != null) {
                VpnController.state.value = VpnState.Blocked
                VpnController.videoQualityStatus.value = "VPN заблокирован"
                showForeground("Kill Switch: интернет заблокирован")
                mainHandler.post { inspectSecurity() }
                return
            }
            closeTun()
            VpnController.state.value = VpnState.Idle
            foregroundActive = false
            clearTrafficRate()
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            getSystemService(NotificationManager::class.java)?.cancel(NOTIFICATION_ID)
            AppRunController.acknowledgeStopped(this)
            stopSelf()
        }
    }

    private fun fail(message: String, generation: Long?) {
        synchronized(operationLock) {
            if (generation != null && operationGeneration.get() != generation) {
                // A newer START/STOP owns the global core and TUN now. A stale
                // failure must never tear down that newer connection.
                return
            }

            val currentGeneration = operationGeneration.get()
            stopCoreForGeneration(currentGeneration)
            activeConfig = null
            activeRawLink = null
            activeHost = null
            activeServer = null
            VpnController.activeServer.value = null
            VpnController.validatingServerId = null
            if (VpnController.killSwitchEnabled) {
                // Оставляем TUN (если есть) или поднимаем пустой блокирующий VPN.
                if (pfd == null) {
                    runCatching {
                        pfd = establishTun(blocked = true)
                    }
                }
                if (pfd != null) {
                    VpnController.state.value = VpnState.Blocked
                    VpnController.videoQualityStatus.value = "VPN заблокирован"
                    showForeground("Kill Switch: $message")
                    mainHandler.post { inspectSecurity() }
                    return
                }
            }

            closeTun()
            clearRecoverableSession()
            VpnController.state.value = VpnState.Error(message)
            foregroundActive = false
            clearTrafficRate()
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun registerNetworkMonitor() {
        val cm = getSystemService(ConnectivityManager::class.java) ?: return
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
            .build()
        runCatching {
            cm.registerNetworkCallback(request, networkCallback)
            connectivityManager = cm
            networkCallbackRegistered = true
        }
    }

    private fun publishUnderlyingNetworks() {
        val networks = synchronized(networkLock) {
            underlyingNetworks.toTypedArray().takeIf { it.isNotEmpty() }
        }
        // Tell Android which physical networks this VPN is layered on. This keeps
        // connectivity accounting and handovers sane while the TUN itself stays up.
        runCatching { setUnderlyingNetworks(networks) }
    }

    /**
     * Wi-Fi <-> cellular handover: reload only Xray, preserving the existing TUN.
     * Current v2rayNG uses the same architectural pattern because stale sockets and
     * DNS results can otherwise survive a physical-network transition.
     */
    private fun scheduleHandoverReload(allowConnecting: Boolean = false) {
        val initialState = VpnController.state.value
        if (
            initialState != VpnState.Connected &&
            !(allowConnecting && initialState == VpnState.Connecting)
        ) return
        val serial = handoverSerial.incrementAndGet()

        ResourceGovernor.workerExecutor.execute handover@{
            Thread.sleep(450) // debounce onLost/onAvailable bursts
            val stateBeforeReload = VpnController.state.value
            if (
                handoverSerial.get() != serial ||
                (stateBeforeReload != VpnState.Connected &&
                    !(allowConnecting && stateBeforeReload == VpnState.Connecting)) ||
                pfd == null
            ) return@handover

            // Snapshot/build outside operationLock so slow DNS on a newly appeared
            // mobile/Wi-Fi network cannot freeze STOP or a manual server switch.
            val fallbackConfig = activeConfig ?: return@handover
            val rawLink = activeRawLink
            val host = activeHost
            val network = synchronized(networkLock) { underlyingNetworks.firstOrNull() }

            val rebuiltConfig = if (!rawLink.isNullOrBlank() && !host.isNullOrBlank()) {
                val resolved = resolveOnNetwork(network, host, 2_500L)
                XrayConfigBuilder.build(
                    Server(
                        id = "handover",
                        country = "",
                        city = "",
                        flagEmoji = "",
                        protocol = rawLink.substringBefore("://").uppercase(),
                        ping = activeServer?.ping ?: 0,
                        host = host,
                        port = activeServer?.port ?: 0,
                        source = activeServer?.source.orEmpty(),
                        rawLink = rawLink
                    ),
                    resolved
                )
            } else null
            val singleConfig = EmbeddedWarmRoutes.singleRoute(rebuiltConfig ?: fallbackConfig)
            val autoMode = getSharedPreferences("sc_settings", MODE_PRIVATE)
                .getString("connection_mode_v1", "AUTO") == ConnectionMode.AUTO.name
            // On a physical-network handover Xray must restart anyway. Rebuild
            // the warm set from the latest qualified reserve store at that moment,
            // without imposing an extra interruption just to add new standbys.
            val currentServer = activeServer
            val warm = if (autoMode && currentServer != null)
                EmbeddedWarmRoutes.select(currentServer, WorkingServerStore.activeServers(this))
                    .filter { XrayConfigBuilder.buildProbe(it) != null }
                else emptyList()
            val config = if (warm.isEmpty()) singleConfig else EmbeddedWarmRoutes.augment(singleConfig, warm)

            val stateBeforeStart = VpnController.state.value
            if (
                handoverSerial.get() != serial ||
                (stateBeforeStart != VpnState.Connected &&
                    !(allowConnecting && stateBeforeStart == VpnState.Connecting)) ||
                pfd == null
            ) return@handover

            try {
                synchronized(operationLock) {
                    val stateInsideLock = VpnController.state.value
                    if (
                        handoverSerial.get() != serial ||
                        (stateInsideLock != VpnState.Connected &&
                            !(allowConnecting && stateInsideLock == VpnState.Connecting))
                    ) return@synchronized
                    val fd = pfd?.fd ?: return@synchronized

                    // Invalidate callbacks from the old controller before StopLoop()
                    // emits shutdown; keep the existing Android TUN fd.
                    recoverySerial.incrementAndGet()
                    val generation = operationGeneration.incrementAndGet()
                    XrayCore.stop()
                    val launched = if (config != singleConfig) {
                        try {
                            XrayCore.start(config, fd, this@XrayVpnService, generation)
                            config
                        } catch (_: Throwable) {
                            XrayCore.stop()
                            XrayCore.start(singleConfig, fd, this@XrayVpnService, generation)
                            singleConfig
                        }
                    } else {
                        XrayCore.start(singleConfig, fd, this@XrayVpnService, generation)
                        singleConfig
                    }
                    if (launched.contains(EmbeddedWarmRoutes.BALANCER_TAG))
                        EmbeddedWarmRoutes.activated(launched, warm)
                    else EmbeddedWarmRoutes.clear()
                    if (
                        operationGeneration.get() == generation &&
                        handoverSerial.get() == serial &&
                        pfd != null
                    ) {
                        activeConfig = launched
                        VpnController.validatingServerId = null
                        VpnController.state.value = VpnState.Connected
                        refreshVideoStatusForActiveRoute()
                        showForeground("Подключено")
                    }
                }
                requestImmediateWatchdog("смена физической сети")
            } catch (t: Throwable) {
                val message =
                    "Не удалось восстановить VPN после смены сети: ${t.message ?: t.javaClass.simpleName}"
                if (VpnController.autoRecoveryEnabled && pfd != null) {
                    VpnController.state.value = VpnState.Connecting
                    VpnController.emitEvent("Guardian: $message; ищу другой сервер")
                    scheduleAutomaticRecovery(message, qualityOnly = false)
                } else {
                    fail(message, null)
                }
            }
        }
    }

    private fun resolveOnNetwork(network: Network?, host: String, timeoutMs: Long): String? {
        if (host.contains(':') || host.matches(Regex("""\d{1,3}(?:\.\d{1,3}){3}"""))) return host
        val task = ResourceGovernor.dnsExecutor.submit<String?> {
            runCatching {
                val all = if (network != null) network.getAllByName(host) else java.net.InetAddress.getAllByName(host)
                (all.firstOrNull { it is Inet4Address } ?: all.firstOrNull())?.hostAddress
            }.getOrNull()
        }
        return try {
            task.get(timeoutMs, TimeUnit.MILLISECONDS)
        } catch (_: TimeoutException) {
            task.cancel(true)
            null
        } catch (_: Throwable) {
            task.cancel(true)
            null
        }
    }

    private fun serverFromIntent(intent: Intent): Server? {
        val id = intent.getStringExtra(EXTRA_SERVER_ID)?.takeIf { it.isNotBlank() } ?: return null
        val rawLink = intent.getStringExtra(EXTRA_RAW_LINK)?.takeIf { it.isNotBlank() } ?: return null
        val host = intent.getStringExtra(EXTRA_HOST).orEmpty()
        val sourceLabels = ConfigParser.parse(rawLink, intent.getStringExtra(EXTRA_SERVER_SOURCE).orEmpty())
        return Server(
            reportedPingMs = sourceLabels?.reportedPingMs,
            reportedLoadPercent = sourceLabels?.reportedLoadPercent,
            id = id,
            country = intent.getStringExtra(EXTRA_SERVER_COUNTRY).orEmpty(),
            city = intent.getStringExtra(EXTRA_SERVER_CITY).orEmpty(),
            flagEmoji = intent.getStringExtra(EXTRA_SERVER_FLAG).orEmpty(),
            protocol = intent.getStringExtra(EXTRA_SERVER_PROTOCOL)
                ?.takeIf { it.isNotBlank() }
                ?: rawLink.substringBefore("://").uppercase(),
            ping = intent.getIntExtra(EXTRA_SERVER_PING, 0).coerceAtLeast(0),
            host = host,
            port = intent.getIntExtra(EXTRA_SERVER_PORT, 0),
            source = intent.getStringExtra(EXTRA_SERVER_SOURCE).orEmpty(),
            rawLink = rawLink
        )
    }

    private fun requestImmediateWatchdog(reason: String) {
        if (!VpnController.autoRecoveryEnabled || VpnController.state.value != VpnState.Connected) return
        val serial = watchdogSerial.incrementAndGet()
        mainHandler.postDelayed({
            if (
                watchdogSerial.get() == serial &&
                VpnController.state.value == VpnState.Connected &&
                !recoveryInProgress.get()
            ) {
                VpnController.emitEvent("Guardian: проверка канала ($reason)")
                runWatchdogProbe()
            }
        }, 350L)
    }

    private fun runWatchdogProbe() {
        if (!VpnController.autoRecoveryEnabled || recoveryInProgress.get()) return
        if (VpnController.state.value != VpnState.Connected) return

        // Periodic + immediate probes can arrive close together (weak signal,
        // capability changes, retry timer). One in-flight probe is enough; piling
        // several TLS handshakes onto the same radio/Xray core only creates false
        // timeouts and steals both app workers from recovery.
        if (!watchdogProbeInProgress.compareAndSet(false, true)) return

        val generation = operationGeneration.get()
        val serial = watchdogSerial.incrementAndGet()
        val useAlternate = watchdogAlternate
        watchdogAlternate = !watchdogAlternate
        val serverSnapshot = activeServer
        val workingRecord = serverSnapshot?.let { WorkingServerStore.activeRecord(this, it.id) }
        val baselineHttpsMs = workingRecord?.ewmaHttpsMs
            ?: serverSnapshot?.let { WorkingServerStore.record(this, it.id)?.ewmaHttpsMs }
        val ioTimeoutMs = GuardianPolicy.watchdogIoTimeoutMs(baselineHttpsMs)

        ResourceGovernor.workerExecutor.execute {
            try {
                if (
                    operationGeneration.get() != generation ||
                    VpnController.state.value != VpnState.Connected ||
                    recoveryInProgress.get()
                ) {
                    return@execute
                }

                if (!hasUnderlyingInternetNetwork()) {
                    watchdogFailures.set(0)
                    watchdogHighLatency.set(0)
                    VpnController.validatingServerId = null
                    VpnController.state.value = VpnState.Connecting
                    VpnController.emitEvent(
                        "Guardian: физическая сеть отсутствует; health-check отложен без штрафа серверу"
                    )
                    showForeground("Ожидание физической сети…")
                    scheduleRecoveryRetry("watchdog ожидает физическую сеть")
                    return@execute
                }

                val result = XrayHealthChecker.quickCheck(useAlternate, ioTimeoutMs)

                if (
                    watchdogSerial.get() != serial ||
                    operationGeneration.get() != generation ||
                    VpnController.state.value != VpnState.Connected
                ) {
                    return@execute
                }

                if (result.passed) {
                    watchdogFailures.set(0)
                    val connectPing = result.connectMs?.takeIf { it > 0 }
                    val httpsLatency = result.latencyMs?.takeIf { it > 0 }

                    if (connectPing != null) {
                        synchronized(operationLock) {
                            if (
                                watchdogSerial.get() == serial &&
                                operationGeneration.get() == generation &&
                                VpnController.state.value == VpnState.Connected &&
                                pfd != null
                            ) {
                                val updated = activeServer?.copy(ping = connectPing)
                                activeServer = updated
                                if (updated != null) VpnController.activeServer.value = updated
                            } else {
                                return@execute
                            }
                        }
                    }

                    if (connectPing != null && httpsLatency != null) {
                        // Attribute the sample to the server that was actually probed,
                        // even if a handover starts just after the generation check.
                        val current = serverSnapshot?.copy(ping = connectPing)
                        if (current != null && System.currentTimeMillis() -
                            (WorkingServerStore.record(this, current.id)?.lastSuccessAtMs ?: 0L) >= 60_000L) {
                            WorkingServerStore.recordSuccess(this, current, connectPing, httpsLatency)
                        }
                    }

                    val poorQuality = GuardianPolicy.isPoorQualitySample(
                        connectMs = connectPing,
                        httpsMs = httpsLatency,
                        baselineHttpsMs = baselineHttpsMs
                    )
                    if (poorQuality) {
                        val badSamples = watchdogHighLatency.incrementAndGet()
                        if (badSamples >= HIGH_LATENCY_SAMPLES) {
                            watchdogHighLatency.set(0)
                            val now = System.currentTimeMillis()
                            val previous = lastQualityRecoveryAtMs.get()
                            if (
                                now - previous >= QUALITY_RECOVERY_COOLDOWN_MS &&
                                lastQualityRecoveryAtMs.compareAndSet(previous, now)
                            ) {
                                val quality = "RTT=${connectPing ?: "—"}мс HTTPS=${httpsLatency ?: "—"}мс"
                                VpnController.emitEvent(
                                    "Guardian: устойчиво плохое качество ($quality), ищу подтверждённый/≤100мс сервер"
                                )
                                scheduleAutomaticRecovery(
                                    reason = "устойчиво плохое качество $quality",
                                    qualityOnly = true
                                )
                            }
                        }
                    } else {
                        watchdogHighLatency.set(0)
                    }
                    return@execute
                }

                // The underlay can disappear while the blocking TLS probe is in
                // flight. Treat that as a network outage, not as a bad VPN server.
                if (!hasUnderlyingInternetNetwork()) {
                    watchdogFailures.set(0)
                    watchdogHighLatency.set(0)
                    noUnderlyingNetworkSinceMs.compareAndSet(0L, System.currentTimeMillis())
                    VpnController.validatingServerId = null
                    VpnController.state.value = VpnState.Connecting
                    VpnController.emitEvent(
                        "Guardian: физическая сеть пропала во время health-check; сервер не штрафуется"
                    )
                    showForeground("Ожидание физической сети…")
                    scheduleRecoveryRetry("сеть пропала во время watchdog")
                    return@execute
                }

                watchdogHighLatency.set(0)
                val recentlyProven = workingRecord != null
                val failures = watchdogFailures.incrementAndGet()
                val requiredFailures = GuardianPolicy.requiredFailureSamples(
                    stage = result.stage,
                    recentlyProven = recentlyProven
                )
                VpnController.emitEvent(
                    "Guardian: health fail $failures/$requiredFailures " +
                        "(${result.endpoint}:${result.stage} ${result.error ?: ""}; timeout=${ioTimeoutMs}ms)"
                )

                // Pre-verify hot alternatives while the original tunnel still works.
                if (failures == 1) ServerScanner.urgentHotRefresh()

                if (failures < requiredFailures) {
                    mainHandler.postDelayed({
                        if (
                            VpnController.state.value == VpnState.Connected &&
                            !recoveryInProgress.get()
                        ) {
                            runWatchdogProbe()
                        }
                    }, WATCHDOG_RETRY_MS)
                    return@execute
                }

                // Confirm remote failure with another provider. A missing local
                // SOCKS listener is different: Xray itself is gone and recovery is
                // justified immediately.
                if (result.stage != "socks_ready") {
                    val confirmTimeoutMs = (ioTimeoutMs + 1_000).coerceAtMost(6_000)
                    val confirmation = XrayHealthChecker.quickCheck(!useAlternate, confirmTimeoutMs)
                    if (
                        watchdogSerial.get() != serial ||
                        operationGeneration.get() != generation ||
                        VpnController.state.value != VpnState.Connected
                    ) {
                        return@execute
                    }
                    if (confirmation.passed) {
                        watchdogFailures.set(0)
                        confirmation.connectMs?.takeIf { it > 0 }?.let { ping ->
                            synchronized(operationLock) {
                                if (
                                    watchdogSerial.get() != serial ||
                                    operationGeneration.get() != generation ||
                                    VpnController.state.value != VpnState.Connected ||
                                    pfd == null
                                ) return@execute
                                val updated = activeServer?.copy(ping = ping)
                                activeServer = updated
                                if (updated != null) VpnController.activeServer.value = updated
                            }
                        }
                        VpnController.emitEvent(
                            "Guardian: transient failure подтверждён как ложный; " +
                                "${confirmation.endpoint}=OK(${confirmation.latencyMs ?: "—"}мс)"
                        )
                        return@execute
                    }
                    VpnController.emitEvent(
                        "Guardian: failover подтверждён вторым endpoint " +
                            "(${confirmation.endpoint}:${confirmation.stage} ${confirmation.error ?: ""})"
                    )
                }

                watchdogFailures.set(0)
                activeServer?.let { failed ->
                    WorkingServerStore.recordFailure(this@XrayVpnService, failed.id)
                    guardianFailedUntilMs[failed.id] =
                        System.currentTimeMillis() + GUARDIAN_FAILURE_COOLDOWN_MS
                }
                VpnController.validatingServerId = null
                VpnController.state.value = VpnState.Connecting
                scheduleAutomaticRecovery(
                    reason = "туннель не прошёл подтверждённые фоновые HTTPS-проверки",
                    qualityOnly = false
                )
            } finally {
                watchdogProbeInProgress.set(false)
            }
        }
    }

    private fun scheduleAutomaticRecovery(reason: String, qualityOnly: Boolean) {
        if (!VpnController.autoRecoveryEnabled || pfd == null) return
        val manual = getSharedPreferences("sc_settings", MODE_PRIVATE)
            .getString("connection_mode_v1", "AUTO") == ConnectionMode.MANUAL.name
        if (manual) {
            VpnController.emitEvent("Ручной режим: не переключаюсь на другой сервер; $reason")
            if (!qualityOnly) VpnController.state.value = VpnState.Error("Ручной сервер недоступен: $reason")
            return
        }

        // Do not churn through server lists while the phone has no physical
        // network. onAvailable() will wake recovery immediately when Wi-Fi/LTE
        // returns.
        if (!hasUnderlyingInternetNetwork()) {
            VpnController.state.value = VpnState.Connecting
            scheduleRecoveryRetry("ожидание физической сети; причина: $reason")
            return
        }

        if (!recoveryInProgress.compareAndSet(false, true)) return
        // Hard failure: refill candidates immediately even with a filled/stale
        // catalogue; this is an event, not a periodic background scan.
        if (!qualityOnly) ServerScanner.requestRecoveryWindow(force = true)
        val serial = recoverySerial.incrementAndGet()

        ResourceGovernor.workerExecutor.execute {
            try {
                performAutomaticRecovery(reason, qualityOnly, serial)
            } catch (t: Throwable) {
                if (recoverySerial.get() == serial) {
                    val detail = t.message ?: t.javaClass.simpleName
                    VpnController.emitEvent("Guardian: ошибка recovery: $detail")
                    if (!qualityOnly && pfd != null) {
                        // A bad reserve or transient native exception must not tear
                        // down the foreground TUN. Keep the service alive and retry.
                        VpnController.state.value = VpnState.Connecting
                        scheduleRecoveryRetry("ошибка recovery: $detail")
                    }
                }
            } finally {
                recoveryInProgress.set(false)
            }
        }
    }

    /**
     * Service-owned recovery works even when the Activity/ViewModel is not alive.
     * The TUN fd stays up; only Xray outbound is replaced.
     */
    private fun performAutomaticRecovery(reason: String, qualityOnly: Boolean, serial: Long) {
        if (recoverySerial.get() != serial || !VpnController.autoRecoveryEnabled ||
            getSharedPreferences("sc_settings", MODE_PRIVATE).getString("connection_mode_v1", "AUTO") ==
                ConnectionMode.MANUAL.name) return

        val fd = pfd?.fd ?: return
        val previousConfig = activeConfig
        val previousServer = activeServer
        val previousRawLink = activeRawLink
        val previousHost = activeHost

        val speedRecovery = qualityOnly && reason.contains("скорость", ignoreCase = true)
        // A hard failure must not launch two throughput benchmarks and a YouTube
        // page fetch while applications are already offline. These tests were
        // completed when the candidate entered the verified pool.
        val emergencyHandover = !qualityOnly
        val recoveryStartedNs = System.nanoTime()
        val candidates = buildBackgroundCandidates(
            qualityOnly = qualityOnly,
            preferSpeed = speedRecovery
        )
        if (!qualityOnly) VpnController.emitEvent(
            "Guardian: горячий резерв ${HotReserveTracker.readyIds().size}/${HotReservePolicy.TARGET}; " +
                "серверов для восстановления=${candidates.size}")
        if (candidates.isEmpty()) {
            if (qualityOnly) {
                if (recoverySerial.get() == serial) {
                    VpnController.emitEvent("Guardian: лучшего кандидата не найдено, текущий VPN оставлен")
                    VpnController.state.value = VpnState.Connected
                    refreshVideoStatusForActiveRoute()
                }
                return
            }
            if (recoverySerial.get() == serial) {
                // The 100-slot cache can contain only dead configs. Rotate
                // source windows instead of repeatedly retrying the same cache.
                getSharedPreferences(ServerStore.SETTINGS_PREFS, MODE_PRIVATE).edit()
                    .putLong(ServerStore.CATALOGUE_ATTEMPT_KEY, 0L).apply()
                ServerScanner.requestRecoveryWindow(force = true)
                VpnController.state.value = VpnState.Connecting
                scheduleRecoveryRetry("нет резервных кандидатов; причина: $reason")
            }
            return
        }

        VpnController.emitEvent(
            "Guardian: ${if (qualityOnly) "оптимизация" else "failover"}; кандидатов=${candidates.size}"
        )
        val network = synchronized(networkLock) { underlyingNetworks.firstOrNull() }
        val attempted = LinkedHashSet<String>()
        val attemptedRoutes = LinkedHashSet<String>()
        var weakReserveForReplacement: String? = null

        for ((index, candidate) in candidates.take(MAX_BACKGROUND_ATTEMPTS).withIndex()) {
            if (
                recoverySerial.get() != serial ||
                !VpnController.autoRecoveryEnabled ||
                pfd == null ||
                getSharedPreferences("sc_settings", MODE_PRIVATE)
                    .getString("connection_mode_v1", "AUTO") == ConnectionMode.MANUAL.name
            ) return
            val routeKey = GuardianPolicy.routeFingerprint(candidate)
            if (
                candidate.id in attempted ||
                routeKey in attemptedRoutes ||
                candidate.rawLink.isBlank()
            ) continue
            attempted += candidate.id
            attemptedRoutes += routeKey

            // DNS/build happen outside operationLock. Slow resolvers must never
            // block ACTION_STOP/ACTION_START on the service main thread.
            // The fast path is restricted to previously double-speed-tested,
            // YouTube-confirmed, <=100ms servers. Unverified catalog entries
            // must never become an emergency automatic route.
            val previousQualification = WorkingServerStore.activeRecord(this, candidate.id)
            val historicalOnly = emergencyHandover && previousQualification == null &&
                WorkingServerStore.historicalRecoveryRecords(this).any { it.server.id == candidate.id }
            if (emergencyHandover && previousQualification == null && !historicalOnly) continue
            val resolved = resolveOnNetwork(network, candidate.host,
                if (emergencyHandover) FastFailoverPolicy.DNS_BUDGET_MS
                else 2_000L)
            if (recoverySerial.get() != serial) return
            // Full tests remain mandatory before a *quality* switch; avoid
            // their cost on the verified emergency recovery path.
            if (speedRecovery) {
                val pending = pendingQualityUpgrade ?: return
                if (previousQualification == null || !AutoQualityUpgradePolicy.isWorthSwitching(
                        pending, previousQualification.effectivePingMs(),
                        previousQualification.verifiedDownloadMbps, previousQualification.verifiedUploadMbps)) continue
                // Standalone preflight on candidate while current VPN stays up.
                // Repeating full YouTube+two uploads here would delay and disrupt video.
                val probeConfig = XrayConfigBuilder.buildProbe(candidate) ?: continue
                val shortProbe = XrayCore.measureStandalone(this, probeConfig,
                    "https://www.gstatic.com/generate_204")
                if (recoverySerial.get() != serial || pfd == null) return
                if (shortProbe.ms == null) {
                    VpnController.emitEvent("Guardian: быстрый резерв не ответил на HTTPS; основной оставлен")
                    guardianFailedUntilMs[candidate.id] = System.currentTimeMillis() + 2L * 60_000L
                    continue
                }
            } else if (!emergencyHandover && previousQualification == null) {
                val test = ServerPrechecker.checkForGuardian(this, candidate)
                if (recoverySerial.get() != serial || pfd == null) return
                if (test.ms == null || !test.speedVerified || !test.youtubePassed ||
                    !WorkingPoolPolicy.qualifiesRtt(test.connectMs)) continue
                WorkingServerStore.recordSuccess(this, candidate, test.connectMs!!, test.ms,
                    youtubeVerified = true, speedVerified = true,
                    downloadMbps = test.downloadMbps, uploadMbps = test.uploadMbps)
            }
            val config = XrayConfigBuilder.build(candidate, resolved)
            if (config == null) {
                WorkingServerStore.recordFailure(this, candidate.id)
                continue
            }
            // Preserve native in-core redundancy after Guardian's own changes,
            // not only on an initial user-driven ACTION_START.
            val nextWarm = EmbeddedWarmRoutes.select(candidate, WorkingServerStore.activeServers(this))
                .filter { TlsRiskStore.eligibleForAutomaticUse(this, it.id) &&
                    XrayConfigBuilder.buildProbe(it) != null }
            val nextConfig = if (nextWarm.isEmpty()) config else EmbeddedWarmRoutes.augment(config, nextWarm)

            // A malformed native configuration must not abort the entire reserve
            // list and schedule a 5/10/20/40-second retry. Skip that node now.
            val generation = try {
                synchronized(operationLock) {
                    if (
                        recoverySerial.get() != serial ||
                        pfd == null ||
                        !VpnController.autoRecoveryEnabled
                    ) {
                        return
                    }

                    val g = operationGeneration.incrementAndGet()
                    VpnController.validatingServerId = candidate.id
                    VpnController.state.value = VpnState.Validating
                    showForeground("Автопереключение ${index + 1}/${minOf(MAX_BACKGROUND_ATTEMPTS, candidates.size)}…")
                    XrayCore.stop()
                    val bootedConfig = if (nextConfig != config) {
                        try {
                            XrayCore.start(nextConfig, fd, this, g)
                            nextConfig
                        } catch (_: Throwable) {
                            XrayCore.stop()
                            XrayCore.start(config, fd, this, g)
                            config
                        }
                    } else {
                        XrayCore.start(config, fd, this, g)
                        config
                    }
                    if (operationGeneration.get() != g || recoverySerial.get() != serial) {
                        return
                    }
                    if (bootedConfig.contains(EmbeddedWarmRoutes.BALANCER_TAG))
                        EmbeddedWarmRoutes.activated(bootedConfig, nextWarm)
                    else EmbeddedWarmRoutes.clear()
                    activeConfig = bootedConfig
                    activeRawLink = candidate.rawLink
                    activeHost = candidate.host
                    activeServer = candidate
                    g
                }
            } catch (t: Throwable) {
                if (recoverySerial.get() != serial) return
                guardianFailedUntilMs[candidate.id] =
                    System.currentTimeMillis() + GUARDIAN_FAILURE_COOLDOWN_MS
                VpnController.emitEvent("Guardian: ядро не приняло резерв ${candidate.country}: " +
                    "${t.message ?: t.javaClass.simpleName}; пробую следующий")
                continue
            }

            // Network validation deliberately runs without operationLock. If a
            // manual action replaces/stops this generation, the socket fails or the
            // stale result is discarded before it can change state.
            val candidateBaseline = WorkingServerStore.record(this, candidate.id)?.ewmaHttpsMs
            val candidateTimeoutMs = if (emergencyHandover)
                FastFailoverPolicy.FAST_TLS_TIMEOUT_MS
                else GuardianPolicy.watchdogIoTimeoutMs(candidateBaseline)
            val primary = XrayHealthChecker.quickCheck(
                useAlternate = index % 2 != 0,
                ioTimeoutMs = candidateTimeoutMs
            )
            // Do not run a second multi-second TLS request before accepting a
            // verified emergency reserve. A failure proceeds to the next node.
            val validation = if (primary.passed || emergencyHandover) {
                primary
            } else {
                XrayHealthChecker.quickCheck(
                    useAlternate = index % 2 == 0,
                    ioTimeoutMs = (candidateTimeoutMs + 750).coerceAtMost(6_000)
                )
            }

            if (
                recoverySerial.get() != serial ||
                operationGeneration.get() != generation ||
                pfd == null
            ) return

            if (validation.passed && emergencyHandover) {
                val connectPing = validation.connectMs?.coerceAtLeast(1)
                    ?: candidate.ping.takeIf { it > 0 } ?: 1
                val httpsLatency = validation.latencyMs?.coerceAtLeast(1) ?: connectPing
                val selected = candidate.copy(ping = connectPing)
                synchronized(operationLock) {
                    if (recoverySerial.get() != serial ||
                        operationGeneration.get() != generation || pfd == null) return
                    activeServer = selected
                    guardianFailedUntilMs.remove(selected.id)
                    persistAutomaticSelection(selected)
                    persistRecoverableSession(selected)
                    VpnController.activeServer.value = selected
                    VpnController.validatingServerId = null
                    VpnController.state.value = VpnState.Connected
                    refreshVideoStatusForActiveRoute()
                    watchdogFailures.set(0)
                    watchdogHighLatency.set(0)
                    recoveryRetryCount.set(0)
                    recoveryRetrySerial.incrementAndGet()
                    showForeground("Подключено · ${connectPing}мс")
                }
                // Preserve the earlier 2x speed and YouTube certifications.
                // HTTPS recovery is not itself proof of either property.
                WorkingServerStore.recordSuccess(this, selected, connectPing, httpsLatency)
                scheduleOpenAiTlsCheck()
                val handoverMs = (System.nanoTime() - recoveryStartedNs) / 1_000_000L
                VpnController.emitEvent(
                    "Guardian: FAST failover за ${handoverMs}мс → ${selected.country}; " +
                    "HTTPS=OK, " +
                    (if (historicalOnly) "исторический резерв, нужна повторная сертификация; "
                     else "YouTube/скорость ранее подтверждены; ") +
                    (if (FastFailoverPolicy.metGoal(handoverMs)) "цель ≤5с достигнута"
                     else "цель ≤5с превышена")
                )
                return
            }

            if (validation.passed && speedRecovery && previousQualification != null) {
                val connected = validation.connectMs?.takeIf { it > 0 }
                    ?: previousQualification.effectivePingMs()
                val selected = candidate.copy(ping = connected)
                synchronized(operationLock) {
                    if (recoverySerial.get() != serial || operationGeneration.get() != generation || pfd == null) return
                    activeServer = selected
                    persistAutomaticSelection(selected)
                    persistRecoverableSession(selected)
                    VpnController.activeServer.value = selected
                    VpnController.validatingServerId = null
                    VpnController.state.value = VpnState.Connected
                    refreshVideoStatusForActiveRoute()
                    watchdogFailures.set(0)
                    watchdogHighLatency.set(0)
                    recoveryRetryCount.set(0)
                    recoveryRetrySerial.incrementAndGet()
                    showForeground("Подключено · ${connected}мс")
                }
                WorkingServerStore.recordSuccess(this, selected, connected,
                    validation.latencyMs?.coerceAtLeast(1) ?: connected)
                pendingQualityUpgrade = null
                speedTriggerMbps = null
                VpnController.qualityUpgradeStatus.value = "completed · faster reserve connected"
                scheduleOpenAiTlsCheck()
                VpnController.emitEvent("Speed: автоматически перешёл на проверенный быстрый сервер " +
                    "${selected.country} · ${selected.city}; RTT=${connected}мс; " +
                    "YouTube и скорость ранее подтверждены")
                // The first new benchmark can run after stabilization, not in the handover itself.
                mainHandler.postDelayed({
                    if (activeServer?.id == selected.id && VpnController.state.value == VpnState.Connected &&
                        AppRunController.mayRun(this)) runPeriodicSpeedProbe()
                }, 60_000L)
                return
            }

            if (validation.passed) {
                val youtube = YouTubePageProbe.checkActive()
                if (recoverySerial.get() != serial || operationGeneration.get() != generation || pfd == null) return
                if (!youtube.passed) {
                    VpnController.emitEvent("Guardian: YouTube HTML не подтверждён для ${candidate.country} (${youtube.error})")
                    if (youtube.verdict == YouTubePageProbe.Verdict.BLOCKED)
                        WorkingServerStore.recordFailure(this, candidate.id)
                    continue
                }
                val speed = VpnSpeedTester.measure()
                if (recoverySerial.get() != serial || operationGeneration.get() != generation || pfd == null) return
                VpnController.speedTestResult.value = VpnSpeedTester.format(speed)
                VpnController.emitEvent("Резерв скорость: ${VpnSpeedTester.format(speed)}")
                if (speedRecovery && speed.verdict != VpnSpeedPolicy.Verdict.PASS) {
                    if (speed.verdict == VpnSpeedPolicy.Verdict.SLOW) {
                        weakReserveForReplacement = candidate.id
                        guardianFailedUntilMs[candidate.id] =
                            System.currentTimeMillis() + GUARDIAN_FAILURE_COOLDOWN_MS
                    }
                    VpnController.emitEvent(
                        "Резерв ${candidate.country} не подтвердил скорость 5/1 Мбит/с; пробую следующий"
                    )
                    // Failed/unknown benchmarks must not displace a still-usable tunnel.
                    continue
                }
                val connectPing = validation.connectMs?.coerceAtLeast(1)
                    ?: candidate.ping.takeIf { it > 0 }
                    ?: validation.latencyMs?.coerceAtLeast(1)
                    ?: 1
                val httpsLatency = validation.latencyMs?.coerceAtLeast(1)
                    ?: connectPing
                val selected = candidate.copy(ping = connectPing)

                synchronized(operationLock) {
                    if (
                        recoverySerial.get() != serial ||
                        operationGeneration.get() != generation ||
                        pfd == null
                    ) return
                    activeServer = selected
                    guardianFailedUntilMs.remove(selected.id)
                    persistAutomaticSelection(selected)
                    persistRecoverableSession(selected)
                    VpnController.activeServer.value = selected
                    VpnController.validatingServerId = null
                    VpnController.state.value = VpnState.Connected
                    refreshVideoStatusForActiveRoute()
                    watchdogFailures.set(0)
                    watchdogHighLatency.set(0)
                    recoveryRetryCount.set(0)
                    recoveryRetrySerial.incrementAndGet()
                    showForeground("Подключено · ${connectPing}мс")
                }

                WorkingServerStore.recordSuccess(
                    this,
                    selected,
                    connectMs = connectPing,
                    httpsMs = httpsLatency,
                    youtubeVerified = true
                )
                VpnController.emitEvent(
                    "Guardian: переключено на ${selected.country} · ${selected.city}, RTT=${connectPing}мс HTTPS=${httpsLatency}мс"
                )
                scheduleOpenAiTlsCheck()
                return
            }

            if (!hasUnderlyingInternetNetwork()) {
                // Do not poison a candidate because Wi-Fi/LTE vanished in the middle
                // of its TLS probe. Park the previous session metadata; onAvailable()
                // will rebuild it on the new physical network.
                synchronized(operationLock) {
                    if (recoverySerial.get() != serial || pfd == null) return
                    XrayCore.stop()
                    activeConfig = previousConfig
                    activeRawLink = previousRawLink
                    activeHost = previousHost
                    activeServer = previousServer
                    VpnController.activeServer.value = previousServer
                    VpnController.validatingServerId = null
                    VpnController.state.value = VpnState.Connecting
                }
                noUnderlyingNetworkSinceMs.compareAndSet(0L, System.currentTimeMillis())
                VpnController.emitEvent(
                    "Guardian: сеть пропала во время проверки резерва; сервер не штрафуется"
                )
                scheduleRecoveryRetry("ожидание физической сети")
                return
            }

            // A single short emergency TLS probe failing is not proof that a
            // fully certified standby is dead; avoid deleting the whole полного резерва
            // pool during a temporary CDN/Wi-Fi disturbance.
            if (!emergencyHandover && !speedRecovery) WorkingServerStore.recordFailure(this, candidate.id)
            guardianFailedUntilMs[candidate.id] = System.currentTimeMillis() +
                if (emergencyHandover) FastFailoverPolicy.FAILED_PROBE_COOLDOWN_MS
                else GUARDIAN_FAILURE_COOLDOWN_MS
            VpnController.emitEvent(
                "Guardian: резерв ${candidate.country} · ${candidate.city} не прошёл HTTPS (${validation.stage})" +
                if (emergencyHandover) "; временная пауза, без удаления из резерва" else ""
            )
        }

        if (recoverySerial.get() != serial || pfd == null) return

        // If NO reserve satisfies the speed target, open at most one replacement
        // slot per hour. This preserves the five-server battery budget rather than
        // restarting continuous 100-config searches at every 15-minute test.
        val weakReserve = weakReserveForReplacement
        if (speedRecovery && weakReserve != null) {
            val now = System.currentTimeMillis()
            val previous = lastSlowReserveReplacementAtMs.get()
            if (now - previous >= SLOW_RESERVE_REFILL_INTERVAL_MS &&
                lastSlowReserveReplacementAtMs.compareAndSet(previous, now)) {
                WorkingServerStore.recordFailure(this, weakReserve)
                ServerScanner.requestRecoveryWindow()
                VpnController.emitEvent("Speed: один слабый резерв снят с готовности; поиск одной замены")
            }
        }

        // Never abandon the last known tunnel just because every reserve failed.
        // Restore and revalidate it with the adaptive baseline-aware timeout. This
        // is especially important after transient mobile/CDN loss bursts.
        if (!previousConfig.isNullOrBlank() && previousServer != null) {
            try {
                val restoreGeneration = synchronized(operationLock) {
                    if (recoverySerial.get() != serial || pfd == null) return
                    val g = operationGeneration.incrementAndGet()
                    XrayCore.stop()
                    XrayCore.start(previousConfig, fd, this, g)
                    if (operationGeneration.get() != g || recoverySerial.get() != serial) return
                    activeConfig = previousConfig
                    activeRawLink = previousRawLink
                    activeHost = previousHost
                    activeServer = previousServer
                    VpnController.validatingServerId = previousServer.id
                    VpnController.state.value = VpnState.Validating
                    g
                }

                val previousBaseline = WorkingServerStore.record(this, previousServer.id)?.ewmaHttpsMs
                val restoreTimeout = GuardianPolicy.watchdogIoTimeoutMs(previousBaseline)
                val restored = XrayHealthChecker.quickCheck(
                    useAlternate = false,
                    ioTimeoutMs = restoreTimeout
                )
                val restoreValidation = if (restored.passed) {
                    restored
                } else {
                    XrayHealthChecker.quickCheck(
                        useAlternate = true,
                        ioTimeoutMs = (restoreTimeout + 1_000).coerceAtMost(6_000)
                    )
                }

                if (
                    recoverySerial.get() == serial &&
                    operationGeneration.get() == restoreGeneration &&
                    pfd != null &&
                    restoreValidation.passed
                ) {
                    val connectPing = restoreValidation.connectMs?.coerceAtLeast(1)
                        ?: previousServer.ping.takeIf { it > 0 }
                        ?: 1
                    val httpsLatency = restoreValidation.latencyMs?.coerceAtLeast(1)
                        ?: WorkingServerStore.record(this, previousServer.id)
                            ?.ewmaHttpsMs?.toInt()?.coerceAtLeast(1)
                        ?: connectPing
                    val restoredServer = previousServer.copy(ping = connectPing)

                    synchronized(operationLock) {
                        if (
                            recoverySerial.get() != serial ||
                            operationGeneration.get() != restoreGeneration ||
                            pfd == null
                        ) return
                        activeServer = restoredServer
                        guardianFailedUntilMs.remove(restoredServer.id)
                        persistAutomaticSelection(restoredServer)
                        persistRecoverableSession(restoredServer)
                        VpnController.activeServer.value = restoredServer
                        VpnController.validatingServerId = null
                        VpnController.state.value = VpnState.Connected
                        refreshVideoStatusForActiveRoute()
                        watchdogFailures.set(0)
                        watchdogHighLatency.set(0)
                        recoveryRetryCount.set(0)
                        recoveryRetrySerial.incrementAndGet()
                        showForeground("Подключено · ${connectPing}мс")
                    }

                    WorkingServerStore.recordSuccess(
                        this,
                        restoredServer,
                        connectMs = connectPing,
                        httpsMs = httpsLatency
                    )
                    VpnController.emitEvent(
                        "Guardian: резервы не прошли; прежний сервер восстановлен и подтверждён " +
                            "(RTT=${connectPing}мс HTTPS=${httpsLatency}мс)"
                    )
                    return
                }

                VpnController.emitEvent(
                    "Guardian: прежний сервер тоже не прошёл повторную HTTPS-проверку"
                )
            } catch (t: Throwable) {
                if (recoverySerial.get() != serial) return
                VpnController.emitEvent(
                    "Guardian: прежний сервер не восстановился: ${t.message ?: t.javaClass.simpleName}"
                )
            }
        }

        if (recoverySerial.get() != serial) return

        // Keep the foreground VPN/TUN alive and retry with bounded exponential
        // backoff. Stop only the failed Xray core; the user remains protected from
        // accidental direct traffic if Kill Switch is enabled.
        synchronized(operationLock) {
            if (recoverySerial.get() != serial || pfd == null) return
            XrayCore.stop()
            activeConfig = null
            activeRawLink = previousRawLink
            activeHost = previousHost
            activeServer = previousServer
            VpnController.validatingServerId = null
            VpnController.state.value = VpnState.Connecting
        }
        scheduleRecoveryRetry(
            "не найден рабочий сервер после ${attempted.size} попыток; причина: $reason"
        )
    }

    private fun scheduleRecoveryRetry(reason: String) {
        if (!VpnController.autoRecoveryEnabled || pfd == null) return
        val retry = recoveryRetryCount.incrementAndGet()
        val delayMs = GuardianPolicy.recoveryRetryDelayMs(
            retry = retry,
            hasPhysicalNetwork = hasUnderlyingInternetNetwork()
        )
        val serial = recoveryRetrySerial.incrementAndGet()
        showForeground("Восстановление VPN · повтор через ${delayMs / 1000}с")
        VpnController.emitEvent(
            "Guardian: $reason; повтор #$retry через ${delayMs / 1000}с"
        )
        mainHandler.postDelayed({
            if (
                recoveryRetrySerial.get() == serial &&
                VpnController.autoRecoveryEnabled &&
                VpnController.state.value == VpnState.Connecting &&
                pfd != null &&
                !recoveryInProgress.get()
            ) {
                scheduleAutomaticRecovery("повтор фонового восстановления #$retry", qualityOnly = false)
            }
        }, delayMs)
    }

    private fun buildBackgroundCandidates(qualityOnly: Boolean, preferSpeed: Boolean = false): List<Server> {
        val current = activeServer
        val currentId = current?.id
        val currentPing = current?.ping?.takeIf { it > 0 } ?: Int.MAX_VALUE
        val now = System.currentTimeMillis()
        guardianFailedUntilMs.entries.removeIf { it.value <= now }
        fun isGuardianCoolingDown(server: Server): Boolean =
            (guardianFailedUntilMs[server.id] ?: 0L) > now

        val working = WorkingServerStore.activeServers(this)
            .filter { TlsRiskStore.eligibleForAutomaticUse(this, it.id) && WorkingPoolPolicy.eligible(it) && FastFailoverPolicy.canUseReadyReserve(
                fullyQualified = true, sameAsActive = it.id == currentId,
                coolingDown = isGuardianCoolingDown(it), rawConfigPresent = it.rawLink.isNotBlank()
            ) }
        // A historical server must have *previously* passed strict 2x throughput,
        // YouTube and <=100ms. It is NEVER shown as a verified member after expiry.
        // During hard failure it can be tried after the live-verified tier, using
        // the same short TLS gate. Never use it for a voluntary speed optimisation.
        val historical = if (qualityOnly) emptyList() else
            WorkingServerStore.historicalRecoveryRecords(this).map { it.server.copy(
                ping = WorkingServerStore.record(this, it.server.id)?.effectivePingMs() ?: it.server.ping
            ) }.filter { TlsRiskStore.eligibleForAutomaticUse(this, it.id) &&
                WorkingPoolPolicy.eligible(it) &&
                FastFailoverPolicy.canUseReadyReserve(true, it.id == currentId,
                    isGuardianCoolingDown(it), it.rawLink.isNotBlank()) }

        if (qualityOnly && preferSpeed) {
            val pending = pendingQualityUpgrade ?: return emptyList()
            val verified = WorkingServerStore.activeRecords(this).asSequence()
                .filter { r -> r.server.id != currentId && !isGuardianCoolingDown(r.server) &&
                    TlsRiskStore.eligibleForAutomaticUse(this, r.server.id) &&
                    AutoQualityUpgradePolicy.isWorthSwitching(pending,
                        r.effectivePingMs(), r.verifiedDownloadMbps, r.verifiedUploadMbps) }
                .sortedWith(compareByDescending<WorkingServerStore.Record> {
                    it.stabilityScore(System.currentTimeMillis())
                }.thenBy { it.effectivePingMs() })
                .map { it.server.copy(ping = it.effectivePingMs()) }.toList()
            return verified.take(MAX_BACKGROUND_ATTEMPTS)
        }
        if (qualityOnly) {
            val betterWorking = working.filter { candidate ->
                val ping = candidate.ping
                ping in 1..GuardianPolicy.TARGET_RTT_MS ||
                    (currentPing != Int.MAX_VALUE && ping > 0 && ping * 100 <= currentPing * 70)
            }
            return GuardianPolicy.diversify(betterWorking).take(WorkingPoolPolicy.MAX_VERIFIED - 1)
        }

        // Emergency first tries the two independently re-checked hot reserves.
        // Hot status never overrides strict quality qualification below.
        val hot = HotReserveTracker.readyIdsForNetwork(ServerScanner.currentPhysicalNetworkKey(this))
        // Hard tiers: verified <=100ms -> other verified. No cold global fallback.
        // Diversification happens inside a tier and therefore never lets an unknown
        // slow node jump ahead of a proven/fast one.
        val workingFast = working.filter { it.ping in 1..GuardianPolicy.TARGET_RTT_MS }
        val workingFastIds = workingFast.mapTo(HashSet<String>()) { it.id }
        val workingRest = working.filterNot { it.id in workingFastIds }

        return buildList {
            // Hot entries must still be among the valid strict/historical pool.
            val all = workingFast + workingRest + historical
            hot.forEach { id -> all.firstOrNull { it.id == id }?.let(::add) }
            addAll(GuardianPolicy.diversify(workingFast))
            addAll(GuardianPolicy.diversify(workingRest))
            addAll(GuardianPolicy.diversify(historical))
        }.distinctBy { it.id }
    }

    private fun hasUnderlyingInternetNetwork(): Boolean {
        val cm = connectivityManager ?: getSystemService(ConnectivityManager::class.java)
            ?: return false

        val tracked = synchronized(networkLock) { underlyingNetworks.toList() }
        fun Network.isInternetUnderlay(): Boolean {
            val caps = runCatching { cm.getNetworkCapabilities(this) }.getOrNull() ?: return false
            return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
        }

        if (tracked.any { it.isInternetUnderlay() }) return true
        return runCatching { cm.allNetworks.any { it.isInternetUnderlay() } }.getOrDefault(false)
    }

    /**
     * Persist only the identity of the currently active session. The full raw link
     * already lives in the bounded private ServerStore/WorkingServerStore caches,
     * so service restart support does not create another credential copy.
     */
    private fun persistRecoverableSession(server: Server) {
        if (!AppRunController.mayRun(this)) return
        if (server.id.isBlank()) return
        getSharedPreferences(SERVICE_SESSION_PREFS, android.content.Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_SESSION_ACTIVE, true)
            .putString(KEY_SESSION_SERVER_ID, server.id)
            .apply()
    }

    private fun clearRecoverableSession() {
        getSharedPreferences(SERVICE_SESSION_PREFS, android.content.Context.MODE_PRIVATE)
            .edit()
            .clear()
            .apply()
    }

    /**
     * Android can recreate a START_STICKY foreground service with a null Intent.
     * Reconstruct the last active server from the existing bounded cache and let
     * the service itself validate it, because no Activity/ViewModel may exist.
     */
    private fun restorePersistedSession(): Boolean {
        val session = getSharedPreferences(SERVICE_SESSION_PREFS, android.content.Context.MODE_PRIVATE)
        if (!session.getBoolean(KEY_SESSION_ACTIVE, false)) return false

        if (VpnService.prepare(this) != null) {
            clearRecoverableSession()
            VpnController.emitEvent("Guardian: автовосстановление после перезапуска невозможно — VPN-разрешение отозвано")
            return false
        }

        val serverId = session.getString(KEY_SESSION_SERVER_ID, null)?.takeIf { it.isNotBlank() }
        val server = serverId?.let { id ->
            WorkingServerStore.record(this, id)?.server
                ?: ServerStore.loadCached(this).firstOrNull { it.id == id }
        }

        if (server == null || server.rawLink.isBlank()) {
            if (VpnController.killSwitchEnabled) {
                return enterRestoredKillSwitch("последний сервер отсутствует в локальном кеше")
            }
            clearRecoverableSession()
            return false
        }

        val config = XrayConfigBuilder.build(server, null)
        if (config == null) {
            if (VpnController.killSwitchEnabled) {
                return enterRestoredKillSwitch("последний сервер больше не поддерживается")
            }
            clearRecoverableSession()
            return false
        }

        val generation = operationGeneration.incrementAndGet()
        try {
            // Satisfy the foreground-service deadline synchronously; startVpn()
            // performs the heavier Xray work on the bounded worker pool.
            showForeground("Восстановление VPN…")
        } catch (t: Throwable) {
            VpnController.emitEvent(
                "Guardian: не удалось восстановить foreground notification: ${t.message ?: t.javaClass.simpleName}"
            )
            return false
        }
        VpnController.emitEvent(
            "Guardian: Android перезапустил VPN-service; восстанавливаю ${server.country} · ${server.city}"
        )
        startVpn(
            config = config,
            rawLink = server.rawLink,
            host = server.host,
            server = server,
            generation = generation,
            serviceOwnsValidation = true
        )
        return true
    }

    private fun enterRestoredKillSwitch(reason: String): Boolean {
        return try {
            showForeground("Kill Switch: восстановление…")
            synchronized(operationLock) {
                val generation = operationGeneration.get()
                stopCoreForGeneration(generation)
                if (pfd == null) {
                    pfd = establishTun(blocked = true)
                }
                VpnController.state.value = VpnState.Blocked
                VpnController.videoQualityStatus.value = "VPN заблокирован"
            }
            showForeground("Kill Switch: интернет заблокирован")
            VpnController.emitEvent("Guardian: $reason; Kill Switch сохранён после перезапуска")
            true
        } catch (t: Throwable) {
            clearRecoverableSession()
            VpnController.emitEvent(
                "Guardian: не удалось восстановить Kill Switch: ${t.message ?: t.javaClass.simpleName}"
            )
            false
        }
    }

    private fun validateRestoredSession(server: Server, generation: Long) {
        if (
            operationGeneration.get() != generation ||
            pfd == null ||
            VpnController.state.value != VpnState.Validating
        ) return

        val baseline = WorkingServerStore.record(this, server.id)?.ewmaHttpsMs
        val timeoutMs = GuardianPolicy.watchdogIoTimeoutMs(baseline)
        val primary = XrayHealthChecker.quickCheck(
            useAlternate = false,
            ioTimeoutMs = timeoutMs
        )
        val validation = if (primary.passed) {
            primary
        } else {
            XrayHealthChecker.quickCheck(
                useAlternate = true,
                ioTimeoutMs = (timeoutMs + 1_000).coerceAtMost(6_000)
            )
        }

        if (
            operationGeneration.get() != generation ||
            pfd == null ||
            VpnController.state.value != VpnState.Validating
        ) return

        if (validation.passed) {
            val connectPing = validation.connectMs?.coerceAtLeast(1)
                ?: server.ping.takeIf { it > 0 }
                ?: 1
            val httpsLatency = validation.latencyMs?.coerceAtLeast(1) ?: connectPing
            val restored = server.copy(ping = connectPing)

            val committed = synchronized(operationLock) {
                if (
                    operationGeneration.get() != generation ||
                    pfd == null ||
                    VpnController.state.value != VpnState.Validating
                ) {
                    false
                } else {
                    activeServer = restored
                    VpnController.activeServer.value = restored
                    VpnController.validatingServerId = null
                    VpnController.state.value = VpnState.Connected
                    refreshVideoStatusForActiveRoute()
                    watchdogFailures.set(0)
                    watchdogHighLatency.set(0)
                    recoveryRetryCount.set(0)
                    recoveryRetrySerial.incrementAndGet()
                    guardianFailedUntilMs.remove(restored.id)
                    persistAutomaticSelection(restored)
                    persistRecoverableSession(restored)
                    showForeground("Подключено · ${connectPing}мс")
                    true
                }
            }
            if (!committed) return

            WorkingServerStore.recordSuccess(
                this,
                restored,
                connectMs = connectPing,
                httpsMs = httpsLatency
            )
            scheduleOpenAiTlsCheck()
            VpnController.emitEvent(
                "Guardian: VPN восстановлен после перезапуска service " +
                    "(RTT=${connectPing}мс HTTPS=${httpsLatency}мс)"
            )
            return
        }

        val shouldRecover = synchronized(operationLock) {
            if (
                operationGeneration.get() != generation ||
                pfd == null ||
                VpnController.state.value != VpnState.Validating
            ) {
                false
            } else {
                VpnController.validatingServerId = null
                VpnController.state.value = VpnState.Connecting
                true
            }
        }
        if (!shouldRecover) return

        // If the physical network disappeared during validation, do not blacklist
        // the restored server. NetworkCallback will trigger recovery on return.
        if (!hasUnderlyingInternetNetwork()) {
            noUnderlyingNetworkSinceMs.compareAndSet(0L, System.currentTimeMillis())
            VpnController.emitEvent(
                "Guardian: сеть пропала во время проверки восстановленного VPN; сервер не штрафуется"
            )
            scheduleRecoveryRetry("ожидание физической сети")
            return
        }

        WorkingServerStore.recordFailure(this, server.id)
        guardianFailedUntilMs[server.id] =
            System.currentTimeMillis() + GUARDIAN_FAILURE_COOLDOWN_MS
        VpnController.emitEvent(
            "Guardian: восстановленный сервер не прошёл HTTPS (${validation.stage}); запускаю failover"
        )
        scheduleAutomaticRecovery(
            reason = "проверка после перезапуска service не прошла",
            qualityOnly = false
        )
    }

    private fun persistAutomaticSelection(server: Server) {
        getSharedPreferences(ServerStore.SETTINGS_PREFS, android.content.Context.MODE_PRIVATE)
            .edit()
            .putString("selected_server", server.id)
            .putBoolean("selected_server_explicit", false)
            .apply()
    }

    private fun closeTun() {
        runCatching { pfd?.close() }
        pfd = null
    }

    /** Direct task-removal shutdown. Android dispatches onTaskRemoved only when
     * stopWithTask=false, so never rely on stopWithTask=true for cleanup.
     * The call closes TUN synchronously before Android publishes Idle.
     */
    private fun shutdownForDismissedTask() {
        if (!taskShutdownStarted.compareAndSet(false, true)) return
        VpnController.stopRequestSerial.value += 1L
        VpnController.autoRecoveryEnabled = false
        periodicTasks.stop()
        taskMonitor.stop()
        mainHandler.removeCallbacks(refreshAppRoutes)
        invalidateAsyncWorkForCommand()
        val generation = operationGeneration.incrementAndGet()
        stopVpn(intentional = true, generation = generation)
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // A delayed callback for an old task must not stop a newly launched task.
        if (AppRunController.hasTask(this) != true) {
            AppRunController.closed(this)
        }
        super.onTaskRemoved(rootIntent)
    }

    override fun onRevoke() {
        clearRecoverableSession()
        invalidateAsyncWorkForCommand()
        val generation = operationGeneration.incrementAndGet()
        synchronized(operationLock) {
            stopCoreForGeneration(generation)
            closeTun()
            VpnController.validatingServerId = null
            VpnController.state.value =
                if (VpnController.killSwitchEnabled) VpnState.Error("VPN отозван системой (Kill Switch)")
                else VpnState.Idle
            foregroundActive = false
            clearTrafficRate()
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    override fun onDestroy() {
        TlsRiskStore.clearApprovals()
        taskMonitor.stop()
        if (liveService?.get() === this) liveService = null
        // A task-owned VPN service being destroyed must never leave a session
        // marker behind. START_STICKY process death generally skips onDestroy.
        clearRecoverableSession()
        // stopWithTask=true stops services on Recents removal but does not invoke
        // onTaskRemoved(). Make the session non-restorable before native shutdown.
        if (AppRunController.hasTask(this) == false && AppRunController.mayRun(this)) {
            AppRunController.taskGoneDuringServiceDestroy(this)
        }
        // A closing task must never retain a START_STICKY recovery marker,
        // including when a native connection completed during task shutdown.
        if (!AppRunController.mayRun(this)) clearRecoverableSession()
        foregroundActive = false
        clearTrafficRate()
        mainHandler.removeCallbacks(refreshAppRoutes)
        periodicTasks.stop()
        speedProbeSerial.incrementAndGet()
        runCatching { unregisterReceiver(packageChangedReceiver) }
        ServerScanner.release(this)
        invalidateAsyncWorkForCommand(resetRetryCount = false)
        // Remove watchdog, retry and immediate-check callbacks so the destroyed
        // Service instance is not retained by the main looper for up to 60 seconds.
        mainHandler.removeCallbacksAndMessages(null)
        if (networkCallbackRegistered) {
            runCatching { connectivityManager?.unregisterNetworkCallback(networkCallback) }
        }
        networkCallbackRegistered = false
        connectivityManager = null
        synchronized(networkLock) { underlyingNetworks.clear() }

        val generation = operationGeneration.incrementAndGet()
        synchronized(operationLock) {
            stopCoreForGeneration(generation)
            activeConfig = null
            activeRawLink = null
            activeHost = null
            activeServer = null
            VpnController.activeServer.value = null
            VpnController.validatingServerId = null
            closeTun()
            val st = VpnController.state.value
            if (st !is VpnState.Error && st !is VpnState.Blocked) {
                VpnController.state.value = VpnState.Idle
            }
        }
        // Unlike a normal network notification, a foreground notification may
        // have been updated with notify(). Explicitly remove both representations.
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        getSystemService(NotificationManager::class.java)?.cancel(NOTIFICATION_ID)
        AppRunController.acknowledgeStopped(this)
        VpnController.state.value = VpnState.Idle
        // Do not resurrect the independent catalogue-scanning foreground service.
        // The visible Activity owns on-demand discovery; VPN recovery owns the tunnel.
        super.onDestroy()
    }

    /** Stable foreground notification; action executes directly inside the VPN service. */
    private fun showForeground(text: String) {
        notificationStatus = text
        val manager = getSystemService(NotificationManager::class.java)
            ?: throw IllegalStateException("NotificationManager недоступен")
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL, "VPN", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = buildVpnNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        foregroundActive = true
        // The running VPN foreground service already owns ServerScanner. Its
        // notification replaces the scanner-only notification (ID 2) so the
        // notification shade shows just ONE SecureConnect card while connected.
        // stopService() releases only ServerScanService's scanner lease; the
        // VpnService lease remains active across Home/background.
        stopService(Intent(this, com.secureconnect.app.ServerScanService::class.java))
    }

    private fun buildVpnNotification(): Notification = VpnNotificationFactory.build(
        context = this,
        state = VpnController.state.value,
        server = activeServer ?: VpnController.activeServer.value,
        activeHost = activeHost,
        status = notificationStatus
    )

    /** notify(), not repeated startForeground(): updates rates without restarting the VPN. */
    private fun refreshNotification() {
        if (!foregroundActive) return
        runCatching {
            getSystemService(NotificationManager::class.java)?.notify(
                NOTIFICATION_ID, buildVpnNotification()
            )
        }.onFailure { VpnController.emitEvent("Уведомление VPN: ${it.message}") }
    }

    companion object {
        private val GLOBAL_OPERATION_GENERATION = AtomicLong(0L)

        const val ACTION_UPDATE_APP_ROUTING = "com.secureconnect.app.UPDATE_APP_ROUTING"
        const val ACTION_START = "com.secureconnect.app.START"
        const val ACTION_CERTIFY_QUALITY = "com.secureconnect.app.CERTIFY_QUALITY"
        const val ACTION_CHECK_VIDEO_NOW = "com.secureconnect.app.CHECK_VIDEO_NOW"
        const val ACTION_CHECK_OPENAI_TLS = "com.secureconnect.app.CHECK_OPENAI_TLS"
        const val EXTRA_QUALITY_CONNECT_MS = "quality_connect_ms"
        const val EXTRA_QUALITY_HTTPS_MS = "quality_https_ms"
        const val EXTRA_AUTO_VIDEO_CHECK = "auto_video_check"
        const val ACTION_RECONCILE_STATE = "com.secureconnect.app.RECONCILE_VPN_STATE"
        const val ACTION_STOP = "com.secureconnect.app.STOP"
        const val ACTION_STOP_FROM_NOTIFICATION = "com.secureconnect.app.STOP_FROM_NOTIFICATION"
        const val ACTION_STOP_FROM_TASK = "com.secureconnect.app.STOP_FROM_TASK"
        @Volatile private var liveService: java.lang.ref.WeakReference<XrayVpnService>? = null
        @Volatile private var uiVisible: Boolean = false

        /**
         * No polling to discover whether Home is visible. Activity lifecycle
         * pushes the change; rescheduling only the *display* sampler never
         * alters tunnel, failover or security checks.
         */
        fun notifyUiVisibilityChanged(visible: Boolean) {
            uiVisible = visible
            liveService?.get()?.let { service ->
                service.mainHandler.post {
                    service.mainHandler.removeCallbacks(service.trafficTicker)
                    service.periodicTasks.reschedule(
                        service.trafficTicker,
                        if (visible) 0L else BatteryAwarePolicy.trafficIntervalMs(false, false)
                    )
                }
            }
        }

        /** This service and Activity share the app process; no synthetic Connected flag.
         *  A live TUN must take precedence over a cleared preference marker.
         */
        fun hasLiveService(): Boolean = liveService?.get() != null
        fun hasLiveTunnel(): Boolean = liveService?.get()?.pfd != null

        /** Called only after the app task is dismissed. Prefer direct shutdown of
         * the already-running instance over startService(), which Android can block
         * for a background app. Never creates a second VPN service.
         */
        fun stopLiveForTaskRemoval(): Boolean {
            val service = liveService?.get() ?: return false
            if (Looper.myLooper() == Looper.getMainLooper()) {
                service.shutdownForDismissedTask()
                return true
            }
            return service.mainHandler.post { service.shutdownForDismissedTask() }
        }

        /** Called on Activity recreation, including an old task's late dismissal. */
        fun reconcileLiveService(): Boolean {
            val service = liveService?.get() ?: return false
            if (VpnController.state.value == VpnState.Stopping) return true
            if (service.pfd == null) return false
            val server = service.activeServer
            if (server == null) {
                // TUN is allocated but core validation is not complete.
                if (VpnController.state.value == VpnState.Idle) {
                    VpnController.state.value = VpnState.Connecting
                }
                return true
            }
            VpnController.activeServer.value = server
            if (VpnController.state.value == VpnState.Idle ||
                VpnController.state.value is VpnState.Error) {
                VpnController.validatingServerId = server.id
                VpnController.state.value = VpnState.Validating
                val generation = service.operationGeneration.get()
                ResourceGovernor.workerExecutor.execute {
                    service.validateRestoredSession(server, generation)
                }
            }
            return true
        }
        const val ACTION_BLOCK = "com.secureconnect.app.BLOCK"
        const val EXTRA_CONFIG = "config"
        const val EXTRA_RAW_LINK = "raw_link"
        const val EXTRA_HOST = "host"
        const val EXTRA_SERVER_ID = "server_id"
        const val EXTRA_SERVER_COUNTRY = "server_country"
        const val EXTRA_SERVER_CITY = "server_city"
        const val EXTRA_SERVER_FLAG = "server_flag"
        const val EXTRA_SERVER_PROTOCOL = "server_protocol"
        const val EXTRA_SERVER_PORT = "server_port"
        const val EXTRA_SERVER_PING = "server_ping"
        const val EXTRA_SERVER_SOURCE = "server_source"
        const val EXTRA_ERROR = "error"

        private const val SERVICE_SESSION_PREFS = "sc_vpn_service_session"
        private const val KEY_SESSION_ACTIVE = "active"
        private const val KEY_SESSION_SERVER_ID = "server_id"

        private const val CHANNEL = "vpn"
        private const val NOTIFICATION_ID = 1
        // Display-only counters run less often with screen off; data path is unchanged.
        // Keep event-driven immediate checks on physical-network changes and bounded retries.
        // Avoid a TLS+HTTPS wake-up every 20 seconds when the tunnel is healthy.
        // Adapted schedules live in BatteryAwarePolicy; network callbacks remain immediate.
        private const val WATCHDOG_RETRY_MS = 3_000L
        private const val QUALITY_RECOVERY_COOLDOWN_MS = 10L * 60L * 1000L
        private const val SLOW_RESERVE_REFILL_INTERVAL_MS = 60L * 60L * 1000L
        // RTT and full HTTPS latency are intentionally separate. A VPN can have
        // excellent 40-80ms RTT while a complete TLS+HTTP request takes 500ms+.
        private const val HIGH_LATENCY_SAMPLES = 5
        private const val MAX_BACKGROUND_ATTEMPTS = 6
        private const val GUARDIAN_FAILURE_COOLDOWN_MS = 5L * 60L * 1000L
        private const val WEAK_SIGNAL_DBM = -105
    }
}
