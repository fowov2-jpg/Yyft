package com.secureconnect.app.viewmodel

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class QuietRuntimeLogPolicyTest {
    @Test
    fun onlyActionableServiceMessagesAreRecorded() {
        assertFalse(QuietRuntimeLogPolicy.classifyServiceEvent("Health-check PASS") == "WARN")
        assertTrue(QuietRuntimeLogPolicy.classifyServiceEvent("TLS риск: сертификат") == "WARN")
        assertTrue(QuietRuntimeLogPolicy.classifyServiceEvent("Автозащита: ошибка") == "WARN")
    }

    @Test
    fun routineInfoIsNotRecorded() {
        val gate = QuietRuntimeLogPolicy()
        assertFalse(gate.accept("INFO", "Health check PASS", 1L))
        assertFalse(gate.accept("DEBUG", "probe", 2L))
    }

    @Test
    fun warningsAndErrorsAreRetained() {
        val gate = QuietRuntimeLogPolicy()
        assertTrue(gate.accept("WARN", "TLS verification failed", 1_000L))
        assertTrue(gate.accept("ERROR", "VPN tunnel failure", 1_001L))
    }

    @Test
    fun repeatedWarningIsLimitedButReturnsAfterWindow() {
        val gate = QuietRuntimeLogPolicy(repeatWindowMs = 120_000L)
        assertTrue(gate.accept("WARN", "lost tunnel", 1_000L))
        assertFalse(gate.accept("WARN", "lost tunnel", 30_000L))
        assertTrue(gate.accept("WARN", "lost tunnel", 121_000L))
    }

    @Test
    fun independentErrorsAreNotLost() {
        val gate = QuietRuntimeLogPolicy()
        assertTrue(gate.accept("ERROR", "first", 100L))
        assertTrue(gate.accept("ERROR", "second", 101L))
    }

    @Test
    fun oldDedupKeysAreEvictedFromBoundedMemory() {
        val gate = QuietRuntimeLogPolicy(repeatWindowMs = 10_000L, maxDedupKeys = 2)
        assertTrue(gate.accept("WARN", "first", 1L))
        assertTrue(gate.accept("WARN", "second", 2L))
        assertTrue(gate.accept("WARN", "third", 3L))
        assertTrue(gate.accept("WARN", "first", 4L))
    }
}
