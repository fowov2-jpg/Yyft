package com.secureconnect.app.vpn

import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.InetSocketAddress
import java.net.Socket
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

/**
 * One low-bandwidth TLS handshake on the current Xray SOCKS outbound.
 * It verifies Android's default trust chain AND the expected hostname; it never
 * sends user tokens, downloads an OpenAI page or overrides certificate errors.
 * Note: ChatGPT app certificate pinning is stronger, and TUN routing is not
 * itself verified by this SOCKS probe. Do not describe success as a guarantee.
 */
object OpenAiTlsProbe {
    private const val TARGET = "android.chat.openai.com"
    private const val TLS_PORT = 443
    private const val CONNECT_TIMEOUT_MS = 900
    private const val IO_TIMEOUT_MS = 3_500

    data class Result(val verdict: OpenAiTlsPolicy.Verdict, val host: String = TARGET,
                      val detail: String = "") {
        val status: String get() = OpenAiTlsPolicy.userStatus(verdict) +
            (if (detail.isBlank()) "" else " · $detail")
    }

    fun checkActive(): Result = checkViaSocks(XrayConfigBuilder.HEALTH_SOCKS_PORT)

    /** Isolated per-server check for admission: avoids conflating routes in the balancer. */
    fun checkViaSocks(localPort: Int): Result {
        try {
            Socket().use { raw ->
                raw.soTimeout = IO_TIMEOUT_MS
                raw.connect(InetSocketAddress("127.0.0.1", localPort), CONNECT_TIMEOUT_MS)
                // Domain name, NOT a previously resolved IP: DNS and TLS SNI must
                // refer to the same protected endpoint through this proxy route.
                XrayHealthChecker.performSocksConnect(
                    DataInputStream(raw.getInputStream()),
                    DataOutputStream(raw.getOutputStream()), TARGET, TLS_PORT
                )
                val tls = (SSLSocketFactory.getDefault() as SSLSocketFactory)
                    .createSocket(raw, TARGET, TLS_PORT, false) as SSLSocket
                tls.use { ssl ->
                    ssl.soTimeout = IO_TIMEOUT_MS
                    ssl.useClientMode = true
                    ssl.sslParameters = ssl.sslParameters.apply {
                        endpointIdentificationAlgorithm = "HTTPS"
                        serverNames = listOf(SNIHostName(TARGET))
                    }
                    ssl.startHandshake()
                    return Result(OpenAiTlsPolicy.Verdict.VERIFIED)
                }
            }
        } catch (error: Throwable) {
            return if (OpenAiTlsPolicy.isCertificateFailure(error)) {
                Result(OpenAiTlsPolicy.Verdict.CERTIFICATE_ERROR, detail = "проверка доверия/имени не пройдена")
            } else {
                // Timeouts, blocked TLS and network changes are not proof of MitM.
                Result(OpenAiTlsPolicy.Verdict.UNAVAILABLE, detail = error.javaClass.simpleName.take(42))
            }
        }
    }
}
