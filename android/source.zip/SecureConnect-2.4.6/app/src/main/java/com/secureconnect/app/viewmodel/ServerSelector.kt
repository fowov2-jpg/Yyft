package com.secureconnect.app.viewmodel

import com.secureconnect.app.data.model.Server
import com.secureconnect.app.data.model.ServerQualityHints
import com.secureconnect.app.data.model.ServerTransport

/** Детерминированный порядок кандидатов для автоматического failover. */
object ServerSelector {
    fun rank(servers: List<Server>, primary: Server): List<Server> {
        val candidates = servers.filter { it.rawLink.isNotBlank() }

        val ordered = candidates.sortedWith(
            compareBy<Server> { ServerTransport.pingBucket(it) }
                .thenBy { ServerTransport.coldStartRank(it) }
                .thenBy { it.pingOrMax() }
                .thenBy { protocolRank(it.protocol) }
        )

        return buildList {
            add(primary)
            ordered.forEach { candidate ->
                if (candidate.id != primary.id && none { it.id == candidate.id }) add(candidate)
            }
        }
    }

    /**
     * Сохраняет глобальный rank, но не позволяет одному агрегатору занять все
     * failover-слоты. Первый кандидат остаётся первым; дальше источники
     * чередуются round-robin в порядке их первого появления.
     */
    fun diversifyBySource(ranked: List<Server>, limit: Int): List<Server> {
        if (limit <= 0 || ranked.isEmpty()) return emptyList()

        val unique = ranked.distinctBy { it.id }
        val queues = LinkedHashMap<String, ArrayDeque<Server>>()
        unique.forEach { server ->
            queues.getOrPut(server.source.ifBlank { "<unknown>" }) { ArrayDeque() }.addLast(server)
        }

        val result = ArrayList<Server>(minOf(limit, unique.size))
        while (result.size < limit && queues.isNotEmpty()) {
            val exhausted = ArrayList<String>()
            for ((source, queue) in queues) {
                if (result.size >= limit) break
                if (queue.isNotEmpty()) result.add(queue.removeFirst())
                if (queue.isEmpty()) exhausted.add(source)
            }
            exhausted.forEach(queues::remove)
        }
        return result
    }

    /**
     * Source diversification that preserves a hard health tier: a server in active
     * cooldown can never be pulled ahead of an eligible server merely because it
     * belongs to a different subscription source.
     */
    fun diversifyBySourceWithCooldown(
        ranked: List<Server>,
        limit: Int,
        isCoolingDown: (Server) -> Boolean
    ): List<Server> {
        if (limit <= 0 || ranked.isEmpty()) return emptyList()
        val eligible = ranked.filterNot(isCoolingDown)
        val cooling = ranked.filter(isCoolingDown)
        val head = diversifyBySource(eligible, limit)
        if (head.size >= limit) return head
        return head + diversifyBySource(cooling, limit - head.size)
    }


    /**
     * Picks one candidate from a health-ranked list while adapting within the
     * current connection attempt. A source that has already failed is temporarily
     * deprioritized, and a transport family is penalized only after repeated
     * failures so one unlucky node does not poison the whole family.
     *
     * Historical end-to-end successes are protected from cold-start penalties.
     */
    fun chooseAdaptive(
        ranked: List<Server>,
        sourceFailures: Map<String, Int>,
        familyFailures: Map<String, Int>,
        isCoolingDown: (Server) -> Boolean,
        hasSuccessfulHistory: (Server) -> Boolean,
        isWorking: (Server) -> Boolean = { false },
        knownLatencyMs: (Server) -> Int? = { server -> server.ping.takeIf { it > 0 } }
    ): Server? {
        if (ranked.isEmpty()) return null
        val baseIndex = ranked.withIndex().associate { it.value.id to it.index }

        /**
         * Priority contract for auto selection:
         *  1) active "Рабочие" pool, with real <=100 ms first;
         *  2) recent health-ledger successes (migration/backward compatibility);
         *  3) global unknowns with measured TCP <=100 ms;
         *  4) the rest, diversified by source/transport.
         *
         * Cooldown always wins over every performance hint.
         */
        return ranked.minWithOrNull(
            compareBy<Server> { if (isCoolingDown(it)) 1 else 0 }
                .thenBy { server ->
                    when {
                        isWorking(server) -> 0
                        hasSuccessfulHistory(server) -> 1
                        else -> 2
                    }
                }
                .thenBy { server ->
                    val latency = knownLatencyMs(server) ?: server.ping.takeIf { it > 0 }
                    if ((isWorking(server) || hasSuccessfulHistory(server)) && latency in 1..100) 0 else 1
                }
                .thenBy { ServerQualityHints.loadPriority(it) }
                .thenBy { server ->
                    val protectedHistory = isWorking(server) || hasSuccessfulHistory(server)
                    if (protectedHistory) 0
                    else sourceFailures[server.source.ifBlank { "<unknown>" }] ?: 0
                }
                .thenBy { server ->
                    val protectedHistory = isWorking(server) || hasSuccessfulHistory(server)
                    if (protectedHistory) 0
                    else ((familyFailures[ServerTransport.family(server)] ?: 0) - 1).coerceAtLeast(0)
                }
                .thenBy { server ->
                    val latency = knownLatencyMs(server) ?: server.ping.takeIf { it > 0 }
                    when {
                        latency == null -> 4
                        latency <= 100 -> 0
                        latency <= 250 -> 1
                        latency <= 600 -> 2
                        else -> 3
                    }
                }
                .thenBy { server ->
                    if (isWorking(server) || hasSuccessfulHistory(server)) 0
                    else ServerTransport.coldStartRank(server)
                }
                .thenBy { baseIndex[it.id] ?: Int.MAX_VALUE }
        )
    }

    private fun protocolRank(protocol: String): Int = when (protocol.uppercase()) {
        "VLESS" -> 0
        "HYSTERIA2" -> 1
        "TROJAN" -> 2
        "VMESS" -> 3
        "SHADOWSOCKS" -> 4
        else -> 5
    }

    private fun Server.pingOrMax(): Int = if (ping > 0) ping else Int.MAX_VALUE
}
