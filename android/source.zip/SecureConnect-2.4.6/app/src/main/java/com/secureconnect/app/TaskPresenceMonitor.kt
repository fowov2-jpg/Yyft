package com.secureconnect.app

import android.app.Service
import android.os.Handler

/** Safety net for OEMs that do not promptly dispatch onTaskRemoved to foreground services. */
internal class TaskPresenceMonitor(
    private val service: Service,
    private val handler: Handler,
    private val onTaskGone: () -> Unit
) {
    private val policy = TaskPresencePolicy(
        priorTaskWasKnown = AppRunController.hadRegisteredTask(service)
    )
    private var running = false
    private val check = object : Runnable {
        override fun run() {
            if (!running) return
            val present = AppRunController.hasTask(service)
            if (present != null && policy.record(present)) {
                running = false
                onTaskGone()
                return
            }
            handler.postDelayed(this, INTERVAL_MS)
        }
    }

    fun start() {
        if (running) return
        running = true
        handler.post(check)
    }

    fun stop() {
        running = false
        handler.removeCallbacks(check)
    }

    companion object { private const val INTERVAL_MS = 30_000L }
}
