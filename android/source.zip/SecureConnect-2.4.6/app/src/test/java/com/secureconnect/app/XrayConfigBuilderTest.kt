package com.secureconnect.app

import com.secureconnect.app.data.model.Server
import com.secureconnect.app.vpn.XrayConfigBuilder
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class XrayConfigBuilderTest {
    private fun server(link: String, host: String, port: Int, protocol: String = "VLESS") = Server(
        id = "test",
        country = "",
        city = "",
        flagEmoji = "",
        protocol = protocol,
        ping = 0,
        host = host,
        port = port,
        source = "test",
        rawLink = link
    )

    @Test
    fun unauthenticatedAndLegacyShadowsocksCiphersAreRejected() {
        for (method in listOf("none", "plain", "rc4-md5", "aes-256-cfb", "aes-128-ctr")) {
            val credentials = java.util.Base64.getEncoder()
                .encodeToString("$method:testpassword".toByteArray())
            val link = "ss://$credentials@example.com:8388#Test"
            assertNull(method, XrayConfigBuilder.build(server(link, "example.com", 8388, "SHADOWSOCKS"), null))
        }
    }

    @Test
    fun modernAuthenticatedShadowsocksIsAccepted() {
        val credentials = java.util.Base64.getEncoder()
            .encodeToString("aes-256-gcm:testpassword".toByteArray())
        val link = "ss://$credentials@example.com:8388#Test"
        assertNotNull(XrayConfigBuilder.build(server(link, "example.com", 8388, "SHADOWSOCKS"), null))
    }

    @Test
    fun dnsOutboundUsesDialerProxyAndNoRemovedProxySettings() {
        val link = "vless://00000000-0000-0000-0000-000000000001@example.com:443?security=tls&sni=example.com&type=tcp"
        val config = XrayConfigBuilder.build(server(link, "example.com", 443), "203.0.113.7")
        assertNotNull(config)

        val root = JSONObject(config!!)
        val outbounds = root.getJSONArray("outbounds")
        val dns = (0 until outbounds.length())
            .map { outbounds.getJSONObject(it) }
            .first { it.getString("tag") == "dns" }

        assertFalse(dns.has("proxySettings"))
        assertEquals(
            "proxy",
            dns.getJSONObject("streamSettings").getJSONObject("sockopt").getString("dialerProxy")
        )
    }

    @Test
    fun publicPlaintextVlessIsRejectedBeforeXrayStart() {
        val link = "vless://00000000-0000-0000-0000-000000000001@45.130.125.160:80?security=none&encryption=none&type=tcp"
        assertNull(XrayConfigBuilder.build(server(link, "45.130.125.160", 80), "45.130.125.160"))
    }

    @Test
    fun privatePlaintextVlessCanStillBeBuilt() {
        val link = "vless://00000000-0000-0000-0000-000000000001@10.0.0.2:8080?security=none&encryption=none&type=tcp"
        assertNotNull(XrayConfigBuilder.build(server(link, "10.0.0.2", 8080), "10.0.0.2"))
    }

    @Test
    fun publicPlaintextTrojanIsRejectedBeforeXrayStart() {
        val link = "trojan://secret@198.51.100.22:443?security=none&type=tcp"
        assertNull(XrayConfigBuilder.build(server(link, "198.51.100.22", 443, "TROJAN"), "198.51.100.22"))
    }

    @Test
    fun modernTlsAndXhttpShareFieldsArePreserved() {
        val extra = "%7B%22xPaddingBytes%22%3A%22100-1000%22%7D"
        val link = "vless://00000000-0000-0000-0000-000000000001@example.com:443" +
            "?security=tls&sni=cdn.example.com&fp=chrome&type=xhttp&host=cdn.example.com&path=%2Fapi" +
            "&mode=auto&pcs=sha256-pin&vcn=cdn.example.com&ech=ech-config&echForceQuery=full" +
            "&allowInsecure=1&extra=$extra"

        val config = XrayConfigBuilder.build(server(link, "example.com", 443), "203.0.113.7")
        assertNotNull(config)

        val proxy = JSONObject(config!!).getJSONArray("outbounds").getJSONObject(0)
        val stream = proxy.getJSONObject("streamSettings")
        val tls = stream.getJSONObject("tlsSettings")
        val xhttp = stream.getJSONObject("xhttpSettings")

        assertEquals("sha256-pin", tls.getString("pinnedPeerCertSha256"))
        assertEquals("cdn.example.com", tls.getString("verifyPeerCertByName"))
        assertEquals("ech-config", tls.getString("echConfigList"))
        assertEquals("full", tls.getString("echForceQuery"))
        assertFalse(tls.has("allowInsecure"))

        assertEquals("/api", xhttp.getString("path"))
        assertEquals("cdn.example.com", xhttp.getString("host"))
        assertEquals("auto", xhttp.getString("mode"))
        assertEquals("100-1000", xhttp.getJSONObject("extra").getString("xPaddingBytes"))
    }

    @Test
    fun realityPostQuantumVerificationFieldIsPreserved() {
        val link = "vless://00000000-0000-0000-0000-000000000001@example.com:443" +
            "?security=reality&type=tcp&sni=www.example.com&fp=chrome&pbk=public-key" +
            "&sid=abcd&spx=%2F&pqv=mldsa65-key"

        val config = XrayConfigBuilder.build(server(link, "example.com", 443), "203.0.113.8")
        assertNotNull(config)

        val proxy = JSONObject(config!!).getJSONArray("outbounds").getJSONObject(0)
        val reality = proxy.getJSONObject("streamSettings").getJSONObject("realitySettings")
        assertEquals("mldsa65-key", reality.getString("mldsa65Verify"))
    }

    @Test
    fun finalMaskJsonIsPreservedAtStreamLevel() {
        val fm = "%7B%22tcp%22%3A%5B%7B%22type%22%3A%22salamander%22%7D%5D%7D"
        val link = "vless://00000000-0000-0000-0000-000000000001@example.com:443" +
            "?security=tls&sni=example.com&type=tcp&fm=$fm"

        val config = XrayConfigBuilder.build(server(link, "example.com", 443), "203.0.113.9")
        assertNotNull(config)

        val proxy = JSONObject(config!!).getJSONArray("outbounds").getJSONObject(0)
        val stream = proxy.getJSONObject("streamSettings")
        assertEquals("salamander", stream.getJSONObject("finalmask")
            .getJSONArray("tcp").getJSONObject(0).getString("type"))
    }

    @Test
    fun malformedXhttpExtraIsRejectedInsteadOfSilentlyChanged() {
        val link = "vless://00000000-0000-0000-0000-000000000001@example.com:443" +
            "?security=tls&sni=example.com&type=xhttp&extra=not-json"
        assertNull(XrayConfigBuilder.build(server(link, "example.com", 443), "203.0.113.10"))
    }


    @Test fun realityRejectsIncompatibleTransportsWithoutChangingTheLink() {
        val base = "vless://00000000-0000-0000-0000-000000000001@example.com:443" +
            "?security=reality&sni=cdn.example.com&pbk=public-key&type="
        for (transport in listOf("ws", "websocket", "httpupgrade")) {
            assertNull(XrayConfigBuilder.build(server(base + transport, "example.com", 443), null))
        }
        for (transport in listOf("tcp", "raw", "grpc", "xhttp")) {
            assertNotNull(XrayConfigBuilder.build(server(base + transport, "example.com", 443), null))
        }
    }

    @Test fun websocketAliasPreservesProviderPathAndHost() {
        val link = "vless://00000000-0000-0000-0000-000000000001@example.com:443" +
            "?security=tls&type=websocket&path=%2Fvpn&host=cdn.example.com&sni=cdn.example.com"
        val stream = JSONObject(XrayConfigBuilder.build(server(link, "example.com", 443), null)!!)
            .getJSONArray("outbounds").getJSONObject(0).getJSONObject("streamSettings")
        assertEquals("ws", stream.getString("network"))
        assertEquals("/vpn", stream.getJSONObject("wsSettings").getString("path"))
        assertEquals("cdn.example.com", stream.getJSONObject("wsSettings").getJSONObject("headers").getString("Host"))
    }

    @Test fun hysteriaMaskIsNeverSilentlyDropped() {
        val base = "hy2://secret@example.com:443?sni=example.com"
        for (query in listOf("&obfs=salamander", "&obfs=salamander&obfs-password=",
            "&obfs=gecko&obfs-password=mask", "&obfs-password=mask", "&fm=not-json",
            "&obfs=salamander&obfs-password=mask&fm=%7B%7D")) {
            assertNull(XrayConfigBuilder.build(server(base + query, "example.com", 443, "HYSTERIA2"), null))
        }
        val config = XrayConfigBuilder.build(server(base + "&obfs=salamander&obfs-password=mask%2Bsecret",
            "example.com", 443, "HYSTERIA2"), null)!!
        val stream = JSONObject(config).getJSONArray("outbounds").getJSONObject(0).getJSONObject("streamSettings")
        val mask = stream.getJSONObject("finalmask").getJSONArray("udp").getJSONObject(0)
        assertEquals("salamander", mask.getString("type"))
        assertEquals("mask+secret", mask.getJSONObject("settings").getString("password"))
    }

    @Test fun hysteriaExplicitFinalMaskAndPlainModeRemainDistinct() {
        val base = "hysteria2://secret@example.com:443?sni=example.com"
        val fm = "%7B%22udp%22%3A%5B%7B%22type%22%3A%22salamander%22%2C%22settings%22%3A%7B%22password%22%3A%22mask%22%7D%7D%5D%7D"
        val config = JSONObject(XrayConfigBuilder.build(server(base + "&fm=$fm", "example.com", 443, "HYSTERIA2"), null)!!)
        val stream = config.getJSONArray("outbounds").getJSONObject(0).getJSONObject("streamSettings")
        assertEquals("mask", stream.getJSONObject("finalmask").getJSONArray("udp").getJSONObject(0)
            .getJSONObject("settings").getString("password"))
        val plain = JSONObject(XrayConfigBuilder.build(server(base, "example.com", 443, "HYSTERIA2"), null)!!)
        assertFalse(plain.getJSONArray("outbounds").getJSONObject(0).getJSONObject("streamSettings").has("finalmask"))
    }

}
