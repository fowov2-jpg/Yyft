package com.secureconnect.app

import com.secureconnect.app.data.model.Server
import com.secureconnect.app.viewmodel.ServerHealthLedger
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ServerHealthLedgerTest {
    private fun server(id: String, ping: Int = 50): Server = Server(
        id = id,
        country = "Test",
        city = id,
        flagEmoji = "🌐",
        protocol = "VLESS",
        ping = ping,
        host = "$id.example",
        port = 443,
        source = "source-$id",
        rawLink = "vless://user@$id.example:443?security=tls"
    )

    @Test
    fun failedPrimaryIsDemotedDuringCooldown() {
        var now = 1_000_000L
        val ledger = ServerHealthLedger { now }
        val primary = server("primary", 10)
        val unknown = server("unknown", 80)

        ledger.recordFailure(primary.id, "tls")

        val ranked = ledger.rank(listOf(primary, unknown))
        assertEquals("unknown", ranked.first().id)
        assertEquals("primary", ranked.last().id)
        assertTrue(ledger.entry(primary.id)!!.cooldownUntilMs > now)
    }

    @Test
    fun successfulHttpsCandidateIsPreferredAndEwmaUpdates() {
        var now = 2_000_000L
        val ledger = ServerHealthLedger { now }
        val a = server("a")
        val b = server("b")

        ledger.recordSuccess(b.id, 200)
        now += 1_000
        ledger.recordSuccess(b.id, 100)

        val ranked = ledger.rank(listOf(a, b))
        assertEquals("b", ranked.first().id)
        val ewma = ledger.entry(b.id)!!.ewmaHttpsMs!!
        assertTrue(ewma in 100.0..200.0)
        assertEquals(0, ledger.entry(b.id)!!.consecutiveFailures)
    }

    @Test
    fun cooldownEscalatesAndExpiredNodeBecomesEligibleAgain() {
        var now = 3_000_000L
        val ledger = ServerHealthLedger { now }
        val a = server("a")
        val b = server("b")

        ledger.recordFailure(a.id, "tls")
        now += 31_000L
        ledger.recordFailure(a.id, "tls")
        val second = ledger.entry(a.id)!!
        assertEquals(2, second.consecutiveFailures)
        assertEquals(now + 120_000L, second.cooldownUntilMs)

        assertEquals("b", ledger.rank(listOf(a, b)).first().id)

        now = second.cooldownUntilMs + 1L
        val ranked = ledger.rank(listOf(a, b))
        assertTrue(ranked.any { it.id == "a" })
        assertTrue(ranked.any { it.id == "b" })
    }

    @Test
    fun successClearsCooldownAfterFailures() {
        var now = 4_000_000L
        val ledger = ServerHealthLedger { now }
        val a = server("a")

        ledger.recordFailure(a.id, "http")
        now += 500L
        ledger.recordSuccess(a.id, 75)

        val entry = ledger.entry(a.id)!!
        assertEquals(0, entry.consecutiveFailures)
        assertEquals(0L, entry.cooldownUntilMs)
        assertEquals(null, entry.lastFailureStage)
    }

    @Test
    fun restoreClampsCorruptFutureCooldown() {
        val now = 5_000_000L
        val ledger = ServerHealthLedger { now }
        ledger.restore(
            listOf(
                ServerHealthLedger.Entry(
                    serverId = "a",
                    consecutiveFailures = 999,
                    cooldownUntilMs = Long.MAX_VALUE,
                    ewmaHttpsMs = Double.NaN
                )
            )
        )

        val entry = ledger.entry("a")!!
        assertEquals(32, entry.consecutiveFailures)
        assertTrue(entry.cooldownUntilMs <= now + 1_800_000L)
        assertEquals(null, entry.ewmaHttpsMs)
    }

    @Test
    fun failureStreakResetsAfterLongHealthyInterval() {
        var now = 6_000_000L
        val ledger = ServerHealthLedger { now }

        ledger.recordFailure("a", "tls")
        now += 1_800_001L
        ledger.recordFailure("a", "tls")

        val entry = ledger.entry("a")!!
        assertEquals(1, entry.consecutiveFailures)
        assertEquals(now + 30_000L, entry.cooldownUntilMs)
    }
    @Test
    fun failureAfterSuccessRemovesProvenHealthyPriority() {
        var now = 7_000_000L
        val ledger = ServerHealthLedger { now }
        val a = server("a")
        val b = server("b")

        ledger.recordSuccess(a.id, 100)
        now += 1_000L
        ledger.recordFailure(a.id, "tls")
        now = ledger.entry(a.id)!!.cooldownUntilMs + 1L

        assertTrue(!ledger.hasSuccessfulHistory(a.id))
        assertEquals("b", ledger.rank(listOf(a, b)).first().id)
    }

    @Test
    fun successfulHistoryExpiresAfterSixHours() {
        var now = 8_000_000L
        val ledger = ServerHealthLedger { now }
        val a = server("a")

        ledger.recordSuccess(a.id, 100)
        assertTrue(ledger.hasSuccessfulHistory(a.id))

        now += 21_600_001L
        assertTrue(!ledger.hasSuccessfulHistory(a.id))
    }

}
