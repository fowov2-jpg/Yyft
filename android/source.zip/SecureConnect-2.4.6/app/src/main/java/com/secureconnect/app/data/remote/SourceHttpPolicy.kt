package com.secureconnect.app.data.remote

import java.text.ParsePosition
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

internal object SourceHttpPolicy {
    fun pauseMs(code: Int, retryAfter: String?, now: Long): Long {
        val fallback = when (code) {
            403 -> 24L * 60L * 60L * 1000L
            429 -> 60L * 60L * 1000L
            else -> 15L * 60L * 1000L
        }
        val value = retryAfter?.trim().orEmpty()
        val seconds = value.takeIf { it.matches(Regex("[0-9]+")) }?.toLongOrNull()
        val requested = if (seconds != null) {
            seconds.coerceAtMost((Long.MAX_VALUE - now.coerceAtLeast(0L)) / 1000L) * 1000L
        } else {
            listOf("EEE, dd MMM yyyy HH:mm:ss zzz", "EEEE, dd-MMM-yy HH:mm:ss zzz", "EEE MMM d HH:mm:ss yyyy")
                .firstNotNullOfOrNull { pattern ->
                    val position = ParsePosition(0)
                    val date = SimpleDateFormat(pattern, Locale.US).apply {
                        timeZone = TimeZone.getTimeZone("GMT"); isLenient = false
                    }.parse(value, position)
                    date?.takeIf { position.index == value.length }?.time?.minus(now)?.coerceAtLeast(0L)
                } ?: 0L
        }
        return maxOf(fallback, requested)
    }
}
