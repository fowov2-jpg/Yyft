package com.secureconnect.app.ui.screens.settings

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import com.secureconnect.app.vpn.CloudVerifier
import com.secureconnect.app.vpn.PublicRankingFeed
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.secureconnect.app.data.model.Server
import com.secureconnect.app.ui.components.NativeActionRow
import com.secureconnect.app.ui.components.NativeGroup
import com.secureconnect.app.ui.components.NativeRowDivider
import com.secureconnect.app.ui.components.NativeSectionTitle
import com.secureconnect.app.ui.components.NativeSwitchRow
import com.secureconnect.app.ui.components.ScreenTopBar
import com.secureconnect.app.ui.screens.home.RiskTone
import com.secureconnect.app.ui.screens.home.RiskTonePolicy
import com.secureconnect.app.ui.theme.*
import com.secureconnect.app.viewmodel.MainViewModel
import com.secureconnect.app.vpn.LeakRiskCalculator
import com.secureconnect.app.vpn.VpnController

/**
 * Native M3 grouped lists. The UI is reactive and performs no network checks itself.
 * All VPN actions and routing semantics stay in the existing ViewModel.
 */
@Composable
fun PremiumSettingsScreen(vm: MainViewModel, onBack: () -> Unit) {
    val kill by vm.killSwitch.collectAsStateWithLifecycle()
    val autoRecovery by vm.autoRecovery.collectAsStateWithLifecycle()
    val autoConnect by vm.autoConnect.collectAsStateWithLifecycle()
    val routing by vm.appRouting.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var publicUrl by remember { mutableStateOf(PublicRankingFeed.endpoint(context)) }
    var publicNotice by remember { mutableStateOf(PublicRankingFeed.status(context)) }
    var cloudUrl by remember { mutableStateOf(CloudVerifier.endpoint(context)) }
    var cloudToken by remember { mutableStateOf("") }
    var cloudNotice by remember { mutableStateOf(
        if (CloudVerifier.isConfigured(context)) "Облачная проверка включена"
        else "Не настроено · используется локальная проверка"
    ) }

    Column(Modifier.fillMaxSize().background(ScBackground)) {
        ScreenTopBar("Настройки", onBack = onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(
                start = 18.dp, end = 18.dp, top = 14.dp, bottom = 28.dp
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { NativeSectionTitle("Подключение") }
            item {
                NativeGroup {
                    NativeSwitchRow(
                        "Автоподключение",
                        "Подключать VPN при запуске приложения",
                        autoConnect,
                        vm::setAutoConnect
                    )
                    NativeRowDivider()
                    NativeSwitchRow(
                        "Автовосстановление",
                        "Восстанавливать VPN при потере соединения",
                        autoRecovery,
                        vm::setAutoRecovery
                    )
                }
            }
            item { NativeSectionTitle("Безопасность и маршруты") }
            item {
                NativeGroup {
                    NativeSwitchRow(
                        "Kill Switch",
                        "Блокирующий режим для защищаемых приложений",
                        kill,
                        vm::setKillSwitch
                    )
                    NativeRowDivider()
                    NativeSwitchRow(
                        "Российские приложения напрямую",
                        "Автоматические исключения из VPN",
                        routing.autoExcludeRussian,
                        { vm.setRussianAutoBypass(it) }
                    )
                }
            }
            item { NativeSectionTitle("Производительность") }
            item {
                NativeGroup {
                    Row(Modifier.fillMaxWidth().padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("Экономия батареи", color = ScTextPrimary,
                                fontWeight = FontWeight.Medium,
                                style = MaterialTheme.typography.bodyLarge)
                            Text("Автоматически. Фоновый поиск спит, пока VPN работает.",
                                color = ScTextSecondary,
                                style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            item { NativeSectionTitle("Бесплатный рейтинг GitHub") }
            item {
                NativeGroup {
                    Column(Modifier.fillMaxWidth().padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Публичный рейтинг HTTPS", color = ScTextPrimary,
                            style = MaterialTheme.typography.titleMedium)
                        Text("Публичный GitHub feed отдаёт только рейтинг известных подписок. " +
                                "Xray проверяет выбранный сервер с телефона. " +
                                "При отсутствии свежего рейтинга поиск и восстановление работают локально.",
                            color = ScTextSecondary, style = MaterialTheme.typography.bodySmall)
                        OutlinedTextField(value = publicUrl, onValueChange = { publicUrl = it },
                            label = { Text("GitHub raw / Pages: feed.json") },
                            singleLine = true, modifier = Modifier.fillMaxWidth())
                        Button(onClick = {
                            publicNotice = runCatching {
                                PublicRankingFeed.configure(context, publicUrl)
                                PublicRankingFeed.status(context)
                            }.getOrElse { it.message ?: "Ошибка адреса" }
                        }) { Text("Сохранить адрес рейтинга") }
                        Text(publicNotice, color = ScTextSecondary,
                            style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item { NativeSectionTitle("Частная проверка (необязательно)") }
            item {
                NativeGroup {
                    Column(Modifier.fillMaxWidth().padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Доверенный сервер проверки",
                            color = ScTextPrimary,
                            style = MaterialTheme.typography.titleMedium)
                        Text("Необязательная функция. Публичные конфигурации " +
                                "передаются только на твой HTTPS-сервер с Xray. " +
                                "Ссылки из ручного импорта не отправляются. " +
                                "Результат дополнительно проверяется с телефона.",
                            color = ScTextSecondary,
                            style = MaterialTheme.typography.bodySmall)
                        OutlinedTextField(
                            value = cloudUrl,
                            onValueChange = { cloudUrl = it },
                            label = { Text("HTTPS-адрес") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = cloudToken,
                            onValueChange = { cloudToken = it },
                            label = { Text("Ключ API (оставь пустым, чтобы сохранить)") },
                            visualTransformation = PasswordVisualTransformation(),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Button(onClick = {
                            cloudNotice = runCatching {
                                CloudVerifier.configure(context, cloudUrl, cloudToken)
                                cloudToken = ""
                                if (CloudVerifier.isConfigured(context)) "Сохранено · проверка включена"
                                else "Выключено · используется локальная проверка"
                            }.getOrElse { it.message ?: "Ошибка настройки" }
                        }) { Text("Сохранить проверку") }
                        Text(cloudNotice, color = ScTextSecondary,
                            style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item {
                Text(
                    "Системная настройка Android «Блокировать подключения без VPN» " +
                        "может блокировать и приложения, исключённые из VPN.",
                    color = ScTextSecondary,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                )
            }
        }
    }
}

@Composable
fun PremiumSecurityScreen(
    vm: MainViewModel,
    onDiagnostics: () -> Unit,
    onSettings: () -> Unit
) {
    val vpnState by VpnController.state.collectAsStateWithLifecycle()
    val tls by VpnController.openAiTlsStatus.collectAsStateWithLifecycle()
    val activeServer by VpnController.activeServer.collectAsStateWithLifecycle()
    val killSwitch by vm.killSwitch.collectAsStateWithLifecycle()
    val autoRecovery by vm.autoRecovery.collectAsStateWithLifecycle()
    val routing by vm.appRouting.collectAsStateWithLifecycle()
    val tlsPresentation = TlsStatusUiPolicy.resolve(tls)
    val risk = LeakRiskCalculator.assess(
        state = vpnState, killSwitchEnabled = killSwitch,
        tlsStatus = tls, routingMode = routing.mode, hasActiveServer = activeServer != null
    )
    val tone = when (RiskTonePolicy.forIndex(risk.index)) {
        RiskTone.GREEN -> ScSuccess
        RiskTone.YELLOW -> ScWarning
        RiskTone.RED -> ScError
        RiskTone.UNKNOWN -> ScTextSecondary
    }

    Column(Modifier.fillMaxSize().background(ScBackground)) {
        ScreenTopBar("Безопасность")
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(
                start = 18.dp, end = 18.dp, top = 16.dp, bottom = 26.dp
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                NativeGroup {
                    Column(Modifier.fillMaxWidth().padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Индекс риска", style = MaterialTheme.typography.titleMedium,
                            color = ScTextPrimary, fontWeight = FontWeight.SemiBold)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(risk.index?.toString() ?: "—",
                                color = tone, style = MaterialTheme.typography.displaySmall)
                            Spacer(Modifier.width(8.dp))
                            Text("/ 100 · условная оценка",
                                color = ScTextSecondary, style = MaterialTheme.typography.bodySmall)
                        }
                        Box(Modifier.fillMaxWidth().height(5.dp)
                            .background(ScBorder, RoundedCornerShape(4.dp))) {
                            risk.index?.let { index ->
                                Box(Modifier.fillMaxWidth(index.coerceIn(0, 100) / 100f)
                                    .height(5.dp).background(tone, RoundedCornerShape(4.dp)))
                            }
                        }
                        Text("Не является измеренной вероятностью утечки.",
                            color = ScTextSecondary, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = ScWarning.copy(alpha = .10f),
                    border = BorderStroke(1.dp, ScWarning.copy(alpha = .29f))
                ) {
                    Column(Modifier.padding(horizontal = 18.dp, vertical = 15.dp),
                        verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("Проверка неполная", color = ScWarning,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold)
                        Text("DNS, IPv6 и Android TUN пока не прошли независимую " +
                            "проверку на утечки.",
                            color = ScTextSecondary, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item { NativeSectionTitle("Состояние защиты") }
            item {
                NativeGroup {
                    SecurityStatusRow("TLS через Xray", tlsPresentation.title,
                        tlsPresentation.detail)
                    NativeRowDivider()
                    SecurityStatusRow("Kill Switch",
                        if (killSwitch) "Включён" else "Выключен",
                        "Для приложений, направленных через VPN")
                    NativeRowDivider()
                    SecurityStatusRow("Автовосстановление",
                        if (autoRecovery) "Включено" else "Выключено",
                        "При потере соединения")
                }
            }
            item { NativeSectionTitle("Дополнительно") }
            item {
                NativeGroup {
                    NativeActionRow("Подробная диагностика",
                        "Проверки и состояние Xray", onClick = onDiagnostics)
                    NativeRowDivider()
                    NativeActionRow("Настройки защиты",
                        "Режимы работы и исключения", onClick = onSettings)
                }
            }
        }
    }
}

@Composable
private fun SecurityStatusRow(title: String, status: String, subtitle: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 15.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, color = ScTextPrimary,
                style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
            Text(subtitle, color = ScTextSecondary, style = MaterialTheme.typography.bodySmall)
        }
        Text(status, style = MaterialTheme.typography.labelMedium,
            color = when (status) {
                "Включён", "Включено", "Сертификат доверенный" -> ScSuccess
                "Выключен", "Выключено", "Ошибка сертификата" -> ScError
                else -> ScWarning
            },
            maxLines = 3,
            modifier = Modifier.width(108.dp))
    }
}

@Composable
fun PremiumServersScreen(vm: MainViewModel, onBack: () -> Unit) {
    val active by VpnController.activeServer.collectAsStateWithLifecycle()
    val working by vm.workingServers.collectAsStateWithLifecycle()
    val connecting by vm.isConnecting.collectAsStateWithLifecycle()
    var pendingPermissionServer by remember { mutableStateOf<Server?>(null) }
    var serverFeedback by remember { mutableStateOf<String?>(null) }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val candidate = pendingPermissionServer
        pendingPermissionServer = null
        if (result.resultCode == Activity.RESULT_OK && candidate != null) {
            serverFeedback = null
            vm.connectManualServer(candidate)
        } else if (candidate != null) {
            serverFeedback = "Android не предоставил разрешение VPN. Сервер не переключён."
        }
    }
    val chooseServer: (Server) -> Unit = { server ->
        if (!connecting) {
            val intent = vm.vpnPermissionIntent()
            if (intent == null) {
                serverFeedback = null
                vm.connectManualServer(server)
            } else {
                pendingPermissionServer = server
                permissionLauncher.launch(intent)
            }
        }
    }
    Column(Modifier.fillMaxSize().background(ScBackground)) {
        ScreenTopBar("Серверы", onBack = onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(
                start = 18.dp, end = 18.dp, top = 14.dp, bottom = 28.dp
            ),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            item {
                NativeGroup {
                    Column(Modifier.fillMaxWidth().padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("ОСНОВНОЙ МАРШРУТ", color = ScTextSecondary,
                            style = MaterialTheme.typography.labelSmall)
                        Text(active?.country?.takeIf { it.isNotBlank() } ?: "Нет подключения",
                            color = ScTextPrimary,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.SemiBold)
                        Text("Автоматический выбор предпочитает ранее проверенные серверы.",
                            color = ScTextSecondary, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item { NativeSectionTitle("Рабочие серверы · ${working.size}") }
            if (working.isEmpty()) item {
                Text("Рабочие серверы ещё не найдены.",
                    color = ScTextSecondary, style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(12.dp))
            }
            serverFeedback?.let { message ->
                item { Text(message, color = ScWarning,
                    modifier = Modifier.padding(10.dp),
                    style = MaterialTheme.typography.bodySmall) }
            }
            items(working.take(30), key = { it.id }) { server ->
                val isSelected = server.id == active?.id
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    color = if (isSelected) ScSuccessSoft else ScCard,
                    border = BorderStroke(1.dp,
                        if (isSelected) ScSuccess.copy(alpha = .46f)
                        else ScBorder.copy(alpha = .65f))
                ) {
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable(enabled = !connecting && pendingPermissionServer == null) {
                                chooseServer(server)
                            }
                            .padding(horizontal = 17.dp, vertical = 17.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(server.country.ifBlank { "Сервер" },
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = ScTextPrimary,
                                maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(if (isSelected) "Используется сейчас"
                                else "Выбрать вручную",
                                color = ScTextSecondary,
                                style = MaterialTheme.typography.bodySmall)
                        }
                        Text(if (isSelected) "●" else "›",
                            color = if (isSelected) ScSuccess else ScTextSecondary,
                            style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
        }
    }
}
