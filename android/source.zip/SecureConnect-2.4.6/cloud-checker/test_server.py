import json
import os
import unittest
from unittest.mock import patch

import server


class CloudVerifierContractTest(unittest.TestCase):
    def test_reject_private_targets(self):
        for address in ("127.0.0.1", "10.0.0.4", "192.168.0.2", "localhost", "metadata.google.internal"):
            self.assertFalse(server.validate_address(address), address)

    def test_reject_arbitrary_inbound(self):
        outbound = {
            "protocol": "vless", "tag": "proxy",
            "settings": {"vnext": [{"address": "1.1.1.1", "port": 443, "users": []}]},
        }
        self.assertTrue(server.validate_outbound(outbound))
        self.assertFalse(server.validate_outbound(dict(outbound, inbounds=[{"protocol": "dokodemo-door"}])))
        self.assertFalse(server.validate_outbound(dict(outbound, sendThrough="0.0.0.0")))
        self.assertFalse(server.validate_outbound(dict(outbound, streamSettings={"sockopt": {"dialerProxy": "direct"}})))

    def test_reject_unsupported_protocol_and_private_ip(self):
        outbound = {
            "protocol": "hysteria2",
            "settings": {"servers": [{"address": "1.1.1.1", "port": 443}]},
        }
        self.assertFalse(server.validate_outbound(outbound))
        outbound["protocol"] = "trojan"
        outbound["settings"]["servers"][0]["address"] = "169.254.169.254"
        self.assertFalse(server.validate_outbound(outbound))

    def test_memory_only_job_retention(self):
        server.JOBS["stale"] = {"state": "done", "at": 1, "results": []}
        server.purge_old_jobs()
        self.assertNotIn("stale", server.JOBS)


if __name__ == "__main__":
    unittest.main()
