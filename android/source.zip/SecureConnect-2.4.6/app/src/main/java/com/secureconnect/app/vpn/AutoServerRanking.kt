package com.secureconnect.app.vpn

/** Compare ONLY fresh/verified candidates. Speed has a stable, capped weight to avoid
 * choosing a distant server purely because one synthetic test reported a huge burst. */
object AutoServerRanking {
    data class Metrics(val id: String, val pingMs: Int, val downMbps: Double, val upMbps: Double)
    fun eligible(m: Metrics): Boolean = m.pingMs in 1..WorkingPoolPolicy.TARGET_RTT_MS &&
        VpnSpeedPolicy.classify(m.downMbps, m.upMbps) == VpnSpeedPolicy.Verdict.PASS
    fun score(m: Metrics): Double =
        60.0 * (m.downMbps.coerceAtMost(15.0) / 15.0) +
        15.0 * (m.upMbps.coerceAtMost(3.0) / 3.0) +
        25.0 * (100 - m.pingMs).coerceIn(0, 100) / 100.0
    fun choose(items: List<Metrics>): Metrics? = items.asSequence().filter(::eligible)
        .sortedWith(compareByDescending<Metrics> { score(it) }.thenBy { it.pingMs }.thenBy { it.id })
        .firstOrNull()
}
