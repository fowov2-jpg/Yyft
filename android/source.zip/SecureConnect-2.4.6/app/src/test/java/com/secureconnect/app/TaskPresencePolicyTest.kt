package com.secureconnect.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TaskPresencePolicyTest {
    @Test fun anUnobservedTaskIsNotAssumedRemoved() {
        val policy = TaskPresencePolicy()
        assertFalse(policy.record(false))
        assertFalse(policy.record(false))
    }

    @Test fun serviceRestartedAfterDismissalCanDetectMissingKnownTask() {
        val policy = TaskPresencePolicy(priorTaskWasKnown = true)
        assertFalse(policy.record(false))
        assertTrue(policy.record(false))
    }

    @Test fun homeKeepsVpnRunning() {
        val policy = TaskPresencePolicy()
        repeat(50) { assertFalse(policy.record(true)) }
    }

    @Test fun twoMissingTaskSnapshotsStopVpn() {
        val policy = TaskPresencePolicy()
        assertFalse(policy.record(true))
        assertFalse(policy.record(false))
        assertTrue(policy.record(false))
    }

    @Test fun quickReopenCancelsPendingClosure() {
        val policy = TaskPresencePolicy()
        assertFalse(policy.record(true))
        assertFalse(policy.record(false))
        assertFalse(policy.record(true))
        assertFalse(policy.record(false))
        assertTrue(policy.record(false))
    }
}
