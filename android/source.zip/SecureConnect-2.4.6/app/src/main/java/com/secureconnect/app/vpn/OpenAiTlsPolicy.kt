package com.secureconnect.app.vpn

import java.security.cert.CertificateException
import javax.net.ssl.SSLHandshakeException
import javax.net.ssl.SSLPeerUnverifiedException

/** Distinguish certificate failures from timeouts; never disable TLS verification. */
object OpenAiTlsPolicy {
    enum class Verdict { VERIFIED, CERTIFICATE_ERROR, UNAVAILABLE }

    fun isCertificateFailure(error: Throwable): Boolean {
        var cause: Throwable? = error
        repeat(10) {
            val current = cause ?: return false
            if (current is CertificateException || current is SSLPeerUnverifiedException) return true
            if (current is SSLHandshakeException &&
                listOf("certificate", "certpath", "trust anchor", "hostname", "no subject alternative")
                    .any { token -> current.message.orEmpty().contains(token, ignoreCase = true) }) return true
            cause = current.cause
        }
        return false
    }

    fun userStatus(verdict: Verdict): String = when (verdict) {
        Verdict.VERIFIED -> "TLS-сертификат Android ChatGPT: доверенный (без проверки pinning)"
        Verdict.CERTIFICATE_ERROR -> "ОПАСНО: сертификат Android ChatGPT не прошёл проверку"
        Verdict.UNAVAILABLE -> "TLS Android ChatGPT: не удалось проверить (не означает подмену)"
    }
}
