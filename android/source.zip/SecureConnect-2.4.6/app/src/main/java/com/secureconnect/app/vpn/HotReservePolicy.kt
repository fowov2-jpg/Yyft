package com.secureconnect.app.vpn

/** Hot = recently rechecked HTTPS through this server, NOT a permanent live tunnel. */
object HotReservePolicy {
    const val TARGET = 3
    const val CHECK_INTERVAL_MS = 60_000L
    const val EMBEDDED_CHECK_INTERVAL_MS = 3L * 60_000L
    // Certification lives between power-aware 5/15min checks.
    // A failure or network change invalidates it immediately.
    const val FRESHNESS_MS = 20L * 60_000L
    const val FAILED_COOLDOWN_MS = 3L * 60_000L

    fun fresh(now: Long, verifiedAt: Long): Boolean =
        verifiedAt > 0 && now >= verifiedAt && now - verifiedAt <= FRESHNESS_MS

    fun needsCheck(now: Long, checkedAt: Long): Boolean =
        checkedAt <= 0L || now < checkedAt || now - checkedAt >= CHECK_INTERVAL_MS

    fun order(eligible: List<String>, activeId: String?,
              certified: Map<String, Long>, now: Long): List<String> =
        eligible.asSequence().filter { it != activeId }.distinct()
            .sortedWith(compareByDescending<String> { fresh(now, certified[it] ?: 0L) }
                .thenByDescending { certified[it] ?: 0L })
            .take(TARGET).toList()
}
