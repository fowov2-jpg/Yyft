package com.secureconnect.app

import com.secureconnect.app.data.local.WorkingServerStore
import com.secureconnect.app.data.model.Server
import org.junit.Assert.*
import org.junit.Test

class WorkingServerStoreTest {
    private fun server(ping: Int) = Server(
        id = "working",
        country = "Test",
        city = "Node",
        flagEmoji = "🏁",
        protocol = "VLESS",
        ping = ping,
        host = "example.com",
        port = 443,
        source = "test",
        rawLink = "vless://id@example.com:443?security=reality&type=tcp"
    )

    @Test
    fun effectivePingUsesConnectRttInsteadOfHttpsWallClock() {
        val record = WorkingServerStore.Record(
            server = server(ping = 80),
            lastSuccessAtMs = 10L,
            ewmaHttpsMs = 547.0,
            ewmaConnectMs = 46.0
        )

        assertEquals(46, record.effectivePingMs())
    }

    @Test
    fun migratedRecordUsesStoredPingBeforeHttpsLatency() {
        val record = WorkingServerStore.Record(
            server = server(ping = 73),
            lastSuccessAtMs = 10L,
            ewmaHttpsMs = 640.0,
            ewmaConnectMs = null
        )

        assertEquals(73, record.effectivePingMs())
    }

    @Test fun olderDatabasesRetainSixtyCertifiedForeignServers() {
        val now = 10_000_000L
        val records = (0 until 130).map { index ->
            WorkingServerStore.Record(
                server = server(50).copy(id = "saved-$index",
                    country = if (index == 0) "Россия" else "Германия"),
                lastSuccessAtMs = now - index,
                lastFailureAtMs = if (index % 3 == 0) now else 0L,
                failures = if (index % 3 == 0) 1 else 0,
                ewmaHttpsMs = 500.0,
                youtubeVerifiedAtMs = now - index,
                speedVerifiedAtMs = now - index,
                verifiedDownloadMbps = 6.2,
                verifiedUploadMbps = 1.4
            )
        }
        val restored = WorkingServerStore.trimToPool(records, now)
        assertEquals(60, restored.size)
        assertTrue(restored.all { it.isActive(now) })
        assertTrue(restored.none { it.server.country == "Россия" })
    }

    @Test fun oldServerHistorySurvivesNewEligibilityRules() {
        val now = 1_000_000L
        val pastRu = WorkingServerStore.Record(
            server = server(90).copy(id = "historical-russian", country = "Россия"),
            lastSuccessAtMs = now - 100L, ewmaHttpsMs = 180.0,
            youtubeVerifiedAtMs = now - 100L,
            speedVerifiedAtMs = now - 100L,
            verifiedDownloadMbps = 9.0, verifiedUploadMbps = 3.0
        )
        val supported = pastRu.copy(server = server(110).copy(id = "supported", country = "Германия"))
        val retained = WorkingServerStore.trimToPool(listOf(pastRu, supported), now)
        // Retain history for future review/migration without routing traffic
        // through a node forbidden by today's automatic-selection policy.
        assertEquals(2, retained.size)
        assertFalse(pastRu.isActive(now))
        assertTrue(supported.isActive(now))
    }

    @Test fun migratedRecordCannotBecomeActiveWithoutYoutubeProof() {
        val legacy = WorkingServerStore.Record(server(50), 100L, ewmaHttpsMs = 400.0)
        assertFalse(legacy.isActive(200L))
        val tested = legacy.copy(youtubeVerifiedAtMs = 101L,
            speedVerifiedAtMs = 101L, verifiedDownloadMbps = 6.0, verifiedUploadMbps = 1.5)
        assertTrue(tested.isActive(200L))
    }

    @Test fun freshRecoveredRecordReentersReserveWithoutDiscardingHistory() {
        val failed = WorkingServerStore.Record(server(50), 100L, 200L, 500.0, failures = 2,
            youtubeVerifiedAtMs = 100L, speedVerifiedAtMs = 100L,
            verifiedDownloadMbps = 6.0, verifiedUploadMbps = 1.5)
        assertFalse(failed.isActive(200L))
        val recovered = failed.copy(lastSuccessAtMs = 200L, failures = 0)
        assertTrue(recovered.isActive(200L))
        assertEquals(200L, recovered.lastFailureAtMs)
    }

}
