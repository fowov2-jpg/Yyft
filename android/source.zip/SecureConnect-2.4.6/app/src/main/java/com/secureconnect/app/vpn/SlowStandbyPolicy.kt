package com.secureconnect.app.vpn

/** Reachable but over-target RTT is not a failed VPN, nor a verified 720p reserve. */
object SlowStandbyPolicy {
    const val MAX_STANDBY = 30
    const val RECHECK_MS = 6L * 60L * 60L * 1000L
    fun shouldPark(httpsMs: Int?, measuredSocksMs: Int?, youtubePassed: Boolean): Boolean =
        httpsMs != null && httpsMs > 0 && youtubePassed &&
            measuredSocksMs != null && measuredSocksMs > WorkingPoolPolicy.TARGET_RTT_MS
    fun due(nowMs: Long, lastCheckedMs: Long): Boolean =
        lastCheckedMs <= 0 || (nowMs >= lastCheckedMs && nowMs - lastCheckedMs >= RECHECK_MS)
}
