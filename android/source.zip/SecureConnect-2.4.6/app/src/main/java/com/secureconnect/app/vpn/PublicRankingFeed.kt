package com.secureconnect.app.vpn

import android.content.Context
import com.secureconnect.app.data.model.Server
import com.secureconnect.app.data.source.ConfigSources
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.URL
import java.time.Instant
import javax.net.ssl.HttpsURLConnection

/**
 * Non-authoritative PUBLIC ranking feed. Never downloads/provisions VPN URIs and
 * never records local/YouTube success. The phone must run its own VPN probe.
 */
object PublicRankingFeed {
    private const val PREFS = "sc_public_feed_v1"
    private const val URL_KEY = "url"
    private const val FEED_KEY = "validated_json"
    private const val ATTEMPT_KEY = "attempt_at"
    private const val STATUS_KEY = "status"
    private const val DEFAULT_ENDPOINT = "https://raw.githubusercontent.com/fowov2-jpg/Yyft/main/feed.json"
    private const val MAX_BYTES = 256 * 1024
    private const val REFRESH_MS = 90L * 60_000
    private const val ENTRY_TTL_MS = 8L * 60 * 60_000
    private const val CLOCK_SKEW_MS = 5L * 60_000
    private const val MAX_RESULTS = 180
    private val fingerprint = Regex("[a-f0-9]{64}")
    private val allowedSourceIds get() = ConfigSources.all.mapTo(HashSet()) { it.id }

    /** Prefer the verified public GitHub raw feed until GitHub Pages is enabled.
     * A user's explicitly saved empty address still disables cloud ranking.
     */
    fun endpoint(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(URL_KEY, DEFAULT_ENDPOINT) ?: DEFAULT_ENDPOINT

    fun validEndpoint(input: String): Boolean = try {
        val url = URL(input.trim())
        val host = url.host.lowercase(java.util.Locale.ROOT)
        val safeUrl = url.protocol == "https" && url.port == -1 &&
            url.userInfo == null && url.query == null && url.ref == null
        val pages = host.endsWith(".github.io") &&
            host.length > ".github.io".length &&
            host.substringBefore(".github.io").matches(Regex("[a-z0-9-]+")) &&
            url.path.matches(Regex("/[a-zA-Z0-9_.-]+/feed\\.json"))
        // Exact, immutable-looking project path; never accept arbitrary raw.github contents.
        val raw = host == "raw.githubusercontent.com" &&
            url.path == "/fowov2-jpg/Yyft/main/feed.json"
        safeUrl && (pages || raw)
    } catch (_: Exception) { false }

    fun configure(context: Context, address: String) {
        val clean = address.trim()
        require(clean.isEmpty() || validEndpoint(clean)) { "Нужен безопасный URL GitHub Pages или официальный raw feed SecureConnect" }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(URL_KEY, clean).remove(FEED_KEY).remove(ATTEMPT_KEY)
            .putString(STATUS_KEY, if (clean.isEmpty()) "Не настроено" else "Ожидает обновления")
            .apply()
    }

    fun status(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(STATUS_KEY, "Не настроено") ?: "Не настроено"

    fun lastPublished(context: Context): String = runCatching {
        JSONObject(validatedJson(context) ?: return "нет свежей публикации").getString("generated_at")
    }.getOrDefault("нет свежей публикации")

    /** Async, rate-limited and independent of the local scanner and connection path. */
    suspend fun refreshIfDue(context: Context): Boolean = withContext(Dispatchers.IO) {
        val endpoint = endpoint(context)
        if (!validEndpoint(endpoint)) return@withContext false
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val last = prefs.getLong(ATTEMPT_KEY, 0L)
        if (last > 0 && now >= last && now - last < REFRESH_MS) return@withContext false
        prefs.edit().putLong(ATTEMPT_KEY, now).apply()
        try {
            val conn = URL(endpoint).openConnection() as HttpsURLConnection
            try {
                conn.instanceFollowRedirects = false
                conn.connectTimeout = 5_000
                conn.readTimeout = 7_000
                conn.setRequestProperty("Accept", "application/json")
                conn.setRequestProperty("Accept-Encoding", "identity")
                if (conn.responseCode != 200) throw IllegalStateException("HTTP ${conn.responseCode}")
                val out = ByteArrayOutputStream()
                conn.inputStream.use { input ->
                    val buffer = ByteArray(4096)
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        if (out.size() + count > MAX_BYTES) throw IllegalStateException("Слишком большой JSON")
                        out.write(buffer, 0, count)
                    }
                }
                val payload = String(out.toByteArray(), Charsets.UTF_8)
                val entries = parseValid(payload, now) ?: throw IllegalStateException("Неверная схема или истёк срок")
                prefs.edit().putString(FEED_KEY, payload)
                    .putString(STATUS_KEY, "Публикация актуальна · записей HTTPS: ${entries.size}").apply()
                true
            } finally { conn.disconnect() }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // The previously validated feed remains available until its actual TTL.
            val reason = when {
                e.message?.startsWith("HTTP") == true -> e.message.orEmpty().take(36)
                e is java.net.SocketTimeoutException -> "Таймаут"
                else -> "Нет свежего JSON / сеть недоступна"
            }
            prefs.edit().putString(STATUS_KEY, "Локальный резерв: $reason").apply()
            false
        }
    }

    private data class Hint(val sourceId: String, val youtube: Boolean, val latency: Int)

    private fun millis(text: String): Long? = try {
        // UTC / RFC3339; reject local timestamps without explicit Z.
        if (!text.endsWith("Z")) null else Instant.parse(text).toEpochMilli()
    } catch (_: Exception) { null }

    private fun parseValid(text: String, now: Long): Map<String, Hint>? {
        return try {
        val root = JSONObject(text)
        if (root.opt("schema") !is Int || root.optInt("schema", -1) != 1 ||
            root.optString("checker") != "xray-github-actions") return null
        val generated = millis(root.optString("generated_at")) ?: return null
        val until = millis(root.optString("valid_until")) ?: return null
        if (generated > now + CLOCK_SKEW_MS || until <= now || until < generated ||
            until - generated > 6L * 60 * 60_000 + CLOCK_SKEW_MS) return null
        val results = root.optJSONArray("results") ?: return null
        if (results.length() > MAX_RESULTS) return null
        val ids = allowedSourceIds
        buildMap {
            for (i in 0 until results.length()) {
                val e = results.optJSONObject(i) ?: return null
                val fp = e.optString("fingerprint")
                val source = e.optString("source_id")
                val success = e.opt("https_ok")
                val video = e.opt("youtube_page_ok")
                val latency = e.opt("https_latency_ms")
                val checked = millis(e.optString("checked_at")) ?: return null
                if (!fingerprint.matches(fp) || source !in ids ||
                    success !is Boolean || video !is Boolean ||
                    latency !is Int || latency !in 0..30_000 ||
                    checked > now + CLOCK_SKEW_MS || now - checked !in 0L until ENTRY_TTL_MS) return null
                if (success) put(fp, Hint(source, video, latency))
            }
        }
        } catch (_: Exception) { null }
    }

    private fun validatedJson(context: Context): String? {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(FEED_KEY, null)
            ?: return null
        if (raw.toByteArray(Charsets.UTF_8).size > MAX_BYTES) return null
        return raw.takeIf { parseValid(it, System.currentTimeMillis()) != null }
    }

    /** Only candidates fetched from an existing, allowlisted PUBLIC catalogue. */
    fun priorities(context: Context, servers: List<Server>): Map<String, Int> {
        val raw = validatedJson(context) ?: return emptyMap()
        val hints = parseValid(raw, System.currentTimeMillis()) ?: return emptyMap()
        val sourceByName = ConfigSources.all.associate { it.name to it.id }
        val eligible = servers.mapNotNull { server ->
            val id = sourceByName[server.source] ?: return@mapNotNull null
            val link = server.rawLink.trim()
            if (link.isEmpty() || !link.substringBefore("://").lowercase().let {
                it in setOf("vless", "vmess", "trojan", "ss")
            }) return@mapNotNull null
            val hint = hints[NodeFingerprint.of(link)] ?: return@mapNotNull null
            if (hint.sourceId != id) return@mapNotNull null
            server.id to hint
        }
        return eligible.sortedWith(compareBy<Pair<String, Hint>> { !it.second.youtube }
            .thenBy { it.second.latency }).mapIndexed { index, pair -> pair.first to index }.toMap()
    }

    fun matchedCount(context: Context, servers: List<Server>): Int = priorities(context, servers).size
}
