package com.secureconnect.app.vpn

/**
 * Battery-first background scheduling for automatic VPN diagnostics.
 * An interval is a maximum cadence for optional work, not a replacement for
 * ConnectivityManager callbacks, on-failure recovery or Android's VPN routing.
 *
 * Android may delay Handler callbacks in Doze; never equate a missing periodic
 * sample with a proven-safe connection.
 */
object BatteryAwarePolicy {
    const val HEAVY_TEST_INTERVAL_MS = 2L * 60L * 60_000L
    const val RESERVE_SPEED_INTERVAL_MS = 2L * 60L * 60_000L
    const val DISCOVERY_PAUSE_MS = 30L * 60_000L

    /**
     * Display counters are useful only while the VPN UI is visible. A screen-on
     * phone running another app must not wake Xray just to refresh our UI.
     */
    fun trafficIntervalMs(interactive: Boolean, uiVisible: Boolean = interactive): Long =
        if (interactive && uiVisible) 10_000L else 10L * 60_000L

    /** Foreground notification rates need not be republished every UI sample. */
    const val NOTIFICATION_RATE_INTERVAL_MS = 30_000L

    /** Stagger large synthetic throughput audits instead of running a burst. */
    const val RESERVE_SPEED_ACTIVE_POLL_MS = 10L * 60_000L
    const val RESERVE_SPEED_TARGETS_PER_CYCLE = 1

    fun securityIntervalMs(interactive: Boolean): Long =
        if (interactive) 3L * 60_000L else 10L * 60_000L

    fun watchdogIntervalMs(interactive: Boolean): Long =
        if (interactive) 90_000L else 4L * 60_000L

    fun hotCheckIntervalMs(interactive: Boolean, powerSave: Boolean): Long = when {
        powerSave -> 60L * 60_000L
        interactive -> 15L * 60_000L
        else -> 45L * 60_000L
    }

    /** Synthetic transfer tests can consume megabytes; defer to charging Wi-Fi. */
    fun allowHeavyTests(interactive: Boolean, powerSave: Boolean,
                        charging: Boolean, unmetered: Boolean): Boolean =
        interactive && !powerSave && charging && unmetered

    /** Keep a small recovery pool on battery; populate full pool when inexpensive. */
    fun discoveryTarget(interactive: Boolean, powerSave: Boolean,
                        charging: Boolean, unmetered: Boolean, maxPool: Int): Int = when {
        powerSave || !interactive -> minOf(2, maxPool)
        // Eight certified routes are adequate for ordinary hot-failover.
        // A 21-node throughput-certified pool is expensive to build on a phone.
        allowHeavyTests(interactive, powerSave, charging, unmetered) -> minOf(5, maxPool)
        else -> minOf(2, maxPool)
    }
}
