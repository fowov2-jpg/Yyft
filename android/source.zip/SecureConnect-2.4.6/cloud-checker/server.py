#!/usr/bin/env python3
"""Private SecureConnect verifier; requires HTTPS reverse proxy and Xray-core.

Does not persist credentials, proxy configurations or logs. Memory-only results
expire after 15 min. Remote verified != reachable from a phone's ISP.
"""
import concurrent.futures
import hashlib
import hmac
import ipaddress
import json
import os
import secrets
import socket
import ssl
import subprocess
import tempfile
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

TOKEN = os.environ.get("SC_API_TOKEN", "")
XRAY = os.environ.get("XRAY_BIN", "/usr/local/bin/xray")
BIND = os.environ.get("SC_LISTEN", "127.0.0.1")
PORT = int(os.environ.get("SC_PORT", "8765"))
MAX_ITEMS = 36
MAX_BYTES = 128 * 1024
MAX_JOBS = 2
TTL = 15 * 60
POOL = concurrent.futures.ThreadPoolExecutor(max_workers=3)
LOCK = threading.RLock()
JOBS = {}
TEST_ENDPOINTS = (
    ("www.gstatic.com", "/generate_204"),
    ("www.youtube.com", "/"),
)


def validate_address(value):
    if not isinstance(value, str) or not (1 <= len(value) <= 250):
        return False
    if any(c.isspace() for c in value) or "/" in value or "@" in value:
        return False
    try:
        ip = ipaddress.ip_address(value.strip("[]"))
        return ip.is_global
    except ValueError:
        if value.endswith(".local") or value.lower() == "localhost":
            return False
        # No internal-use hostnames are allowed, even if the DNS currently fails.
        if "." not in value or not all(part and len(part) <= 63 for part in value.split(".")):
            return False
        try:
            resolved = socket.getaddrinfo(value, 443, type=socket.SOCK_STREAM)
        except OSError:
            return False
        return bool(resolved) and all(
            ipaddress.ip_address(record[4][0]).is_global for record in resolved
        )


def validate_outbound(obj):
    if not isinstance(obj, dict):
        return False
    if obj.get("protocol") not in {"vless", "vmess", "trojan", "shadowsocks"}:
        # UDP-only protocols must be validated with a separate supported core.
        return False
    if set(obj) - {"protocol", "tag", "settings", "streamSettings"}:
        return False
    if obj.get("tag") not in (None, "proxy"):
        return False
    settings = obj.get("settings")
    if not isinstance(settings, dict):
        return False
    destinations = settings.get("vnext", settings.get("servers", []))
    if not isinstance(destinations, list) or len(destinations) != 1:
        return False
    target = destinations[0]
    if not isinstance(target, dict):
        return False
    addr = target.get("address")
    port = target.get("port")
    if not isinstance(port, int) or not 1 <= port <= 65535:
        return False
    if not validate_address(addr):
        return False
    # Prevent accidental proxy bypass from attacker-supplied dialer rules.
    stream = obj.get("streamSettings", {})
    if not isinstance(stream, dict) or "sockopt" in stream:
        return False
    return True


def reserve_port():
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


def socks_http(port, host, path, timeout=5):
    """Perform TLS-verifying HTTPS GET THROUGH the Xray SOCKS exit."""
    start = time.monotonic()
    with socket.create_connection(("127.0.0.1", port), timeout=timeout) as raw:
        raw.settimeout(timeout)
        raw.sendall(b"\x05\x01\x00")
        if raw.recv(2) != b"\x05\x00":
            raise OSError("SOCKS auth failed")
        host_bytes = host.encode("ascii")
        raw.sendall(b"\x05\x01\x00\x03" + bytes([len(host_bytes)]) +
                    host_bytes + (443).to_bytes(2, "big"))
        head = read_exact(raw, 4)
        if head[1] != 0:
            raise OSError("SOCKS outbound rejected connection")
        addr_type = head[3]
        if addr_type == 1:
            read_exact(raw, 4)
        elif addr_type == 4:
            read_exact(raw, 16)
        elif addr_type == 3:
            read_exact(raw, read_exact(raw, 1)[0])
        else:
            raise OSError("bad SOCKS address")
        read_exact(raw, 2)
        # Standard system trust store, hostname verification ON.
        with ssl.create_default_context().wrap_socket(raw, server_hostname=host) as tls:
            tls.settimeout(timeout)
            tls.sendall(
                f"GET {path} HTTP/1.1\r\nHost: {host}\r\n"
                "Connection: close\r\nUser-Agent: SecureConnect-Checker/1\r\n\r\n".encode()
            )
            status = tls.recv(256).split(b"\r\n", 1)[0]
        if not status.startswith(b"HTTP/"):
            raise OSError("bad HTTP response")
        code = int(status.split()[1])
        return code, round((time.monotonic() - start) * 1000)


def read_exact(sock, amount):
    buf = bytearray()
    while len(buf) < amount:
        part = sock.recv(amount - len(buf))
        if not part:
            raise OSError("SOCKS connection closed")
        buf.extend(part)
    return bytes(buf)


def wait_port(port, process):
    until = time.monotonic() + 3.5
    while time.monotonic() < until:
        if process.poll() is not None:
            return False
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=.15):
                return True
        except OSError:
            time.sleep(.08)
    return False


def check_one(candidate):
    result = {"id": candidate["id"], "https": False,
              "youtube": False, "latency_ms": None}
    port = reserve_port()
    config = {
        "log": {"loglevel": "none"},
        "inbounds": [{
            "tag": "check-socks", "listen": "127.0.0.1", "port": port,
            "protocol": "socks", "settings": {"auth": "noauth", "udp": False},
        }],
        "outbounds": [candidate["outbound"]],
    }
    # tmpfs is recommended for the container's /tmp mount.
    path = None
    process = None
    try:
        fd, path = tempfile.mkstemp(prefix="sc-xray-", suffix=".json")
        with os.fdopen(fd, "w", encoding="utf-8") as config_file:
            json.dump(config, config_file, separators=(",", ":"))
        process = subprocess.Popen(
            [XRAY, "run", "-c", path],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            close_fds=True,
        )
        if not wait_port(port, process):
            return result
        code, ms = socks_http(port, *TEST_ENDPOINTS[0])
        if code == 204:
            result.update(https=True, latency_ms=ms)
            try:
                yt_code, _ = socks_http(port, *TEST_ENDPOINTS[1])
                result["youtube"] = yt_code in (200, 301, 302, 303, 307, 308)
            except (OSError, ssl.SSLError, ValueError, TimeoutError):
                pass
    except (OSError, ssl.SSLError, ValueError, TimeoutError, subprocess.SubprocessError):
        pass
    finally:
        if process is not None:
            process.terminate()
            try:
                process.wait(timeout=1.5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
        if path:
            try:
                os.unlink(path)
            except OSError:
                pass
    return result


def do_job(job_id, candidates):
    with LOCK:
        JOBS[job_id]["state"] = "running"
    try:
        results = list(POOL.map(check_one, candidates))
        results.sort(key=lambda item: (
            not (item["https"] and item["youtube"]),
            not item["https"],
            item["latency_ms"] if item["latency_ms"] is not None else 999999,
        ))
        with LOCK:
            JOBS[job_id].update(state="done", results=results)
    except Exception:
        with LOCK:
            JOBS[job_id].update(state="error", results=[])


class API(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        # Do not log proxy configs or user credentials.
        return

    def reply(self, code, value):
        data = json.dumps(value, separators=(",", ":")).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def authorized(self):
        header = self.headers.get("Authorization", "")
        supplied = header.removeprefix("Bearer ") if header.startswith("Bearer ") else ""
        return bool(TOKEN) and hmac.compare_digest(supplied, TOKEN)

    def do_GET(self):
        if not self.authorized():
            return self.reply(401, {"error": "unauthorized"})
        parts = self.path.split("/")
        if len(parts) != 4 or parts[1:3] != ["v1", "jobs"]:
            return self.reply(404, {"error": "not found"})
        with LOCK:
            purge_old_jobs()
            item = JOBS.get(parts[3])
            if item is None:
                return self.reply(404, {"error": "expired"})
            return self.reply(200, {
                "state": item["state"],
                "results": item.get("results", []) if item["state"] == "done" else [],
            })

    def do_POST(self):
        if not self.authorized():
            return self.reply(401, {"error": "unauthorized"})
        if self.path != "/v1/jobs":
            return self.reply(404, {"error": "not found"})
        size = self.headers.get("Content-Length", "")
        if not size.isdecimal() or not 0 < int(size) <= MAX_BYTES:
            return self.reply(413, {"error": "payload too large"})
        try:
            payload = json.loads(self.rfile.read(int(size)))
            candidates = payload["candidates"]
        except (ValueError, KeyError, TypeError):
            return self.reply(400, {"error": "invalid JSON"})
        if not isinstance(candidates, list) or not 1 <= len(candidates) <= MAX_ITEMS:
            return self.reply(400, {"error": "invalid candidate count"})
        checked = []
        seen = set()
        for item in candidates:
            if not isinstance(item, dict) or not isinstance(item.get("id"), str):
                return self.reply(400, {"error": "invalid candidate"})
            ident = item["id"]
            if not 1 <= len(ident) <= 128 or ident in seen:
                return self.reply(400, {"error": "invalid candidate id"})
            if not validate_outbound(item.get("outbound")):
                # Unsupported/suspicious configs are not run as processes.
                continue
            seen.add(ident)
            checked.append({"id": ident, "outbound": item["outbound"]})
        if not checked:
            return self.reply(422, {"error": "no supported outbounds"})
        with LOCK:
            purge_old_jobs()
            running = sum(1 for x in JOBS.values() if x["state"] in ("queued", "running"))
            if running >= MAX_JOBS:
                return self.reply(429, {"error": "checker busy"})
            job_id = str(uuid.uuid4())
            JOBS[job_id] = {"state": "queued", "at": time.time(), "results": []}
        threading.Thread(target=do_job, args=(job_id, checked), daemon=True).start()
        return self.reply(202, {"job": job_id, "submitted": len(checked)})


def purge_old_jobs():
    now = time.time()
    for key in list(JOBS):
        if now - JOBS[key]["at"] > TTL and JOBS[key]["state"] not in ("running", "queued"):
            del JOBS[key]


if __name__ == "__main__":
    if not TOKEN or len(TOKEN) < 32:
        raise SystemExit("Set SC_API_TOKEN to a random value of at least 32 chars")
    print(f"SecureConnect Xray cloud checker listening on {BIND}:{PORT} (HTTPS reverse proxy required)")
    ThreadingHTTPServer((BIND, PORT), API).serve_forever()
