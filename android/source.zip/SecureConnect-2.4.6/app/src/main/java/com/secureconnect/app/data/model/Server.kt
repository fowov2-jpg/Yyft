package com.secureconnect.app.data.model

/** Конфигурация узла и результаты измерений. */
data class Server(
    val id: String,
    val country: String,          // "Нидерланды"
    val city: String,             // "Amsterdam"
    val flagEmoji: String,        // "🇳🇱"
    val protocol: String,         // "TLS", "VLESS", ...
    val ping: Int,                // мс; 0 = ещё не измерен
    val isFavorite: Boolean = false,
    val host: String = "",
    val port: Int = 0,
    val source: String = "",      // название источника
    val rawLink: String = "",     // исходная ссылка конфига (vless://, vmess:// ...)
    val reportedPingMs: Int? = null, // Source label, never a local measurement.
    val reportedLoadPercent: Double? = null
)
