package com.secureconnect.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.secureconnect.app.ui.theme.ScBorder
import com.secureconnect.app.ui.theme.ScCard
import com.secureconnect.app.ui.theme.ScError
import com.secureconnect.app.ui.theme.ScSuccess
import com.secureconnect.app.ui.theme.ScTextSecondary
import com.secureconnect.app.ui.theme.ScWarning
import com.secureconnect.app.vpn.LeakRiskAssessment

/** User-facing risk indicator with caveat, never presented as measured leak probability. */
@Composable
fun LeakRiskCard(
    assessment: LeakRiskAssessment,
    onDetails: () -> Unit,
    showButton: Boolean = true,
    lastCheckedAtMs: Long = 0L,
    compact: Boolean = false
) {
    val severityColor = when {
        assessment.index == null -> ScTextSecondary
        assessment.index >= 60 -> ScError
        assessment.index >= 33 -> ScWarning
        else -> ScSuccess
    }
    if (compact) {
        // Only the index is visible by default. Everything else is user-expandable;
        // the actual network diagnostics stay on the separate diagnostics screen.
        var expanded by rememberSaveable { mutableStateOf(false) }
        Column(
            modifier = Modifier.fillMaxWidth()
                .border(1.dp, ScBorder, RoundedCornerShape(16.dp))
                .background(ScCard, RoundedCornerShape(16.dp))
        ) {
            Row(
                modifier = Modifier.fillMaxWidth()
                    .clickable(role = Role.Button) { expanded = !expanded }
                    .padding(horizontal = 14.dp, vertical = 15.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = assessment.index?.let { "Индекс риска утечки: $it%" }
                        ?: "Индекс риска: не проверено",
                    color = severityColor,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    if (expanded) "Скрыть ▲" else "Подробнее ▼",
                    color = ScTextSecondary,
                    style = MaterialTheme.typography.labelSmall
                )
            }
            if (expanded) {
                Column(modifier = Modifier.padding(start = 14.dp, end = 14.dp, bottom = 14.dp)) {
                    Text(
                        assessment.level,
                        color = severityColor,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(6.dp))
                    assessment.details.forEach { detail ->
                        Text(
                            "• $detail",
                            color = MaterialTheme.colorScheme.onSurface,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Spacer(Modifier.height(5.dp))
                    }
                    Text(
                        "Процент — диагностический индекс, не измеренная вероятность утечки. " +
                            "Для подтверждения DNS/IPv6/TUN-утечек нужны отдельные проверки.",
                        color = ScTextSecondary,
                        style = MaterialTheme.typography.bodySmall
                    )
                    if (lastCheckedAtMs > 0L) {
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Контроль: " + java.text.DateFormat.getTimeInstance(
                                java.text.DateFormat.SHORT
                            ).format(java.util.Date(lastCheckedAtMs)),
                            color = ScTextSecondary,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                    if (showButton) {
                        Spacer(Modifier.height(10.dp))
                        OutlinedButton(onClick = onDetails, modifier = Modifier.fillMaxWidth()) {
                            Text("Полная диагностика")
                        }
                    }
                }
            }
        }
        return
    }
    Column(
        modifier = Modifier.fillMaxWidth()
            .border(1.dp, ScBorder, RoundedCornerShape(18.dp))
            .background(ScCard, RoundedCornerShape(18.dp))
            .padding(16.dp)
    ) {
        Text(
            text = assessment.index?.let { "Индекс риска утечки: $it%" }
                ?: "Индекс риска: нет оценки",
            color = severityColor,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleLarge
        )
        Spacer(Modifier.height(5.dp))
        Text(
            assessment.level,
            color = severityColor,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(Modifier.height(8.dp))
        Text(
            assessment.details.firstOrNull().orEmpty(),
            color = MaterialTheme.colorScheme.onSurface,
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(5.dp))
        Text(
            "Это условный индекс по настройкам и диагностике, а не вероятность утечки. " +
                "Российские приложения из исключений подключаются напрямую.",
            color = ScTextSecondary,
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(6.dp))
        Text(
            if (lastCheckedAtMs > 0L)
                "Автоматический контроль работает · последняя проверка: " +
                    java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT).format(
                        java.util.Date(lastCheckedAtMs))
            else "Автоматический контроль начнётся при активном VPN.",
            color = ScTextSecondary,
            style = MaterialTheme.typography.bodySmall
        )
        if (showButton) {
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick = onDetails, modifier = Modifier.fillMaxWidth()) {
                Text("Почему такая оценка?")
            }
        }
    }
}
