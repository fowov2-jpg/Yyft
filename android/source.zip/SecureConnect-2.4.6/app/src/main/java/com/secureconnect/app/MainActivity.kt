package com.secureconnect.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import android.content.Intent
import androidx.lifecycle.ViewModelProvider
import com.secureconnect.app.ui.navigation.AppNavigation
import com.secureconnect.app.ui.theme.SecureConnectTheme
import com.secureconnect.app.viewmodel.MainViewModel
import com.secureconnect.app.vpn.VpnController
import com.secureconnect.app.vpn.VpnState
import com.secureconnect.app.vpn.XrayVpnService
import com.secureconnect.app.vpn.ScannerUiVisibility
import com.secureconnect.app.vpn.ServerScanner

class MainActivity : ComponentActivity() {

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        // Permission result is intentionally not logged to Android logcat.
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppRunController.opened(this)
        reconcileVpnOnOpen()

        val crash = getSharedPreferences(SecureConnectApplication.PREFS, MODE_PRIVATE)
            .getString(SecureConnectApplication.KEY_CRASH, null)
        val crashThread = getSharedPreferences(SecureConnectApplication.PREFS, MODE_PRIVATE)
            .getString(SecureConnectApplication.KEY_CRASH_THREAD, null)

        // Consume only the crash marker. Do not clear real application settings.
        getSharedPreferences(SecureConnectApplication.PREFS, MODE_PRIVATE).edit()
            .remove(SecureConnectApplication.KEY_CRASH)
            .remove(SecureConnectApplication.KEY_CRASH_THREAD)
            .apply()

        try {
            if (crash != null) {
                // Не используем Compose для экрана диагностики: даже при поломке Compose
                // пользователь всё равно должен увидеть точную причину прошлого падения.
                showNativeCrashReport(
                    buildString {
                        if (!crashThread.isNullOrBlank()) appendLine("Поток: $crashThread")
                        append(crash)
                    }
                )
            } else {
                // Create the ViewModel before Compose. This makes constructor/init failures catchable.
                val vm = ViewModelProvider(
                    this,
                    ViewModelProvider.AndroidViewModelFactory.getInstance(application)
                ).get(MainViewModel::class.java)
                setContent { SecureConnectTheme { AppNavigation(vm) } }
                requestNotificationPermissionIfNeeded()
            }
        } catch (t: Throwable) {
            Log.e("SecureConnect", "Fatal startup", t)
            showNativeError("Ошибка запуска", t)
        }
    }

    /** Ask the service for the actual TUN state after a process/Activity recreation.
     * VpnService.prepare() checks permission, NOT whether a tunnel is connected.
     */
    private fun reconcileVpnOnOpen() {
        val hadSession = getSharedPreferences("sc_vpn_service_session", MODE_PRIVATE)
            .getBoolean("active", false)
        // The previous task can have cleared the persistence marker while its
        // foreground VPN service is STILL holding the TUN. Inspect that service
        // before trusting in-memory Idle or any SharedPreferences flag.
        if (XrayVpnService.reconcileLiveService()) return
        if (!hadSession || VpnController.state.value != VpnState.Idle) return
        VpnController.state.value = VpnState.Connecting
        runCatching {
            startService(Intent(this, XrayVpnService::class.java)
                .setAction(XrayVpnService.ACTION_RECONCILE_STATE))
        }.onFailure {
            Log.w("SecureConnect", "Could not reconcile restored VPN state", it)
            VpnController.state.value = VpnState.Idle
        }
    }

    override fun onResume() {
        super.onResume()
        ScannerUiVisibility.visible = true
        // Refresh stale subscription metadata on return, without a full probe storm.
        ServerScanner.requestUiRefresh(this)
        // A returning Activity may not be recreated. Reconcile with the live
        // foreground VpnService every time, never infer a tunnel from permission.
        reconcileVpnOnOpen()
        XrayVpnService.notifyUiVisibilityChanged(true)
    }

    override fun onPause() {
        ScannerUiVisibility.visible = false
        ServerScanner.request()
        XrayVpnService.notifyUiVisibilityChanged(false)
        super.onPause()
    }

    override fun onDestroy() {
        if (isFinishing && !isChangingConfigurations) {
            AppRunController.closed(this)
        }
        super.onDestroy()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun showNativeError(title: String, throwable: Throwable) {
        showNativeCrashReport(
            "$title\n\n${throwable.javaClass.name}: ${throwable.message}\n\n${Log.getStackTraceString(throwable)}",
            title
        )
    }

    private fun showNativeCrashReport(details: String, title: String = "Предыдущий запуск завершился ошибкой") {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(32, 48, 32, 32)
            setBackgroundColor(Color.rgb(11, 18, 32))
        }

        val titleView = TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            textSize = 20f
            setPadding(0, 0, 0, 24)
        }

        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        }
        val detailsView = TextView(this).apply {
            text = details
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(0, 0, 0, 24)
        }
        scroll.addView(detailsView)

        val continueButton = Button(this).apply {
            text = "Запустить приложение"
            setOnClickListener {
                try {
                    val vm = ViewModelProvider(
                        this@MainActivity,
                        ViewModelProvider.AndroidViewModelFactory.getInstance(application)
                    ).get(MainViewModel::class.java)
                    setContent { SecureConnectTheme { AppNavigation(vm) } }
                    } catch (t: Throwable) {
                    Log.e("SecureConnect", "Failed after diagnostic screen", t)
                    showNativeError("Ошибка запуска", t)
                }
            }
        }

        root.addView(titleView)
        root.addView(scroll)
        root.addView(continueButton)
        setContentView(root)
    }

}
