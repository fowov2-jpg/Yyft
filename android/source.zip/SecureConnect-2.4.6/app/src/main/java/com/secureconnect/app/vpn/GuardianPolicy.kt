package com.secureconnect.app.vpn

import com.secureconnect.app.data.model.Server
import com.secureconnect.app.data.model.ServerTransport
import kotlin.math.roundToInt

/**
 * Pure decision policy for the foreground Guardian.
 *
 * Keeping these rules free of Android/service state makes the failover hysteresis
 * deterministic and unit-testable.
 */
object GuardianPolicy {
    const val TARGET_RTT_MS = 100
    const val POOR_RTT_MS = 180
    const val ABSOLUTE_POOR_HTTPS_MS = 6_000

    private const val MIN_WATCHDOG_TIMEOUT_MS = 3_000
    private const val MAX_WATCHDOG_TIMEOUT_MS = 6_000

    /**
     * A server that was proven at 2.5-3s must not be judged by a shorter 2.2s
     * watchdog timeout. Give the established baseline ~1.8x headroom, bounded so
     * a truly dead path still fails in finite time.
     */
    fun watchdogIoTimeoutMs(baselineHttpsMs: Double?): Int {
        val baseline = baselineHttpsMs
            ?.takeIf { it.isFinite() && it > 0.0 }
            ?: return MIN_WATCHDOG_TIMEOUT_MS
        return (baseline * 1.8)
            .roundToInt()
            .coerceIn(MIN_WATCHDOG_TIMEOUT_MS, MAX_WATCHDOG_TIMEOUT_MS)
    }

    /**
     * Local SOCKS disappearing means Xray itself is gone and should recover
     * immediately. A recently proven server gets extra hysteresis for remote
     * TLS/HTTP failures because mobile/CDN paths often have brief loss bursts.
     */
    fun requiredFailureSamples(stage: String, recentlyProven: Boolean): Int = when {
        stage == "socks_ready" -> 1
        recentlyProven -> 3
        else -> 2
    }

    /**
     * RTT is the primary quality signal. Full HTTPS latency is intentionally only
     * an emergency secondary signal: TLS handshakes can be slow while RTT and
     * actual traffic remain healthy.
     */
    fun isPoorQualitySample(
        connectMs: Int?,
        httpsMs: Int?,
        baselineHttpsMs: Double?
    ): Boolean {
        if (connectMs != null && connectMs > POOR_RTT_MS) return true
        if (httpsMs == null) return false
        val dynamicHttpsLimit = baselineHttpsMs
            ?.takeIf { it.isFinite() && it > 0.0 }
            ?.times(2.2)
            ?.roundToInt()
            ?.coerceAtLeast(ABSOLUTE_POOR_HTTPS_MS)
            ?: ABSOLUTE_POOR_HTTPS_MS
        return httpsMs > dynamicHttpsLimit
    }


    /**
     * Recovery retries stay responsive while an underlay exists, but back off hard
     * when Wi-Fi/LTE is completely absent. NetworkCallback.onAvailable triggers an
     * immediate retry, so the long no-network delay costs no reconnection latency.
     */
    fun recoveryRetryDelayMs(retry: Int, hasPhysicalNetwork: Boolean): Long {
        if (!hasPhysicalNetwork) return 60_000L
        return when (retry.coerceAtLeast(1)) {
            1 -> 5_000L
            2 -> 10_000L
            3 -> 20_000L
            4 -> 40_000L
            else -> 60_000L
        }
    }
    fun routeFingerprint(server: Server): String =
        "${server.host.trim().lowercase()}:${server.port}|${ServerTransport.family(server)}"

    /**
     * Spread a failover burst across independent sources/transport families before
     * repeatedly probing one subscription family. Original order remains the final
     * tie-breaker, so <=100ms and "Рабочие" tiers from the caller are preserved.
     */
    fun diversify(candidates: List<Server>): List<Server> {
        if (candidates.size <= 2) return candidates.distinctBy(::routeFingerprint)

        val unique = candidates.distinctBy(::routeFingerprint).toMutableList()
        val originalIndex = unique.withIndex().associate { it.value.id to it.index }
        val sourceCount = HashMap<String, Int>()
        val familyCount = HashMap<String, Int>()
        val out = ArrayList<Server>(unique.size)

        while (unique.isNotEmpty()) {
            val best = unique.minWithOrNull(
                compareBy<Server> { sourceCount[it.source] ?: 0 }
                    .thenBy { familyCount[ServerTransport.family(it)] ?: 0 }
                    .thenBy { originalIndex[it.id] ?: Int.MAX_VALUE }
            ) ?: break
            unique.remove(best)
            out += best
            sourceCount[best.source] = (sourceCount[best.source] ?: 0) + 1
            val family = ServerTransport.family(best)
            familyCount[family] = (familyCount[family] ?: 0) + 1
        }
        return out
    }
}
