package com.secureconnect.app.data.model

/**
 * Stable, credential-free transport classification used for cold-start ranking
 * and in-session failover diversity.
 *
 * Never includes UUIDs/passwords from rawLink.
 */
object ServerTransport {
    fun family(server: Server): String {
        val protocol = server.protocol.uppercase()
        if (protocol != "VLESS") return protocol

        val security = queryParam(server.rawLink, "security").ifBlank { "none" }.lowercase()
        val network = (
            queryParam(server.rawLink, "type").ifBlank {
                queryParam(server.rawLink, "network")
            }.ifBlank { "tcp" }
        ).lowercase()

        return "VLESS:$security:$network"
    }

    /**
     * Lower is preferred when there is no end-to-end HTTPS history yet.
     *
     * SecureConnect targets restrictive networks, so authenticated/obfuscated
     * VLESS Reality and modern transports are tried before ordinary TLS/TCP.
     * This is only a cold-start hint; a real historical HTTPS success always wins.
     */
    fun coldStartRank(server: Server): Int {
        val protocol = server.protocol.uppercase()
        if (protocol == "VLESS") {
            val security = queryParam(server.rawLink, "security").lowercase()
            val network = (
                queryParam(server.rawLink, "type").ifBlank {
                    queryParam(server.rawLink, "network")
                }.ifBlank { "tcp" }
            ).lowercase()

            if (security == "reality") return 0
            if (security == "tls") {
                return when (network) {
                    "xhttp", "splithttp" -> 2
                    "grpc" -> 3
                    "ws", "websocket" -> 4
                    "httpupgrade" -> 5
                    else -> 6
                }
            }
            return 8
        }

        return when (protocol) {
            "HYSTERIA2" -> 1
            "TROJAN" -> 7
            "VMESS" -> 9
            "SHADOWSOCKS" -> 10
            else -> 11
        }
    }

    fun pingBucket(server: Server): Int = when {
        server.ping <= 0 -> 4
        server.ping <= 100 -> 0
        server.ping <= 250 -> 1
        server.ping <= 600 -> 2
        server.ping <= 1_200 -> 3
        else -> 4
    }


    private fun queryParam(rawLink: String, key: String): String {
        val query = rawLink
            .substringBefore('#')
            .substringAfter('?', "")
        if (query.isBlank()) return ""

        return query.split('&')
            .firstOrNull { part -> part.substringBefore('=').equals(key, ignoreCase = true) }
            ?.substringAfter('=', "")
            .orEmpty()
    }
}
