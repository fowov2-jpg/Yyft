package com.secureconnect.app.data.source

/** Один внешний источник конфигов (GitHub-репозиторий). */
data class ConfigSource(
    val id: String,
    val name: String,
    val urls: List<String>,       // один или несколько файлов подписки
    val interval: String,         // как часто обновляется
    val note: String,
    val enabled: Boolean = true
)

/** Результат загрузки одного источника (для экрана «Источники»). */
data class SourceStatus(
    val sourceId: String,
    val loaded: Int,              // сколько конфигов разобрано
    val error: String? = null
)

/**
 * Источники, заточенные под РФ (октябрь 2026).
 * Приоритет: VLESS + Reality и Hysteria2. TUIC намеренно отбрасывается:
 * Xray 26.9.x не предоставляет TUIC outbound, поэтому показывать такие узлы
 * пользователю было бы ложным обещанием подключения.
 */
object ConfigSources {
    private const val RAW = "https://raw.githubusercontent.com"

    // Stable IDs preserve the user's disabled-source preferences across updates.
    const val CATALOGUE_REVISION = 174
    val all: List<ConfigSource> = listOf(
        // --- специально под Россию ---
        ConfigSource(
            "avia", "aviamastersgh/vpn-free-russia",
            listOf(
                "$RAW/aviamastersgh/vpn-free-russia/main/ru_configs.txt",
                "$RAW/aviamastersgh/vpn-free-russia/main/verified_configs.txt",
                "$RAW/aviamastersgh/vpn-free-russia/main/all_configs.txt"
            ),
            "Ежедневно", "РФ: RU/allowlist пул + проверенные VLESS Reality / Trojan"
        ),
        ConfigSource(
            "nikita", "nikita29a/FreeProxyList",
            listOf(
                "https://github.com/nikita29a/FreeProxyList/raw/refs/heads/main/mirror/1.txt",
                "https://github.com/nikita29a/FreeProxyList/raw/refs/heads/main/mirror/2.txt",
                "https://github.com/nikita29a/FreeProxyList/raw/refs/heads/main/mirror/3.txt"
            ),
            "Ежедневно", "РФ: Reality + Hysteria2 + TUIC (берём VLESS/Trojan)"
        ),
        ConfigSource(
            "3inker", "3inker/v2ray-subscription",
            listOf(
                "$RAW/3inker/v2ray-subscription/main/subs/all_not_ru.txt",
                "$RAW/3inker/v2ray-subscription/main/subs/all_ru.txt"
            ),
            "Каждые 12 ч", "TCP-проверенные, отдельно RU / не-RU"
        ),

        // --- качественные общие (много Reality) ---
        ConfigSource(
            "radikal", "0xRadikal/Free-v2ray-Configs",
            listOf(
                "$RAW/0xRadikal/Free-v2ray-Configs/main/verified/configs.txt",
                "$RAW/0xRadikal/Free-v2ray-Configs/main/top100.txt",
                "$RAW/0xRadikal/Free-v2ray-Configs/main/protocols/vless.txt"
            ),
            "Каждые 15 мин", "3 раунда HTTP-проверки, top + VLESS"
        ),
        ConfigSource(
            "morpheus", "morpheusadam/v2ray-config",
            listOf(
                "$RAW/morpheusadam/v2ray-config/main/subs/bundles/best.txt",
                "$RAW/morpheusadam/v2ray-config/main/subs/bundles/reality.txt",
                "$RAW/morpheusadam/v2ray-config/main/subs/bundles/vless.txt"
            ),
            "Ежедневно", "best + reality + vless бандлы"
        ),
        ConfigSource(
            "hamed", "hamedcode/port-based-v2ray-configs",
            listOf(
                "$RAW/hamedcode/port-based-v2ray-configs/main/sub/top100.txt",
                "$RAW/hamedcode/port-based-v2ray-configs/main/sub/vless.txt"
            ),
            "Каждые 4 часа", "Много VLESS на 443"
        ),
        ConfigSource(
            "alirewa", "Alirewa/V2ray-Configs",
            listOf(
                "$RAW/Alirewa/V2ray-Configs/main/sub1.txt",
                "$RAW/Alirewa/V2ray-Configs/main/config.txt"
            ),
            "Заявлено: 30 мин", "Top-100 base64 + основной пул"
        ),
        ConfigSource(
            "barry", "barry-far/V2ray-Config",
            listOf(
                "$RAW/barry-far/V2ray-Config/main/Splitted-By-Protocol/vless.txt",
                "$RAW/barry-far/V2ray-Config/main/Sub1.txt"
            ),
            "Каждые 15 мин", "Только VLESS + Sub1"
        ),
        ConfigSource(
            "au1rxx", "Au1rxx/free-vpn-subscriptions",
            listOf("https://github.com/Au1rxx/free-vpn-subscriptions/raw/main/output/v2ray-base64.txt"),
            "Каждый час", "HTTP-проверенные, base64"
        ),
        ConfigSource(
            "epodonios", "Epodonios/v2ray-configs",
            listOf(
                "https://github.com/Epodonios/v2ray-configs/raw/main/Splitted-By-Protocol/vless.txt",
                "https://github.com/Epodonios/v2ray-configs/raw/main/All_Configs_Sub.txt"
            ),
            "Каждые 5 мин", "VLESS отдельно + полный список"
        ),
        ConfigSource(
            "solispirit", "SoliSpirit/v2ray-configs",
            listOf("$RAW/SoliSpirit/v2ray-configs/main/Protocols/vless.txt"),
            "Заявлено: 15 мин", "VLESS; локальная проверка обязательна"
        ),
        ConfigSource(
            "ebrasha", "ebrasha/free-v2ray-public-list",
            listOf("$RAW/ebrasha/free-v2ray-public-list/main/vless_configs.txt"),
            "Заявлено: 15 мин", "VLESS из публичной подписки"
        ),
        ConfigSource(
            "milad_dumper", "miladtahanian/V2RayCFGDumper",
            listOf("$RAW/miladtahanian/V2RayCFGDumper/main/sub.txt"),
            "Заявлено: 15 мин", "Смешанная подписка"
        ),
        ConfigSource(
            "mohammad", "MohammadBahemmat/V2ray-Collector",
            listOf("$RAW/MohammadBahemmat/V2ray-Collector/main/Tested.txt",
                "$RAW/MohammadBahemmat/V2ray-Collector/main/all_servers.txt"),
            "Заявлено: 15 мин", "Проверенные сборщиком; перепроверяем на устройстве"
        ),
        ConfigSource(
            "v2rayroot", "V2RayRoot/V2RayConfig",
            listOf("$RAW/V2RayRoot/V2RayConfig/main/Config/vless.txt"),
            "Заявлено: 30 мин", "VLESS из Telegram-источников"
        ),
        ConfigSource(
            "amir", "amir-reza-bijandi/v2ray-configs",
            listOf("$RAW/amir-reza-bijandi/v2ray-configs/main/configs.txt"),
            "Заявлено: 30 мин", "Подписка до 100 конфигов"
        ),
        ConfigSource(
            "milad_collector", "miladtahanian/Config-Collector",
            listOf("$RAW/miladtahanian/Config-Collector/main/mixed_iran.txt"),
            "Заявлено: 30 мин", "Смешанная подписка; доступность в РФ проверяем локально"
        )
    )
}
