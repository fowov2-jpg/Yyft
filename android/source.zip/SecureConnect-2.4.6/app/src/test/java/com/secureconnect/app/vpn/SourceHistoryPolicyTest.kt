package com.secureconnect.app.vpn

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SourceHistoryPolicyTest {
    private val now = 1_800_000_000_000L
    private val hour = 60L * 60_000L

    private fun proof(source: String, ageHours: Long = 2, failed: Boolean = false) =
        SourceHistoryPolicy.Proof(
            source = source,
            lastSuccessAtMs = now - ageHours * hour,
            youtubeVerifiedAtMs = now - ageHours * hour,
            speedVerifiedAtMs = now - ageHours * hour,
            lastFailureAtMs = if (failed) now - hour else 0L,
            consecutiveFailures = if (failed) 2 else 0
        )

    @Test fun multipleProvenServersMakeSourceFirst() {
        val preferred = SourceHistoryPolicy.preferredSources(
            listOf(proof("A"), proof("B"), proof("A", 5)), now)
        assertEquals(listOf("A", "B"), preferred)
        assertTrue(SourceHistoryPolicy.rank("A", preferred) <
            SourceHistoryPolicy.rank("untried", preferred))
    }

    @Test fun staleAndFailedAndUnverifiedDoNotEarnPreference() {
        val noVideo = proof("without-video").copy(youtubeVerifiedAtMs = 0)
        val noSpeed = proof("without-speed").copy(speedVerifiedAtMs = 0)
        val candidates = listOf(proof("stale", 96), proof("failed", failed = true),
            noVideo, noSpeed, proof("working"))
        assertEquals(listOf("working"), SourceHistoryPolicy.preferredSources(candidates, now))
    }

    @Test fun goodSourceGoesFirstButUnknownSourcesStillGetChecked() {
        val ranked = listOf("A1", "A2", "A3", "B1", "C1")
        val result = SourceHistoryPolicy.interleave(ranked) { it.substring(0, 1) }
        assertEquals(listOf("A1", "B1", "C1", "A2", "A3"), result)
    }

    @Test fun unexpectedFutureTimestampsCannotKeepSourceTrusted() {
        val future = proof("future").copy(lastSuccessAtMs = now + hour)
        assertFalse("future" in SourceHistoryPolicy.preferredSources(listOf(future), now))
    }

    @Test fun sourcePreferenceIsOnlyAWeightedOrderingHint() {
        assertEquals(0, SourceHistoryPolicy.rank("A", listOf("A", "B")))
        assertEquals(1, SourceHistoryPolicy.rank("B", listOf("A", "B")))
        assertTrue(SourceHistoryPolicy.rank("none", listOf("A", "B")) > 1)
    }
}
