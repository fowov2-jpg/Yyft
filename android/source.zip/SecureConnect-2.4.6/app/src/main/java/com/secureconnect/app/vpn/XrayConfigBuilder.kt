package com.secureconnect.app.vpn

import com.secureconnect.app.data.model.Server
import com.secureconnect.app.data.remote.ConfigParser
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLDecoder

/**
 * Превращает ссылку (vless/vmess/trojan/ss/hysteria2) в JSON-конфиг Xray с TUN-входом.
 * Возвращает null, если протокол/транспорт ядро-обёртка не поддерживает.
 */
object XrayConfigBuilder {

    /** Локальный SOCKS только для health-check; наружу он не публикуется. */
    const val HEALTH_SOCKS_PORT = 10808

    /** resolvedHost — IP сервера, уже разрешённый приложением (чтобы ядро не делало DNS через туннель). */
    fun build(server: Server, resolvedHost: String?): String? = try {
        buildInternal(server.rawLink, resolvedHost)
    } catch (e: Exception) {
        null
    }

    /** Standalone outbound test: no TUN, listeners, DNS hijacking or live controller. */
    fun buildProbe(server: Server): String? = build(server, null)?.let { config ->
        val root = JSONObject(config)
        root.remove("inbounds")
        root.remove("routing")
        root.remove("dns")
        root.remove("stats")
        root.remove("policy")
        root.put("outbounds", JSONArray().put(root.getJSONArray("outbounds").getJSONObject(0)))
        root.toString()
    }

    /** Separate short-lived SOCKS core to verify actual YouTube HTML, not just native HTTP status. */
    fun buildSocksProbe(outboundConfig: String, localPort: Int): String = JSONObject(outboundConfig).apply {
        put("stats", JSONObject()) // AndroidLibXrayLite startLoop requires a stats manager.
        put("inbounds", JSONArray().put(JSONObject()
            .put("tag", "youtube-probe")
            .put("listen", "127.0.0.1")
            .put("port", localPort)
            .put("protocol", "socks")
            .put("settings", JSONObject().put("auth", "noauth").put("udp", false))))
    }.toString()

    private class Parsed(val user: String, val host: String, val port: Int, val q: Map<String, String>)

    private fun buildInternal(link: String, ip: String?): String? {
        val scheme = link.substringBefore("://").lowercase()
        val rest = link.substringAfter("://")
        val proxy = when (scheme) {
            "vless" -> vless(rest, ip)
            "vmess" -> vmess(rest, ip)
            "trojan" -> trojan(rest, ip)
            "ss" -> shadowsocks(rest, ip)
            "hysteria2", "hy2" -> hysteria2(rest, ip)
            else -> null
        } ?: return null
        proxy.put("tag", "proxy")

        // TUN inbound: fd передаётся из VpnService через startLoop(config, tunFd)
        val tun = JSONObject()
            .put("tag", "tun")
            .put("protocol", "tun")
            .put(
                "settings",
                JSONObject()
                    // IMPORTANT: TUN name belongs inside `settings`. If it is put on
                    // the inbound object, Xray sees an empty TunConfig.Name and calls
                    // net.Interfaces()/GetAvailableTunName(), which is restricted on Android.
                    .put("name", "xray0")
                    .put("mtu", 1280)
                    // Android feeds an already-created VpnService fd into Xray.
                    // The native TUN path owns the actual file descriptor; no Xray user
                    // policy belongs in the TUN settings object.
            )
            .put(
                "sniffing",
                JSONObject()
                    .put("enabled", true)
                    .put("destOverride", JSONArray(listOf("http", "tls", "quic")))
                    .put("routeOnly", false)
            )

        // DNS must be handled by Xray itself. Android's VpnService DNS entries
        // only tell the OS where to send DNS packets; they do not make Xray's
        // built-in DNS module receive them. We therefore route TUN:53 to the
        // dedicated dns outbound and hijack those queries into Xray DNS.
        // IPv4-only resolution is intentional: broken/filtered IPv6 is a common
        // reason that apps can appear connected while real traffic never loads.
        val dns = JSONObject()
            .put("servers", JSONArray(listOf(
                "https://1.1.1.1/dns-query",
                "https://9.9.9.9/dns-query",
                "https://8.8.8.8/dns-query"
            )))
            .put("tag", "vpn-dns")
            .put("queryStrategy", "UseIPv4")
            .put("disableCache", false)

        // TUN DNS -> DNS outbound -> Xray DNS. DoH intentionally uses https://,
        // not https+local://: local mode bypasses Xray routing. With `proxy` as
        // the default outbound, the DoH connection follows the active proxy.
        val dnsOutbound = JSONObject()
            .put("tag", "dns")
            .put("protocol", "dns")
            .put(
                "streamSettings", JSONObject().put(
                    "sockopt", JSONObject().put("dialerProxy", "proxy")
                )
            )
            .put(
                "settings", JSONObject()
                    .put("rewriteNetwork", "tcp")
                    .put("rewriteAddress", "1.1.1.1")
                    .put("rewritePort", 53)
                    .put("userLevel", 8)
            )

        val root = JSONObject()
            // Quiet the native core in normal operation. Operational health and
            // security decisions are tracked separately in VpnController.
            .put("log", JSONObject().put("loglevel", "error"))
            .put("stats", JSONObject())
            .put(
                "policy", JSONObject()
                    .put(
                        "levels",
                        JSONObject().put(
                            "8",
                            JSONObject()
                                .put("handshake", 4)
                                .put("connIdle", 300)
                                .put("uplinkOnly", 1)
                                .put("downlinkOnly", 1)
                                .put("statsUserUplink", true)
                                .put("statsUserDownlink", true)
                        )
                    )
                    .put(
                        "system",
                        JSONObject().put("statsOutboundUplink", true).put("statsOutboundDownlink", true)
                    )
            )
            .put("dns", dns)
            .put(
                "inbounds",
                JSONArray()
                    .put(tun)
                    .put(
                        JSONObject()
                            .put("tag", "health-socks")
                            .put("listen", "127.0.0.1")
                            .put("port", HEALTH_SOCKS_PORT)
                            .put("protocol", "socks")
                            .put(
                                "settings",
                                JSONObject()
                                    .put("auth", "noauth")
                                    .put("udp", true)
                                    .put("ip", "127.0.0.1")
                            )
                    )
            )
            .put(
                "outbounds", JSONArray()
                    .put(proxy)
                    .put(dnsOutbound)
                    .put(JSONObject().put("tag", "direct").put("protocol", "freedom"))
                    .put(JSONObject().put("tag", "block").put("protocol", "blackhole"))
            )
            .put(
                "routing",
                JSONObject()
                    .put("domainStrategy", "AsIs")
                    .put(
                        "rules",
                        JSONArray()
                            // Built-in DoH must use the selected proxy, including DNS from other apps.
                            .put(
                                JSONObject()
                                    .put("type", "field")
                                    .put("inboundTag", JSONArray(listOf("vpn-dns")))
                                    .put("outboundTag", "proxy")
                            )
                            // Local health-check SOCKS → the active proxy outbound.
                            .put(
                                JSONObject()
                                    .put("type", "field")
                                    .put("inboundTag", JSONArray(listOf("health-socks")))
                                    .put("outboundTag", "proxy")
                            )
                            // TUN DNS → Xray built-in DNS.
                            .put(
                                JSONObject()
                                    .put("type", "field")
                                    .put("inboundTag", JSONArray(listOf("tun")))
                                    .put("port", "53")
                                    .put("network", "tcp,udp")
                                    .put("outboundTag", "dns")
                            )
                            // Весь остальной трафик с TUN → proxy
                            .put(
                                JSONObject()
                                    .put("type", "field")
                                    .put("inboundTag", JSONArray(listOf("tun")))
                                    .put("outboundTag", "proxy")
                            )
                    )
            )
        return root.toString()
    }

    // ---------------- протоколы ----------------

    private fun vless(rest: String, ip: String?): JSONObject? {
        val p = parseUrl(rest)
        val q = { k: String -> p.q[k]?.takeIf { it.isNotBlank() } }
        val encryption = q("encryption") ?: "none"
        val transportSecurity = q("security") ?: "none"

        // Xray-core 26.7+ rejects public VLESS endpoints that have neither
        // TLS/REALITY nor VLESS Encryption. Public subscription lists contain
        // many such stale links; rejecting them here prevents wasting failover
        // attempts on configs the core will refuse before any network I/O.
        val outboundAddress = ip ?: p.host
        if (transportSecurity.equals("none", true) &&
            encryption.equals("none", true) &&
            !isClearlyPrivateOrLocalHost(outboundAddress)) {
            return null
        }

        val user = JSONObject().put("id", p.user).put("encryption", encryption).put("level", 8)
        q("flow")?.let { user.put("flow", it) }
        val stream = stream(q("type") ?: "tcp", transportSecurity, q, p.host) ?: return null
        return JSONObject().put("protocol", "vless")
            .put(
                "settings", JSONObject().put(
                    "vnext", JSONArray().put(
                        JSONObject().put("address", outboundAddress).put("port", p.port).put("users", JSONArray().put(user))
                    )
                )
            )
            .put("streamSettings", stream)
    }

    private fun vmess(rest: String, ip: String?): JSONObject? {
        val j = JSONObject(ConfigParser.decodeBase64(rest.substringBefore('#')) ?: return null)
        val host = j.optString("add")
        val map = mapOf(
            "path" to j.optString("path"), "host" to j.optString("host"), "sni" to j.optString("sni"),
            "fp" to j.optString("fp"), "alpn" to j.optString("alpn"), "serviceName" to j.optString("path")
        )
        val q = { k: String -> map[k]?.takeIf { it.isNotBlank() } }
        val user = JSONObject().put("id", j.optString("id")).put("alterId", j.optInt("aid", 0))
            .put("security", j.optString("scy").ifBlank { "auto" }).put("level", 8)
        val security = if (j.optString("tls") == "tls") "tls" else "none"
        val stream = stream(j.optString("net").ifBlank { "tcp" }, security, q, host) ?: return null
        return JSONObject().put("protocol", "vmess")
            .put(
                "settings", JSONObject().put(
                    "vnext", JSONArray().put(
                        JSONObject().put("address", ip ?: host).put("port", j.optInt("port")).put("users", JSONArray().put(user))
                    )
                )
            )
            .put("streamSettings", stream)
    }

    private fun trojan(rest: String, ip: String?): JSONObject? {
        val p = parseUrl(rest)
        val q = { k: String -> p.q[k]?.takeIf { it.isNotBlank() } }
        val transportSecurity = q("security") ?: "tls"
        val outboundAddress = ip ?: p.host
        // Current Xray applies the same transport-security safety rule to
        // Trojan on public endpoints. Drop stale plaintext public nodes early.
        if (transportSecurity.equals("none", true) && !isClearlyPrivateOrLocalHost(outboundAddress)) return null
        val stream = stream(q("type") ?: "tcp", transportSecurity, q, p.host) ?: return null
        return JSONObject().put("protocol", "trojan")
            .put(
                "settings", JSONObject().put(
                    "servers", JSONArray().put(
                        JSONObject().put("address", outboundAddress).put("port", p.port).put("password", p.user).put("level", 8)
                    )
                )
            )
            .put("streamSettings", stream)
    }

    // Only authenticated AEAD methods. Legacy stream ciphers, 'plain' and
    // 'none' are not acceptable for public configurations, including manual import.
    private val SS_METHODS = setOf(
        "aes-128-gcm", "aes-192-gcm", "aes-256-gcm",
        "chacha20-ietf-poly1305", "chacha20-poly1305", "xchacha20-ietf-poly1305",
        "2022-blake3-aes-128-gcm", "2022-blake3-aes-256-gcm", "2022-blake3-chacha20-poly1305"
    )

    private fun shadowsocks(rest: String, ip: String?): JSONObject? {
        val noFrag = rest.substringBefore('#')
        // SIP003 plugins (obfs/v2ray-plugin) ядро без плагина не поднимет
        if (noFrag.contains("plugin=", ignoreCase = true)) return null
        val main = noFrag.substringBefore('?')

        val userinfo: String
        val hp: String
        if (main.contains('@')) {
            // ss://BASE64(method:password)@host:port  или  ss://method:password@host:port
            userinfo = main.substringBeforeLast('@')
            hp = main.substringAfterLast('@')
        } else {
            // ss://BASE64(method:password@host:port)
            val d = ConfigParser.decodeBase64(main) ?: return null
            if (!d.contains('@')) return null
            userinfo = d.substringBeforeLast('@')
            hp = d.substringAfterLast('@')
        }

        val cred = when {
            userinfo.contains(':') -> urlDecode(userinfo)
            else -> ConfigParser.decodeBase64(userinfo) ?: return null
        }
        // method — до первого ':', password — всё после (в пароле могут быть ':')
        val colon = cred.indexOf(':')
        if (colon <= 0) return null
        val method = cred.substring(0, colon).lowercase().trim()
        val password = cred.substring(colon + 1)
        if (method !in SS_METHODS || password.isEmpty()) return null

        val (host, port) = hostPort(hp.substringBefore('/')) ?: return null
        return JSONObject().put("protocol", "shadowsocks")
            .put(
                "settings", JSONObject().put(
                    "servers", JSONArray().put(
                        JSONObject().put("address", ip ?: host).put("port", port)
                            .put("method", method).put("password", password).put("level", 8)
                    )
                )
            )
            .put("streamSettings", JSONObject().put("network", "tcp").put("security", "none"))
    }

    private fun hysteria2(rest: String, ip: String?): JSONObject? {
        val noFragment = rest.substringBefore('#')
        val query = noFragment.substringAfter('?', "")
            .split('&')
            .filter { it.contains('=') }
            .associate { it.substringBefore('=') to urlDecode(it.substringAfter('=')) }
        val main = noFragment.substringBefore('?')
        val authority = main.substringAfterLast('@').substringBefore('/')
        val auth = urlDecode(main.substringBeforeLast('@', ""))
        if (auth.isBlank()) return null

        val host: String
        val port: Int
        if (authority.startsWith("[")) {
            host = authority.substringAfter('[').substringBefore(']')
            port = authority.substringAfter("]:", "443").toIntOrNull() ?: 443
        } else {
            host = authority.substringBeforeLast(':')
            port = authority.substringAfterLast(':', "").toIntOrNull() ?: 443
        }
        if (host.isBlank() || port !in 1..65535) return null

        // Xray 26.x removed the legacy `allowInsecure` escape hatch. Keep
        // certificate verification enabled and preserve modern pinning fields
        // when a subscription provides them.
        val tls = JSONObject()
            .put("serverName", query["sni"] ?: query["peer"] ?: host)
        query["alpn"]?.takeIf { it.isNotBlank() }?.let {
            tls.put("alpn", JSONArray(it.split(',').filter(String::isNotBlank)))
        }
        (query["pinSHA256"] ?: query["pcs"])?.takeIf { it.isNotBlank() }?.let {
            tls.put("pinnedPeerCertSha256", it)
        }

        val hysteriaSettings = JSONObject()
            .put("version", 2)
            .put("auth", auth)
            .put("udpIdleTimeout", 60)

        // Hysteria2 Salamander is represented by Xray's FinalMask layer.
        val obfs = query["obfs"]?.lowercase()?.takeIf { it.isNotBlank() }
        val obfsPassword = query["obfs-password"]
        // Dropping an unsupported/malformed mask changes the wire protocol.
        // Salamander needs the exact password configured at the server.
        if (obfs != null && (obfs != "salamander" || obfsPassword.isNullOrBlank())) return null
        if (obfs == null && !obfsPassword.isNullOrBlank()) return null
        val rawFinalMask = query["fm"] ?: query["finalmask"]
        if (obfs != null && rawFinalMask != null) return null // Ambiguous duplicate masking.
        val stream = JSONObject()
            .put("network", "hysteria")
            .put("method", "hysteria")
            .put("security", "tls")
            .put("tlsSettings", tls)
            .put("hysteriaSettings", hysteriaSettings)
        rawFinalMask?.let { raw ->
            val finalMask = runCatching { JSONObject(raw) }.getOrNull() ?: return null
            stream.put("finalmask", finalMask)
        }
        if (obfs == "salamander") {
            stream.put(
                "finalmask", JSONObject().put(
                    "udp", JSONArray().put(
                        JSONObject()
                            .put("type", "salamander")
                            .put("settings", JSONObject().put("password", obfsPassword))
                    )
                )
            )
        }

        return JSONObject()
            .put("protocol", "hysteria")
            .put(
                "settings", JSONObject()
                    .put("version", 2)
                    .put("address", ip ?: host)
                    .put("port", port)
            )
            .put("streamSettings", stream)
    }

    // ---------------- транспорт / безопасность ----------------

    private fun stream(networkRaw: String, security: String, q: (String) -> String?, host: String): JSONObject? {
        val net = when (networkRaw.lowercase()) {
            "", "tcp", "raw" -> "tcp"
            "ws", "websocket" -> "ws"
            "grpc" -> "grpc"
            "httpupgrade" -> "httpupgrade"
            "xhttp", "splithttp" -> "xhttp"
            else -> return null
        }
        // REALITY negotiates only RAW, XHTTP or gRPC. Never silently rewrite
        // an incompatible transport: the remote server must match the client.
        if (security.equals("reality", true) && net !in setOf("tcp", "xhttp", "grpc")) return null
        val s = JSONObject().put("network", net)
        when (net) {
            "ws" -> {
                val ws = JSONObject().put("path", q("path") ?: "/")
                q("host")?.let { ws.put("headers", JSONObject().put("Host", it)) }
                s.put("wsSettings", ws)
            }
            "grpc" -> {
                val grpc = JSONObject().put("serviceName", q("serviceName") ?: q("path") ?: "")
                q("authority")?.let { grpc.put("authority", it) }
                s.put("grpcSettings", grpc)
            }
            "httpupgrade" -> s.put(
                "httpupgradeSettings",
                JSONObject().put("path", q("path") ?: "/").put("host", q("host") ?: "")
            )
            "xhttp" -> {
                val xhttp = JSONObject()
                    .put("path", q("path") ?: "/")
                    .put("host", q("host") ?: "")
                    .put("mode", q("mode") ?: "auto")

                // 2026 XHTTP share links can carry a JSON `extra` object with
                // packet-up/down tuning. Silently dropping it can materially
                // change the transport and make otherwise valid nodes unusable.
                q("extra")?.let { raw ->
                    val extra = runCatching { JSONObject(raw) }.getOrNull() ?: return null
                    xhttp.put("extra", extra)
                }
                s.put("xhttpSettings", xhttp)
            }
        }

        // FinalMask is a stream-level object. Providers commonly encode it as
        // `fm=<urlencoded JSON>` in VLESS/Trojan share links.
        (q("fm") ?: q("finalmask"))?.let { raw ->
            val finalMask = runCatching { JSONObject(raw) }.getOrNull() ?: return null
            s.put("finalmask", finalMask)
        }

        when (security.lowercase()) {
            "tls" -> {
                val tls = JSONObject()
                    .put("serverName", q("sni") ?: q("host") ?: host)
                    .put("fingerprint", q("fp") ?: "chrome")

                q("alpn")?.takeIf { it.isNotBlank() }?.let {
                    tls.put("alpn", JSONArray(it.split(',').filter(String::isNotBlank)))
                }

                // Modern Xray share-link fields. Do not emit the removed
                // `allowInsecure` option even when an old link asks for it:
                // current cores reject that legacy setting. Normal TLS
                // verification remains enabled unless a cryptographic pin is
                // explicitly supplied.
                q("pcs")?.let { tls.put("pinnedPeerCertSha256", it) }
                q("vcn")?.let { tls.put("verifyPeerCertByName", it) }
                (q("ech") ?: q("echConfigList"))?.let { tls.put("echConfigList", it) }
                q("echForceQuery")?.let { raw ->
                    if (raw !in setOf("none", "half", "full")) return null
                    tls.put("echForceQuery", raw)
                }

                s.put("security", "tls").put("tlsSettings", tls)
            }
            "reality" -> {
                val r = JSONObject()
                    .put("serverName", q("sni") ?: host)
                    .put("fingerprint", q("fp") ?: "chrome")
                    .put("publicKey", q("pbk") ?: return null)
                    .put("shortId", q("sid") ?: "")
                    .put("spiderX", q("spx") ?: "")

                q("alpn")?.takeIf { it.isNotBlank() }?.let {
                    r.put("alpn", JSONArray(it.split(',').filter(String::isNotBlank)))
                }
                (q("pqv") ?: q("mldsa65Verify"))?.let { r.put("mldsa65Verify", it) }

                s.put("security", "reality").put("realitySettings", r)
            }
            "none", "" -> s.put("security", "none")
            else -> return null
        }

        // Do not force TCP_MAXSEG/TFO here. tcpMaxSeg applies to the whole
        // connection, not just the TLS ClientHello, and a hard 1200-byte MSS can
        // reduce throughput on otherwise healthy paths. Transport-specific
        // fragmentation should be opt-in, not silently imposed on every TLS node.
        return s
    }


    /**
     * Conservative local/private check mirroring the safety intent of Xray-core.
     * Public subscription nodes that use plaintext VLESS/Trojan are rejected.
     */
    private fun isClearlyPrivateOrLocalHost(hostRaw: String): Boolean {
        val host = hostRaw.trim().trim('[', ']').trimEnd('.').lowercase()
        if (host.isBlank()) return false
        if (host == "localhost" || host.endsWith(".localhost") || host.endsWith(".local") ||
            host.endsWith(".lan") || host.endsWith(".home.arpa")) return true

        val v4 = host.split('.')
        if (v4.size == 4) {
            val octets = v4.map { it.toIntOrNull() ?: return false }
            if (octets.any { it !in 0..255 }) return false
            val a = octets[0]
            val b = octets[1]
            return a == 10 ||
                a == 127 ||
                (a == 169 && b == 254) ||
                (a == 172 && b in 16..31) ||
                (a == 192 && b == 168) ||
                (a == 100 && b in 64..127)
        }

        if (host.contains(':')) {
            return host == "::1" || host.startsWith("fc") || host.startsWith("fd") ||
                host.startsWith("fe8") || host.startsWith("fe9") ||
                host.startsWith("fea") || host.startsWith("feb")
        }
        return false
    }

    // ---------------- утилиты ----------------

    private fun parseUrl(rest: String): Parsed {
        val noFrag = rest.substringBefore('#')
        val query = noFrag.substringAfter('?', "")
        val main = noFrag.substringBefore('?').substringBefore('/')
        val user = urlDecode(main.substringBeforeLast('@', ""))
        val (host, port) = hostPort(main.substringAfterLast('@')) ?: throw IllegalArgumentException("bad host")
        val q = query.split('&').filter { it.contains('=') }
            .associate { it.substringBefore('=') to urlDecode(it.substringAfter('=')) }
        return Parsed(user, host, port, q)
    }

    private fun hostPort(hp: String): Pair<String, Int>? {
        val host: String
        val portStr: String
        if (hp.startsWith("[")) {
            host = hp.substringAfter('[').substringBefore(']')
            portStr = hp.substringAfter("]:", "")
        } else {
            host = hp.substringBeforeLast(':')
            portStr = hp.substringAfterLast(':', "")
        }
        val port = portStr.takeWhile { it.isDigit() }.toIntOrNull() ?: return null
        if (host.isBlank() || port !in 1..65535) return null
        return host to port
    }

    private fun urlDecode(s: String): String =
        try { URLDecoder.decode(s.replace("+", "%2B"), "UTF-8") } catch (e: Exception) { s }
}
