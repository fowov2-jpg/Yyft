package com.secureconnect.app.vpn

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import com.secureconnect.app.MainActivity

/**
 * No new network calls: observes the VPN's real service state and existing TLS
 * probe. Independent DNS/IPv6/public-IP leak measurements remain unimplemented.
 * Periodic sampling works when the Activity is not visible while the service lives.
 */
internal class AutomaticSecurityMonitor(private val context: Context) {
    private val gate = SecurityAlertGate()
    private var lastIncidentId = "ok"

    fun inspect(tunPresent: Boolean, serverPresent: Boolean) {
        val state = VpnController.state.value
        // No alerts for ordinary startup/teardown transitions.
        if (state != VpnState.Connected && state != VpnState.Blocked &&
            state !is VpnState.Error) return

        val routing = runCatching { AppRoutingStore(context).load().mode }
            .getOrDefault(AppVpnMode.EXCLUDE_SELECTED)
        val tls = VpnController.openAiTlsStatus.value
        val alert = SecurityAlertPolicy.classify(
            state = state, tunPresent = tunPresent,
            killSwitchEnabled = VpnController.killSwitchEnabled,
            tlsStatus = tls, routingMode = routing,
            hasActiveServer = serverPresent
        )
        val now = System.currentTimeMillis()
        VpnController.lastAutomaticSecurityCheckAtMs.value = now

        val accepted = gate.accept(alert, now)
        if (alert.severity == SecuritySeverity.NONE) {
            if (lastIncidentId != "ok") {
                SecurityEventStore.record(context, SecurityEventStore.Event(
                    now, "INFO", "Критическое предупреждение снято",
                    "Активная сессия больше не имеет прежнего обнаруженного признака риска. DNS/IP-утечки отдельно не проверены."))
            }
            lastIncidentId = "ok"
            return
        }
        lastIncidentId = alert.id
        if (!accepted) return
        SecurityEventStore.record(context, SecurityEventStore.Event(
            now, alert.severity.name, alert.title, alert.explanation))
        VpnController.emitEvent("Автозащита: ${alert.title}")
        postAlert(alert)
    }

    private fun postAlert(alert: SecurityAlert) {
        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED) return
        runCatching {
            val manager = context.getSystemService(NotificationManager::class.java) ?: return
            manager.createNotificationChannel(NotificationChannel(
                CHANNEL, "Предупреждения безопасности", NotificationManager.IMPORTANCE_DEFAULT))
            val open = PendingIntent.getActivity(
                context, 221, Intent(context, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val notification = Notification.Builder(context, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentTitle("SecureConnect · ${alert.title}")
                .setContentText(alert.explanation)
                .setStyle(Notification.BigTextStyle().bigText(alert.explanation))
                .setContentIntent(open)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_STATUS)
                .build()
            manager.notify(NOTIFICATION_ID, notification)
        }.onFailure { VpnController.emitEvent("Не удалось показать предупреждение безопасности") }
    }

    companion object {
        private const val CHANNEL = "security_alerts"
        private const val NOTIFICATION_ID = 2215
    }
}
