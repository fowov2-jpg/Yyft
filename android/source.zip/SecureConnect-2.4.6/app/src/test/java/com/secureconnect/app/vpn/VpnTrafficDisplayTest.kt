package com.secureconnect.app.vpn

import org.junit.Assert.*
import org.junit.Test

class VpnTrafficDisplayTest {
    @Test fun bytesAreConvertedUsingElapsedIntervalNotTotalTime() {
        val rate = VpnTrafficDisplay.calculate(6_000_000L, 1_500_000L, 2_000_000_000L)
        assertEquals(24.0f, rate.downloadMbps, 0.001f)
        assertEquals(6.0f, rate.uploadMbps, 0.001f)
    }

    @Test fun firstSampleAndInvalidCountersStayZero() {
        assertEquals(VpnTrafficRate.ZERO, VpnTrafficDisplay.calculate(1_000L, 1_000L, 0))
        assertEquals(VpnTrafficRate.ZERO, VpnTrafficDisplay.calculate(-1, -10, 2_000_000_000L))
        assertEquals("0.00", VpnTrafficDisplay.formatRate(Float.NaN))
    }

    @Test fun displayShowsBothDirectionsAndDestination() {
        assertEquals("↓ 24.00 Мбит/с   ↑ 6.00 Мбит/с",
            VpnTrafficDisplay.speedLine(VpnTrafficRate(24f, 6f)))
        assertEquals("Эстония · Таллин", VpnTrafficDisplay.serverLabel("Эстония", "Таллин", "host"))
        assertEquals("185.155.55.3", VpnTrafficDisplay.serverLabel("", "", "185.155.55.3"))
    }
}