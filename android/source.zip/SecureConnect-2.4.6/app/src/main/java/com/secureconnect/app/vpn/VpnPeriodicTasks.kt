package com.secureconnect.app.vpn

/** Owns just the three periodic service callbacks; no VPN operations are performed here.
 * A stopped scheduler refuses to re-arm a callback that has already started running.
 */
internal class VpnPeriodicTasks(
    private val schedule: (Runnable, Long) -> Unit,
    private val cancel: (Runnable) -> Unit
) {
    private var running = false
    private val tasks = mutableSetOf<Runnable>()

    fun start(vararg scheduled: Pair<Runnable, Long>) {
        check(!running) { "Periodic tasks are already running" }
        running = true
        scheduled.forEach { (task, delayMs) ->
            tasks += task
            schedule(task, delayMs)
        }
    }

    fun reschedule(task: Runnable, delayMs: Long) {
        if (running && task in tasks) schedule(task, delayMs)
    }

    fun stop() {
        running = false
        tasks.forEach(cancel)
        tasks.clear()
    }
}
