package com.secureconnect.app.vpn

/** Real HTTPS payload throughput, NOT Xray's idle traffic counter or a ping estimate. */
object VpnSpeedPolicy {
    const val MIN_DOWNLOAD_MBPS = 5.0
    const val MIN_UPLOAD_MBPS = 1.0
    const val PERIOD_MS = 5L * 60_000L
    const val CONFIRM_DELAY_MS = 45_000L
    const val DOWNLOAD_BYTES = 1024 * 1024
    const val UPLOAD_BYTES = 256 * 1024
    const val MAX_TEST_DURATION_MS = 15_000L

    // 720p needs ~2.5 Mbps sustained; 5 Mbps is a deliberate headroom target.
    // The 99% experience goal cannot be proven by synthetic Cloudflare transfers.
    const val CRITICAL_DOWNLOAD_MBPS = 2.5
    const val REPLACEMENT_GAIN = 1.25
    const val QUALITY_FRESHNESS_MS = 12L * 60L * 60_000L
    const val ADMISSION_PAUSE_MS = 300L
    enum class Verdict { PASS, SLOW, UNKNOWN }

    data class Result(
        val downloadMbps: Double?,
        val uploadMbps: Double?,
        val error: String? = null
    ) {
        val verdict: Verdict get() = classify(downloadMbps, uploadMbps)
    }

    fun classify(downloadMbps: Double?, uploadMbps: Double?): Verdict {
        val down = downloadMbps?.takeIf { it.isFinite() && it >= 0.0 }
        val up = uploadMbps?.takeIf { it.isFinite() && it >= 0.0 }
        // A successfully measured weak direction is sufficient to reject the node;
        // an unmeasured direction alone is not evidence of poor throughput.
        if (down != null && down < MIN_DOWNLOAD_MBPS) return Verdict.SLOW
        if (up != null && up < MIN_UPLOAD_MBPS) return Verdict.SLOW
        return if (down != null && up != null) Verdict.PASS else Verdict.UNKNOWN
    }

    /** Both independent samples must pass; UNKNOWN never admits a standby node. */
    fun qualifiesStandby(first: Result?, second: Result?): Boolean =
        first?.verdict == Verdict.PASS && second?.verdict == Verdict.PASS

    /** Hysteresis: switching disrupts existing TCP/video streams. */
    fun betterThanCurrent(candidateMbps: Double?, measuredCurrentMbps: Double?): Boolean {
        val candidate = candidateMbps?.takeIf { it.isFinite() && it >= MIN_DOWNLOAD_MBPS } ?: return false
        val current = measuredCurrentMbps?.takeIf { it.isFinite() && it >= 0.0 } ?: return false
        return current < CRITICAL_DOWNLOAD_MBPS || candidate >= current * REPLACEMENT_GAIN
    }

    fun mbps(bytes: Long, elapsedNs: Long): Double? {
        if (bytes <= 0L || elapsedNs <= 0L) return null
        return bytes.toDouble() * 8_000_000_000.0 / elapsedNs.toDouble() / 1_000_000.0
    }

    /** Two measured failures on the SAME server/generation; never switch on a timeout. */
    fun shouldFailover(first: Verdict, confirmation: Verdict): Boolean =
        first == Verdict.SLOW && confirmation == Verdict.SLOW
}
