package com.secureconnect.app.vpn

import org.junit.Assert.assertEquals
import org.junit.Test

/** The same four UTF-8 vectors are exercised by the Python verifier. */
class NodeFingerprintTest {
    @Test fun crossLanguageVectors() {
        assertEquals("6c6a8ae570863a7dfb15200305a2761b2b931e4e532e6c494405d351f644648e", NodeFingerprint.of("vless://01234567-89ab-cdef-0123-456789abcdef@good.example.org:443?security=reality&pbk=abc&sni=example.com#Москва 🇷🇺"))
        assertEquals("516c14051aeea678f405c6cd4bf255c127934c7404e0f186d2defd37462dae4b", NodeFingerprint.of("vmess://eyJhZGQiOiAiZ29vZC5leGFtcGxlLm9yZyIsICJwb3J0IjogNDQzLCAiaWQiOiAiMDEyMzQ1NjctODlhYi1jZGVmLTAxMjMtNDU2Nzg5YWJjZGVmIiwgInBzIjogIlx1Njc3MVx1NGVhYyIsICJ0bHMiOiAidGxzIiwgIm5ldCI6ICJ3cyIsICJwYXRoIjogIi92In0#тест"))
        assertEquals("aa4679483031d702cb07f6f1b48452d20ce218a0914af600a419b82d1451b406", NodeFingerprint.of("trojan://secret@good.example.org:443?security=tls&sni=example.com#Париж"))
        assertEquals("8af62a9ee84000fc22b0c0d3025ca6c1eea5c600682833f75627f809134eead1", NodeFingerprint.of("ss://YWVzLTEyOC1nY206c2VjcmV0@good.example.org:443#Санкт-Петербург"))
    }
    @Test fun labelsWhitespaceAndUnicodeDoNotChangeHash() {
        val base = "trojan://password@example.com:443?security=tls"
        assertEquals(NodeFingerprint.of(base), NodeFingerprint.of("   $base#Москва 🇷🇺   "))
        assertEquals(NodeFingerprint.of(base), NodeFingerprint.of("$base#東京 🌏"))
    }
}
