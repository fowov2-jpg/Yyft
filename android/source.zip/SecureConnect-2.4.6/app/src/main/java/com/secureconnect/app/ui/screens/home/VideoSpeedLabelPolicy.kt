package com.secureconnect.app.ui.screens.home

/**
 * Extracts the last download benchmark for the small home-screen label.
 * Live traffic counters are not benchmarks, and a failed test has no number.
 */
object VideoSpeedLabelPolicy {
    private val downloadPattern = Regex("""↓\s*([0-9]+(?:[.,][0-9]+)?)""")

    fun downloadMbps(result: String?): String? =
        downloadPattern.find(result.orEmpty())?.groupValues?.getOrNull(1)
}
