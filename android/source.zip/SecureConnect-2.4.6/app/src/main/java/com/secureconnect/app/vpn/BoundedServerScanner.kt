package com.secureconnect.app.vpn

import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicBoolean

/** Fixed worker count, dynamic queue: one slow server cannot hold up the other lane. */
object BoundedServerScanner {
    suspend fun <T, R> scan(
        items: List<T>,
        workers: Int,
        beforeEach: suspend () -> Unit,
        check: suspend (T) -> R,
        onResult: suspend (T, R) -> Boolean
    ) = coroutineScope {
        val next = AtomicInteger(0)
        val stop = AtomicBoolean(false)
        List(workers.coerceIn(1, 2).coerceAtMost(items.size)) {
            async {
                while (!stop.get()) {
                    beforeEach()
                    val index = next.getAndIncrement()
                    if (index >= items.size || stop.get()) break
                    val item = items[index]
                    val result = check(item)
                    if (!onResult(item, result)) stop.set(true)
                }
            }
        }.awaitAll()
        Unit
    }
}
