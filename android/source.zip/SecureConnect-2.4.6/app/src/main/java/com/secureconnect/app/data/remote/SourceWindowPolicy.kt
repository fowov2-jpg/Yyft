package com.secureconnect.app.data.remote

/** Rotate source candidates without growing the on-disk 100-config cache. */
object SourceWindowPolicy {
    fun <T> page(items: List<T>, pageSize: Int, page: Int): List<T> {
        if (items.isEmpty() || pageSize <= 0) return emptyList()
        val start = ((page.coerceAtLeast(0).toLong() * pageSize) % items.size).toInt()
        return (items.drop(start) + items.take(start)).take(pageSize)
    }
}
