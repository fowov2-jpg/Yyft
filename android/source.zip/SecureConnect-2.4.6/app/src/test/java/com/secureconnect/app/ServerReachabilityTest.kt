package com.secureconnect.app

import com.secureconnect.app.vpn.ServerReachability
import org.junit.Assert.*
import org.junit.Test

class ServerReachabilityTest {
    private fun config(protocol: String, network: String) =
        """{"outbounds":[{"protocol":"$protocol","streamSettings":{"network":"$network"}}]}"""

    @Test fun udpAndUnknownTransportsAreNeverRejectedByTcpFilter() {
        assertFalse(ServerReachability.usesTcp(config("hysteria2", "")))
        assertFalse(ServerReachability.usesTcp(config("tuic", "")))
        assertFalse(ServerReachability.usesTcp(config("vless", "kcp")))
        assertFalse(ServerReachability.usesTcp(config("vmess", "quic")))
        assertFalse(ServerReachability.usesTcp(config("vless", "unknown")))
    }

    @Test fun commonTcpTransportsCanUseTheCheapFilter() {
        for (network in listOf("tcp", "raw", "ws", "grpc", "xhttp", "httpupgrade")) {
            assertTrue(ServerReachability.usesTcp(config("vless", network)))
        }
    }

    @Test fun currentMethodFieldTakesPrecedenceOverLegacyNetwork() {
        val udp = """{"outbounds":[{"protocol":"vless","streamSettings":{"method":"mkcp","network":"tcp"}}]}"""
        val tcp = """{"outbounds":[{"protocol":"vless","streamSettings":{"method":"websocket","network":"quic"}}]}"""
        assertFalse(ServerReachability.usesTcp(udp))
        assertTrue(ServerReachability.usesTcp(tcp))
    }

}
