import java.util.zip.ZipFile
import java.io.File
import java.net.URI
import java.security.MessageDigest

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "com.secureconnect.app"
    compileSdk = 36

    lint {
        checkReleaseBuilds = true
        abortOnError = true
    }

    defaultConfig {
        applicationId = "com.secureconnect.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 252
        versionName = "2.4.6"

        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    signingConfigs {
        val releaseKeystore = rootProject.file("release.keystore")
        if (releaseKeystore.exists()) {
            create("release") {
                storeFile = releaseKeystore
                storePassword = providers.gradleProperty("SC_STORE_PASSWORD").orNull
                    ?: providers.environmentVariable("SC_STORE_PASSWORD").orNull
                keyAlias = providers.gradleProperty("SC_KEY_ALIAS").orNull
                    ?: providers.environmentVariable("SC_KEY_ALIAS").orNull
                    ?: "secureconnect"
                keyPassword = providers.gradleProperty("SC_KEY_PASSWORD").orNull
                    ?: providers.environmentVariable("SC_KEY_PASSWORD").orNull
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            if (rootProject.file("release.keystore").exists()) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
        debug {
            isMinifyEnabled = false
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            excludes += "META-INF/kotlinx_coroutines_core.version"
            pickFirsts += "META-INF/kotlin-project-structure-metadata.json"
            pickFirsts += "**/libc++_shared.so"
            pickFirsts += "**/libgojni.so"
        }
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.fromTarget("17"))
    }
}

// libv2ray.aar — скачивание при первой сборке
val xrayAar = layout.projectDirectory.file("libs/libv2ray.aar").asFile
val xrayVersion = "v26.9.30"
// Prefer the upstream release; the verified SourceForge mirror handles restricted
// GitHub networks. Both files must match the SAME pinned SHA-256.
val xrayUrls = listOf(
    "https://github.com/2dust/AndroidLibXrayLite/releases/download/$xrayVersion/libv2ray.aar",
    "https://sourceforge.net/projects/androidlibxraylite.mirror/files/$xrayVersion/libv2ray.aar/download"
)
// Published GitHub release asset digest for v26.9.30. Pinning it makes builds reproducible
// and prevents a corrupt/HTML response from being accepted as the native core.
val xraySha256 = "cf71680b776b9ca583747ba652f816b047a655eab875d8951e6141636d88bbd6"

fun sha256(file: File): String {
    val md = MessageDigest.getInstance("SHA-256")
    file.inputStream().buffered().use { input ->
        val buffer = ByteArray(1024 * 1024)
        while (true) {
            val n = input.read(buffer)
            if (n < 0) break
            if (n > 0) md.update(buffer, 0, n)
        }
    }
    return md.digest().joinToString("") { "%02x".format(it) }
}

fun validateXrayAar(file: File) {
    if (!file.isFile || file.length() < 1024L) {
        throw GradleException("libv2ray.aar отсутствует или пуст: ${file.absolutePath}")
    }
    val actualSha256 = sha256(file)
    if (!actualSha256.equals(xraySha256, ignoreCase = true)) {
        throw GradleException(
            "Некорректный libv2ray.aar: SHA-256=$actualSha256, ожидался $xraySha256 ($xrayVersion)"
        )
    }
    try {
        ZipFile(file).use { zip ->
            val required = listOf(
                "classes.jar",
                "jni/arm64-v8a/libgojni.so",
                "jni/armeabi-v7a/libgojni.so"
            )
            val missing = required.filter { zip.getEntry(it) == null }
            if (missing.isNotEmpty()) {
                throw GradleException("Некорректный libv2ray.aar: отсутствуют ${missing.joinToString()}")
            }
        }
    } catch (e: GradleException) {
        throw e
    } catch (e: Exception) {
        throw GradleException("libv2ray.aar не является корректным AAR/ZIP: ${e.message}", e)
    }
}

val downloadXray = tasks.register("downloadXray") {
    onlyIf { !xrayAar.exists() }
    doLast {
        xrayAar.parentFile.mkdirs()
        val tmp = File(xrayAar.parentFile, "libv2ray.aar.part")
        val errors = mutableListOf<String>()
        var success = false
        for (url in xrayUrls) {
            try {
                tmp.delete()
                val connection = URI.create(url).toURL().openConnection().apply {
                    connectTimeout = 15_000
                    readTimeout = 90_000
                    setRequestProperty("User-Agent", "SecureConnect-Gradle/1.7.7")
                }
                connection.getInputStream().use { input ->
                    tmp.outputStream().use { output -> input.copyTo(output) }
                }
                validateXrayAar(tmp)
                if (!tmp.renameTo(xrayAar)) {
                    tmp.copyTo(xrayAar, overwrite = true)
                    tmp.delete()
                }
                success = true
                break
            } catch (e: Exception) {
                errors += "$url: ${e.message}"
                tmp.delete()
            }
        }
        if (!success) {
            throw GradleException(
                "Не удалось скачать подлинный libv2ray.aar. Проверены два источника: " +
                    errors.joinToString(" | ") +
                    ". Можно вручную поместить этот же SHA-256 AAR в app/libs/."
            )
        }
    }
}

val validateXray = tasks.register("validateXray") {
    dependsOn(downloadXray)
    inputs.file(xrayAar)
    doLast { validateXrayAar(xrayAar) }
}

tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(validateXray) }

dependencies {
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")

    // Локальный AAR ядра Xray. downloadXray гарантирует наличие до preBuild.
    implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.aar"))))

    implementation(libs.androidx.core.ktx)

    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation("androidx.compose.animation:animation")
    implementation(libs.androidx.compose.foundation)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.icons.core)

    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.navigation.compose)

    implementation(libs.androidx.lifecycle.viewmodel.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.runtime.compose)
}
