package com.secureconnect.app.vpn

/** Android VpnService routes by installed package/UID, not by the domain being opened. */
enum class AppVpnMode { EXCLUDE_SELECTED, ONLY_SELECTED }

/**
 * Russian apps are automatically routed outside VPN unless manually overridden.
 * `excluded` stores only explicit direct-access choices, never the auto-generated catalog.
 * `forceVpn` stores explicit VPN choices that win over the Russian auto preset.
 */
data class AppRoutingSnapshot(
    val mode: AppVpnMode = AppVpnMode.EXCLUDE_SELECTED,
    val excluded: Set<String> = emptySet(),
    val included: Set<String> = emptySet(),
    val autoExcludeRussian: Boolean = true,
    val forceVpn: Set<String> = emptySet()
) {
    fun directPackages(): Set<String> = (
        excluded + if (autoExcludeRussian) RussianApps.defaultDirectPackages else emptySet()
    ) - forceVpn

    fun usesVpn(pkg: String): Boolean = when (mode) {
        AppVpnMode.EXCLUDE_SELECTED -> pkg !in directPackages()
        AppVpnMode.ONLY_SELECTED -> pkg in included
    }
}

data class InstalledVpnApp(
    val packageName: String,
    val title: String,
    val russianPreset: Boolean,
    val systemApp: Boolean
)

data class RussianApp(val packageName: String, val name: String)

/** Curated package IDs; country cannot safely be inferred from package prefixes or language. */
object RussianApps {
    val recommendedDirect = listOf(
        RussianApp("com.vkontakte.android", "ВКонтакте"),
        RussianApp("ru.oneme.app", "MAX"),
        RussianApp("ru.ok.android", "Одноклассники"),
        RussianApp("ru.yandex.searchplugin", "Яндекс Старт"),
        RussianApp("ru.yandex.yandexmaps", "Яндекс Карты"),
        RussianApp("ru.yandex.taxi", "Яндекс Go"),
        RussianApp("ru.yandex.music", "Яндекс Музыка"),
        RussianApp("ru.beru.android", "Яндекс Маркет"),
        RussianApp("ru.dublgis.dgismobile", "2ГИС"),
        RussianApp("ru.ozon.app.android", "Ozon"),
        RussianApp("com.wildberries.ru", "Wildberries"),
        RussianApp("com.avito.android", "Авито"),
        RussianApp("ru.rostel", "Госуслуги"),
        RussianApp("ru.mail.mailapp", "Почта Mail"),
        RussianApp("com.idamob.tinkoff.android", "Т-Банк"),
        RussianApp("ru.sberbankmobile", "СберБанк Онлайн"),
        RussianApp("ru.vtb24.mobilebanking.android", "ВТБ Онлайн"),
        RussianApp("ru.rutube.app", "RUTUBE"),
        RussianApp("com.vk.vkvideo", "VK Видео"),
        // Verified Android package identifiers, including heavily used Yandex services.
        RussianApp("com.yandex.browser", "Яндекс Браузер"),
        RussianApp("ru.yandex.mail", "Яндекс Почта"),
        RussianApp("ru.yandex.disk", "Яндекс Диск"),
        RussianApp("ru.vk.store", "RuStore"),
        RussianApp("com.punicapp.whoosh", "Whoosh"),
        RussianApp("com.edadeal.android", "Едадил"),
        RussianApp("ru.zen.android", "Дзен"),
        RussianApp("ru.alfabank.mobile.android", "Альфа-Банк"),
        RussianApp("ru.pyaterochka.app.browser", "Пятёрочка"),
        RussianApp("ru.vkusvill", "ВкусВилл"),
        RussianApp("ru.mts.mymts", "Мой МТС"),
        // Additional verified Russian-service apps (Google Play, 2026-10-08).
        RussianApp("ru.yandex.yandexnavi", "Яндекс Навигатор"),
        RussianApp("ru.kinopoisk", "Кинопоиск"),
        RussianApp("ru.kinopoisk.tv", "Кинопоиск для ТВ"),
        RussianApp("com.yandex.aliceapp", "Алиса AI"),
        RussianApp("ru.yandex.weatherplugin", "Яндекс Погода"),
        RussianApp("com.yandex.iot", "Дом с Алисой"),
        RussianApp("ru.yandex.telemost", "Яндекс Телемост"),
        RussianApp("ru.yandex.travel", "Яндекс Путешествия"),
        RussianApp("ru.yandex.rasp", "Яндекс Электрички"),
        RussianApp("ru.yandex.metro", "Яндекс Метро"),
        RussianApp("ru.yandex.key", "Яндекс ID"),
        RussianApp("ru.yandex.translate", "Яндекс Переводчик"),
        RussianApp("ru.yandex.androidkeyboard", "Яндекс Клавиатура"),
        RussianApp("ru.yandex.games", "Яндекс Игры"),
        RussianApp("ru.mail.cloud", "Облако Mail"),
        RussianApp("ru.tander.magnit", "Магнит"),
        RussianApp("ru.dodopizza.app", "Додо Пицца"),
        RussianApp("ru.sportmaster.app", "Спортмастер"),
        RussianApp("ru.leroymerlin.mobile", "Лемана ПРО"),
        RussianApp("ru.megamarket.marketplace", "Мегамаркет"),
        RussianApp("goldapple.ru.goldapple.customers", "Золотое Яблоко"),
        RussianApp("com.octopod.russianpost.client.android", "Почта России"),
        RussianApp("ru.rzd.pass", "РЖД Пассажирам"),
        RussianApp("ru.beeline.services", "билайн"),
        RussianApp("ru.tele2.mytele2", "t2"),
        RussianApp("ru.superapp.plus", "Яндекс Плюс")
    ) + RussianAppsExpanded.catalog
    /** Old v1 preset, used exclusively to migrate existing users without losing their overrides. */
    val legacyDirectPackages: Set<String> = recommendedDirect.take(19).mapTo(linkedSetOf()) { it.packageName }
    val defaultDirectPackages: Set<String> = recommendedDirect.mapTo(linkedSetOf()) { it.packageName }
}

/** Pure migration: treat missing legacy preset packages as deliberate user's VPN override. */
fun migrateLegacyExclusions(saved: Set<String>?): Pair<Set<String>, Set<String>> =
    if (saved == null) emptySet<String>() to emptySet()
    else (saved - RussianApps.legacyDirectPackages) to (RussianApps.legacyDirectPackages - saved)

sealed class AppRoutingRule {
    data class DenyVpn(val packages: Set<String>) : AppRoutingRule()
    data class AllowVpn(val packages: Set<String>) : AppRoutingRule()
}

/** Compiles policy for current installed packages and always keeps our own tunnel socket off VPN. */
fun AppRoutingSnapshot.forInstalledPackages(
    installed: Set<String>,
    ownPackage: String
): AppRoutingRule = when (mode) {
    AppVpnMode.EXCLUDE_SELECTED -> AppRoutingRule.DenyVpn(
        (directPackages() + ownPackage).filterTo(linkedSetOf()) { it in installed }
    )
    AppVpnMode.ONLY_SELECTED -> {
        val allowed = included.filterTo(linkedSetOf()) { it in installed && it != ownPackage }
        require(allowed.isNotEmpty()) {
            "Ни одно приложение из списка «Только выбранные» не установлено; проверьте фильтр"
        }
        AppRoutingRule.AllowVpn(allowed)
    }
}
