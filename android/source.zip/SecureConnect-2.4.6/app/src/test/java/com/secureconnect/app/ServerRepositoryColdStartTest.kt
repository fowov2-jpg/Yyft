package com.secureconnect.app

import com.secureconnect.app.data.model.Server
import com.secureconnect.app.data.remote.ServerRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ServerRepositoryColdStartTest {
    private fun server(
        id: String,
        source: String,
        rawLink: String,
        ping: Int
    ) = Server(
        id = id,
        country = "",
        city = id,
        flagEmoji = "",
        protocol = "VLESS",
        ping = ping,
        host = "example.com",
        port = 443,
        source = source,
        rawLink = rawLink
    )

    @Test fun expandedCandidateBudgetIsSharedAcrossAllSources() {
        val servers = (0 until 17).flatMap { source ->
            (0 until 50).map { index ->
                server("$source-$index", "source-$source",
                    "vless://id@x:443?security=reality&type=tcp", 0)
            }
        }
        val pool = ServerRepository.buildColdStartPool(servers, com.secureconnect.app.data.local.ServerStore.MAX_CACHED_SERVERS)
        assertEquals(240, pool.size)
        assertEquals(240, pool.map { it.id }.toSet().size)
        assertEquals(17, pool.map { it.source }.toSet().size)
        assertTrue(pool.groupBy { it.source }.values.all { it.size in 14..15 })
    }

    @Test
    fun previouslySuccessfulSourceGetsFirstProbeButDoesNotMonopolizePool() {
        val input = listOf(
            server("untried", "cold", "vless://id@x:443?security=tls&type=tcp", 70),
            server("trusted1", "proven", "vless://id@x:443?security=tls&type=tcp", 90),
            server("trusted2", "proven", "vless://id@x:443?security=tls&type=tcp", 95),
            server("other", "other", "vless://id@x:443?security=tls&type=tcp", 80)
        )
        val pool = ServerRepository.buildColdStartPool(input, 3, listOf("proven"))
        assertEquals("proven", pool.first().source)
        assertEquals(3, pool.map { it.source }.toSet().size)
    }

    @Test
    fun poolInterleavesSourcesInsteadOfTakingOnlyLowestTcpPing() {
        val servers = listOf(
            server("a-fast1", "a", "vless://id@x:443?security=tls&type=tcp", 10),
            server("a-fast2", "a", "vless://id@x:443?security=tls&type=tcp", 11),
            server("b-reality", "b", "vless://id@x:443?security=reality&type=tcp", 800),
            server("c-reality", "c", "vless://id@x:443?security=reality&type=tcp", 900)
        )

        val pool = ServerRepository.buildColdStartPool(servers, 3)

        assertEquals(3, pool.size)
        assertEquals(setOf("a", "b", "c"), pool.map { it.source }.toSet())
    }

    @Test
    fun sub100PingWinsInsideOneSourceBeforeTransportHeuristic() {
        val servers = listOf(
            server("tls", "a", "vless://id@x:443?security=tls&type=tcp", 15),
            server("reality", "a", "vless://id@x:443?security=reality&type=tcp", 700)
        )

        val pool = ServerRepository.buildColdStartPool(servers, 2)

        assertEquals("tls", pool.first().id)
        assertTrue(pool.any { it.id == "reality" })
    }
}
