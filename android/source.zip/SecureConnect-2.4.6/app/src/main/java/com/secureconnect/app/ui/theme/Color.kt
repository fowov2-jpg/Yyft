package com.secureconnect.app.ui.theme

import androidx.compose.ui.graphics.Color

/** Cold Titanium: subdued surfaces; color reserved for actual connection/security state. */
val ScBackground = Color(0xFF0C1017)
val ScSurface = Color(0xFF141B26)
val ScCard = Color(0xFF1C2532)
val ScCardSelected = Color(0xFF273545)
val ScPrimary = Color(0xFFC6D3E0)
val ScPrimaryVariant = Color(0xFF526A7C)
val ScPrimarySoft = Color(0xFF263746)
val ScOnPrimary = Color(0xFF14202C)
val ScTextPrimary = Color(0xFFF3F6FA)
val ScTextSecondary = Color(0xFF97A5B6)
val ScSuccess = Color(0xFF79DDB8)
val ScSuccessSoft = Color(0xFF1E493B)
val ScWarning = Color(0xFFF2C074)
val ScError = Color(0xFFFF7886)
val ScBorder = Color(0xFF303A49)
