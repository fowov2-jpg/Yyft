package com.secureconnect.app.viewmodel

import com.secureconnect.app.data.model.Server
import kotlin.math.roundToInt

/**
 * Adaptive health history for failover.
 *
 * The ledger intentionally stores only opaque server ids and aggregate timing/error
 * metadata. Credentials and raw subscription links never enter persistence.
 */
class ServerHealthLedger(
    private val nowMs: () -> Long = { System.currentTimeMillis() }
) {
    data class Entry(
        val serverId: String,
        val lastSuccessAtMs: Long = 0L,
        val lastFailureAtMs: Long = 0L,
        val consecutiveFailures: Int = 0,
        val cooldownUntilMs: Long = 0L,
        val ewmaHttpsMs: Double? = null,
        val lastFailureStage: String? = null
    )

    private val entries = LinkedHashMap<String, Entry>()

    @Synchronized
    fun recordSuccess(serverId: String, httpsMs: Int) {
        val now = nowMs()
        val previous = entries[serverId]
        val sample = httpsMs.coerceAtLeast(1).toDouble()
        val ewma = previous?.ewmaHttpsMs?.let { old ->
            EWMA_ALPHA * sample + (1.0 - EWMA_ALPHA) * old
        } ?: sample

        entries[serverId] = Entry(
            serverId = serverId,
            lastSuccessAtMs = now,
            lastFailureAtMs = previous?.lastFailureAtMs ?: 0L,
            consecutiveFailures = 0,
            cooldownUntilMs = 0L,
            ewmaHttpsMs = ewma,
            lastFailureStage = null
        )
        trim()
    }

    @Synchronized
    fun recordFailure(serverId: String, stage: String?) {
        val now = nowMs()
        val previous = entries[serverId]
        val previousFailures = if (
            previous != null &&
            previous.lastFailureAtMs > 0L &&
            now - previous.lastFailureAtMs <= STREAK_RESET_MS
        ) {
            previous.consecutiveFailures
        } else {
            0
        }
        val failures = previousFailures + 1
        val cooldown = cooldownFor(failures)

        entries[serverId] = Entry(
            serverId = serverId,
            lastSuccessAtMs = previous?.lastSuccessAtMs ?: 0L,
            lastFailureAtMs = now,
            consecutiveFailures = failures,
            cooldownUntilMs = now + cooldown,
            ewmaHttpsMs = previous?.ewmaHttpsMs,
            lastFailureStage = stage?.take(48)
        )
        trim()
    }

    @Synchronized
    fun entry(serverId: String): Entry? = entries[serverId]

    @Synchronized
    fun isCoolingDown(serverId: String): Boolean {
        val e = entries[serverId] ?: return false
        return e.cooldownUntilMs > nowMs()
    }

    @Synchronized
    fun hasSuccessfulHistory(serverId: String): Boolean {
        val e = entries[serverId] ?: return false
        return isProvenHealthy(e, nowMs())
    }

    @Synchronized
    fun ewmaMs(serverId: String): Int? =
        entries[serverId]?.ewmaHttpsMs
            ?.takeIf { it.isFinite() && it > 0.0 }
            ?.roundToInt()
            ?.coerceAtLeast(1)

    @Synchronized
    fun snapshot(): List<Entry> = entries.values.toList()

    @Synchronized
    fun restore(restored: Iterable<Entry>) {
        entries.clear()
        val now = nowMs()
        restored
            .filter { it.serverId.isNotBlank() }
            .sortedByDescending { maxOf(it.lastSuccessAtMs, it.lastFailureAtMs) }
            .take(MAX_ENTRIES)
            .forEach { entry ->
                // Never revive absurd/corrupt timestamps indefinitely.
                val cooldown = entry.cooldownUntilMs
                    .coerceAtMost(now + MAX_COOLDOWN_MS)
                    .coerceAtLeast(0L)
                entries[entry.serverId] = entry.copy(
                    consecutiveFailures = entry.consecutiveFailures.coerceIn(0, 32),
                    cooldownUntilMs = cooldown,
                    ewmaHttpsMs = entry.ewmaHttpsMs?.takeIf { it.isFinite() && it > 0.0 }
                )
            }
    }

    /**
     * Applies health history without permanently blacklisting servers.
     *
     * Healthy/unknown candidates outside cooldown come first. Candidates still in
     * cooldown are kept as a last-resort tail so a small server pool can recover.
     */
    @Synchronized
    fun rank(base: List<Server>): List<Server> {
        if (base.size <= 1) return base
        val now = nowMs()
        val baseOrder = base.withIndex().associate { it.value.id to it.index }

        return base.distinctBy { it.id }.sortedWith(
            compareBy<Server> { server ->
                val e = entries[server.id]
                if (e != null && e.cooldownUntilMs > now) 1 else 0
            }.thenBy { server ->
                val e = entries[server.id]
                when {
                    e != null && isProvenHealthy(e, now) -> 0
                    e == null -> 1
                    e.consecutiveFailures == 0 -> 1
                    else -> 2
                }
            }.thenBy { server ->
                val e = entries[server.id]
                if (e != null && isProvenHealthy(e, now)) {
                    e.ewmaHttpsMs ?: Double.MAX_VALUE
                } else {
                    Double.MAX_VALUE
                }
            }.thenByDescending { server ->
                entries[server.id]?.lastSuccessAtMs ?: 0L
            }.thenBy { server ->
                val e = entries[server.id]
                if (e != null && e.cooldownUntilMs > now) e.cooldownUntilMs else 0L
            }.thenBy { server ->
                baseOrder[server.id] ?: Int.MAX_VALUE
            }
        )
    }

    @Synchronized
    fun describe(serverId: String): String? {
        val e = entries[serverId] ?: return null
        val now = nowMs()
        val cooldownLeft = (e.cooldownUntilMs - now).coerceAtLeast(0L)
        return buildString {
            if (e.ewmaHttpsMs != null) {
                append("ewma=")
                append(e.ewmaHttpsMs.roundToInt())
                append("ms")
            }
            if (e.consecutiveFailures > 0) {
                if (isNotEmpty()) append(", ")
                append("fails=")
                append(e.consecutiveFailures)
            }
            if (cooldownLeft > 0L) {
                if (isNotEmpty()) append(", ")
                append("cooldown=")
                append((cooldownLeft + 999L) / 1000L)
                append("s")
            }
            e.lastFailureStage?.let {
                if (isNotEmpty()) append(", ")
                append("stage=")
                append(it)
            }
        }.ifBlank { null }
    }

    private fun isProvenHealthy(entry: Entry, now: Long): Boolean {
        if (entry.lastSuccessAtMs <= 0L) return false
        if (entry.lastSuccessAtMs <= entry.lastFailureAtMs) return false
        val age = now - entry.lastSuccessAtMs
        return age in 0..SUCCESS_FRESH_MS
    }

    private fun trim() {
        if (entries.size <= MAX_ENTRIES) return
        val keep = entries.values
            .sortedByDescending { maxOf(it.lastSuccessAtMs, it.lastFailureAtMs) }
            .take(MAX_ENTRIES)
        entries.clear()
        keep.forEach { entries[it.serverId] = it }
    }

    private fun cooldownFor(failures: Int): Long = when (failures) {
        1 -> 30_000L
        2 -> 120_000L
        3 -> 600_000L
        else -> MAX_COOLDOWN_MS
    }

    companion object {
        private const val EWMA_ALPHA = 0.35
        private const val MAX_ENTRIES = 256
        private const val SUCCESS_FRESH_MS = 21_600_000L
        private const val STREAK_RESET_MS = 1_800_000L
        private const val MAX_COOLDOWN_MS = 1_800_000L
    }
}
