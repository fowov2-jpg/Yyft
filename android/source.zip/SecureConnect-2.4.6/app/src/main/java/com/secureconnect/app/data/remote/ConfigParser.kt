package com.secureconnect.app.data.remote

import java.util.Base64
import com.secureconnect.app.data.model.ServerQualityHints
import com.secureconnect.app.data.model.Server
import org.json.JSONObject
import java.net.URLDecoder
import java.util.Locale

/** Разбор подписок (plain / base64) и ссылок vless://, vmess://, trojan://, ss://, hysteria2://, tuic:// */
object ConfigParser {

    private val schemes = listOf("vless", "vmess", "trojan", "ss", "hysteria2", "hy2", "hysteria", "tuic")
    private val isoCountries: Set<String> = Locale.getISOCountries().toSet()

    /** Достаёт ограниченный список ссылок из plain/base64 тела подписки. */
    fun extractLinks(body: String, maxLinks: Int = 500): List<String> {
        if (maxLinks <= 0) return emptyList()
        val text = body.trim()
        if (text.isBlank()) return emptyList()

        // Some subscription formats prepend Clash-style `#profile-*` metadata,
        // including ordinary https:// links, before a base64 payload. Looking only
        // for `://` would misclassify such a subscription as plain text and never
        // decode the actual VPN nodes. Collect both the visible text and safe
        // base64 candidates instead.
        val pattern = Regex("(?i)(?:${schemes.joinToString("|")})://[^\\s<>\"']+")
        val result = LinkedHashSet<String>()

        fun collect(candidate: String) {
            if (candidate.isBlank() || result.size >= maxLinks) return
            for (line in candidate.lineSequence()) {
                if (result.size >= maxLinks) break
                val trimmed = line.trim()
                val matches = pattern.findAll(trimmed).take(maxLinks - result.size).toList()
                if (matches.size == 1 && matches[0].range.first == 0 && '#' in matches[0].value &&
                    pattern.findAll(trimmed).take(2).count() == 1) {
                    // Preserve explicit labels after # even if publisher omitted URL escaping.
                    result += trimmed.trimEnd(',', ';')
                } else {
                    matches.forEach { result += it.value.trim().trimEnd(',', ';') }
                }
            }
        }

        collect(text)

        if (result.size < maxLinks) {
            val payloadWithoutMetadata = text.lineSequence()
                .map(String::trim)
                .filter { it.isNotEmpty() && !it.startsWith('#') }
                .joinToString(separator = "")
            decodeBase64(payloadWithoutMetadata)?.let(::collect)
        }

        // A few providers concatenate independently encoded chunks line-by-line.
        // Decode a bounded number of plausible base64 lines as a fallback.
        if (result.size < maxLinks) {
            text.lineSequence()
                .map(String::trim)
                .filter { line ->
                    line.length >= 16 && !line.startsWith('#') && !line.contains("://")
                }
                .take(64)
                .forEach { line -> decodeBase64(line)?.let(::collect) }
        }

        return result.take(maxLinks)
    }

    fun parse(link: String, source: String): Server? {
        val scheme = link.substringBefore("://").lowercase()
        val rest = link.substringAfter("://")
        return try {
            when (scheme) {
                "vmess" -> parseVmess(rest, link, source)
                "ss" -> parseSs(rest, link, source)
                "hysteria2", "hy2" -> parseHysteria2(rest, link, source)
                // Xray 26.9.x does not provide a TUIC outbound. Keep the parser
                // strict instead of showing a server which can never connect.
                "tuic" -> null
                else -> parseGeneric(scheme, rest, link, source)
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun parseGeneric(scheme: String, rest: String, link: String, source: String): Server? {
        val remark = decodeUrl(rest.substringAfterLast('#', ""))
        val authority = rest.substringBefore('#').substringBefore('?').substringBefore('/')
        val hostPort = authority.substringAfterLast('@')
        return build(scheme, hostPort, remark, link, source)
    }


    private fun parseHysteria2(rest: String, link: String, source: String): Server? {
        val noFragment = rest.substringBefore('#')
        val main = noFragment.substringBefore('?')
        val authority = main.substringAfterLast('@').substringBefore('/')
        val host: String
        val port: Int
        if (authority.startsWith("[")) {
            host = authority.substringAfter('[').substringBefore(']')
            port = authority.substringAfter("]:", "443").toIntOrNull() ?: 443
        } else {
            host = authority.substringBeforeLast(':')
            val rawPort = authority.substringAfterLast(':', "")
            port = rawPort.toIntOrNull() ?: 443
        }
        if (host.isBlank() || port !in 1..65535) return null
        val remark = decodeUrl(rest.substringAfterLast('#', ""))
        val (flag, country) = detectCountry(remark) ?: ("🌐" to "Неизвестно")
        val city = stripFlags(remark).trim().take(28).ifBlank { host }
        val id = "cfg-" + link.substringBefore('#').hashCode().toUInt().toString(16)
        val password = decodeUrl(main.substringBeforeLast('@', ""))
        if (password.isBlank()) return null
        // Keep the complete URI in rawLink. XrayConfigBuilder reads SNI,
        // insecure and Salamander parameters from it when creating the core config.
        val labels = ServerQualityHints.parse(remark)
        return Server(
            reportedPingMs = labels.pingMs, reportedLoadPercent = labels.loadPercent,
            id = id, country = country, city = city, flagEmoji = flag,
            protocol = "HYSTERIA2", ping = 0,
            host = host, port = port, source = source, rawLink = link
        )
    }

    private fun parseVmess(rest: String, link: String, source: String): Server? {
        val json = JSONObject(decodeBase64(rest.substringBefore('#')) ?: return null)
        val host = json.optString("add")
        val port = json.optInt("port", 0)
        val remark = json.optString("ps")
        val hostPort = if (host.contains(':')) "[$host]:$port" else "$host:$port"
        return build("vmess", hostPort, remark, link, source)
    }

    private fun parseSs(rest: String, link: String, source: String): Server? {
        val remark = decodeUrl(rest.substringAfterLast('#', ""))
        val main = rest.substringBefore('#').substringBefore('?')
        val hostPart = if (main.contains('@')) {
            main.substringAfterLast('@')
        } else {
            (decodeBase64(main) ?: return null).substringAfterLast('@')
        }
        return build("ss", hostPart.substringBefore('/'), remark, link, source)
    }

    private fun build(scheme: String, hostPort: String, remark: String, link: String, source: String): Server? {
        val host: String
        val portStr: String
        if (hostPort.startsWith("[")) {
            host = hostPort.substringAfter('[').substringBefore(']')
            portStr = hostPort.substringAfter("]:", "")
        } else {
            host = hostPort.substringBeforeLast(':')
            portStr = hostPort.substringAfterLast(':', "")
        }
        val port = portStr.takeWhile { it.isDigit() }.toIntOrNull() ?: return null
        if (host.isBlank() || port !in 1..65535) return null

        val (flag, country) = detectCountry(remark) ?: ("🌐" to "Неизвестно")
        val city = stripFlags(remark).trim().take(28).ifBlank { host }
        val id = "cfg-" + link.substringBefore('#').hashCode().toUInt().toString(16)

        val labels = ServerQualityHints.parse(remark)
        return Server(
            reportedPingMs = labels.pingMs, reportedLoadPercent = labels.loadPercent,
            id = id,
            country = country,
            city = city,
            flagEmoji = flag,
            protocol = protocolLabel(scheme),
            ping = 0,
            host = host,
            port = port,
            source = source,
            rawLink = link
        )
    }

    private fun protocolLabel(scheme: String) = when (scheme) {
        "ss" -> "SHADOWSOCKS"
        "hy2" -> "HYSTERIA2"
        else -> scheme.uppercase()
    }

    /** Ищем страну: сначала эмодзи-флаг, потом двухбуквенный ISO-код в тексте. */
    private fun detectCountry(text: String): Pair<String, String>? {
        val cps = text.codePoints().toArray()
        for (i in 0 until cps.size - 1) {
            if (isRegional(cps[i]) && isRegional(cps[i + 1])) {
                val code = "${'A' + (cps[i] - 0x1F1E6)}${'A' + (cps[i + 1] - 0x1F1E6)}"
                if (code in isoCountries) return flagOf(code) to countryName(code)
            }
        }
        val token = text.split(Regex("[^A-Za-z]+"))
            .firstOrNull { it.length == 2 && it == it.uppercase() && it in isoCountries }
        return token?.let { flagOf(it) to countryName(it) }
    }

    private fun isRegional(cp: Int) = cp in 0x1F1E6..0x1F1FF

    private fun flagOf(code: String): String {
        val sb = StringBuilder()
        code.forEach { sb.appendCodePoint(0x1F1E6 + (it - 'A')) }
        return sb.toString()
    }

    private fun countryName(code: String): String =
        Locale("", code).getDisplayCountry(Locale("ru")).ifBlank { code }

    private fun stripFlags(text: String): String {
        val sb = StringBuilder()
        text.codePoints().forEach { if (!isRegional(it)) sb.appendCodePoint(it) }
        return sb.toString()
    }

    private fun decodeUrl(s: String): String =
        try { URLDecoder.decode(s, "UTF-8") } catch (e: Exception) { s }

    internal fun decodeBase64(input: String): String? {
        val s = input.filter { !it.isWhitespace() }.replace('-', '+').replace('_', '/')
        if (s.isEmpty()) return null
        val padded = s + "=".repeat((4 - s.length % 4) % 4)
        return try {
            String(Base64.getDecoder().decode(padded), Charsets.UTF_8)
        } catch (e: IllegalArgumentException) {
            null
        }
    }
}
