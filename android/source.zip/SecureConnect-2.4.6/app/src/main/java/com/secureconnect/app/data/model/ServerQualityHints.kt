package com.secureconnect.app.data.model

import kotlin.math.ceil

/** Explicit, unverified publisher labels. Never infer load from RTT or link counts. */
object ServerQualityHints {
    data class Labels(val pingMs: Int?, val loadPercent: Double?)
    private val ping = Regex("""(?iu)(?<![\p{L}\p{N}_])(?:ping|latency|delay|пинг|задержка)\s*[:=]?\s*(?:≤|<=|до\s*)?\s*(\d+(?:[.,]\d+)?)\s*(?:ms|мс)(?![\p{L}])""")
    private val load = Regex("""(?iu)(?<![\p{L}\p{N}_])(?:load|server\s+load|нагрузка|загрузка)\s*[:=]?\s*(?:≤|<=|до\s*)?\s*(\d+(?:[.,]\d+)?)\s*%""")

    fun parse(remark: String): Labels {
        fun values(pattern: Regex): List<Double> = pattern.findAll(remark.take(4096))
            .mapNotNull { it.groupValues[1].replace(',', '.').toDoubleOrNull() }.toList()
        val delays = values(ping)
        val loads = values(load)
        // Conflicting repeated labels use the worse value. Invalid labels remain unknown.
        val delay = delays.takeIf { it.isNotEmpty() && it.all { x -> x.isFinite() && x > 0 && x <= 60_000 } }
            ?.maxOrNull()?.let { ceil(it).toInt() }
        val utilization = loads.takeIf { it.isNotEmpty() && it.all { x -> x.isFinite() && x in 0.0..100.0 } }
            ?.maxOrNull()
        return Labels(delay, utilization)
    }

    fun importPriority(server: Server): Int {
        val ping = server.reportedPingMs
        val load = server.reportedLoadPercent
        if ((ping != null && ping > 100) || (load != null && load > 70.0)) return 3
        if (ping != null && load != null) return 0
        if (ping != null || load != null) return 1
        return 2
    }

    fun loadPriority(server: Server): Int = when {
        server.reportedLoadPercent == null -> 1
        server.reportedLoadPercent <= 70.0 -> 0
        else -> 2
    }

    fun description(server: Server): String? {
        if (server.reportedPingMs == null && server.reportedLoadPercent == null) return null
        val ping = server.reportedPingMs?.let { "$it мс" } ?: "не указана"
        val load = server.reportedLoadPercent?.let { "${it.toString().removeSuffix(".0")}%" } ?: "не указана"
        return "Источник: задержка $ping · нагрузка $load"
    }
}
