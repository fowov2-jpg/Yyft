package com.secureconnect.app.ui.screens.home

import org.junit.Assert.assertEquals
import org.junit.Test

class RiskTonePolicyTest {
    @Test fun thresholdsAreInclusiveAtUserChosenBoundaries() {
        assertEquals(RiskTone.UNKNOWN, RiskTonePolicy.forIndex(null))
        assertEquals(RiskTone.GREEN, RiskTonePolicy.forIndex(0))
        assertEquals(RiskTone.GREEN, RiskTonePolicy.forIndex(20))
        assertEquals(RiskTone.GREEN, RiskTonePolicy.forIndex(32))
        assertEquals(RiskTone.YELLOW, RiskTonePolicy.forIndex(33))
        assertEquals(RiskTone.YELLOW, RiskTonePolicy.forIndex(59))
        assertEquals(RiskTone.RED, RiskTonePolicy.forIndex(60))
        assertEquals(RiskTone.RED, RiskTonePolicy.forIndex(100))
    }
}
