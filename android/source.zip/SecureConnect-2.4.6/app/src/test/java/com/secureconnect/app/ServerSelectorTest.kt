package com.secureconnect.app

import com.secureconnect.app.data.model.Server
import com.secureconnect.app.viewmodel.ServerSelector
import org.junit.Assert.assertEquals
import org.junit.Test

class ServerSelectorTest {
    private fun server(id: String, source: String, ping: Int) = Server(
        id = id,
        country = "",
        city = "",
        flagEmoji = "",
        protocol = "VLESS",
        ping = ping,
        host = "example.com",
        port = 443,
        source = source,
        rawLink = "vless://$id@example.com:443?security=tls&type=tcp"
    )

    @Test
    fun diversifyBySourceRoundRobinsWithoutDestroyingPerSourceRank() {
        val ranked = listOf(
            server("a1", "a", 10),
            server("a2", "a", 11),
            server("a3", "a", 12),
            server("b1", "b", 20),
            server("c1", "c", 30),
            server("b2", "b", 21)
        )

        val result = ServerSelector.diversifyBySource(ranked, 6)

        assertEquals(listOf("a1", "b1", "c1", "a2", "b2", "a3"), result.map { it.id })
    }

    @Test
    fun diversifyBySourceHonorsLimitAndDeduplicatesIds() {
        val a1 = server("a1", "a", 10)
        val result = ServerSelector.diversifyBySource(
            listOf(a1, a1, server("b1", "b", 20), server("a2", "a", 11)),
            2
        )

        assertEquals(listOf("a1", "b1"), result.map { it.id })
    }

    @Test
    fun cooldownTierIsPreservedAcrossSourceDiversification() {
        val ranked = listOf(
            server("a1", "a", 10),
            server("b1", "b", 11),
            server("a2", "a", 12),
            server("c1", "c", 13)
        )

        val result = ServerSelector.diversifyBySourceWithCooldown(
            ranked = ranked,
            limit = 4,
            isCoolingDown = { it.id == "b1" }
        )

        assertEquals(listOf("a1", "c1", "a2", "b1"), result.map { it.id })
    }
    @Test
    fun adaptiveChoicePrefersProvenSuccessOverColdStartPenalty() {
        val unknown = server("unknown", "fresh", 20)
        val proven = server("proven", "used", 900)

        val result = ServerSelector.chooseAdaptive(
            ranked = listOf(unknown, proven),
            sourceFailures = mapOf("used" to 3),
            familyFailures = emptyMap(),
            isCoolingDown = { false },
            hasSuccessfulHistory = { it.id == "proven" }
        )

        assertEquals("proven", result?.id)
    }

    @Test
    fun adaptiveChoiceMovesAwayFromAlreadyFailingSource() {
        val sameSource = server("a2", "source-a", 10)
        val otherSource = server("b1", "source-b", 200)

        val result = ServerSelector.chooseAdaptive(
            ranked = listOf(sameSource, otherSource),
            sourceFailures = mapOf("source-a" to 1),
            familyFailures = emptyMap(),
            isCoolingDown = { false },
            hasSuccessfulHistory = { false }
        )

        assertEquals("b1", result?.id)
    }

    @Test
    fun workingPoolAlwaysComesBeforeUnknownGlobalCandidates() {
        val working = server("working", "known", 550)
        val globalFastTcp = server("global-fast", "fresh", 20)

        val result = ServerSelector.chooseAdaptive(
            ranked = listOf(globalFastTcp, working),
            sourceFailures = emptyMap(),
            familyFailures = emptyMap(),
            isCoolingDown = { false },
            hasSuccessfulHistory = { false },
            isWorking = { it.id == "working" },
            knownLatencyMs = { it.ping }
        )

        assertEquals("working", result?.id)
    }

    @Test
    fun sub100RealLatencyWinsInsideWorkingPool() {
        val slowWorking = server("slow", "known-a", 240)
        val fastWorking = server("fast", "known-b", 95)

        val result = ServerSelector.chooseAdaptive(
            ranked = listOf(slowWorking, fastWorking),
            sourceFailures = emptyMap(),
            familyFailures = emptyMap(),
            isCoolingDown = { false },
            hasSuccessfulHistory = { false },
            isWorking = { true },
            knownLatencyMs = { it.ping }
        )

        assertEquals("fast", result?.id)
    }

    @Test
    fun sub100GlobalCandidateBeatsHigherLatencyGlobalTransportHint() {
        val fastTls = server("fast", "a", 75)
        val slowerReality = server("slow", "b", 450).copy(
            rawLink = "vless://slow@example.com:443?security=reality&type=tcp"
        )

        val result = ServerSelector.chooseAdaptive(
            ranked = listOf(slowerReality, fastTls),
            sourceFailures = emptyMap(),
            familyFailures = emptyMap(),
            isCoolingDown = { false },
            hasSuccessfulHistory = { false }
        )

        assertEquals("fast", result?.id)
    }


    @Test
    fun defaultRankingHonorsPrimaryAndDeduplicatesCandidates() {
        val primary = server("selected", "a", 300)
        val fast = server("fast", "b", 40)
        val slow = server("slow", "c", 800)
        val ranked = ServerSelector.rank(listOf(primary, slow, fast, fast), primary)
        assertEquals(listOf("selected", "fast", "slow"), ranked.map { it.id })
    }

}
