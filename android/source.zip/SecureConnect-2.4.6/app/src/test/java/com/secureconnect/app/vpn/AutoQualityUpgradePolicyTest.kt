package com.secureconnect.app.vpn

import org.junit.Assert.*
import org.junit.Test

class AutoQualityUpgradePolicyTest {
    private val poorDown = AutoQualityUpgradePolicy.Pending("active", 1.6, 2.0)
    private val poorUp = AutoQualityUpgradePolicy.Pending("active", 14.0, 0.4)

    @Test fun slowDownloadChoosesQualifiedFastReserve() {
        assertTrue(AutoQualityUpgradePolicy.isWorthSwitching(poorDown, 45, 9.0, 2.0))
        assertTrue(AutoQualityUpgradePolicy.isWorthSwitching(poorDown, 100, 5.0, 1.0))
    }
    @Test fun highPingAndSlowReserveNotAdmitted() {
        assertFalse(AutoQualityUpgradePolicy.isWorthSwitching(poorDown, 101, 12.0, 3.0))
        assertFalse(AutoQualityUpgradePolicy.isWorthSwitching(poorDown, 0, 12.0, 3.0))
        assertFalse(AutoQualityUpgradePolicy.isWorthSwitching(poorDown, 50, 4.9, 3.0))
        assertFalse(AutoQualityUpgradePolicy.isWorthSwitching(poorDown, 50, 8.0, .9))
    }
    @Test fun uploadOnlySlowMustNotSacrificeDownload() {
        assertTrue(AutoQualityUpgradePolicy.isWorthSwitching(poorUp, 30, 12.0, 1.5))
        assertFalse(AutoQualityUpgradePolicy.isWorthSwitching(poorUp, 30, 6.0, 2.5))
    }
    @Test fun doNotSwitchHealthyOrUnknownBaseline() {
        assertFalse(AutoQualityUpgradePolicy.isWorthSwitching(
            AutoQualityUpgradePolicy.Pending("a", 10.0, 1.5), 30, 12.0, 2.0))
        assertFalse(AutoQualityUpgradePolicy.isWorthSwitching(
            AutoQualityUpgradePolicy.Pending("a", Double.POSITIVE_INFINITY, .5), 30, 12.0, 2.0))
    }
    @Test fun repeatedOptimizationIsRateLimited() {
        assertTrue(AutoQualityUpgradePolicy.canAttempt(1_000_000L, 0L))
        assertFalse(AutoQualityUpgradePolicy.canAttempt(1_060_000L, 1_000_000L))
        assertTrue(AutoQualityUpgradePolicy.canAttempt(1_120_000L, 1_000_000L))
    }

    @Test fun blockedYouTubeMayUseAlreadyCertifiedReserve() {
        val blocked = AutoQualityUpgradePolicy.Pending(
            "active", Double.NaN, Double.NaN, youtubeBlocked = true
        )
        assertTrue(AutoQualityUpgradePolicy.isWorthSwitching(blocked, 45, 6.0, 1.5))
        assertFalse(AutoQualityUpgradePolicy.isWorthSwitching(blocked, 120, 8.0, 2.0))
        assertFalse(AutoQualityUpgradePolicy.isWorthSwitching(blocked, 45, 3.0, 1.5))
    }
}
