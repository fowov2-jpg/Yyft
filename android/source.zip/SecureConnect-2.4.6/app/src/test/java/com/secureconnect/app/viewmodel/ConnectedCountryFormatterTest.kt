package com.secureconnect.app.viewmodel

import com.secureconnect.app.data.model.Server
import com.secureconnect.app.ui.screens.home.ConnectedCountryFormatter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ConnectedCountryFormatterTest {
    private fun server(country: String, flag: String = "🌐") = Server(
        id = "test", country = country, flagEmoji = flag, city = "",
        protocol = "VLESS", ping = 35
    )

    @Test fun displayCountryAndFlagFromRussianName() {
        assertEquals("🇩🇪", ConnectedCountryFormatter.fromServer(server("Германия"))?.flag)
        assertEquals("Германия", ConnectedCountryFormatter.fromServer(server("Германия"))?.name)
    }

    @Test fun displayCountryAndFlagFromIsoCode() {
        assertEquals("🇺🇸", ConnectedCountryFormatter.fromServer(server("US"))?.flag)
        assertEquals("🇬🇧", ConnectedCountryFormatter.fromServer(server("UK"))?.flag)
        assertEquals("🇫🇮", ConnectedCountryFormatter.fromServer(server("Finland"))?.flag)
    }

    @Test fun unknownAndMissingServerDoNotPretendToKnowCountry() {
        assertNull(ConnectedCountryFormatter.fromServer(null))
        assertNull(ConnectedCountryFormatter.fromServer(server("Неизвестно")))
        assertNull(ConnectedCountryFormatter.fromServer(server("")))
    }

    @Test fun sanitizeUnknownCountryFlagInsteadOfGuessing() {
        assertEquals("🌐", ConnectedCountryFormatter.fromServer(server("New fictional land"))?.flag)
    }
}
