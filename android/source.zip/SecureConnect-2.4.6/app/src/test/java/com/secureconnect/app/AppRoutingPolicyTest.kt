package com.secureconnect.app

import com.secureconnect.app.vpn.AppRoutingSnapshot
import com.secureconnect.app.vpn.AppVpnMode
import com.secureconnect.app.vpn.AppRoutingRule
import com.secureconnect.app.vpn.forInstalledPackages
import com.secureconnect.app.vpn.RussianApps
import org.junit.Assert.*
import org.junit.Test

class AppRoutingPolicyTest {
    @Test fun enlargedRussianCatalogAutomaticallyBypassesRealInstalledPackages() {
        val examples = setOf(
            "ru.yandex.yandexnavi", "ru.kinopoisk", "com.yandex.aliceapp",
            "ru.yandex.weatherplugin", "ru.yandex.telemost", "ru.yandex.travel",
            "ru.mail.cloud", "ru.tander.magnit", "ru.dodopizza.app",
            "ru.megamarket.marketplace", "com.octopod.russianpost.client.android",
            "ru.rzd.pass", "ru.beeline.services", "ru.tele2.mytele2"
        )
        assertTrue(RussianApps.defaultDirectPackages.size >= 56)
        assertTrue(RussianApps.defaultDirectPackages.containsAll(examples))
        val installed = examples + "com.secureconnect.app" + "org.telegram.messenger"
        val rule = AppRoutingSnapshot().forInstalledPackages(installed, "com.secureconnect.app")
                as AppRoutingRule.DenyVpn
        assertTrue(rule.packages.containsAll(examples))
        assertFalse(rule.packages.contains("org.telegram.messenger"))
    }

    @Test fun userOverrideStillWinsForNewCatalogEntries() {
        val app = "ru.yandex.yandexnavi"
        val rule = AppRoutingSnapshot(forceVpn = setOf(app)).forInstalledPackages(
            setOf(app,"com.secureconnect.app"), "com.secureconnect.app"
        ) as AppRoutingRule.DenyVpn
        assertFalse(rule.packages.contains(app))
        assertTrue(rule.packages.contains("com.secureconnect.app"))
    }

    @Test fun defaultPresetBypassesVerifiedRussianApplications() {
        val state = AppRoutingSnapshot()
        assertEquals(AppVpnMode.EXCLUDE_SELECTED, state.mode)
        assertFalse(state.usesVpn("ru.yandex.yandexmaps"))
        assertFalse(state.usesVpn("ru.sberbankmobile"))
        assertFalse(state.usesVpn("com.vkontakte.android"))
        assertTrue(state.usesVpn("org.telegram.messenger"))
        assertTrue(state.usesVpn("com.google.android.youtube"))
    }

    @Test fun defaultPresetDoesNotMatchEveryRussianPackageByPrefix() {
        assertTrue(RussianApps.defaultDirectPackages.size >= 15)
        assertFalse("ru.some.random.app" in RussianApps.defaultDirectPackages)
        assertEquals(RussianApps.defaultDirectPackages.size,
            RussianApps.recommendedDirect.distinctBy { it.packageName }.size)
    }

    @Test fun userCanExplicitlyEnableRussianAppInExclusionMode() {
        val selected = AppRoutingSnapshot(forceVpn = setOf("ru.rostel"))
        assertTrue(selected.usesVpn("ru.rostel"))
        assertFalse(selected.usesVpn("ru.yandex.taxi"))
    }

    @Test fun freshRussianAppsAreAutomaticallyExcludedAfterUpgrade() {
        val snapshot = AppRoutingSnapshot(excluded = setOf("com.example.manual"))
        assertFalse(snapshot.usesVpn("com.yandex.browser"))
        assertFalse(snapshot.usesVpn("ru.vk.store"))
        assertFalse(snapshot.usesVpn("ru.alfabank.mobile.android"))
        assertFalse(snapshot.usesVpn("ru.zen.android"))
        assertFalse(snapshot.usesVpn("com.example.manual"))
        val policy = snapshot.forInstalledPackages(
            setOf("com.yandex.browser", "ru.vk.store", "com.secureconnect.app", "com.example.manual"),
            "com.secureconnect.app") as AppRoutingRule.DenyVpn
        assertEquals(setOf("com.yandex.browser", "ru.vk.store", "com.secureconnect.app", "com.example.manual"), policy.packages)
    }

    @Test fun autoBypassIsIndependentOfManualChoice() {
        val enabled = AppRoutingSnapshot()
        assertFalse(enabled.usesVpn("ru.yandex.disk"))
        val disabled = enabled.copy(autoExcludeRussian = false)
        assertTrue(disabled.usesVpn("ru.yandex.disk"))
        assertFalse(disabled.copy(excluded = setOf("ru.yandex.disk")).usesVpn("ru.yandex.disk"))
        assertTrue(enabled.copy(forceVpn = setOf("ru.yandex.disk")).usesVpn("ru.yandex.disk"))
    }

    @Test fun legacyMigrationPreservesRussianVpnOverride() {
        val before = RussianApps.legacyDirectPackages - "ru.rostel" + "com.example.manual"
        val (direct, forcedVpn) = com.secureconnect.app.vpn.migrateLegacyExclusions(before)
        assertEquals(setOf("com.example.manual"), direct)
        assertEquals(setOf("ru.rostel"), forcedVpn)
        val snapshot = AppRoutingSnapshot(excluded = direct, forceVpn = forcedVpn)
        assertTrue(snapshot.usesVpn("ru.rostel"))
        assertFalse(snapshot.usesVpn("com.yandex.browser"))
        assertFalse(snapshot.usesVpn("com.example.manual"))
        val (freshDirect, freshForce) = com.secureconnect.app.vpn.migrateLegacyExclusions(null)
        assertTrue(freshDirect.isEmpty() && freshForce.isEmpty())
    }

    @Test fun onlySelectedModeNeverImplicitlyIncludesOtherPackages() {
        val state = AppRoutingSnapshot(
            mode = AppVpnMode.ONLY_SELECTED,
            included = setOf("com.vkontakte.android")
        )
        assertTrue(state.usesVpn("com.vkontakte.android"))
        assertFalse(state.usesVpn("org.telegram.messenger"))
        assertFalse(state.usesVpn("ru.rostel"))
    }

    @Test fun onlySelectedUsesExactlyInstalledAppPackages() {
        val state = AppRoutingSnapshot(
            mode = AppVpnMode.ONLY_SELECTED,
            included = setOf("com.example.installed", "com.example.deleted", "com.secureconnect.app")
        )
        val rule = state.forInstalledPackages(
            setOf("com.example.installed", "com.secureconnect.app"), "com.secureconnect.app"
        ) as AppRoutingRule.AllowVpn
        assertEquals(setOf("com.example.installed"), rule.packages)
    }

    @Test fun missingSelectedApplicationsFailClosedInsteadOfRoutingEverything() {
        val state = AppRoutingSnapshot(
            mode = AppVpnMode.ONLY_SELECTED,
            included = setOf("com.example.deleted", "com.secureconnect.app")
        )
        try {
            state.forInstalledPackages(setOf("com.secureconnect.app"), "com.secureconnect.app")
            fail("An empty allow-list must not create a full-tunnel VPN")
        } catch (expected: IllegalArgumentException) {
            assertTrue(expected.message.orEmpty().contains("не установлено"))
        }
    }

    @Test fun excludeModeNeverRoutesOwnAppThroughVpn() {
        val state = AppRoutingSnapshot(excluded = setOf("com.vkontakte.android", "com.uninstalled"))
        val rule = state.forInstalledPackages(
            setOf("com.vkontakte.android", "com.secureconnect.app", "com.example.foreign"),
            "com.secureconnect.app"
        ) as AppRoutingRule.DenyVpn
        assertEquals(setOf("com.vkontakte.android", "com.secureconnect.app"), rule.packages)
        assertFalse("com.example.foreign" in rule.packages)
        assertFalse("com.uninstalled" in rule.packages)
    }
    @Test fun russianExpansionHasDistinctIdsAndExpectedCoverage() {
        assertTrue("Российский каталог не должен сокращаться", RussianApps.defaultDirectPackages.size >= 122)
        val expected = setOf(
            "ru.instamart", "ru.sbcs.store", "ru.nspk.sbpay", "ru.gosuslugi.auto",
            "com.vk.im", "ru.ivi.client", "ru.rt.video.app.mobile", "ru.megafon.mlk",
            "ru.perekrestok.app", "ru.gazprombank.android.mobilebank.app",
            "ru.ozon.fintech.finance", "ru.yandex.mobile.afisha"
        )
        assertTrue(RussianApps.defaultDirectPackages.containsAll(expected))
        assertTrue(RussianApps.recommendedDirect.all { it.packageName.matches(Regex("[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+")) })
        assertEquals(RussianApps.recommendedDirect.size,
            RussianApps.recommendedDirect.map { it.packageName }.toSet().size)
    }

    @Test fun newRussianAppsBypassOnlyIfInstalledAndUserCanOptBackIn() {
        val installed = setOf("com.secureconnect.app", "ru.instamart", "ru.nspk.sbpay", "com.google.android.youtube")
        val route = AppRoutingSnapshot().forInstalledPackages(installed, "com.secureconnect.app") as AppRoutingRule.DenyVpn
        assertEquals(setOf("com.secureconnect.app", "ru.instamart", "ru.nspk.sbpay"), route.packages)
        val opted = AppRoutingSnapshot(forceVpn = setOf("ru.instamart"))
        assertTrue(opted.usesVpn("ru.instamart"))
        assertFalse(opted.usesVpn("ru.nspk.sbpay"))
        assertTrue(opted.usesVpn("com.google.android.youtube"))
    }

}
