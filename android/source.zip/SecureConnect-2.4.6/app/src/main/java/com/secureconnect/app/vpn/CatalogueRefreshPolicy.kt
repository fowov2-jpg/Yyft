package com.secureconnect.app.vpn

/** Up to 240 real unique configs, never fake entries; retry failures independently of success. */
object CatalogueRefreshPolicy {
    const val TARGET = 240
    fun isDue(now: Long, count: Int, lastSuccess: Long,
              lastFailure: Long, failures: Int, readyBackups: Int,
              adequateBackups: Boolean = false): Boolean {
        // A full catalogue is a capacity cap, not a permanent freshness signal.
        // Public subscriptions rotate; 100 cached links can all go stale.
        if (lastFailure > 0 && now - lastFailure in 0L until retryMs(failures)) return false
        if (count <= 0 || lastSuccess <= 0 || lastSuccess > now) return true
        // A healthy small pool doesn't justify downloading dozens of source
        // lists every 45 minutes. Still rotate periodically for freshness.
        val interval = when {
            adequateBackups -> 60L * 60_000L
            count < TARGET -> 20L * 60_000L
            else -> 30L * 60_000L
        }
        return now - lastSuccess >= interval
    }
    fun retryMs(failures: Int): Long =
        (30_000L * (1L shl (failures - 1).coerceIn(0, 4))).coerceAtMost(5L * 60_000L)
}
