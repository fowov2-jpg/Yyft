package com.secureconnect.app.vpn

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BatteryAwarePolicyTest {
    @Test fun screenOffReducesDisplayPollingWithoutDisablingWatchdog() {
        assertEquals(10_000L, BatteryAwarePolicy.trafficIntervalMs(true))
        assertEquals(600_000L, BatteryAwarePolicy.trafficIntervalMs(false))
        assertEquals(600_000L, BatteryAwarePolicy.trafficIntervalMs(true, false))
        assertEquals(10_000L, BatteryAwarePolicy.trafficIntervalMs(true, true))
        assertEquals(30_000L, BatteryAwarePolicy.NOTIFICATION_RATE_INTERVAL_MS)
        assertEquals(180_000L, BatteryAwarePolicy.securityIntervalMs(true))
        assertEquals(600_000L, BatteryAwarePolicy.securityIntervalMs(false))
        assertEquals(90_000L, BatteryAwarePolicy.watchdogIntervalMs(true))
        assertEquals(240_000L, BatteryAwarePolicy.watchdogIntervalMs(false))
    }

    @Test fun expensiveSyntheticTestsRequireChargingUnmeteredAndScreenOn() {
        assertTrue(BatteryAwarePolicy.allowHeavyTests(true, false, true, true))
        assertFalse(BatteryAwarePolicy.allowHeavyTests(true, false, false, true))
        assertFalse(BatteryAwarePolicy.allowHeavyTests(true, false, true, false))
        assertFalse(BatteryAwarePolicy.allowHeavyTests(false, false, true, true))
        assertFalse(BatteryAwarePolicy.allowHeavyTests(true, true, true, true))
    }

    @Test fun discoveryKeepsEmergencyBackupsWithoutChasingFullPoolOnBattery() {
        assertEquals(5, BatteryAwarePolicy.discoveryTarget(true, false, true, true, 21))
        assertEquals(2, BatteryAwarePolicy.discoveryTarget(true, false, false, true, 21))
        assertEquals(2, BatteryAwarePolicy.discoveryTarget(false, false, true, true, 21))
        assertEquals(2, BatteryAwarePolicy.discoveryTarget(true, true, true, true, 21))
        assertEquals(2, BatteryAwarePolicy.discoveryTarget(true, true, true, true, 2))
    }

    @Test fun emergencyHotCheckCanStillBeWokenSeparately() {
        assertEquals(900_000L, BatteryAwarePolicy.hotCheckIntervalMs(true, false))
        assertEquals(2_700_000L, BatteryAwarePolicy.hotCheckIntervalMs(false, false))
        assertEquals(3_600_000L, BatteryAwarePolicy.hotCheckIntervalMs(true, true))
    }

    @Test fun heavyReserveAuditsAreSpreadOverTime() {
        assertEquals(1, BatteryAwarePolicy.RESERVE_SPEED_TARGETS_PER_CYCLE)
        assertTrue(BatteryAwarePolicy.RESERVE_SPEED_ACTIVE_POLL_MS >= 10L * 60_000L)
        assertEquals(60, EmbeddedWarmRoutes.OBSERVE_INTERVAL_SECONDS)
        assertEquals(2L * 60L * 60_000L, BatteryAwarePolicy.HEAVY_TEST_INTERVAL_MS)
        assertEquals(30L * 60_000L, BatteryAwarePolicy.DISCOVERY_PAUSE_MS)
    }
}
