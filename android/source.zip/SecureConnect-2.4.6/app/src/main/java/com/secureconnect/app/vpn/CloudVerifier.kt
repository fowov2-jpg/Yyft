package com.secureconnect.app.vpn

import android.content.Context
import com.secureconnect.app.data.local.SensitivePrefs
import com.secureconnect.app.data.model.Server
import com.secureconnect.app.data.source.ConfigSources
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.URL
import javax.net.ssl.HttpsURLConnection

/**
 * Opt-in, user-controlled HTTPS Xray verifier. No built-in third-party upload.
 *
 * Only nodes fetched from the app's PUBLIC source list can be submitted. A cloud
 * pass prioritizes local probing; it never marks a node as local/video-verified.
 * An unavailable cloud leaves normal local discovery entirely functional.
 */
object CloudVerifier {
    private const val PREFS = "sc_cloud_verifier"
    private const val ENDPOINT = "endpoint"
    private const val TOKEN = "api_token"
    private const val RECOMMENDED = "recommended_ids"
    private const val VERIFIED_AT = "checked_at"
    private const val MAX_BATCH = 36
    private const val MAX_RESPONSE_BYTES = 128 * 1024
    private const val FRESH_MS = 6L * 60 * 60_000L

    fun endpoint(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(ENDPOINT, "") ?: ""

    fun hasToken(context: Context): Boolean =
        !SensitivePrefs.read(context, PREFS, TOKEN).isNullOrBlank()

    fun isConfigured(context: Context): Boolean =
        validEndpoint(endpoint(context)) && hasToken(context)

    fun validEndpoint(text: String): Boolean = try {
        val url = URL(text.trim())
        url.protocol.equals("https", ignoreCase = true) &&
            url.host.isNotBlank() && url.toURI().userInfo == null &&
            url.query == null && url.ref == null &&
            (url.port == -1 || url.port in 1..65535) &&
            url.path.length <= 128
    } catch (_: Exception) { false }

    /** Token is encrypted with Android Keystore, never stored in plaintext. */
    fun configure(context: Context, inputEndpoint: String, inputToken: String) {
        val clean = inputEndpoint.trim().trimEnd('/')
        if (clean.isEmpty() && inputToken.isBlank()) {
            // Disable remote checks while retaining the encrypted token for easy re-enable.
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .remove(ENDPOINT).apply()
            return
        }
        require(validEndpoint(clean)) { "Нужен адрес HTTPS без логина и параметров" }
        if (inputToken.isNotBlank()) {
            SensitivePrefs.write(context, PREFS, TOKEN, inputToken.trim())
        }
        require(hasToken(context)) { "Нужен ключ доступа к своему серверу" }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(ENDPOINT, clean).apply()
    }

    fun recommendedIds(context: Context): Set<String> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val at = prefs.getLong(VERIFIED_AT, 0)
        if (at <= 0 || System.currentTimeMillis() - at !in 0..FRESH_MS) return emptySet()
        val raw = prefs.getString(RECOMMENDED, null) ?: return emptySet()
        return try {
            val arr = JSONArray(raw)
            buildSet { for (i in 0 until minOf(arr.length(), 48)) {
                arr.optString(i).takeIf { it.isNotBlank() }?.let(::add)
            } }
        } catch (_: Exception) { emptySet() }
    }

    fun rememberPriorities(context: Context, ids: List<String>) {
        val arr = JSONArray()
        ids.distinct().take(48).forEach { arr.put(it) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(RECOMMENDED, arr.toString())
            .putLong(VERIFIED_AT, System.currentTimeMillis()).apply()
    }

    suspend fun verifyPublicCandidates(context: Context, candidates: List<Server>): List<String> =
        withContext(Dispatchers.IO) {
            val base = endpoint(context).trimEnd('/')
            val token = SensitivePrefs.read(context, PREFS, TOKEN) ?: return@withContext emptyList()
            if (!validEndpoint(base)) return@withContext emptyList()
            val publicNames = ConfigSources.all.mapTo(HashSet()) { it.name }
            val entries = JSONArray()
            val knownIds = HashSet<String>()
            val submission = candidates.asSequence()
                .filter { it.source in publicNames && it.id.isNotBlank() && knownIds.add(it.id) }
                .take(MAX_BATCH).toList()
            for (server in submission) {
                val probe = XrayConfigBuilder.buildProbe(server) ?: continue
                val outbound = try {
                    JSONObject(probe).getJSONArray("outbounds").getJSONObject(0)
                } catch (_: Exception) { continue }
                entries.put(JSONObject().put("id", server.id).put("outbound", outbound))
            }
            if (entries.length() == 0) return@withContext emptyList()
            try {
                val created = request(base + "/v1/jobs", token, "POST",
                    JSONObject().put("candidates", entries))
                val jobId = created.optString("job")
                if (!jobId.matches(Regex("[a-f0-9-]{36}"))) return@withContext emptyList()
                repeat(30) { // Up to 150 sec, remote Xray probes run outside the phone.
                    delay(5_000L)
                    val status = request("$base/v1/jobs/$jobId", token, "GET", null)
                    when (status.optString("state")) {
                        "done" -> {
                            val results = status.optJSONArray("results") ?: JSONArray()
                            val good = ArrayList<Pair<String, Boolean>>()
                            val submittedIds = submission.mapTo(HashSet()) { it.id }
                            for (i in 0 until results.length()) {
                                val r = results.optJSONObject(i) ?: continue
                                val id = r.optString("id")
                                if (id in submittedIds && r.optBoolean("https", false)) {
                                    good += id to r.optBoolean("youtube", false)
                                }
                            }
                            return@withContext good.sortedByDescending { it.second }
                                .map { it.first }.distinct()
                        }
                        "error" -> return@withContext emptyList()
                    }
                }
                emptyList()
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                // The remote checker is always optional; local scans remain available.
                emptyList()
            }
        }

    private fun request(url: String, token: String, method: String, body: JSONObject?): JSONObject {
        val conn = URL(url).openConnection() as HttpsURLConnection
        conn.instanceFollowRedirects = false
        conn.connectTimeout = 7_000
        conn.readTimeout = 12_000
        conn.requestMethod = method
        conn.setRequestProperty("Authorization", "Bearer $token")
        conn.setRequestProperty("Accept", "application/json")
        try {
            if (body != null) {
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            }
            if (conn.responseCode !in 200..299) throw IOException("Cloud HTTP ${conn.responseCode}")
            val bytes = conn.inputStream.use { input ->
                val out = java.io.ByteArrayOutputStream()
                val buf = ByteArray(4096)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    if (out.size() + n > MAX_RESPONSE_BYTES) throw IOException("Cloud response too large")
                    out.write(buf, 0, n)
                }
                out.toByteArray()
            }
            return JSONObject(String(bytes, Charsets.UTF_8))
        } finally {
            conn.disconnect()
        }
    }
}
