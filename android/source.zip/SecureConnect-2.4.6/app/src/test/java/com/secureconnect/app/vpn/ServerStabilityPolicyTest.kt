package com.secureconnect.app.vpn

import com.secureconnect.app.data.local.WorkingServerStore
import com.secureconnect.app.data.model.Server
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ServerStabilityPolicyTest {
    private val now = 1_000_000_000L
    private fun server() = Server("stable", "Германия", "", "🇩🇪", "VLESS", 41,
        host = "server.example", port = 443, source = "public", rawLink = "vless://example")

    private fun qualified(failures: Int = 0) = WorkingServerStore.Record(
        server = server(), lastSuccessAtMs = now - 100L,
        lastFailureAtMs = if (failures > 0) now - 50L else 0L,
        ewmaHttpsMs = 370.0, ewmaConnectMs = 41.0,
        successes = 48, failures = failures, totalFailures = 3,
        youtubeVerifiedAtMs = now - 60_000L, speedVerifiedAtMs = now - 60_000L,
        verifiedDownloadMbps = 9.5, verifiedUploadMbps = 2.0
    )

    @Test fun oneTransientErrorKeepsAQualifiedServer() {
        assertTrue(qualified(1).isActive(now))
        assertFalse(qualified(2).isActive(now))
        assertTrue(qualified(1).stabilityScore(now) < qualified(0).stabilityScore(now))
    }

    @Test fun duplicateCallbacksDoNotBecomeIndependentOutages() {
        assertTrue(ServerStabilityPolicy.countNewFailure(now, 0L))
        assertFalse(ServerStabilityPolicy.countNewFailure(now, now - 20_000L))
        assertTrue(ServerStabilityPolicy.countNewFailure(now, now - 61_000L))
    }

    @Test fun historyBeatsAnUnprovenSyntheticSpeedBurst() {
        val stable = ServerStabilityPolicy.score(45, 12.0, 2.1, 50, 1, 0, now, now)
        val unproven = ServerStabilityPolicy.score(40, 100.0, 3.5, 1, 0, 0, now, now)
        assertTrue(stable > unproven)
    }

    @Test fun minorScoreDifferencesDoNotCauseNeedlessSwitches() {
        assertTrue(ServerStabilityPolicy.shouldKeepCurrent(80.0, 86.0))
        assertFalse(ServerStabilityPolicy.shouldKeepCurrent(70.0, 86.0))
    }

    @Test fun historicalProofIsNotFreshForever() {
        val expired = qualified().copy(speedVerifiedAtMs = now - VpnSpeedPolicy.QUALITY_FRESHNESS_MS - 1L)
        assertFalse(expired.isActive(now))
    }
}
