package com.secureconnect.app.vpn

/** Mode is independent of the optional launch-at-startup preference. */
enum class ConnectionMode { AUTO, MANUAL;
    companion object {
        fun parse(raw: String?): ConnectionMode = entries.firstOrNull { it.name == raw } ?: AUTO
    }
}
