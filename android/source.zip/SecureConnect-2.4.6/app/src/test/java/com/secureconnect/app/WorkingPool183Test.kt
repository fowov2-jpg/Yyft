package com.secureconnect.app

import com.secureconnect.app.vpn.WorkingPoolPolicy
import com.secureconnect.app.data.remote.SourceWindowPolicy
import org.junit.Assert.*
import org.junit.Test

class WorkingPool183Test {
    @Test fun measuredLatencyIsRankingHintNotHardGate() {
        assertTrue(WorkingPoolPolicy.qualifiesRtt(41))
        assertTrue(WorkingPoolPolicy.qualifiesRtt(100))
        assertTrue(WorkingPoolPolicy.qualifiesRtt(101))
        assertTrue(WorkingPoolPolicy.qualifiesRtt(220))
        assertFalse(WorkingPoolPolicy.qualifiesRtt(0))
        assertFalse(WorkingPoolPolicy.qualifiesRtt(null))
    }
    @Test fun cachedHundredRotatesCandidatesWithoutInventingNodes() {
        val source = (1..250).toList()
        val first = SourceWindowPolicy.page(source, 50, 0)
        val second = SourceWindowPolicy.page(source, 50, 1)
        assertEquals(50, first.size)
        assertEquals(50, second.size)
        assertTrue(first.intersect(second.toSet()).isEmpty())
        assertEquals((201..250).toList(), SourceWindowPolicy.page(source, 50, 4))
        assertEquals(first, SourceWindowPolicy.page(source, 50, 5))
        val longSource = (1..1200).toList()
        assertTrue(1200 in SourceWindowPolicy.page(longSource, 500, 2))
        assertEquals(500, SourceWindowPolicy.page(longSource, 500, 1).size)
    }
    @Test fun neverExceedsAvailableRealNodes() {
        val source = listOf("A", "B", "C")
        assertEquals(3, SourceWindowPolicy.page(source, 100, 3).size)
        assertEquals(0, SourceWindowPolicy.page(source, 0, 1).size)
    }
}
