package com.secureconnect.app.vpn

import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URI
import java.util.Locale
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

/** Bounded HTTPS content check over the selected Xray SOCKS outbound. No direct traffic. */
object YouTubePageProbe {
    enum class Verdict { VERIFIED, BLOCKED, INCONCLUSIVE }
    data class Result(
        val passed: Boolean,
        val bytes: Int = 0,
        val error: String? = null,
        val verdict: Verdict = if (passed) Verdict.VERIFIED else Verdict.INCONCLUSIVE,
        val connectMs: Int? = null
    )

    private const val MAX_HEADER = 16 * 1024
    private const val MAX_BODY = 192 * 1024
    private const val SOCKET_TIMEOUT_MS = 4_000
    private const val DEADLINE_MS = 12_000L
    private const val MAX_REDIRECTS = 3
    private val homePages = listOf(URI("https://www.youtube.com/"), URI("https://m.youtube.com/"))

    fun checkActive(): Result = checkViaSocks(XrayConfigBuilder.HEALTH_SOCKS_PORT)

    fun checkViaSocks(port: Int): Result {
        val started = System.nanoTime()
        var last = Result(false, error = "Нет подтверждения HTML YouTube")
        for (startPage in homePages) {
            if (expired(started)) break
            val result = runCatching { followPage(port, startPage, started) }
                .getOrElse { Result(false, error = "${it.javaClass.simpleName}: ${it.message.orEmpty().take(90)}") }
            if (result.passed) return result
            // A second YouTube host may behave differently on a mobile network.
            last = result
        }
        return last
    }

    private fun followPage(port: Int, initial: URI, started: Long): Result {
        var current = initial
        val visited = HashSet<URI>()
        for (redirect in 0..MAX_REDIRECTS) {
            if (expired(started)) return Result(false, error = "Истёк лимит времени YouTube")
            if (!visited.add(current)) return Result(false, error = "Циклический редирект YouTube")
            val response = fetch(port, current, started)
            if (response.error != null) return Result(false, response.bytes.size, response.error)
            when (response.status) {
                301, 302, 303, 307, 308 -> {
                    val next = YouTubePagePolicy.nextPage(current, response.location)
                        ?: return Result(false, response.bytes.size,
                            "YouTube HTTP ${response.status}: перенаправление вне страницы YouTube (${safeLocationHost(response.location)})")
                    current = next
                }
                200 -> return if (YouTubePagePolicy.isHomePage(response.status,
                        response.contentType, response.bytes.toString(Charsets.UTF_8))) {
                    Result(true, response.bytes.size, connectMs = response.connectMs)
                } else {
                    Result(false, response.bytes.size,
                        "YouTube HTTP 200: HTML главной страницы не подтверждён")
                }
                403, 451 -> return Result(false, response.bytes.size,
                    "YouTube HTTP ${response.status}: доступ запрещён", Verdict.BLOCKED)
                else -> return Result(false, response.bytes.size,
                    "YouTube HTTP ${response.status} (${response.contentType.ifBlank { "не указан" }})")
            }
        }
        return Result(false, error = "Превышен лимит из $MAX_REDIRECTS переходов YouTube")
    }

    private data class Response(
        val status: Int = 0,
        val contentType: String = "",
        val location: String? = null,
        val bytes: ByteArray = byteArrayOf(),
        val error: String? = null,
        val connectMs: Int? = null
    )

    private fun fetch(port: Int, uri: URI, started: Long): Response {
        val host = uri.host ?: return Response(error = "Нет адреса YouTube")
        Socket().use { raw ->
            raw.soTimeout = SOCKET_TIMEOUT_MS
            raw.connect(InetSocketAddress("127.0.0.1", port), 800)
            val socksStarted = System.nanoTime()
            XrayHealthChecker.performSocksConnect(
                DataInputStream(raw.getInputStream()), DataOutputStream(raw.getOutputStream()), host, 443
            )
            val connectMs = ((System.nanoTime() - socksStarted) / 1_000_000L)
                .coerceIn(1L, Int.MAX_VALUE.toLong()).toInt()
            val ssl = (SSLSocketFactory.getDefault() as SSLSocketFactory)
                .createSocket(raw, host, 443, false) as SSLSocket
            ssl.use { socket ->
                socket.soTimeout = SOCKET_TIMEOUT_MS
                socket.useClientMode = true
                socket.sslParameters = socket.sslParameters.apply {
                    endpointIdentificationAlgorithm = "HTTPS"
                }
                socket.startHandshake()
                val path = (uri.rawPath?.ifBlank { "/" } ?: "/") +
                    (uri.rawQuery?.let { "?$it" } ?: "")
                // Generic browser UA: the prior synthetic UA was commonly redirected.
                val request = "GET $path HTTP/1.1\r\nHost: $host\r\n" +
                    "User-Agent: Mozilla/5.0 (Linux; Android 16; Mobile) AppleWebKit/537.36 " +
                    "(KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36\r\n" +
                    "Accept: text/html,application/xhtml+xml\r\nAccept-Encoding: identity\r\n" +
                    "Connection: close\r\n\r\n"
                socket.outputStream.write(request.toByteArray(Charsets.US_ASCII))
                socket.outputStream.flush()
                val input = BufferedInputStream(socket.inputStream)
                val header = ByteArrayOutputStream()
                var state = 0
                while (header.size() < MAX_HEADER && state != 4) {
                    if (expired(started)) return Response(error = "Таймаут заголовков YouTube")
                    val b = input.read()
                    if (b < 0) return Response(error = "Нет HTTP-ответа YouTube")
                    header.write(b)
                    state = when {
                        state == 0 && b == 13 -> 1
                        state == 1 && b == 10 -> 2
                        state == 2 && b == 13 -> 3
                        state == 3 && b == 10 -> 4
                        b == 13 -> 1
                        else -> 0
                    }
                }
                if (state != 4) return Response(error = "Слишком большие HTTP-заголовки YouTube")
                val headers = header.toString("US-ASCII")
                val status = headers.substringBefore("\r\n").split(' ').getOrNull(1)?.toIntOrNull() ?: 0
                fun headerValue(name: String): String = Regex("(?im)^${Regex.escape(name)}:\\s*([^\\r\\n]+)")
                    .find(headers)?.groupValues?.get(1).orEmpty().trim()
                val contentType = headerValue("content-type")
                val location = headerValue("location").ifEmpty { null }
                // A redirect normally has no HTML body/content-type. Handle Location first.
                if (status in listOf(301, 302, 303, 307, 308) || status != 200 ||
                    !contentType.lowercase(Locale.ROOT).contains("text/html")) {
                    return Response(status, contentType, location)
                }
                val body = ByteArrayOutputStream()
                val buffer = ByteArray(4096)
                while (body.size() < MAX_BODY && !expired(started)) {
                    val n = input.read(buffer, 0, minOf(buffer.size, MAX_BODY - body.size()))
                    if (n <= 0) break
                    body.write(buffer, 0, n)
                    if (YouTubePagePolicy.isHomePage(status, contentType, body.toString("UTF-8"))) break
                }
                return Response(status, contentType, location, body.toByteArray(), connectMs = connectMs)
            }
        }
    }

    private fun safeLocationHost(location: String?): String = try {
        URI(location.orEmpty()).host?.take(80) ?: "относительный/неизвестный адрес"
    } catch (_: Exception) { "некорректный адрес" }

    private fun expired(start: Long): Boolean =
        Thread.currentThread().isInterrupted || (System.nanoTime() - start) / 1_000_000L > DEADLINE_MS
}
