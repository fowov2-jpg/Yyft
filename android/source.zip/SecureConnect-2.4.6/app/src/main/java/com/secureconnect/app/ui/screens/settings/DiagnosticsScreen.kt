package com.secureconnect.app.ui.screens.settings

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.secureconnect.app.ui.components.LeakRiskCard
import com.secureconnect.app.ui.components.ScreenTopBar
import com.secureconnect.app.ui.theme.ScCard
import com.secureconnect.app.ui.theme.ScTextPrimary
import com.secureconnect.app.ui.theme.ScTextSecondary
import com.secureconnect.app.viewmodel.MainViewModel
import com.secureconnect.app.vpn.LeakRiskCalculator
import com.secureconnect.app.vpn.SecurityEventStore
import com.secureconnect.app.vpn.VpnController
import com.secureconnect.app.vpn.VpnState

/**
 * Everyday security tab: summary first, advanced tools only after deliberate disclosure.
 * Diagnostic report is generated only when requested to avoid unnecessary work.
 */
@Composable
fun DiagnosticsScreen(vm: MainViewModel, onBack: () -> Unit = {}) {
    val context = LocalContext.current
    var report by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var showEvents by rememberSaveable { mutableStateOf(false) }
    var showTechnical by rememberSaveable { mutableStateOf(false) }

    val vpnState by VpnController.state.collectAsStateWithLifecycle()
    val killSwitch by vm.killSwitch.collectAsStateWithLifecycle()
    val autoRecovery by vm.autoRecovery.collectAsStateWithLifecycle()
    val autoConnect by vm.autoConnect.collectAsStateWithLifecycle()
    val routing by vm.appRouting.collectAsStateWithLifecycle()
    val tls by VpnController.openAiTlsStatus.collectAsStateWithLifecycle()
    val activeServer by VpnController.activeServer.collectAsStateWithLifecycle()
    val lastSecurityCheck by VpnController.lastAutomaticSecurityCheckAtMs.collectAsStateWithLifecycle()
    val eventRevision by SecurityEventStore.revision.collectAsStateWithLifecycle()
    val events = remember(eventRevision) { SecurityEventStore.recent(context) }
    val risk = LeakRiskCalculator.assess(
        state = vpnState,
        killSwitchEnabled = killSwitch,
        tlsStatus = tls,
        routingMode = routing.mode,
        hasActiveServer = activeServer != null
    )

    val saveLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        runCatching {
            context.contentResolver.openOutputStream(uri)?.use { output ->
                output.write(vm.diagnosticReport().toByteArray(Charsets.UTF_8))
            } ?: error("Не удалось открыть файл")
            status = "Отчёт сохранён"
        }.onFailure { status = "Не удалось сохранить: ${it.message ?: "unknown"}" }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenTopBar("Диагностика", onBack = onBack)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(
                start = 16.dp, end = 16.dp, top = 12.dp, bottom = 20.dp
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                LeakRiskCard(
                    assessment = risk,
                    onDetails = {},
                    showButton = false,
                    compact = true,
                    lastCheckedAtMs = if (
                        vpnState == VpnState.Connected || vpnState == VpnState.Blocked
                    ) lastSecurityCheck else 0L
                )
            }
            item {
                Text(
                    "Индекс — ориентир по доступным сигналам, не вероятность утечки. " +
                        "Проверка системного TUN, DNS и IPv6 пока не подтверждена. " +
                        "Российские приложения из исключений выходят напрямую.",
                    style = MaterialTheme.typography.bodySmall,
                    color = ScTextSecondary
                )
            }
            item {
                Column(
                    modifier = Modifier.fillMaxWidth()
                        .background(ScCard, RoundedCornerShape(16.dp))
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Text(
                        "Автоматическая защита",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = ScTextPrimary
                    )
                    SecurityToggle(
                        title = "Kill Switch",
                        subtitle = "Блокировка защищаемого трафика при сбое, если позволяет Android",
                        checked = killSwitch,
                        onChanged = vm::setKillSwitch
                    )
                    SecurityToggle(
                        title = "Автовосстановление",
                        subtitle = "Подбор нового сервера после обрыва",
                        checked = autoRecovery,
                        onChanged = vm::setAutoRecovery
                    )
                    SecurityToggle(
                        title = "Автоподключение",
                        subtitle = "Пытаться подключаться при запуске приложения",
                        checked = autoConnect,
                        onChanged = vm::setAutoConnect
                    )
                    Text(
                        "Системная блокировка Android вне VPN может затрагивать и исключённые приложения.",
                        style = MaterialTheme.typography.bodySmall,
                        color = ScTextSecondary,
                        modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
                    )
                }
            }
            item {
                Column(
                    modifier = Modifier.fillMaxWidth()
                        .background(ScCard, RoundedCornerShape(16.dp))
                        .padding(14.dp)
                ) {
                    Text(
                        "События безопасности",
                        color = ScTextPrimary,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (events.isEmpty()) {
                        Text(
                            "Событий пока нет. Монитор работает вместе с VPN.",
                            color = ScTextSecondary,
                            style = MaterialTheme.typography.bodySmall
                        )
                    } else {
                        val visible = if (showEvents) events else events.take(3)
                        visible.forEach { event ->
                            Text(
                                java.text.DateFormat.getDateTimeInstance(
                                    java.text.DateFormat.SHORT, java.text.DateFormat.SHORT
                                ).format(java.util.Date(event.atMs)) +
                                    " · " + event.severity + " · " + event.title,
                                color = ScTextPrimary,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(top = 10.dp)
                            )
                            if (showEvents) {
                                Text(event.detail, color = ScTextSecondary,
                                    style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        if (events.size > 3) {
                            TextButton(onClick = { showEvents = !showEvents }) {
                                Text(if (showEvents) "Свернуть" else "Все события (${events.size})")
                            }
                        }
                    }
                }
            }
            item {
                Column(
                    modifier = Modifier.fillMaxWidth()
                        .background(ScCard, RoundedCornerShape(16.dp))
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().clickable {
                            showTechnical = !showTechnical
                            if (showTechnical && report.isEmpty()) report = vm.diagnosticReport()
                        },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Технический отчёт",
                            color = ScTextPrimary,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold)
                        Text(if (showTechnical) "▲" else "▼", color = ScTextSecondary)
                    }
                    if (showTechnical) {
                        Text(
                            "Отчёт содержит IP-адреса и сведения о серверах. " +
                                "Проверь его перед отправкой кому-либо.",
                            color = ScTextSecondary,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(vertical = 10.dp)
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Button(onClick = {
                                report = vm.diagnosticReport()
                                val clipboard = context.getSystemService(
                                    Context.CLIPBOARD_SERVICE
                                ) as ClipboardManager
                                clipboard.setPrimaryClip(
                                    ClipData.newPlainText("SecureConnect diagnostics", report)
                                )
                                status = "Отчёт скопирован"
                            }, modifier = Modifier.weight(1f)) { Text("Копировать") }
                            OutlinedButton(onClick = {
                                saveLauncher.launch("SecureConnect-diagnostics.txt")
                            }, modifier = Modifier.weight(1f)) { Text("Сохранить") }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = {
                                report = vm.diagnosticReport()
                                context.startActivity(Intent.createChooser(
                                    Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_SUBJECT, "SecureConnect diagnostics")
                                        putExtra(Intent.EXTRA_TEXT, report)
                                    },
                                    "Поделиться отчётом"
                                ))
                            }, modifier = Modifier.weight(1f)) { Text("Поделиться") }
                            OutlinedButton(onClick = {
                                report = vm.diagnosticReport()
                                status = "Отчёт обновлён"
                            }, modifier = Modifier.weight(1f)) { Text("Обновить") }
                        }
                        if (status.isNotBlank()) {
                            Text(
                                status,
                                color = ScTextPrimary,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Text(
                            report,
                            color = ScTextSecondary,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(top = 12.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SecurityToggle(
    title: String,
    subtitle: String,
    checked: Boolean,
    onChanged: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = ScTextPrimary, style = MaterialTheme.typography.bodyMedium)
            Text(subtitle, color = ScTextSecondary, style = MaterialTheme.typography.bodySmall)
        }
        Switch(checked = checked, onCheckedChange = onChanged)
    }
}
