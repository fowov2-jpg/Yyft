package com.secureconnect.app.vpn

/** Persistent success history and freshness are separate from retry scheduling. */
object ReserveScanPolicy {
    const val RECHECK_MS = 5L * 60L * 1000L
    const val MAX_RETRY_MS = 30L * 60L * 1000L

    fun canLaunch(state: VpnState, hasNetwork: Boolean, memoryPressure: Boolean): Boolean =
        hasNetwork && !memoryPressure && state != VpnState.Connecting && state != VpnState.Validating

    fun workerCount(state: VpnState, hasLiveServer: Boolean): Int =
        if (state == VpnState.Connected || hasLiveServer) 1 else 2

    fun catalogueIntervalMs(readyBackups: Int): Long =
        if (readyBackups >= WorkingPoolPolicy.MAX_VERIFIED) Long.MAX_VALUE
        else 45L * 60_000L // Maintenance cadence; a confirmed deficit also wakes refresh.

    fun retryDelayMs(consecutiveFailures: Int): Long =
        (RECHECK_MS * (1L shl (consecutiveFailures - 1).coerceIn(0, 3)))
            .coerceAtMost(MAX_RETRY_MS)

    fun due(nowMs: Long, lastSuccessMs: Long?, nextAttemptMs: Long?): Boolean {
        if (nextAttemptMs != null) return nowMs >= nextAttemptMs
        // Verified entries are not polled merely because an arbitrary TTL elapsed.
        return lastSuccessMs == null
    }

    fun latencyPriority(pingMs: Int): Int = when (pingMs) {
        in 1..100 -> 0
        in 101..Int.MAX_VALUE -> 1
        else -> 2 // Unknown is not a successful zero-millisecond result.
    }

    fun priority(saved: Boolean, pendingFinalAttempt: Boolean): Int = when {
        saved -> 0 // Maintain known backups before exploring untested endpoints.
        !pendingFinalAttempt -> 1 // Fast discovery pass before expensive retries.
        else -> 2
    }
}
