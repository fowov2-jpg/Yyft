package com.secureconnect.app.vpn

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject

/** Small, local, bounded log. Never stores links, server credentials, domains or package lists. */
internal object SecurityEventStore {
    data class Event(val atMs: Long, val severity: String, val title: String, val detail: String)

    val revision = MutableStateFlow(0)
    private const val PREFS = "sc_security_events_v1"
    private const val KEY = "events"
    private const val LIMIT = 24

    @Synchronized
    fun recent(context: Context): List<Event> {
        val encoded = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]")
        return runCatching {
            val arr = JSONArray(encoded)
            (0 until minOf(arr.length(), LIMIT)).map { index ->
                val item = arr.getJSONObject(index)
                Event(
                    item.optLong("time", 0L),
                    item.optString("level", "INFO"),
                    item.optString("title", "").take(120),
                    item.optString("detail", "").take(240)
                )
            }
        }.getOrElse { emptyList() }
    }

    @Synchronized
    fun record(context: Context, event: Event) {
        val events = (listOf(event) + recent(context)).take(LIMIT)
        val arr = JSONArray()
        events.forEach {
            arr.put(JSONObject().put("time", it.atMs)
                .put("level", it.severity.take(20))
                .put("title", it.title.take(120))
                .put("detail", it.detail.take(240)))
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY, arr.toString()).apply()
        revision.value += 1
    }
}
