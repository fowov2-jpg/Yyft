package com.secureconnect.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import androidx.core.app.ServiceCompat
import com.secureconnect.app.vpn.ServerScanner

/** Keeps endpoint health checking alive after Home/background, without a ViewModel. */
class ServerScanService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val taskMonitor by lazy {
        TaskPresenceMonitor(this, handler) { AppRunController.closed(this) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!AppRunController.mayRun(this)) {
            stopSelfResult(startId)
            return START_NOT_STICKY
        }
        val manager = getSystemService(NotificationManager::class.java) ?: run {
            stopSelfResult(startId)
            return START_NOT_STICKY
        }
        val channel = "server_checks"
        manager.createNotificationChannel(NotificationChannel(
            channel, "Проверка VPN-серверов", NotificationManager.IMPORTANCE_LOW))
        val notification = Notification.Builder(this, channel)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("SecureConnect")
            .setContentText("Проверка серверов в фоне")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(2, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(2, notification)
        }
        ServerScanner.acquire(this, this)
        taskMonitor.start()
        // May recover after OS process reclamation while task remains open.
        // After task dismissal AppRunController.mayRun() rejects sticky restarts.
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // If a new launch task already exists, this may be a delayed callback
        // for the previous task. Do not shut down the newly opened session.
        if (AppRunController.hasTask(this) != true) {
            AppRunController.closed(this)
        }
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        taskMonitor.stop()
        if (!com.secureconnect.app.vpn.XrayVpnService.hasLiveService() &&
            AppRunController.hasTask(this) == false && AppRunController.mayRun(this)) {
            AppRunController.closed(this)
        }
        ServerScanner.release(this)
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
}
