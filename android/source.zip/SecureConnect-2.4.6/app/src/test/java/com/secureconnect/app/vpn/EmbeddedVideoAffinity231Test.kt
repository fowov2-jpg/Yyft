package com.secureconnect.app.vpn

import com.secureconnect.app.data.model.Server
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class EmbeddedVideoAffinity231Test {
    private fun server(id: String) = Server(
        id = id, country = "Молдова", city = "", flagEmoji = "",
        protocol = "VLESS", ping = 40, source = "test",
        host = "$id.example.org", port = 443,
        rawLink = "vless://00000000-0000-0000-0000-000000000001@$id.example.org:443?security=tls&sni=$id.example.org&type=tcp"
    )

    @Test fun youtubeUsesSelectedPrimaryBeforeGenericBalancer() {
        val base = XrayConfigBuilder.build(server("main"), null)!!
        val full = EmbeddedWarmRoutes.augment(base, listOf(server("backup")))
        val rules = JSONObject(full).getJSONObject("routing").getJSONArray("rules")
        val all = (0 until rules.length()).map { rules.getJSONObject(it) }
        val videoIndex = all.indexOfFirst {
            it.optJSONArray("domain")?.toString()?.contains("googlevideo.com") == true
        }
        val defaultTunIndex = all.indexOfFirst {
            it.optString("balancerTag") == EmbeddedWarmRoutes.BALANCER_TAG &&
                it.optJSONArray("inboundTag")?.toString()?.contains("tun") == true
        }
        assertTrue(videoIndex >= 0)
        assertTrue(defaultTunIndex > videoIndex)
        assertEquals("proxy", all[videoIndex].getString("outboundTag"))
        assertTrue(all[videoIndex].getJSONArray("domain").toString().contains("ytimg.com"))
        val socks = all.first { it.optJSONArray("inboundTag")?.toString()?.contains("health-socks") == true }
        assertEquals("proxy", socks.getString("outboundTag"))
        assertFalse(socks.has("balancerTag"))
    }

    @Test fun manualSwitchRemovesYoutubeAffinityAndRestoresProbes() {
        val base = XrayConfigBuilder.build(server("main"), null)!!
        val full = EmbeddedWarmRoutes.augment(base, listOf(server("backup")))
        val restored = EmbeddedWarmRoutes.singleRoute(full)
        val root = JSONObject(restored)
        assertFalse(restored.contains(EmbeddedWarmRoutes.BALANCER_TAG))
        assertFalse(restored.contains("domain:googlevideo.com"))
        assertFalse(root.has("observatory"))
        assertEquals(4, root.getJSONArray("outbounds").length())
        assertEquals("proxy", root.getJSONArray("outbounds")
            .getJSONObject(1).getJSONObject("streamSettings")
            .getJSONObject("sockopt").getString("dialerProxy"))
    }

    @Test fun noCandidatesKeepsExistingRouting() {
        val base = XrayConfigBuilder.build(server("main"), null)!!
        assertEquals(base, EmbeddedWarmRoutes.augment(base, emptyList()))
    }
}
