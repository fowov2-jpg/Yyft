package com.secureconnect.app.viewmodel

import org.junit.Assert.*
import org.junit.Test

class AutoSelectionRequestTest {
    @Test fun emptyPoolWaitsAndFirstSuccessConnectsOnlyOnce() {
        val request = AutoSelectionRequest()
        request.request()
        assertFalse(request.consumeIf(ready = false, connecting = false))
        assertTrue(request.pending.value)
        assertTrue(request.consumeIf(ready = true, connecting = false))
        assertFalse(request.consumeIf(ready = true, connecting = false))
    }
    @Test fun cancelPreventsLateProbeFromConnecting() {
        val request = AutoSelectionRequest()
        request.request()
        request.cancel()
        assertFalse(request.consumeIf(ready = true, connecting = false))
    }
    @Test fun repeatedTapDoesNotQueueDuplicateConnections() {
        val request = AutoSelectionRequest()
        repeat(3) { request.request() }
        assertFalse(request.consumeIf(ready = true, connecting = true))
        assertTrue(request.consumeIf(ready = true, connecting = false))
        assertFalse(request.consumeIf(ready = true, connecting = false))
        request.request()
        assertTrue(request.consumeIf(ready = true, connecting = false))
    }
}
