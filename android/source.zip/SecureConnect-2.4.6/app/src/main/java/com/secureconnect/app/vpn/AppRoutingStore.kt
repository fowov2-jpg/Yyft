package com.secureconnect.app.vpn

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build

/** Persisted by package identifier so labels, updates and reboots don't reset user choices. */
class AppRoutingStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("sc_settings", Context.MODE_PRIVATE)

    fun load(): AppRoutingSnapshot {
        // v1 stored auto-generated Russian packages in the same set as manual choices.
        // Migrate once so newly added Russian apps can automatically bypass VPN,
        // while a previously manually VPN-enabled Russian app remains enabled.
        if (prefs.getInt(KEY_SCHEMA, 1) < 2) {
            val saved = if (prefs.contains(KEY_EXCLUDED)) {
                prefs.getStringSet(KEY_EXCLUDED, emptySet()).orEmpty().toSet()
            } else null
            val (manualDirect, manualVpn) = migrateLegacyExclusions(saved)
            check(prefs.edit()
                .putStringSet(KEY_EXCLUDED, manualDirect)
                .putStringSet(KEY_FORCE_VPN, manualVpn)
                .putBoolean(KEY_AUTO_RUSSIAN, true)
                .putInt(KEY_SCHEMA, 2)
                .commit()) { "Не удалось сохранить обновлённый фильтр приложений" }
        }
        val mode = if (prefs.getString(KEY_MODE, null) == AppVpnMode.ONLY_SELECTED.name) {
            AppVpnMode.ONLY_SELECTED
        } else AppVpnMode.EXCLUDE_SELECTED
        return AppRoutingSnapshot(
            mode = mode,
            excluded = prefs.getStringSet(KEY_EXCLUDED, emptySet()).orEmpty().toSet(),
            included = prefs.getStringSet(KEY_INCLUDED, emptySet()).orEmpty().toSet(),
            autoExcludeRussian = prefs.getBoolean(KEY_AUTO_RUSSIAN, true),
            forceVpn = prefs.getStringSet(KEY_FORCE_VPN, emptySet()).orEmpty().toSet()
        )
    }

    fun setAutoExcludeRussian(enabled: Boolean): AppRoutingSnapshot =
        load().copy(autoExcludeRussian = enabled).also(::save)

    fun setVpnEnabled(pkg: String, enabled: Boolean): AppRoutingSnapshot {
        require(pkg.isNotBlank() && pkg != context.packageName)
        val old = load()
        val new = when (old.mode) {
            AppVpnMode.EXCLUDE_SELECTED -> old.copy(
                excluded = old.excluded.toMutableSet().apply {
                    if (enabled) remove(pkg) else add(pkg)
                },
                forceVpn = old.forceVpn.toMutableSet().apply {
                    if (enabled && pkg in RussianApps.defaultDirectPackages) add(pkg)
                    else remove(pkg)
                }
            )
            AppVpnMode.ONLY_SELECTED -> {
                val included = old.included.toMutableSet().apply {
                    if (enabled) add(pkg) else remove(pkg)
                }
                // Never allow an empty allow-list: Android would route ALL apps instead.
                val candidate = old.copy(included = included)
                candidate.forInstalledPackages(installedPackageNames(), context.packageName)
                candidate
            }
        }
        save(new)
        return new
    }

    fun setMode(mode: AppVpnMode): AppRoutingSnapshot {
        val old = load()
        if (mode == AppVpnMode.ONLY_SELECTED) {
            // A stale package id is not a valid allow-list. Android would route all
            // applications if addAllowedApplication() were never called.
            old.copy(mode = mode).forInstalledPackages(installedPackageNames(), context.packageName)
        }
        return old.copy(mode = mode).also(::save)
    }

    /** Edits a pending allow-list without switching the active policy. */
    fun prepareIncluded(pkg: String, enabled: Boolean): AppRoutingSnapshot {
        require(pkg.isNotBlank() && pkg != context.packageName)
        val old = load()
        return old.copy(included = old.included.toMutableSet().apply {
            if (enabled) add(pkg) else remove(pkg)
        }).also(::save)
    }

    private fun save(snapshot: AppRoutingSnapshot) {
        prefs.edit()
            .putString(KEY_MODE, snapshot.mode.name)
            .putStringSet(KEY_EXCLUDED, snapshot.excluded.toSet())
            .putStringSet(KEY_INCLUDED, snapshot.included.toSet())
            .putStringSet(KEY_FORCE_VPN, snapshot.forceVpn.toSet())
            .putBoolean(KEY_AUTO_RUSSIAN, snapshot.autoExcludeRussian)
            .putInt(KEY_SCHEMA, 2)
            .commit().also { check(it) { "Не удалось сохранить настройки маршрутизации" } }
    }

    /** All installed package IDs, used to resolve the actual Builder routes. */
    fun installedPackageNames(): Set<String> = allInstalledApplications()
        .mapTo(hashSetOf()) { it.packageName }

    private fun allInstalledApplications(): List<ApplicationInfo> {
        val pm = context.packageManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledApplications(0)
        }
    }

    /**
     * List all installed packages including those without launcher icons.
     * App inventory is used locally only. Never uploaded or logged.
     */
    fun installedApps(): List<InstalledVpnApp> {
        val pm = context.packageManager
        return allInstalledApplications().asSequence()
            .filter { it.packageName != context.packageName }
            .map { info ->
                val title = info.loadLabel(pm).toString().ifBlank { info.packageName }
                InstalledVpnApp(
                    packageName = info.packageName,
                    title = title,
                    russianPreset = info.packageName in RussianApps.defaultDirectPackages,
                    systemApp = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0 ||
                        (info.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
                )
            }
            .distinctBy { it.packageName }
            .sortedWith(compareByDescending<InstalledVpnApp> { it.russianPreset }
                .thenBy { it.systemApp }
                .thenBy { it.title.lowercase() })
            .toList()
    }

    companion object {
        private const val KEY_SCHEMA = "app_routing_schema"
        private const val KEY_AUTO_RUSSIAN = "app_routing_auto_ru_v2"
        private const val KEY_FORCE_VPN = "app_routing_force_vpn_v2"
        private const val KEY_MODE = "app_routing_mode_v1"
        private const val KEY_EXCLUDED = "app_routing_excluded_v1"
        private const val KEY_INCLUDED = "app_routing_included_v1"
    }
}
