package com.secureconnect.app.vpn

import com.secureconnect.app.data.model.Server
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.MutableSharedFlow

sealed class VpnState {
    object Idle : VpnState()
    object Connecting : VpnState()
    /** User dismissed the task; wait for the actual Android TUN to close. */
    object Stopping : VpnState()
    /** Xray поднят, но реальный HTTPS/DNS-трафик ещё проходит проверку через proxy. */
    object Validating : VpnState()
    object Connected : VpnState()
    /** VPN оборвался, но Kill Switch держит TUN — интернет заблокирован. */
    object Blocked : VpnState()
    class Error(val message: String) : VpnState()
}

/** Общее состояние VPN: сервис пишет, ViewModel читает. */
object VpnController {
    val state = MutableStateFlow<VpnState>(VpnState.Idle)
    /** Active server can change inside the foreground service while UI is closed. */
    val activeServer = MutableStateFlow<Server?>(null)
    /** Unsafe TLS route: show an explicit one-session decision in the UI. */
    val riskyCandidate = MutableStateFlow<Server?>(null)
    /** One counter owner in XrayVpnService; UI never drains native Xray stats. */
    val trafficRate = MutableStateFlow(VpnTrafficRate.ZERO)
    /** Separate benchmark, never confused with current app traffic. */
    val speedTestResult = MutableStateFlow<String?>(null)
    /** True only while the user-requested, bandwidth-consuming video benchmark is running. */
    val videoManualCheckBusy = MutableStateFlow(false)
    /** Single automatic first-connect video test; no manual button required. */
    val videoAutoCheckBusy = MutableStateFlow(false)
    /** Displayed independently from VPN readiness. Never claim video on HTTPS alone. */
    val videoQualityStatus = MutableStateFlow("Не проверено")
    /** A service-owned, bounded TLS probe. Unlike native ChatGPT, it cannot verify app pinning. */
    val openAiTlsStatus = MutableStateFlow("TLS ChatGPT: ещё не проверялся")
    /** Observable background quality improvement state; not a UI control. */
    val qualityUpgradeStatus = MutableStateFlow("inactive")
    /** Time of last local automatic safety assessment, not a DNS/IPv6 leak test. */
    val lastAutomaticSecurityCheckAtMs = MutableStateFlow(0L)
    /** Allows the notification Stop button to cancel ViewModel prechecks/reconnect jobs. */
    val stopRequestSerial = MutableStateFlow(0L)
    /** Counts of actual accepted Android VpnService.Builder package rules, not just UI defaults. */
    val appliedAppRouting = MutableStateFlow<String?>(null)
    /**
     * Identity of the server whose Xray instance is currently being validated.
     * This prevents a new UI/manual attempt from mistaking stale Validating state
     * from an older recovery attempt for its own server.
     */
    @Volatile var validatingServerId: String? = null
    /** Short service-originated diagnostics for the UI log. */
    val events = MutableSharedFlow<String>(replay = 16, extraBufferCapacity = 16)

    /** Синхронизируется из ViewModel (SharedPreferences). */
    @Volatile var killSwitchEnabled: Boolean = true
    @Volatile var autoRecoveryEnabled: Boolean = true

    fun emitEvent(message: String) {
        events.tryEmit(message.take(300))
    }
}
