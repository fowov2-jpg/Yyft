package com.secureconnect.app.vpn

/** Time budgets for a verified-reserve failover; not an end-to-end SLA. */
object FastFailoverPolicy {
    const val TARGET_MS = 5_000L
    const val DNS_BUDGET_MS = 500L
    const val FAST_TLS_TIMEOUT_MS = 1_800
    const val FAILED_PROBE_COOLDOWN_MS = 30_000L

    /** A fast handover cannot promise success when no previously qualified node exists. */
    fun canUseReadyReserve(fullyQualified: Boolean, sameAsActive: Boolean,
                           coolingDown: Boolean, rawConfigPresent: Boolean): Boolean =
        fullyQualified && !sameAsActive && !coolingDown && rawConfigPresent

    /** Always show when the observed handover exceeded the goal. */
    fun metGoal(elapsedMs: Long): Boolean = elapsedMs in 0L..TARGET_MS
}
