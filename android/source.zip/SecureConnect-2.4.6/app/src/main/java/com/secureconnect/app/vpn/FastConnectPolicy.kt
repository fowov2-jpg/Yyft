package com.secureconnect.app.vpn

/**
 * HTTPS confirms basic tunnel reachability, not whether video is usable.
 * HTTPS readiness is independent of optional video certification.
 * Strict reserves still need actual YouTube and measured throughput evidence.
 */
internal object FastConnectPolicy {
    const val FAST_QUALITY_REUSE_MS = 2L * 60L * 60L * 1000L

    fun canReuseCertifiedQuality(
        sameConfiguration: Boolean,
        youtubeVerifiedAtMs: Long,
        speedVerifiedAtMs: Long,
        nowMs: Long
    ): Boolean =
        sameConfiguration &&
            youtubeVerifiedAtMs > 0L && speedVerifiedAtMs > 0L &&
            nowMs >= youtubeVerifiedAtMs && nowMs >= speedVerifiedAtMs &&
            nowMs - youtubeVerifiedAtMs <= FAST_QUALITY_REUSE_MS &&
            nowMs - speedVerifiedAtMs <= FAST_QUALITY_REUSE_MS

    fun needsLiveVideoCheck(automaticMode: Boolean, hasRecentCertifiedQuality: Boolean): Boolean =
        automaticMode && !hasRecentCertifiedQuality

    /**
     * An actually passed Xray HTTPS probe is sufficient for VPN readiness.
     * Video certifications are independent indicators (never inferred from HTTPS).
     * Kept the original signature for callers and pre-existing migration tests.
     */
    @Suppress("UNUSED_PARAMETER")
    fun canPublishConnected(
        httpsVerified: Boolean,
        automaticMode: Boolean,
        hasRecentCertifiedQuality: Boolean,
        youtubeCheckedNow: Boolean,
        measuredSpeedQualifiedNow: Boolean
    ): Boolean = httpsVerified

    /** Video suitability is not the same as the two-way, strict reserve gate. */
    fun videoSuitable(youtubeVerified: Boolean, downloadMbps: Double?): Boolean =
        youtubeVerified && downloadMbps != null && downloadMbps.isFinite() &&
            downloadMbps >= VpnSpeedPolicy.MIN_DOWNLOAD_MBPS

    /** Both independent speed samples + YouTube are required for strict reserve admission. */
    fun canCertifyYouTubeReserve(youtubeVerified: Boolean, throughputQualified: Boolean): Boolean =
        youtubeVerified && throughputQualified
}
