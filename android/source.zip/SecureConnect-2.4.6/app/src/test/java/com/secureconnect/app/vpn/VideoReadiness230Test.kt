package com.secureconnect.app.vpn

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VideoReadiness230Test {
    @Test fun httpsIsSufficientForWorkingVpnNotForCertifiedVideo() {
        assertTrue(FastConnectPolicy.canPublishConnected(true, true, false, false, false))
        assertFalse(FastConnectPolicy.canCertifyYouTubeReserve(true, false))
    }

    @Test fun youtubeAndDownloadRequiredForVideoNotUpload() {
        assertTrue(FastConnectPolicy.videoSuitable(true, 5.0))
        assertFalse(FastConnectPolicy.videoSuitable(true, 4.99))
        assertFalse(FastConnectPolicy.videoSuitable(false, 100.0))
        assertFalse(FastConnectPolicy.videoSuitable(true, Double.NaN))
    }

    @Test fun certificationExpiresAndCannotFollowChangedConfiguration() {
        val now = 2_000_000_000L
        val proof = now - 30_000L
        assertTrue(FastConnectPolicy.canReuseCertifiedQuality(true, proof, proof, now))
        assertFalse(FastConnectPolicy.canReuseCertifiedQuality(false, proof, proof, now))
        assertFalse(FastConnectPolicy.canReuseCertifiedQuality(true, proof,
            now - FastConnectPolicy.FAST_QUALITY_REUSE_MS - 1L, now))
    }
}
