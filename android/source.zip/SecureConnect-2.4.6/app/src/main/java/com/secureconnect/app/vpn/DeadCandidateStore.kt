package com.secureconnect.app.vpn

import android.content.Context
import org.json.JSONObject

/**
 * Bounded, temporary retry memory. IDs only; never store config URLs, IPs or
 * credentials. Quarantine is limited to the physical network on which it failed.
 * A new network immediately permits a retest.
 */
object DeadCandidateStore {
    private const val PREFS = "sc_failed_candidate_cooldown"
    private const val KEY_ITEMS = "cooldowns_v1"
    private const val KEY_NETWORK = "underlay_v1"
    private const val MAX_ITEMS = 100
    const val TRANSPORT_COOLDOWN_MS = 60L * 60_000L
    const val VIDEO_COOLDOWN_MS = 20L * 60_000L
    private val lock = Any()

    fun syncNetwork(context: Context, physicalNetwork: String) = synchronized(lock) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.getString(KEY_NETWORK, null) != physicalNetwork) {
            prefs.edit().putString(KEY_NETWORK, physicalNetwork).remove(KEY_ITEMS).apply()
        }
    }

    fun coolingIds(context: Context, nowMs: Long = System.currentTimeMillis()): Set<String> =
        synchronized(lock) {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val saved = runCatching { JSONObject(prefs.getString(KEY_ITEMS, "{}") ?: "{}") }
                .getOrDefault(JSONObject())
            val ids = HashSet<String>()
            val iter = saved.keys()
            while (iter.hasNext()) {
                val id = iter.next()
                if (saved.optLong(id, 0L) > nowMs) ids.add(id)
            }
            ids
        }

    fun quarantine(
        context: Context, serverId: String, videoOnly: Boolean,
        nowMs: Long = System.currentTimeMillis()
    ) = synchronized(lock) {
        if (serverId.isBlank() || serverId.length > 160) return@synchronized
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val stored = runCatching { JSONObject(prefs.getString(KEY_ITEMS, "{}") ?: "{}") }
            .getOrDefault(JSONObject())
        val records = LinkedHashMap<String, Long>()
        val iter = stored.keys()
        while (iter.hasNext()) {
            val id = iter.next()
            val expires = stored.optLong(id, 0L)
            if (expires > nowMs) records[id] = expires
        }
        val ttl = if (videoOnly) VIDEO_COOLDOWN_MS else TRANSPORT_COOLDOWN_MS
        records[serverId] = nowMs + ttl
        val trimmed = records.entries.sortedByDescending { it.value }.take(MAX_ITEMS)
        val newJson = JSONObject()
        trimmed.forEach { newJson.put(it.key, it.value) }
        prefs.edit().putString(KEY_ITEMS, newJson.toString()).apply()
    }

    fun clear(context: Context, serverId: String) = synchronized(lock) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val saved = runCatching { JSONObject(prefs.getString(KEY_ITEMS, "{}") ?: "{}") }
            .getOrDefault(JSONObject())
        if (saved.has(serverId)) {
            saved.remove(serverId)
            prefs.edit().putString(KEY_ITEMS, saved.toString()).apply()
        }
    }

    /** A single control-site error must not be treated as a dead VPN. */
    fun videoOnlyFailure(error: String?): Boolean {
        val detail = error.orEmpty().lowercase()
        return "youtube" in detail || "скорост" in detail ||
            "бюджет тестов" in detail || "speed" in detail
    }
}
