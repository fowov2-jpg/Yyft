package com.secureconnect.app.vpn

import android.content.Context
import com.secureconnect.app.data.model.Server
import com.secureconnect.app.util.ResourceGovernor
import kotlinx.coroutines.withContext

/** Liveness-only TLS test. No bandwidth transfer or YouTube fetch. */
object ReserveHealthProbe {
    suspend fun check(context: Context, server: Server): Boolean =
        withContext(ResourceGovernor.probeDispatcher) {
            val config = XrayConfigBuilder.buildProbe(server) ?: return@withContext false
            val first = XrayCore.measureStandalone(context, config,
                "https://www.gstatic.com/generate_204")
            first.ms != null || XrayCore.measureStandalone(context, config,
                "https://cp.cloudflare.com/generate_204").ms != null
        }
}
