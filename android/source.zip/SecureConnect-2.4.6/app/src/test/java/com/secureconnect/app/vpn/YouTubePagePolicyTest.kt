package com.secureconnect.app.vpn

import org.junit.Assert.*
import org.junit.Test

class YouTubePagePolicyTest {
    @Test fun youtubeHomeDocumentPasses() {
        assertTrue(YouTubePagePolicy.isHomePage(200, "text/html; charset=utf-8",
            "<!doctype html><html><head><script>ytcfg.set({})</script></head></html>"))
        assertTrue(YouTubePagePolicy.isHomePage(200, "text/html",
            "<html><script>var ytInitialData={}</script></html>"))
    }
    @Test fun redirectConsentAndBlockedPageNeverPass() {
        assertFalse(YouTubePagePolicy.isHomePage(302, "text/html", "<html>ytcfg.set</html>"))
        assertFalse(YouTubePagePolicy.isHomePage(200, "text/html", "<html>Before you continue to YouTube</html>"))
        assertFalse(YouTubePagePolicy.isHomePage(200, "text/html", "<html>Access denied by proxy</html>"))
        assertFalse(YouTubePagePolicy.isHomePage(403, "text/html", "<html>ytcfg.set</html>"))
        assertFalse(YouTubePagePolicy.isHomePage(200, "application/json", "<html>ytcfg.set</html>"))
    }
    @Test fun genericConnectivityPageIsNotYoutube() {
        assertFalse(YouTubePagePolicy.isHomePage(204, "text/html", ""))
        assertFalse(YouTubePagePolicy.isHomePage(200, "text/html", "<html><body>OK</body></html>"))
    }

    @Test fun redirectsOnlyToCanonicalHttpsYouTubeHosts() {
        val current = java.net.URI("https://www.youtube.com/")
        assertEquals("https://m.youtube.com/watch?v=123",
            YouTubePagePolicy.nextPage(current, "https://m.youtube.com/watch?v=123").toString())
        assertEquals("https://www.youtube.com/?gl=US",
            YouTubePagePolicy.nextPage(current, "/?gl=US").toString())
        assertNull(YouTubePagePolicy.nextPage(current, "https://consent.youtube.com/m"))
        assertNull(YouTubePagePolicy.nextPage(current, "https://evil.youtube.com/"))
        assertNull(YouTubePagePolicy.nextPage(current, "https://youtube.com.evil.org/"))
        assertNull(YouTubePagePolicy.nextPage(current, "http://www.youtube.com/"))
        assertNull(YouTubePagePolicy.nextPage(current, "https://www.youtube.com:444/"))
        assertNull(YouTubePagePolicy.nextPage(current, "https://user@www.youtube.com/"))
        assertNull(YouTubePagePolicy.nextPage(current, "javascript:alert(1)"))
    }

    @Test fun misleadingHtmlCannotPass() {
        assertFalse(YouTubePagePolicy.isHomePage(200, "text/html",
            "<html>Access denied <script>ytcfg.set({})</script></html>"))
        assertFalse(YouTubePagePolicy.isHomePage(200, "text/html",
            "<html>Before you continue to YouTube <script>ytcfg.set()</script></html>"))
    }
}
