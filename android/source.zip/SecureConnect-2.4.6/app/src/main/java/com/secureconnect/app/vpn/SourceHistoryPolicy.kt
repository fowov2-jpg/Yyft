package com.secureconnect.app.vpn

/**
 * Learn a preference for subscription sources from ACTUAL video-qualified servers.
 *
 * Source names are only ordering hints, never proof that all configs from a
 * source work. Do not retain URLs, credentials, hostnames or traffic data.
 * Failed/stale proofs lose their preference; other sources stay discoverable.
 */
object SourceHistoryPolicy {
    data class Proof(
        val source: String,
        val lastSuccessAtMs: Long,
        val youtubeVerifiedAtMs: Long,
        val speedVerifiedAtMs: Long,
        val lastFailureAtMs: Long = 0L,
        val consecutiveFailures: Int = 0
    )

    const val PROOF_MAX_AGE_MS: Long = 3L * 24L * 60L * 60_000L
    private const val MAX_PREFERRED_SOURCES = 5

    fun preferredSources(proofs: List<Proof>, nowMs: Long): List<String> {
        if (nowMs <= 0L) return emptyList()
        val valid = proofs.filter { p ->
            p.source.isNotBlank() &&
                p.lastSuccessAtMs in 1L..nowMs &&
                nowMs - p.lastSuccessAtMs <= PROOF_MAX_AGE_MS &&
                p.youtubeVerifiedAtMs in 1L..nowMs &&
                nowMs - p.youtubeVerifiedAtMs <= PROOF_MAX_AGE_MS &&
                p.speedVerifiedAtMs in 1L..nowMs &&
                nowMs - p.speedVerifiedAtMs <= PROOF_MAX_AGE_MS &&
                !(p.consecutiveFailures >= 2 && p.lastFailureAtMs > p.lastSuccessAtMs)
        }
        return valid.groupBy { it.source }.entries
            .sortedWith(compareByDescending<Map.Entry<String, List<Proof>>> { it.value.size.coerceAtMost(5) }
                .thenByDescending { group -> group.value.maxOf { it.lastSuccessAtMs } }
                .thenBy { it.key })
            .take(MAX_PREFERRED_SOURCES)
            .map { it.key }
    }

    /** Round-robin keeps discovery alive if a once-good subscription goes stale. */
    fun <T> interleave(ranked: List<T>, source: (T) -> String): List<T> {
        val queues = LinkedHashMap<String, ArrayDeque<T>>()
        ranked.forEach { item ->
            queues.getOrPut(source(item).ifBlank { "<unknown>" }) { ArrayDeque() }.addLast(item)
        }
        val result = ArrayList<T>(ranked.size)
        while (queues.isNotEmpty()) {
            val empty = ArrayList<String>()
            for ((name, queue) in queues) {
                if (queue.isNotEmpty()) result.add(queue.removeFirst())
                if (queue.isEmpty()) empty.add(name)
            }
            empty.forEach(queues::remove)
        }
        return result
    }

    fun rank(source: String, preferredSources: List<String>): Int {
        val index = preferredSources.indexOf(source)
        return if (index >= 0) index else preferredSources.size + 1
    }
}
