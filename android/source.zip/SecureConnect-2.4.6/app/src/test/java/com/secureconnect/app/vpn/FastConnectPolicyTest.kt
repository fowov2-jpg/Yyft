package com.secureconnect.app.vpn

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FastConnectPolicyTest {
    @Test fun vpnHttpsReadyRegardlessOfVideoQualification() {
        assertTrue(FastConnectPolicy.canPublishConnected(true, true, false, false, false))
        assertTrue(FastConnectPolicy.canPublishConnected(true, true, false, true, false))
        assertTrue(FastConnectPolicy.canPublishConnected(true, true, false, false, true))
        assertFalse(FastConnectPolicy.canPublishConnected(false, true, true, true, true))
    }

    @Test fun videoReadinessRequiresYouTubeAndDownloadOnly() {
        assertTrue(FastConnectPolicy.videoSuitable(true, 5.0))
        assertFalse(FastConnectPolicy.videoSuitable(false, 9.0))
        assertFalse(FastConnectPolicy.videoSuitable(true, 4.99))
        assertFalse(FastConnectPolicy.videoSuitable(true, null))
    }

    @Test fun manualSelectionCanConnectWithoutVideoQualification() {
        assertTrue(FastConnectPolicy.canPublishConnected(true, false, false, false, false))
    }

    @Test fun oldOrChangedConfigsCannotReuseProof() {
        val now = 10_000_000L
        val good = now - FastConnectPolicy.FAST_QUALITY_REUSE_MS / 2
        val old = now - FastConnectPolicy.FAST_QUALITY_REUSE_MS - 1
        assertTrue(FastConnectPolicy.canReuseCertifiedQuality(true, good, good, now))
        assertFalse(FastConnectPolicy.canReuseCertifiedQuality(false, good, good, now))
        assertFalse(FastConnectPolicy.canReuseCertifiedQuality(true, old, good, now))
        assertFalse(FastConnectPolicy.canReuseCertifiedQuality(true, good, old, now))
        assertFalse(FastConnectPolicy.canReuseCertifiedQuality(true, 0L, good, now))
        assertFalse(FastConnectPolicy.canReuseCertifiedQuality(true, now + 1, good, now))
    }

    @Test fun liveQualificationOnlyForAutomaticWithoutCache() {
        assertTrue(FastConnectPolicy.needsLiveVideoCheck(true, false))
        assertFalse(FastConnectPolicy.needsLiveVideoCheck(true, true))
        assertFalse(FastConnectPolicy.needsLiveVideoCheck(false, false))
    }

    @Test fun strictReserveStillNeedsBothProofs() {
        assertFalse(FastConnectPolicy.canCertifyYouTubeReserve(false, false))
        assertFalse(FastConnectPolicy.canCertifyYouTubeReserve(true, false))
        assertFalse(FastConnectPolicy.canCertifyYouTubeReserve(false, true))
        assertTrue(FastConnectPolicy.canCertifyYouTubeReserve(true, true))
    }
}
