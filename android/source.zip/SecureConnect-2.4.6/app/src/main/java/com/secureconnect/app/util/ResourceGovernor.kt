package com.secureconnect.app.util

import android.app.ActivityManager
import android.content.Context
import android.os.Debug
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.asCoroutineDispatcher
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.ThreadFactory
import java.util.concurrent.atomic.AtomicLong

/**
 * Best-effort resource governor for SecureConnect-owned work.
 *
 * Android does not expose an application API that can hard-pin the whole process
 * (including the embedded Go/Xray runtime) to two CPU cores or impose a custom
 * 512 MiB cgroup limit. What we can control is our own concurrency and whether we
 * start expensive refresh/probe work while the process is under memory pressure.
 */
object ResourceGovernor {
    const val MAX_APP_WORKERS = 2
    const val REQUESTED_MEMORY_CEILING_BYTES = 512L * 1024L * 1024L
    const val SOFT_PSS_LIMIT_BYTES = 384L * 1024L * 1024L

    private val pressureUntilMs = AtomicLong(0L)
    private val lastPssSampleElapsedMs = AtomicLong(-1L)
    @Volatile private var cachedPssBytes = 0L
    private const val PSS_SAMPLE_INTERVAL_MS = 60_000L

    init {
        applyRuntimeHints()
    }

    private val workerThreadFactory = ThreadFactory { task ->
        Thread(task, "sc-worker").apply {
            isDaemon = true
            priority = Thread.NORM_PRIORITY - 1
        }
    }

    /** Shared executor for SecureConnect-owned CPU/blocking background jobs. */
    val workerExecutor: ExecutorService =
        Executors.newFixedThreadPool(MAX_APP_WORKERS, workerThreadFactory)

    val dispatcher: CoroutineDispatcher = workerExecutor.asCoroutineDispatcher()

    /** Standalone probes must not occupy the two latency-critical health workers. */
    val probeDispatcher: CoroutineDispatcher = Executors.newFixedThreadPool(2) { task ->
        Thread(task, "sc-probe").apply {
            isDaemon = true
            priority = Thread.MIN_PRIORITY
        }
    }.asCoroutineDispatcher()

    /** DNS may ignore interrupt; reject new probes rather than queue unbounded work. */
    val dnsExecutor: ExecutorService = ThreadPoolExecutor(
        1, 1, 0L, TimeUnit.MILLISECONDS,
        ArrayBlockingQueue<Runnable>(2),
        ThreadFactory { task ->
            Thread(task, "sc-dns").apply {
                isDaemon = true
                priority = Thread.MIN_PRIORITY
            }
        },
        ThreadPoolExecutor.AbortPolicy()
    )

    /**
     * Apply scheduler hints before application coroutines are created.
     * These are best-effort: native/Xray threads are outside this scheduler.
     */
    fun configureRuntimeHints() {
        applyRuntimeHints()
    }

    private fun applyRuntimeHints() {
        runCatching { System.setProperty("kotlinx.coroutines.scheduler.core.pool.size", "2") }
        runCatching { System.setProperty("kotlinx.coroutines.scheduler.max.pool.size", "2") }
        runCatching { System.setProperty("kotlinx.coroutines.io.parallelism", "2") }
        runCatching { System.setProperty("java.util.concurrent.ForkJoinPool.common.parallelism", "2") }
    }

    fun noteTrimMemory(level: Int) {
        // Never latch memory pressure forever: Android may send a trim callback while
        // the UI is backgrounded and never send a matching "all clear" callback.
        // Heavy catalogue work backs off temporarily and can resume later.
        val backoffMs = when (level) {
            android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL -> 120_000L
            android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW -> 60_000L
            android.content.ComponentCallbacks2.TRIM_MEMORY_COMPLETE -> 90_000L
            android.content.ComponentCallbacks2.TRIM_MEMORY_MODERATE -> 60_000L
            android.content.ComponentCallbacks2.TRIM_MEMORY_BACKGROUND -> 30_000L
            else -> 0L
        }
        if (backoffMs > 0L) {
            val until = System.currentTimeMillis() + backoffMs
            pressureUntilMs.updateAndGet { old -> maxOf(old, until) }
        }
    }

    fun clearTransientPressure() {
        pressureUntilMs.set(0L)
    }

    fun isMemoryPressured(context: Context? = null): Boolean {
        if (System.currentTimeMillis() < pressureUntilMs.get()) return true
        val pss = processPssBytes()
        if (pss >= SOFT_PSS_LIMIT_BYTES) return true

        // If Android gives this device a heap smaller than our requested ceiling,
        // respect the platform's real limit and start backing off at ~80%.
        val maxHeap = Runtime.getRuntime().maxMemory().coerceAtLeast(1L)
        val usedHeap = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()
        if (usedHeap >= (maxHeap * 80L / 100L)) return true

        if (context != null) {
            val am = context.getSystemService(ActivityManager::class.java)
            if (am != null && am.isLowRamDevice && usedHeap >= (maxHeap * 70L / 100L)) return true
        }
        return false
    }

    /**
     * Debug.getMemoryInfo invokes platform memory accounting; it must not run
     * on each scan iteration. Cache for one minute and still honor immediate
     * Android onTrimMemory callbacks via pressureUntilMs.
     */
    fun processPssBytes(): Long {
        val now = android.os.SystemClock.elapsedRealtime()
        val previous = lastPssSampleElapsedMs.get()
        if (previous >= 0 && now >= previous && now - previous < PSS_SAMPLE_INTERVAL_MS) {
            return cachedPssBytes
        }
        synchronized(this) {
            val updated = lastPssSampleElapsedMs.get()
            if (updated >= 0 && now >= updated && now - updated < PSS_SAMPLE_INTERVAL_MS) {
                return cachedPssBytes
            }
            cachedPssBytes = runCatching {
                val info = Debug.MemoryInfo()
                Debug.getMemoryInfo(info)
                info.totalPss.toLong() * 1024L
            }.getOrDefault(0L)
            lastPssSampleElapsedMs.set(now)
            return cachedPssBytes
        }
    }

    fun resourceSummary(context: Context? = null): String {
        val maxHeapMb = Runtime.getRuntime().maxMemory() / (1024L * 1024L)
        val pssMb = processPssBytes() / (1024L * 1024L)
        val lowRam = context?.getSystemService(ActivityManager::class.java)?.isLowRamDevice
        return "healthWorkers=$MAX_APP_WORKERS, probeWorkers=1(VPN)/2(idle), pss=${pssMb}MB, heapMax=${maxHeapMb}MB, pressure=${isMemoryPressured(context)}, lowRam=${lowRam ?: "?"}"
    }
}
