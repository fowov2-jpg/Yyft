package com.secureconnect.app.vpn

/**
 * Extended, curated Android application IDs, verified against official
 * Google Play or RuStore listing URLs (11 October 2026).
 *
 * IMPORTANT: exact package equality only; never auto-exclude by name/prefix.
 * Manual VPN overrides in AppRoutingSnapshot.forceVpn have priority.
 * An application listed here is not proof all its external endpoints work without VPN.
 */
internal object RussianAppsExpanded {
    val catalog = listOf(
        // PSB / Promsvyazbank: verified official RuStore listings (2026-10-11).
        RussianApp("logo.com.mbanking", "ПСБ — мобильный банк"),
        RussianApp("ru.psbank.msb.dev.psb_appstore", "ПСБ Бизнес"),
        RussianApp("ru.psbank.invest", "ПСБ Инвестиции"),
        RussianApp("ru.ozon.fintech.finance", "Ozon Банк"),
        RussianApp("ru.ozon.fintech.sme", "Ozon Банк для бизнеса"),
        RussianApp("ru.rshb.dbo", "Россельхозбанк"),
        RussianApp("ru.bankuralsib.mb.android", "Уралсиб Онлайн"),
        RussianApp("ru.sovcomcard.halva.v1", "Халва — Совкомбанк"),
        RussianApp("ru.nspk.sbpay", "СБПэй"),
        RussianApp("ru.gazprombank.android.mobilebank.app", "Газпромбанк"),
        RussianApp("ru.gazprombank.broker", "ГПБ Брокер"),
        RussianApp("ru.lewis.dbo", "МТС Деньги"),
        RussianApp("ru.sberbank_sbbol", "СберБизнес"),
        RussianApp("ru.mkb.mobile", "МКБ Онлайн"),
        RussianApp("ru.raiffeisennews", "Райффайзен Онлайн Россия"),
        RussianApp("ru.bspb.b2b", "БСПБ Бизнес"),
        RussianApp("ru.sngb.dbo.client.android", "СНГБ Онлайн"),
        RussianApp("ru.sberbank.spasibo", "СберСпасибо (ранее установленное)"),
        RussianApp("ru.gosuslugi.auto", "Госуслуги Авто"),
        RussianApp("ru.gosuslugi.culture", "Госуслуги Культура"),
        RussianApp("ru.sigma.gisgkh", "Госуслуги Дом"),
        RussianApp("ru.mos.app", "Моя Москва"),
        RussianApp("ru.fns.lkfl", "Налоги ФЛ"),
        RussianApp("ru.megafon.mlk", "МегаФон"),
        RussianApp("ru.onlime.my.app", "Ростелеком Москва"),
        RussianApp("ru.netbynet.app.personal_cabinet", "Wifire — личный кабинет"),
        RussianApp("ru.perekrestok.app", "Перекрёсток"),
        RussianApp("club.chizhik", "Чижик"),
        RussianApp("ru.sbcs.store", "Самокат — доставка"),
        RussianApp("ru.instamart", "Купер"),
        RussianApp("com.icemobile.lenta.prod", "Лента"),
        RussianApp("ru.lenta.lentochka", "Лента Онлайн"),
        RussianApp("com.ru.dixy", "Дикси"),
        RussianApp("ru.x5.perekrestok.darkstore", "Впрок"),
        RussianApp("ru.proshoper", "Прошопер"),
        RussianApp("ru.burgerking", "Бургер Кинг Россия"),
        RussianApp("com.apegroup.mcdonaldsrussia", "Вкусно — и точка"),
        RussianApp("com.teremok.keys", "Теремок"),
        RussianApp("ru.handh.igooods", "igooods"),
        RussianApp("ru.bestprice.fixprice", "Fix Price"),
        RussianApp("ru.sunlight.sunlight", "SUNLIGHT"),
        RussianApp("ru.letu", "ЛЭТУАЛЬ"),
        RussianApp("com.podrygka.app", "Подружка"),
        RussianApp("com.lamoda.lite", "Lamoda"),
        RussianApp("ru.dns.shop.android", "DNS SHOP"),
        RussianApp("ru.detmir.dmbonus", "Детский мир"),
        RussianApp("com.yandex.mobile.drive", "Яндекс Драйв"),
        RussianApp("com.carshering", "Делимобиль"),
        RussianApp("youdrive.today", "Ситидрайв"),
        RussianApp("com.citymobil", "Ситимобил"),
        RussianApp("ru.tutu.tutu_emp", "Туту"),
        RussianApp("ru.tutu.avia", "Туту — авиабилеты"),
        RussianApp("ru.tutu.tutu_bus", "Туту — автобусы"),
        RussianApp("com.onetwotrip.onetwotrip", "OneTwoTrip"),
        RussianApp("com.onetwotrip.onetwotrip.avia", "OneTwoTrip — авиабилеты"),
        RussianApp("ru.ostrovok.android", "Островок"),
        RussianApp("ru.yandex.mobile.afisha", "Яндекс Афиша"),
        RussianApp("ru.s7tl.app", "S7 Airlines"),
        RussianApp("com.docdoc.docdoc", "СберЗдоровье"),
        RussianApp("ru.napopravku", "НаПоправку"),
        RussianApp("com.vk.im", "VK Мессенджер"),
        RussianApp("ru.mail.search.electroscope", "Маруся"),
        RussianApp("ru.rt.video.app.mobile", "Wink"),
        RussianApp("ru.rt.video.app.tv", "Wink для ТВ"),
        RussianApp("gpm.tnt_premier", "PREMIER"),
        RussianApp("ru.mts.mtstv", "КИОН"),
        RussianApp("ru.start.androidmobile", "START"),
        RussianApp("ru.ivi.client", "Иви"),
        RussianApp("com.zvooq.openplay", "Звук")
    )
}
