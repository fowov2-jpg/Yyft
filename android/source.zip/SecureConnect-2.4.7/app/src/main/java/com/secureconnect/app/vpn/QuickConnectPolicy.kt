package com.secureconnect.app.vpn

import com.secureconnect.app.data.model.Server
import com.secureconnect.app.data.model.ServerTransport

/**
 * Basic connectivity and strict reserve qualification are different decisions.
 * Never run a 100-config, double-throughput admission scan on the Connect button.
 */
object QuickConnectPolicy {
    const val MAX_INITIAL_ATTEMPTS = 4

    fun order(
        selected: Server,
        mode: ConnectionMode,
        explicitSelection: Boolean,
        verified: List<Server>,
        historical: List<Server>,
        recentlyConnectedIds: List<String>,
        catalogue: List<Server>,
        isCoolingDown: (Server) -> Boolean = { false },
        preferredSources: List<String> = emptyList(),
        // Public results are only a scheduling hint. Never mark such nodes Connected
        // or part of the locally verified pool without a device-side TLS check.
        publicRanks: Map<String, Int> = emptyMap()
    ): List<Server> {
        if (mode == ConnectionMode.MANUAL) return listOf(selected).filter(WorkingPoolPolicy::eligible)

        val cold = catalogue.filter(WorkingPoolPolicy::eligible).sortedWith(
            compareBy<Server> { SourceHistoryPolicy.rank(it.source, preferredSources) }
                .thenBy { ServerTransport.coldStartRank(it) }
                .thenBy { if (it.ping in 1..100) 0 else 1 }
                .thenBy { it.ping.takeIf { ms -> ms > 0 } ?: Int.MAX_VALUE }
        )
        // Avoid testing four configs from the same failing source in a row.
        val queues = LinkedHashMap<String, java.util.ArrayDeque<Server>>() 
        for (candidate in cold) {
            queues.getOrPut(candidate.source.ifBlank { "unknown" }) { java.util.ArrayDeque<Server>() }.add(candidate)
        }
        val diversified = mutableListOf<Server>()
        while (queues.isNotEmpty()) {
            val empty = mutableListOf<String>()
            for ((source, queue) in queues) {
                if (queue.isNotEmpty()) diversified.add(queue.removeFirst())
                if (queue.isEmpty()) empty.add(source)
            }
            empty.forEach(queues::remove)
        }
        // Only cold candidates are reordered using public evidence. Keep an
        // actual local verification/history ahead of remote suggestions.
        val cloudRanked = diversified.filter { it.id in publicRanks }
            .sortedWith(compareBy<Server> { publicRanks[it.id] ?: Int.MAX_VALUE })
        val coldByEvidence = SourceHistoryPolicy.interleave(cloudRanked) { it.source } +
            diversified.filterNot { it.id in publicRanks }
        // Never let a stale catalogue copy overwrite an observed, working config
        // for a recently used ID. The older associateBy(last-wins) did exactly
        // that and could retry an outdated rawLink during quick reconnect.
        val byId = LinkedHashMap<String, Server>()
        (verified + historical + listOf(selected) + coldByEvidence).forEach { candidate ->
            byId.putIfAbsent(candidate.id, candidate)
        }
        val recent = recentlyConnectedIds.mapNotNull(byId::get)
        val ordered = buildList {
            if (explicitSelection) add(selected)
            // Prefer a currently quality-certified candidate over even a
            // recently connected but unverified endpoint. Those may be reachable
            // while YouTube/video speed is broken.
            if (!explicitSelection && verified.any { it.id == selected.id }) add(selected)
            addAll(verified)
            addAll(recent)
            addAll(historical)
            // A legacy/default selected card is not evidence of success. Try
            // candidates from previously proven sources before that unverified
            // selection; explicit user choices remain first.
            addAll(coldByEvidence)
            if (!explicitSelection) add(selected)
        }
        val eligible = ordered.asSequence().filter(WorkingPoolPolicy::eligible)
            .distinctBy { it.id }.toList()
        return eligible.filterNot(isCoolingDown) + eligible.filter(isCoolingDown)
    }
}
