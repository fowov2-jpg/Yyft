package com.secureconnect.app.vpn

/** Paces check admission, not the native library's internal requests. No reset on UI refresh. */
internal class ProbeStartBudget(
    private val globalSpacingMs: Long = 1_000L,
    private val hostSpacingMs: Long = 10_000L
) {
    companion object {
        private val restrictedStatus = Regex("(?i)(?:invalid status:|HTTP)\\s*(403|429|503)\\b")
        fun isRestricted(error: String?): Boolean = restrictedStatus.containsMatchIn(error.orEmpty())
    }
    private var nextGlobal = 0L
    private val nextHost = mutableMapOf<String, Long>()

    @Synchronized fun waitMs(host: String, now: Long): Long =
        (maxOf(nextGlobal, nextHost[host] ?: 0L) - now).coerceAtLeast(0L)

    @Synchronized fun reserve(host: String, now: Long): Long {
        nextHost.entries.removeAll { it.value <= now }
        val wait = waitMs(host, now)
        if (wait > 0L) return wait
        val at = now
        nextGlobal = at + globalSpacingMs
        nextHost[host] = at + hostSpacingMs
        return at - now
    }

    @Synchronized fun defer(host: String, now: Long, pauseMs: Long) {
        nextHost[host] = maxOf(nextHost[host] ?: 0L, now + pauseMs)
    }
}
