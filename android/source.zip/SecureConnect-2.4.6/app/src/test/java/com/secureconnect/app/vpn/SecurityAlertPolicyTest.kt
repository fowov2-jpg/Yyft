package com.secureconnect.app.vpn

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SecurityAlertPolicyTest {
    private fun assess(
        state: VpnState = VpnState.Connected,
        tun: Boolean = true,
        killSwitch: Boolean = true,
        tls: String = "TLS ChatGPT: сертификат доверенный",
        mode: AppVpnMode = AppVpnMode.EXCLUDE_SELECTED,
        server: Boolean = true
    ) = SecurityAlertPolicy.classify(state, tun, killSwitch, tls, mode, server)

    @Test fun normal_splitTunnelingDoesNotTriggerIncident() {
        assertEquals(SecuritySeverity.NONE, assess().severity)
    }

    @Test fun explicitTlsFailureTriggersCriticalWarning() {
        assertEquals("tls_certificate", assess(tls = "ОПАСНО: неверный сертификат").id)
        assertEquals(SecuritySeverity.CRITICAL, assess(tls = "ОПАСНО: неверный сертификат").severity)
    }

    @Test fun missingTunNeverClaimsProtected() {
        assertEquals(SecuritySeverity.CRITICAL, assess(tun = false).severity)
    }

    @Test fun blockedTunnelReportsProtectionWithDirectExceptions() {
        val alert = assess(state = VpnState.Blocked)
        assertEquals("vpn_blocked", alert.id)
        assertTrue(alert.explanation.contains("российские"))
    }

    @Test fun weakPolicyRaisesCaution() {
        assertEquals("kill_switch_off", assess(killSwitch = false).id)
        assertEquals("only_selected", assess(mode = AppVpnMode.ONLY_SELECTED).id)
    }

    @Test fun appTemporarilyConnectingShouldNotWarn() {
        assertEquals(SecuritySeverity.NONE, assess(state = VpnState.Connecting).severity)
    }

    @Test fun dedupesRepeatedAlertAndResetsOnRecovery() {
        val gate = SecurityAlertGate(repeatAfterMs = 1000)
        val blocked = assess(state = VpnState.Blocked)
        assertTrue(gate.accept(blocked, 100))
        assertFalse(gate.accept(blocked, 110))
        assertTrue(gate.accept(blocked, 1101))
        assertFalse(gate.accept(assess(), 1200))
        assertTrue(gate.accept(blocked, 1300))
    }
}
