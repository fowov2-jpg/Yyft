package com.secureconnect.app.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.secureconnect.app.ui.theme.ScPrimary
import com.secureconnect.app.ui.theme.ScSuccess
import com.secureconnect.app.ui.theme.ScTextSecondary
import com.secureconnect.app.ui.theme.ScWarning

/**
 * Cold Titanium action: the visual does no polling and starts no background work.
 * Search motion is represented by a shape change; no forever-running animation.
 */
@Composable
fun ConnectButton(
    isConnected: Boolean,
    isConnecting: Boolean,
    isBlocked: Boolean,
    label: String,
    enabled: Boolean,
    actionDescription: String,
    onClick: () -> Unit,
    compact: Boolean = false,
    animateActivity: Boolean = true,
    modifier: Modifier = Modifier
) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val corner by animateDpAsState(
        targetValue = if (isConnecting && animateActivity) 32.dp else 25.dp,
        animationSpec = tween(270), label = "connect-shape"
    )
    val accent by animateColorAsState(
        targetValue = when {
            isBlocked || isConnecting -> ScWarning
            isConnected -> ScSuccess
            !enabled -> ScTextSecondary
            else -> ScPrimary
        },
        animationSpec = tween(230), label = "connect-tone"
    )
    val top by animateColorAsState(
        targetValue = when {
            isBlocked || isConnecting -> Color(0xFF5A4835)
            isConnected -> Color(0xFF39765F)
            else -> Color(0xFF435565)
        }, animationSpec = tween(230), label = "connect-gradient"
    )
    Box(
        modifier = modifier
            .size(if (compact) 90.dp else 98.dp)
            .graphicsLayer {
                val scale = if (pressed) 0.94f else 1f
                scaleX = scale
                scaleY = scale
            }
            .clip(RoundedCornerShape(corner))
            .background(Brush.linearGradient(listOf(top, Color(0xFF172431))))
            .semantics { contentDescription = actionDescription }
            .clickable(
                enabled = enabled,
                interactionSource = source,
                indication = null,
                role = Role.Button,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        // Fine satin highlight, one static stroke; no infinite draw loops.
        Canvas(modifier = Modifier.matchParentSize()) {
            drawRoundRect(
                color = accent.copy(alpha = 0.42f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(corner.toPx()),
                style = Stroke(width = 1.dp.toPx())
            )
        }
        Canvas(Modifier.size(35.dp)) {
            val stroke = 3.dp.toPx()
            drawArc(
                color = accent,
                startAngle = -48f,
                sweepAngle = 276f,
                useCenter = false,
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )
            drawLine(
                color = accent,
                start = androidx.compose.ui.geometry.Offset(size.width / 2f, size.height * 0.03f),
                end = androidx.compose.ui.geometry.Offset(size.width / 2f, size.height * 0.47f),
                strokeWidth = stroke,
                cap = StrokeCap.Round
            )
        }
    }
}
