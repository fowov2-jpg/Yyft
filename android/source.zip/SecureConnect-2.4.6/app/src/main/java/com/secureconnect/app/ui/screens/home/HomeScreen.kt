package com.secureconnect.app.ui.screens.home

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.secureconnect.app.ui.components.ConnectButton
import com.secureconnect.app.ui.theme.ScBorder
import com.secureconnect.app.ui.theme.ScCard
import com.secureconnect.app.ui.theme.ScError
import com.secureconnect.app.ui.theme.ScSuccess
import com.secureconnect.app.ui.theme.ScTextSecondary
import com.secureconnect.app.ui.theme.ScWarning
import com.secureconnect.app.viewmodel.MainViewModel
import com.secureconnect.app.vpn.ConnectionMode
import com.secureconnect.app.vpn.LeakRiskCalculator
import com.secureconnect.app.vpn.VpnController
import com.secureconnect.app.vpn.VpnState
import com.secureconnect.app.vpn.VpnTrafficDisplay

import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.material3.Icon
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.unit.sp
/**
 * Everyday screen: power, current primary country, live usage rates and risk index.
 * Diagnostics/routing remain in the bottom tabs; tapping risk opens
 * the security tab. Country is the primary server, not a promise that each
 * Xray-balanced connection exits in that country.
 */
@Composable
fun HomeScreen(
    vm: MainViewModel,
    onDiagnostics: () -> Unit,
    onServers: () -> Unit,
    onSettings: () -> Unit
) {
    val connecting by vm.isConnecting.collectAsStateWithLifecycle()
    val pending by vm.autoSelectionPending.collectAsStateWithLifecycle()
    val error by vm.vpnError.collectAsStateWithLifecycle()
    val downMbps by vm.downloadMbps.collectAsStateWithLifecycle()
    val upMbps by vm.uploadMbps.collectAsStateWithLifecycle()
    val activeServer by VpnController.activeServer.collectAsStateWithLifecycle()
    val tlsStatus by VpnController.openAiTlsStatus.collectAsStateWithLifecycle()
    val videoQuality by VpnController.videoQualityStatus.collectAsStateWithLifecycle()
    val autoVideoTestBusy by VpnController.videoAutoCheckBusy.collectAsStateWithLifecycle()
    val speedTestResult by VpnController.speedTestResult.collectAsStateWithLifecycle()
    val killSwitch by vm.killSwitch.collectAsStateWithLifecycle()
    val routing by vm.appRouting.collectAsStateWithLifecycle()
    val vpnState by VpnController.state.collectAsStateWithLifecycle()
    val connectionUi = ConnectionUiPolicy.resolve(vpnState, pending, connecting)
    val connected = connectionUi.connected
    // A blocked tunnel is an intentional fail-closed state; don't switch it
    // off with one accidental press. Reset confirmation on each state change.
    var confirmStopBlocked by remember(connectionUi.blocked) { mutableStateOf(false) }

    val risk = LeakRiskCalculator.assess(
        state = vpnState,
        killSwitchEnabled = killSwitch,
        tlsStatus = tlsStatus,
        routingMode = routing.mode,
        hasActiveServer = activeServer != null
    )
    val country = if (connected) ConnectedCountryFormatter.fromServer(activeServer) else null
    val riskTone = RiskTonePolicy.forIndex(risk.index)
    val riskColor: Color = when (riskTone) {
        RiskTone.GREEN -> ScSuccess
        RiskTone.YELLOW -> ScWarning
        RiskTone.RED -> ScError
        RiskTone.UNKNOWN -> ScTextSecondary
    }

    val permission = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) vm.selectAutoServer()
    }
    val toggleConnection: () -> Unit = {
        when (connectionUi.action) {
            ConnectionAction.DISCONNECT -> {
                if (connectionUi.blocked) confirmStopBlocked = true else vm.disconnect()
            }
            ConnectionAction.CANCEL_CONNECTION -> vm.disconnect()
            ConnectionAction.CANCEL_SEARCH -> vm.cancelAutoSelection()
            ConnectionAction.NONE -> Unit // prevent a second START while Android closes the TUN
            ConnectionAction.CONNECT -> {
                vm.setConnectionMode(ConnectionMode.AUTO)
                val intent = vm.vpnPermissionIntent()
                if (intent == null) vm.selectAutoServer() else permission.launch(intent)
            }
        }
    }

    if (confirmStopBlocked && connectionUi.blocked) {
        AlertDialog(
            onDismissRequest = { confirmStopBlocked = false },
            title = { Text("Отключить защиту?") },
            text = {
                Text(
                    "VPN сейчас удерживает блокирующий режим. После полного отключения " +
                        "защищаемые приложения могут выйти в интернет напрямую."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmStopBlocked = false
                    vm.disconnect()
                }) { Text("Отключить VPN") }
            },
            dismissButton = {
                TextButton(onClick = { confirmStopBlocked = false }) { Text("Оставить защиту") }
            }
        )
    }


    val lifecycleOwner = LocalLifecycleOwner.current
    val lifecycleState by lifecycleOwner.lifecycle.currentStateFlow.collectAsState()
    val screenResumed = lifecycleState.isAtLeast(Lifecycle.State.RESUMED)
    val riskProgress by animateFloatAsState(
        targetValue = (risk.index ?: 0).coerceIn(0, 100) / 100f,
        animationSpec = tween(310), label = "risk-progress"
    )
    val riskAccent by animateColorAsState(
        targetValue = riskColor,
        animationSpec = tween(220), label = "risk-accent"
    )
    val countryLabel = when {
        country != null -> "${country.flag} ${ConnectedCountryFormatter.compactName(country)}"
        connectionUi.busy -> "Подбираем сервер"
        else -> "Нет подключения"
    }
    val videoPresentation = VideoQualityUiPolicy.resolve(videoQuality)
    val videoSummary = if (autoVideoTestBusy) "Подбираем качество видео…" else videoPresentation.title
    val videoAccent = when (videoPresentation.tone) {
        VideoQualityUiPolicy.Tone.GOOD -> ScSuccess
        VideoQualityUiPolicy.Tone.BAD -> ScError
        VideoQualityUiPolicy.Tone.NOTICE -> ScWarning
        VideoQualityUiPolicy.Tone.NEUTRAL -> ScTextSecondary
    }
    val screenTitle = when {
        connectionUi.blocked -> "Защита активна"
        connectionUi.busy -> connectionUi.title
        connected -> "VPN активен"
        else -> "VPN выключен"
    }
    Box(
        modifier = Modifier.fillMaxSize().background(
            Brush.verticalGradient(
                listOf(Color(0xFF293D4A), Color(0xFF151F2A), Color(0xFF0C1017)),
                endY = 920f
            )
        ),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().widthIn(max = 440.dp)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 18.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    Modifier.size(32.dp)
                        .background(
                            Brush.linearGradient(listOf(Color(0xFFD9E4ED), Color(0xFF879CAF))),
                            RoundedCornerShape(11.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text("S", style = MaterialTheme.typography.titleMedium, color = Color(0xFF14202B))
                }
                Spacer(Modifier.width(9.dp))
                Text(
                    "SecureConnect",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.weight(1f)
                )
                FilledTonalIconButton(
                    onClick = onSettings,
                    modifier = Modifier.size(48.dp),
                    colors = IconButtonDefaults.filledTonalIconButtonColors(
                        containerColor = ScCard
                    )
                ) {
                    Icon(
                        Icons.Filled.Settings, contentDescription = "Настройки",
                        tint = Color(0xFFC6D3E0), modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(Modifier.height(25.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "СОСТОЯНИЕ СЕТИ",
                        style = MaterialTheme.typography.labelSmall,
                        color = ScTextSecondary,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                    Spacer(Modifier.height(7.dp))
                    Text(
                        screenTitle,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground,
                        maxLines = 2
                    )
                    Spacer(Modifier.height(9.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(7.dp).background(
                                when {
                                    connectionUi.blocked || connectionUi.busy -> ScWarning
                                    connected -> ScSuccess
                                    else -> ScTextSecondary
                                }, RoundedCornerShape(7.dp)
                            )
                        )
                        Spacer(Modifier.width(7.dp))
                        Text(
                            connectionUi.hint ?: when {
                                connectionUi.busy -> "Подключение к серверу"
                                connected && autoVideoTestBusy -> "VPN работает · подбираем качество видео"
                                connected -> "Автоматический режим"
                                else -> "Нажмите для подключения"
                            },
                            color = ScTextSecondary,
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                Spacer(Modifier.width(12.dp))
                ConnectButton(
                    isConnected = connectionUi.connected,
                    isConnecting = connectionUi.busy,
                    isBlocked = connectionUi.blocked,
                    label = connectionUi.title,
                    enabled = connectionUi.enabled,
                    actionDescription = connectionUi.actionDescription,
                    onClick = toggleConnection,
                    compact = true,
                    animateActivity = screenResumed
                )
            }
            Spacer(Modifier.height(23.dp))

            val panelShape = RoundedCornerShape(22.dp)
            Column(
                Modifier.fillMaxWidth()
                    .background(
                        Brush.linearGradient(listOf(Color(0xFF242F3E), Color(0xFF181F2C))),
                        panelShape
                    )
                    .border(1.dp, Color(0xFF374453), panelShape)
            ) {
                Column(
                    Modifier.fillMaxWidth()
                        .clickable(role = Role.Button, onClick = onServers)
                        .padding(horizontal = 19.dp, vertical = 18.dp)
                ) {
                    Text(
                        if (connected) "ОСНОВНОЙ МАРШРУТ" else "СЕРВЕР",
                        style = MaterialTheme.typography.labelSmall,
                        color = ScTextSecondary,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.1.sp
                    )
                    Spacer(Modifier.height(9.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Crossfade(
                            targetState = countryLabel,
                            modifier = Modifier.weight(1f),
                            animationSpec = tween(240),
                            label = "country"
                        ) { display ->
                            Text(
                                display, style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        Spacer(Modifier.width(10.dp))
                        Text("›", color = ScTextSecondary, style = MaterialTheme.typography.titleLarge)
                    }
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF344353)))
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 19.dp, vertical = 17.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("↓ Загрузка", style = MaterialTheme.typography.labelSmall, color = ScTextSecondary)
                        Spacer(Modifier.height(5.dp))
                        Text(
                            if (connected) "${VpnTrafficDisplay.formatRate(downMbps)} Мбит/с" else "—",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                    Column(Modifier.weight(1f)) {
                        Text("↑ Отдача", style = MaterialTheme.typography.labelSmall, color = ScTextSecondary)
                        Spacer(Modifier.height(5.dp))
                        Text(
                            if (connected) "${VpnTrafficDisplay.formatRate(upMbps)} Мбит/с" else "—",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                // Live counters are not a benchmark; when idle zero Mbps is normal.
                if (connected) {
                    Text(
                        "Текущий трафик · не скорость сервера",
                        color = ScTextSecondary,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(start = 19.dp, end = 19.dp, bottom = 14.dp)
                    )
                }
            }

            if (connected) {
                Spacer(Modifier.height(14.dp))
                val videoShape = RoundedCornerShape(20.dp)
                val lastVideoDownload = VideoSpeedLabelPolicy.downloadMbps(speedTestResult)
                val videoHint = when {
                    autoVideoTestBusy ->
                        "Проверяем YouTube и скорость. VPN уже работает."
                    videoPresentation.tone == VideoQualityUiPolicy.Tone.GOOD ->
                        "Сетевой тест пройден. Просмотр 720p зависит от реальной сети."
                    videoPresentation.tone == VideoQualityUiPolicy.Tone.BAD ->
                        "VPN работает. Ищем лучший проверенный сервер автоматически."
                    else -> videoPresentation.detail
                }
                Column(
                    Modifier.fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF22303E), Color(0xFF18232F))
                            ),
                            videoShape
                        )
                        .border(1.dp, Color(0xFF344A5A), videoShape)
                        .semantics {
                            contentDescription = "YouTube: ${videoSummary}. ${videoHint}"
                        }
                        .padding(horizontal = 18.dp, vertical = 16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "YOUTUBE · АВТОРЕЖИМ",
                            style = MaterialTheme.typography.labelSmall,
                            color = ScTextSecondary,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp,
                            modifier = Modifier.weight(1f)
                        )
                        if (autoVideoTestBusy) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(15.dp),
                                color = ScWarning,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Box(
                                Modifier.size(9.dp)
                                    .background(videoAccent, RoundedCornerShape(9.dp))
                            )
                        }
                    }
                    Spacer(Modifier.height(9.dp))
                    Text(
                        videoSummary,
                        style = MaterialTheme.typography.titleMedium,
                        color = if (autoVideoTestBusy) ScWarning else videoAccent,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(5.dp))
                    Text(
                        videoHint,
                        style = MaterialTheme.typography.bodySmall,
                        color = ScTextSecondary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (!autoVideoTestBusy && lastVideoDownload != null) {
                        Spacer(Modifier.height(11.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "Последний тест загрузки",
                                style = MaterialTheme.typography.labelSmall,
                                color = ScTextSecondary,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(
                                "↓ $lastVideoDownload Мбит/с",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFFD1E4EE),
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(13.dp))
            Column(
                Modifier.fillMaxWidth()
                    .clickable(role = Role.Button, onClick = onDiagnostics)
                    .semantics {
                        contentDescription = risk.index?.let {
                            "Индекс риска $it из 100. Открыть безопасность."
                        } ?: "Индекс риска неизвестен. Открыть безопасность."
                    }
                    .padding(horizontal = 1.dp, vertical = 13.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Индекс риска · условный", style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        risk.index?.let { "$it" } ?: "—",
                        color = riskAccent, style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(" / 100  ›", color = riskAccent, style = MaterialTheme.typography.bodySmall)
                }
                Spacer(Modifier.height(10.dp))
                Box(
                    Modifier.fillMaxWidth().height(4.dp)
                        .background(Color(0xFF344150), RoundedCornerShape(8.dp))
                ) {
                    if (risk.index != null) {
                        Box(
                            Modifier.fillMaxWidth(riskProgress).height(4.dp)
                                .background(riskAccent, RoundedCornerShape(8.dp))
                        )
                    }
                }
                Spacer(Modifier.height(9.dp))
                Text(
                    if (risk.index == null) "Защита не подтверждена"
                    else "Неполная проверка · DNS, IPv6 и TUN не проверены",
                    color = if (connected) ScWarning else ScTextSecondary,
                    style = MaterialTheme.typography.labelSmall
                )
            }
            if (connected && risk.urgent) {
                Spacer(Modifier.height(10.dp))
                Text(
                    "⚠ Требуется проверка безопасности",
                    modifier = Modifier.fillMaxWidth().clickable(onClick = onDiagnostics),
                    color = ScError, style = MaterialTheme.typography.bodySmall
                )
            }
            if (!error.isNullOrBlank()) {
                Spacer(Modifier.height(9.dp))
                Text(
                    error.orEmpty(), color = ScError,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 3, overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
