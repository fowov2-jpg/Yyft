package com.secureconnect.app.vpn

import org.junit.Assert.*
import org.junit.Test

class ProbeStartBudgetTest {
    @Test fun rateLimitIsNotConfusedWithLatencyNumbers() {
        assertTrue(ProbeStartBudget.isRestricted("invalid status: 429 Too Many Requests"))
        assertTrue(ProbeStartBudget.isRestricted("HTTP 403"))
        assertFalse(ProbeStartBudget.isRestricted("timeout after 429 ms"))
        assertFalse(ProbeStartBudget.isRestricted("invalid status: 404 Not Found"))
    }
    @Test fun independentHostsProgressWithoutWaitingForTenSecondHostWindow() {
        val b = ProbeStartBudget()
        assertEquals(0L, b.reserve("a", 100L))
        assertEquals(1_000L, b.waitMs("b", 100L))
        assertEquals(10_000L, b.waitMs("a", 100L))
        assertEquals(0L, b.reserve("b", 1_100L))
        assertEquals(9_000L, b.waitMs("a", 1_100L))
    }
    @Test fun explicitRestrictionOutlivesOrdinarySpacing() {
        val b = ProbeStartBudget()
        b.reserve("a", 100L)
        b.defer("a", 200L, 3_600_000L)
        assertEquals(3_599_900L, b.waitMs("a", 300L))
        assertEquals(0L, b.waitMs("a", 3_600_200L))
    }
}
