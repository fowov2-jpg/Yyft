package com.secureconnect.app.ui.screens.home

import com.secureconnect.app.vpn.VpnState

/**
 * Single source of truth for the main connection control.
 *
 * The foreground VPN service owns [VpnState]. ViewModel search flags only refine
 * Idle/connecting presentation; they never override Stopping/Blocked/Connected.
 * Every state maps to exactly one user action, preventing start/stop races.
 */
enum class ConnectionAction {
    CONNECT, DISCONNECT, CANCEL_SEARCH, CANCEL_CONNECTION, NONE
}

data class ConnectionUiModel(
    val title: String,
    val hint: String?,
    val action: ConnectionAction,
    val connected: Boolean = false,
    val busy: Boolean = false,
    val blocked: Boolean = false
) {
    val enabled: Boolean get() = action != ConnectionAction.NONE
    val actionDescription: String get() = when (action) {
        ConnectionAction.CONNECT -> "Подключить VPN"
        ConnectionAction.DISCONNECT -> "Отключить VPN"
        ConnectionAction.CANCEL_SEARCH -> "Отменить поиск сервера"
        ConnectionAction.CANCEL_CONNECTION -> "Остановить подключение VPN"
        ConnectionAction.NONE -> "VPN завершает отключение"
    }
}

object ConnectionUiPolicy {
    fun resolve(state: VpnState, pending: Boolean, connecting: Boolean): ConnectionUiModel =
        when {
            state == VpnState.Stopping ->
                ConnectionUiModel("Отключение…", "Ожидаем завершения VPN", ConnectionAction.NONE, busy = false)
            state == VpnState.Blocked ->
                ConnectionUiModel(
                    "Защита активна",
                    "VPN прерван: трафик защищаемых приложений заблокирован.",
                    ConnectionAction.DISCONNECT,
                    blocked = true
                )
            state == VpnState.Connected ->
                ConnectionUiModel("Подключено", null, ConnectionAction.DISCONNECT, connected = true)
            state == VpnState.Validating ->
                ConnectionUiModel("Проверка…", "Проверяю соединение", ConnectionAction.CANCEL_CONNECTION, busy = true)
            state == VpnState.Connecting || connecting ->
                ConnectionUiModel("Подключение…", "Устанавливаю защищённый туннель", ConnectionAction.CANCEL_CONNECTION, busy = true)
            pending ->
                ConnectionUiModel("Поиск…", "Подбираю рабочий сервер", ConnectionAction.CANCEL_SEARCH, busy = true)
            state is VpnState.Error ->
                ConnectionUiModel("Повторить", "Ошибка подключения", ConnectionAction.CONNECT)
            else ->
                ConnectionUiModel("Подключить", null, ConnectionAction.CONNECT)
        }
}
