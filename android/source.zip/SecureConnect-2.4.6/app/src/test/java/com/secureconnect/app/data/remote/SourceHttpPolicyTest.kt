package com.secureconnect.app.data.remote

import org.junit.Assert.*
import org.junit.Test

class SourceHttpPolicyTest {
    @Test fun retryAfterSecondsCannotShortenConservativePause() {
        assertEquals(3_600_000L, SourceHttpPolicy.pauseMs(429, "2", 0L))
        assertEquals(7_200_000L, SourceHttpPolicy.pauseMs(429, "7200", 0L))
        assertEquals(86_400_000L, SourceHttpPolicy.pauseMs(403, null, 0L))
    }
    @Test fun retryAfterDateAndMalformedValues() {
        assertEquals(7_200_000L, SourceHttpPolicy.pauseMs(503, "Thu, 01 Jan 1970 02:00:00 GMT", 0L))
        assertEquals(900_000L, SourceHttpPolicy.pauseMs(503, "not a date", 0L))
        assertEquals(900_000L, SourceHttpPolicy.pauseMs(503, "-2", 0L))
    }
}
