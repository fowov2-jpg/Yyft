package com.secureconnect.app

import com.secureconnect.app.data.model.Server
import com.secureconnect.app.data.model.ServerTransport
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ServerTransportTest {
    private fun server(raw: String, ping: Int = 0) = Server(
        id = raw.hashCode().toString(),
        country = "",
        city = "",
        flagEmoji = "",
        protocol = "VLESS",
        ping = ping,
        host = "example.com",
        port = 443,
        source = "test",
        rawLink = raw
    )

    @Test
    fun realityFamilyIsRecognizedWithoutLeakingCredentials() {
        val s = server("vless://secret-uuid@example.com:443?security=reality&type=tcp&pbk=secret#name")
        val family = ServerTransport.family(s)

        assertEquals("VLESS:reality:tcp", family)
        assertTrue(!family.contains("secret-uuid"))
        assertTrue(!family.contains("pbk"))
    }

    @Test
    fun realityColdStartRankBeatsOrdinaryTlsTcp() {
        val reality = server("vless://id@example.com:443?security=reality&type=tcp")
        val tls = server("vless://id@example.com:443?security=tls&type=tcp")

        assertTrue(ServerTransport.coldStartRank(reality) < ServerTransport.coldStartRank(tls))
    }

    @Test
    fun tcpPingIsBucketedInsteadOfTreatedAsAbsoluteQuality() {
        assertEquals(0, ServerTransport.pingBucket(server("vless://id@x:443?security=reality", 50)))
        assertEquals(0, ServerTransport.pingBucket(server("vless://id@x:443?security=reality", 100)))
        assertEquals(1, ServerTransport.pingBucket(server("vless://id@x:443?security=reality", 101)))
        assertEquals(3, ServerTransport.pingBucket(server("vless://id@x:443?security=reality", 895)))
        assertEquals(4, ServerTransport.pingBucket(server("vless://id@x:443?security=reality", 0)))
    }
}
