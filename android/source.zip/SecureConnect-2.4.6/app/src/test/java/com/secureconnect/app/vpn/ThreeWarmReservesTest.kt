package com.secureconnect.app.vpn

import com.secureconnect.app.data.model.Server
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Network-independent regression tests for the 1+3+20 standby policy. */
class ThreeWarmReservesTest {
    private fun node(id: String, source: String, host: String, ping: Int = 45,
                     country: String = "Германия", family: String = "tcp") = Server(
        id, country, "", "", "VLESS", ping, source = source, host = host, port = 443,
        rawLink = "vless://test@$host:443?security=reality&type=$family"
    )

    @Test fun choosesThreeDiverseQualifiedAlternates() {
        val primary = node("primary", "provider1", "10.10.10.1", 20)
        val candidates = listOf(primary,
            node("sameNetwork", "provider1", "10.10.10.2", 21),
            node("a", "provider2", "10.10.11.2", 64),
            node("b", "provider3", "10.10.12.2", 75, family="ws"),
            node("c", "provider4", "10.10.13.2", 81),
            node("slow", "provider5", "10.10.14.2", 101),
            node("ru", "provider6", "10.10.15.2", 12, country="Россия")
        )
        val picked = EmbeddedWarmRoutes.select(primary, candidates)
        assertEquals(3, picked.size)
        assertEquals(3, picked.map { it.source }.toSet().size)
        assertFalse(picked.any { it.id == primary.id || it.ping > 100 || it.country == "Россия" })
    }

    @Test fun neverFakesThreeWhenOnlyOneIsQualified() {
        val primary = node("primary", "p1", "10.10.10.1")
        // 100 ms is a ranking goal, not an eligibility cutoff on mobile networks.
        assertEquals(2, EmbeddedWarmRoutes.select(primary, listOf(
            node("good", "p2", "10.10.20.2"),
            node("slowButViable", "p3", "10.10.30.3", 150))).size)
        assertEquals(1, EmbeddedWarmRoutes.select(primary, listOf(
            node("good", "p2", "10.10.20.2"),
            node("notMeasured", "p3", "10.10.30.3", 0))).size)
        assertTrue(EmbeddedWarmRoutes.select(primary, listOf(primary)).isEmpty())
    }

    @Test fun reserveAndProbeBudgetStaysBounded() {
        assertEquals(3, EmbeddedWarmRoutes.MAX_HOT)
        assertEquals(3, HotReservePolicy.TARGET)
        assertEquals(20, WorkingPoolPolicy.MIN_BACKUPS)
        assertEquals(45L * 60_000L, WorkingPoolPolicy.BACKUP_AUDIT_INTERVAL_MS)
        assertTrue(HotReservePolicy.EMBEDDED_CHECK_INTERVAL_MS >= HotReservePolicy.CHECK_INTERVAL_MS)
    }
}
