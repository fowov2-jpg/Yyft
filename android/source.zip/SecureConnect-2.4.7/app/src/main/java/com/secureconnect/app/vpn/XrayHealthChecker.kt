package com.secureconnect.app.vpn

import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import com.secureconnect.app.util.ResourceGovernor
import java.io.BufferedReader
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.InputStreamReader
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLException
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

/**
 * Verifies the real data path through the active Xray outbound.
 *
 * Failover deliberately does not use AndroidLibXrayLite.measureDelay(): that API has
 * a long native timeout and cannot be cancelled safely while StopLoop() is closing
 * the same controller. Instead this checker performs an end-to-end bounded probe:
 *
 * local SOCKS5 -> remote DNS (SOCKS domain request) -> TLS with hostname verification
 * -> HTTP response.
 *
 * A TCP-only SOCKS CONNECT is diagnostic evidence, not a pass condition.
 * SecureConnect's UID is excluded from the VPN to prevent native socket loops.
 * These probes verify the proxy outbound; they cannot certify other apps' TUN path.
 */
object XrayHealthChecker {
    data class Result(
        val tcpMs: Int?,
        val dnsMs: Int?,
        val httpsMs: Int?,
        val udpOk: Boolean?,
        val ipv4Ok: Boolean,
        val ipv6Ok: Boolean?,
        val realityHandshakeOk: Boolean?,
        val error: String? = null,
        val detail: String? = null,
        val failureStage: String? = null
    ) {
        val passed: Boolean
            get() = httpsMs != null
    }

    data class QuickResult(
        val passed: Boolean,
        /** SOCKS CONNECT RTT through Xray; used as the user-facing ping metric. */
        val connectMs: Int?,
        /** Full TLS+HTTP wall-clock latency; used for tunnel quality/liveness. */
        val latencyMs: Int?,
        val stage: String,
        val endpoint: String,
        val error: String?
    )

    private data class Endpoint(val host: String, val port: Int, val path: String)

    private data class HttpsProbe(
        val endpoint: Endpoint,
        val socksMs: Int?,
        val totalMs: Int?,
        val httpCode: Int?,
        val stage: String,
        val error: String? = null
    ) {
        val passed: Boolean get() = totalMs != null && httpCode != null
    }

    private const val SOCKS_PORT = XrayConfigBuilder.HEALTH_SOCKS_PORT
    private const val LOCAL_CONNECT_TIMEOUT_MS = 500
    private const val IO_TIMEOUT_MS = 2_200
    private const val DIAGNOSTIC_TIMEOUT_MS = 1_200
    private const val READY_ATTEMPTS = 6
    private const val READY_DELAY_MS = 100L

    private val HTTPS_TARGETS = listOf(
        Endpoint("www.gstatic.com", 443, "/generate_204"),
        Endpoint("cp.cloudflare.com", 443, "/generate_204")
    )

    // A cancelled/stale connection attempt may still be finishing a blocking
    // java.net call. Serializing full validation prevents two checks from consuming
    // both bounded workers and starving each other's alternate endpoint.
    private val fullCheckMutex = Mutex()

    suspend fun check(
        serverProtocol: String,
        isReality: Boolean,
        baselineHttpsMs: Double? = null,
        fastConnect: Boolean = false
    ): Result =
        fullCheckMutex.withLock {
            withContext(ResourceGovernor.dispatcher) {
                var ready = false
                for (attempt in 0 until READY_ATTEMPTS) {
                    if (socksPortOpen()) {
                        ready = true
                        break
                    }
                    if (attempt + 1 < READY_ATTEMPTS) Thread.sleep(READY_DELAY_MS)
                }
                if (!ready) {
                    return@withContext Result(
                        tcpMs = null,
                        dnsMs = null,
                        httpsMs = null,
                        udpOk = null,
                        ipv4Ok = false,
                        ipv6Ok = null,
                        realityHandshakeOk = if (isReality) false else null,
                        error = "Локальный health-check SOCKS 127.0.0.1:$SOCKS_PORT не поднялся",
                        detail = "SOCKS-READY=FAIL(${READY_ATTEMPTS * READY_DELAY_MS}ms)",
                        failureStage = "socks_ready"
                    )
                }

                // Keep SecureConnect-owned work inside the two-worker budget. HTTPS is the
                // pass/fail signal; secondary DNS/UDP diagnostics run only after it.
                // Use the same headroom as the watchdog for a separately proven node.
                // Initial validation must not reject it under a shorter fixed timeout.
                val ioTimeoutMs = if (fastConnect) {
                    GuardianPolicy.initialConnectIoTimeoutMs(baselineHttpsMs)
                } else {
                    GuardianPolicy.watchdogIoTimeoutMs(baselineHttpsMs)
                }
                val probes = probeHttpsTargets(ioTimeoutMs)
                val winner = probes.firstOrNull { it.passed }
                // The initial Connect action only needs a real, certificate-validated
                // HTTPS response. DNS/UDP are supplemental diagnostics and can delay
                // a good route by seconds. The steady-state monitor retains them.
                val dns = if (fastConnect) null else socksConnectOnly("www.google.com", 443)
                val udpOk = if (!fastConnect && serverProtocol.equals("HYSTERIA2", true)) {
                    runCatching { udpDnsThroughSocks() }.getOrNull()
                } else {
                    null
                }

                if (winner == null) {
                    val best = probes.maxByOrNull { stageRank(it.stage) }
                    val stage = best?.stage ?: "https"
                    val summary = probes.joinToString(" | ") { probe ->
                        "${probe.endpoint.host}:${probe.stage}=${probe.error ?: "FAIL"}"
                    }
                    return@withContext Result(
                        tcpMs = probes.mapNotNull { it.socksMs }.minOrNull(),
                        dnsMs = dns?.socksMs,
                        httpsMs = null,
                        udpOk = udpOk,
                        ipv4Ok = probes.any { it.socksMs != null },
                        ipv6Ok = null,
                        realityHandshakeOk = if (isReality) false else null,
                        error = when (stage) {
                            "tls" -> "TLS через Xray не установился"
                            "http" -> "HTTPS через Xray не получил корректный HTTP-ответ"
                            "socks_connect", "socks_handshake" -> "SOCKS5 не открыл удалённое соединение через Xray"
                            else -> "HTTPS-тест через Xray не прошёл"
                        },
                        detail = "HTTPS=FAIL($summary); DNS-hostname=${if (fastConnect) "NOT_TESTED" else dns?.socksMs ?: "FAIL"}; IO-timeout=${ioTimeoutMs}ms",
                        failureStage = stage
                    )
                }

                val detail = buildString {
                    append("SOCKS-TCP=OK(${winner.socksMs ?: "—"}ms@${winner.endpoint.host})")
                    append("; TLS+HTTPS=OK(${winner.totalMs}ms@${winner.endpoint.host}, HTTP ${winner.httpCode})")
                    append("; SYSTEM-TUN=NOT_TESTED(app UID excluded)")
                    append("; DNS-hostname=").append(
                        if (fastConnect) "NOT_TESTED(fast-connect)" else dns?.socksMs ?: "FAIL"
                    )
                    if (udpOk != null) append("; UDP-DNS=").append(if (udpOk) "OK" else "FAIL")
                    append("; IO-timeout=${ioTimeoutMs}ms")
                    if (probes.any { it.stage == "cancelled" }) {
                        append("; alternate=SKIPPED(primary success)")
                    }
                    val failures = probes.filter { !it.passed && it.stage != "cancelled" }
                    if (failures.isNotEmpty()) {
                        append("; alternate=")
                        append(failures.joinToString("|") { "${it.endpoint.host}:${it.stage}" })
            }
        }

        Result(
            tcpMs = winner.socksMs,
            dnsMs = dns?.socksMs,
            httpsMs = winner.totalMs,
            udpOk = udpOk,
            ipv4Ok = true,
            ipv6Ok = null,
            realityHandshakeOk = if (isReality) true else null,
            error = null,
            detail = detail,
            failureStage = null
        )
            }
        }

    /**
     * Low-cost watchdog probe for an already connected tunnel.
     * Uses exactly one HTTPS endpoint; the service alternates providers between
     * samples so provider-specific filtering does not immediately trigger failover.
     */
    fun quickCheck(useAlternate: Boolean = false, ioTimeoutMs: Int = IO_TIMEOUT_MS): QuickResult {
        val endpoint = HTTPS_TARGETS[if (useAlternate) 1 else 0]
        if (!socksPortOpen()) {
            return QuickResult(
                passed = false,
                connectMs = null,
                latencyMs = null,
                stage = "socks_ready",
                endpoint = endpoint.host,
                error = "local SOCKS unavailable"
            )
        }

        val probe = probeHttps(endpoint, ProbeControl(), ioTimeoutMs)
        return QuickResult(
            passed = probe.passed,
            connectMs = probe.socksMs,
            latencyMs = probe.totalMs,
            stage = probe.stage,
            endpoint = endpoint.host,
            error = probe.error
        )
    }

    /**
     * Requests overlap on the two existing workers. Socket IO is bounded per
     * operation, and waiting for an unfinished alternate has a shared deadline.
     * A completed alternate remains valid even when the primary finishes late.
     */
    private class ProbeControl {
        @Volatile var socket: Socket? = null
        @Volatile var stage: String = "socks_connect"
        @Volatile var socksMs: Int? = null
    }

    private fun probeHttpsTargets(ioTimeoutMs: Int): List<HttpsProbe> {
        val primaryControl = ProbeControl()
        val alternateControl = ProbeControl()
        val waitBudgetMs = ioTimeoutMs.toLong() + 300L
        val deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(waitBudgetMs)

        // check() itself runs on one ResourceGovernor worker. The alternate occupies
        // the second worker while the primary runs on this worker, so the app never
        // needs a third health worker.
        val alternateFuture = ResourceGovernor.workerExecutor.submit<HttpsProbe> {
            probeHttps(HTTPS_TARGETS[1], alternateControl, ioTimeoutMs)
        }

        val primary = probeHttps(HTTPS_TARGETS[0], primaryControl, ioTimeoutMs)
        if (primary.passed) {
            // Preserve an already completed result. Otherwise cancellation is a
            // skipped test, not evidence that the alternate site is blocked.
            val completed = ProbeAwaiter.completedOrWithin(alternateFuture, 0L)
            if (completed != null) return listOf(primary, completed)
            runCatching { alternateControl.socket?.close() }
            alternateFuture.cancel(true)
            return listOf(
                primary,
                HttpsProbe(
                    endpoint = HTTPS_TARGETS[1],
                    socksMs = alternateControl.socksMs,
                    totalMs = null,
                    httpCode = null,
                    stage = "cancelled",
                    error = "skipped after primary success"
                )
            )
        }

        val remainingNanos = deadline - System.nanoTime()
        val alternate = ProbeAwaiter.completedOrWithin(alternateFuture, remainingNanos)

        if (alternate == null) {
            runCatching { alternateControl.socket?.close() }
            alternateFuture.cancel(true)
        }

        return listOf(
            primary,
            alternate ?: HttpsProbe(
                endpoint = HTTPS_TARGETS[1],
                socksMs = alternateControl.socksMs,
                totalMs = null,
                httpCode = null,
                stage = alternateControl.stage,
                error = "alternate wait budget ${waitBudgetMs}ms exceeded"
            )
        )
    }

    private fun probeHttps(endpoint: Endpoint, control: ProbeControl, ioTimeoutMs: Int = IO_TIMEOUT_MS): HttpsProbe {
        val started = System.nanoTime()

        return try {
            val tcp = Socket()
            control.socket = tcp
            tcp.soTimeout = ioTimeoutMs.coerceIn(1_000, 6_000)
            tcp.connect(InetSocketAddress("127.0.0.1", SOCKS_PORT), LOCAL_CONNECT_TIMEOUT_MS)

            tcp.use { socket ->
                control.stage = "socks_handshake"
                val input = DataInputStream(socket.getInputStream())
                val output = DataOutputStream(socket.getOutputStream())
                performSocksConnect(input, output, endpoint.host, endpoint.port) { stage ->
                    control.stage = stage
                }
                control.socksMs = elapsedMs(started)

                control.stage = "tls"
                val ssl = (SSLSocketFactory.getDefault() as SSLSocketFactory)
                    .createSocket(socket, endpoint.host, endpoint.port, true) as SSLSocket
                control.socket = ssl
                ssl.soTimeout = ioTimeoutMs.coerceIn(1_000, 6_000)
                ssl.useClientMode = true
                ssl.sslParameters = ssl.sslParameters.apply {
                    endpointIdentificationAlgorithm = "HTTPS"
                }

                ssl.use { tls ->
                    tls.startHandshake()

                    control.stage = "http"
                    val request = buildString {
                        append("GET ${endpoint.path} HTTP/1.1\r\n")
                        append("Host: ${endpoint.host}\r\n")
                        append("User-Agent: SecureConnect-Health\r\n")
                        append("Accept: */*\r\n")
                        append("Connection: close\r\n\r\n")
                    }
                    tls.outputStream.write(request.toByteArray(Charsets.US_ASCII))
                    tls.outputStream.flush()

                    val line = BufferedReader(InputStreamReader(tls.inputStream, Charsets.US_ASCII)).readLine()
                        ?: throw IllegalStateException("empty HTTP response")
                    val code = line.split(' ').getOrNull(1)?.toIntOrNull()
                        ?: throw IllegalStateException("bad HTTP status: ${line.take(80)}")
                    if (code != 200 && code != 204) {
                        throw IllegalStateException("HTTP $code")
                    }

                    HttpsProbe(
                        endpoint = endpoint,
                        socksMs = control.socksMs,
                        totalMs = elapsedMs(started),
                        httpCode = code,
                        stage = "ok"
                    )
                }
            }
        } catch (e: SocketTimeoutException) {
            HttpsProbe(endpoint, control.socksMs, null, null, control.stage, "timeout")
        } catch (e: SSLException) {
            HttpsProbe(endpoint, control.socksMs, null, null, "tls", compactError(e))
        } catch (e: Throwable) {
            HttpsProbe(endpoint, control.socksMs, null, null, control.stage, compactError(e))
        } finally {
            control.socket = null
        }
    }

    private fun socksConnectOnly(host: String, port: Int): HttpsProbe? {
        val endpoint = Endpoint(host, port, "")
        val started = System.nanoTime()
        return try {
            Socket().use { socket ->
                socket.soTimeout = DIAGNOSTIC_TIMEOUT_MS
                socket.connect(InetSocketAddress("127.0.0.1", SOCKS_PORT), LOCAL_CONNECT_TIMEOUT_MS)
                val input = DataInputStream(socket.getInputStream())
                val output = DataOutputStream(socket.getOutputStream())
                performSocksConnect(input, output, host, port)
                val elapsed = elapsedMs(started)
                HttpsProbe(endpoint, elapsed, elapsed, 200, "ok")
            }
        } catch (_: Throwable) {
            null
        }
    }

    /**
     * SOCKS5 CONNECT with ATYP=DOMAIN. Xray therefore resolves the destination;
     * Android's resolver is not allowed to leak/short-circuit this health check.
     */
    internal fun performSocksConnect(
        input: DataInputStream,
        output: DataOutputStream,
        host: String,
        port: Int,
        onStage: (String) -> Unit = {}
    ) {
        val hostBytes = host.toByteArray(Charsets.UTF_8)
        require(hostBytes.size in 1..255) { "invalid SOCKS hostname length" }

        output.write(byteArrayOf(0x05, 0x01, 0x00))
        output.flush()
        if (input.readUnsignedByte() != 0x05 || input.readUnsignedByte() != 0x00) {
            throw IllegalStateException("SOCKS auth negotiation failed")
        }

        onStage("socks_connect")
        output.writeByte(0x05)
        output.writeByte(0x01)
        output.writeByte(0x00)
        output.writeByte(0x03)
        output.writeByte(hostBytes.size)
        output.write(hostBytes)
        output.writeShort(port)
        output.flush()

        if (input.readUnsignedByte() != 0x05) throw IllegalStateException("bad SOCKS version")
        val reply = input.readUnsignedByte()
        if (reply != 0x00) throw IllegalStateException("SOCKS reply 0x${reply.toString(16)}")
        input.readUnsignedByte() // RSV
        val atyp = input.readUnsignedByte()
        skipSocksAddress(input, atyp)
        input.readUnsignedShort() // BND.PORT
    }

    private fun skipSocksAddress(input: DataInputStream, atyp: Int) {
        val length = when (atyp) {
            0x01 -> 4
            0x03 -> input.readUnsignedByte()
            0x04 -> 16
            else -> throw IllegalStateException("bad SOCKS ATYP $atyp")
        }
        val bytes = ByteArray(length)
        input.readFully(bytes)
    }

    private fun socksPortOpen(): Boolean = runCatching {
        Socket().use {
            it.connect(InetSocketAddress("127.0.0.1", SOCKS_PORT), LOCAL_CONNECT_TIMEOUT_MS)
        }
        true
    }.getOrDefault(false)

    /**
     * SOCKS5 UDP ASSOCIATE + real DNS query to 1.1.1.1:53.
     * Diagnostic only; never blocks a TCP/VLESS connection from being accepted.
     */
    private fun udpDnsThroughSocks(): Boolean {
        val tcp = Socket()
        tcp.soTimeout = DIAGNOSTIC_TIMEOUT_MS
        tcp.connect(InetSocketAddress("127.0.0.1", SOCKS_PORT), LOCAL_CONNECT_TIMEOUT_MS)
        return tcp.use { control ->
            val input = DataInputStream(control.getInputStream())
            val output = DataOutputStream(control.getOutputStream())

            output.write(byteArrayOf(0x05, 0x01, 0x00))
            output.flush()
            if (input.readUnsignedByte() != 0x05 || input.readUnsignedByte() != 0x00) return false

            output.write(byteArrayOf(0x05, 0x03, 0x00, 0x01, 0, 0, 0, 0, 0, 0))
            output.flush()

            if (input.readUnsignedByte() != 0x05) return false
            if (input.readUnsignedByte() != 0x00) return false
            input.readUnsignedByte()
            val atyp = input.readUnsignedByte()
            val relayHost = readSocksAddress(input, atyp) ?: return false
            val relayPort = input.readUnsignedShort()
            val relayAddress = if (relayHost.hostAddress == "0.0.0.0") {
                control.localAddress
            } else {
                relayHost
            }

            DatagramSocket().use { udp ->
                udp.soTimeout = DIAGNOSTIC_TIMEOUT_MS
                val query = dnsQuery()
                val header = byteArrayOf(
                    0x00, 0x00, 0x00, 0x01,
                    1, 1, 1, 1,
                    0x00, 0x35
                )
                val payload = header + query
                udp.send(java.net.DatagramPacket(payload, payload.size, relayAddress, relayPort))

                val buffer = ByteArray(2048)
                val response = java.net.DatagramPacket(buffer, buffer.size)
                udp.receive(response)
                response.length >= 16
            }
        }
    }

    private fun readSocksAddress(input: DataInputStream, atyp: Int): java.net.InetAddress? = when (atyp) {
        0x01 -> {
            val b = ByteArray(4)
            input.readFully(b)
            java.net.InetAddress.getByAddress(b)
        }
        0x03 -> {
            val len = input.readUnsignedByte()
            val b = ByteArray(len)
            input.readFully(b)
            java.net.InetAddress.getByName(String(b, Charsets.UTF_8))
        }
        0x04 -> {
            val b = ByteArray(16)
            input.readFully(b)
            java.net.InetAddress.getByAddress(b)
        }
        else -> null
    }

    private fun dnsQuery(): ByteArray {
        val id = 0x4A21
        val header = byteArrayOf(
            (id shr 8).toByte(), id.toByte(),
            0x01, 0x00,
            0x00, 0x01,
            0x00, 0x00,
            0x00, 0x00,
            0x00, 0x00
        )
        val name = "cloudflare.com".split('.')
        val qname = buildList<Byte> {
            for (part in name) {
                add(part.length.toByte())
                part.toByteArray(Charsets.US_ASCII).forEach(::add)
            }
            add(0)
        }.toByteArray()
        return header + qname + byteArrayOf(0x00, 0x01, 0x00, 0x01)
    }

    private fun elapsedMs(startNanos: Long): Int =
        ((System.nanoTime() - startNanos) / 1_000_000L)
            .coerceAtLeast(1L)
            .coerceAtMost(Int.MAX_VALUE.toLong())
            .toInt()

    private fun stageRank(stage: String): Int = when (stage) {
        "http" -> 4
        "tls" -> 3
        "socks_handshake" -> 2
        "socks_connect" -> 1
        else -> 0
    }

    private fun compactError(t: Throwable): String =
        "${t.javaClass.simpleName}: ${t.message ?: "no message"}".take(220)
}
