package com.secureconnect.app.vpn

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.secureconnect.app.MainActivity
import com.secureconnect.app.R
import com.secureconnect.app.data.model.Server

/**
 * Plain Android notification. Avoid OEM-specific RemoteViews, exposed host/IP,
 * duplicate Stop buttons, and constant custom-layout remeasure work.
 */
internal object VpnNotificationFactory {
    private const val CHANNEL = "vpn"
    private const val REQUEST_OPEN_APP = 181
    private const val REQUEST_STOP_VPN = 182

    fun build(
        context: Context,
        state: VpnState,
        server: Server?,
        activeHost: String?,
        status: String
    ): Notification {
        val connected = state == VpnState.Connected
        val country = server?.country?.trim()?.takeIf { it.isNotBlank() }
            ?.take(32) ?: "Сервер"
        val rate = if (connected)
            VpnTrafficDisplay.speedLine(VpnController.trafficRate.value)
        else ""
        val openApp = PendingIntent.getActivity(
            context, REQUEST_OPEN_APP,
            Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopVpn = PendingIntent.getService(
            context, REQUEST_STOP_VPN,
            Intent(context, XrayVpnService::class.java)
                .setAction(XrayVpnService.ACTION_STOP_FROM_NOTIFICATION),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val publicVersion = Notification.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("SecureConnect")
            .setContentText("Состояние VPN доступно в приложении")
            .build()
        return Notification.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle(if (connected) "VPN подключён · $country" else "SecureConnect · $status")
            .setContentText(if (connected) rate else "Состояние VPN: $status")
            .setVisibility(Notification.VISIBILITY_PRIVATE)
            .setPublicVersion(publicVersion)
            .setContentIntent(openApp)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .addAction(
                Notification.Action.Builder(
                    R.drawable.ic_stop_notification, "Отключить", stopVpn
                ).build()
            )
            .build()
    }
}
