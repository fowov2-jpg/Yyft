package com.secureconnect.app

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import com.secureconnect.app.vpn.ServerScanner
import com.secureconnect.app.vpn.VpnController
import com.secureconnect.app.vpn.VpnState
import com.secureconnect.app.vpn.XrayVpnService
import com.secureconnect.app.vpn.TlsRiskStore

/** The VPN is owned by the user's Android task; pressing Home is not closing it. */
object AppRunController {
    private const val PREFS = "sc_app_run"
    private const val KEY_OPEN = "task_open"
    private const val KEY_TASK_ID = "task_id"
    private const val KEY_SHUTDOWN_PENDING = "shutdown_pending"
    private const val KEY_LAST_TASK_DISMISSAL_MS = "last_task_dismissal_ms"
    @Volatile private var openInProcess = false

    fun opened(activity: Activity) {
        val prefs = activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val oldTaskId = prefs.getInt(KEY_TASK_ID, -1)
        val nowTaskId = activity.taskId
        // OEMs may fail to deliver onTaskRemoved(). If the old Recent Task has
        // vanished, never resurrect its session in a newly launched task.
        if (oldTaskId >= 0 && nowTaskId >= 0 && oldTaskId != nowTaskId &&
            taskExists(activity, oldTaskId) == false) {
            closed(activity)
        }
        // Reopening during the previous task's teardown must not re-arm a VPN.
        val shutdownPending = prefs.getBoolean(KEY_SHUTDOWN_PENDING, false)
        if (shutdownPending) {
            if (XrayVpnService.hasLiveService()) {
                VpnController.state.value = VpnState.Stopping
                requestTaskStop(activity)
            } else {
                // A dead service cannot still hold an Android TUN file descriptor.
                acknowledgeStopped(activity)
                VpnController.activeServer.value = null
                VpnController.state.value = VpnState.Idle
            }
        }
        openInProcess = true
        prefs.edit().putBoolean(KEY_OPEN, true).putInt(KEY_TASK_ID, nowTaskId).commit()
    }

    fun lastTaskDismissalAtMs(context: Context): Long =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getLong(KEY_LAST_TASK_DISMISSAL_MS, 0L)

    fun shutdownPending(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_SHUTDOWN_PENDING, false)

    fun mayRun(context: Context): Boolean =
        openInProcess || context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_OPEN, false)

    /** The registered Activity's task id survives a service restart. The
     *  monitor must be able to observe its removal even if launched too late
     *  to witness the task while it was still present. */
    fun hadRegisteredTask(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getInt(KEY_TASK_ID, -1) >= 0

    /** null means the OS did not provide a reliable app-task snapshot. */
    fun hasTask(context: Context): Boolean? = runCatching {
        val manager = context.getSystemService(ActivityManager::class.java) ?: return null
        manager.appTasks.isNotEmpty()
    }.getOrNull()

    private fun taskExists(context: Context, taskId: Int): Boolean? = runCatching {
        val manager = context.getSystemService(ActivityManager::class.java) ?: return null
        @Suppress("DEPRECATION")
        manager.appTasks.any { it.taskInfo.id == taskId }
    }.getOrNull()

    /** Idempotent intentional shutdown: clear persistence before stopping both services. */
    fun closed(context: Context) {
        TlsRiskStore.clearApprovals()
        VpnController.riskyCandidate.value = null
        openInProcess = false
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_OPEN, false).putBoolean(KEY_SHUTDOWN_PENDING, true)
            .putLong(KEY_LAST_TASK_DISMISSAL_MS, System.currentTimeMillis())
            .remove(KEY_TASK_ID).commit()
        context.getSharedPreferences("sc_vpn_service_session", Context.MODE_PRIVATE)
            .edit().clear().commit()
        ServerScanner.stopAll()
        VpnController.autoRecoveryEnabled = false
        // Do not lie to the UI: the tunnel remains active until the service
        // explicitly closes its ParcelFileDescriptor and removes its notification.
        // Clearing StateFlow / stopService() first caused Idle UI + live VPN.
        if (XrayVpnService.hasLiveTunnel() ||
            VpnController.state.value != VpnState.Idle) {
            VpnController.state.value = VpnState.Stopping
        }
        context.stopService(Intent(context, ServerScanService::class.java))
        // Deliver shutdown to the already-running VPN service. It invalidates
        // all asynchronous starts and closes TUN before publishing Idle.
        if (XrayVpnService.stopLiveForTaskRemoval()) {
            // Actual TUN closure and Idle publication are owned by VpnService.
        } else if (XrayVpnService.hasLiveService()) {
            // Fallback only if the direct main-thread shutdown could not queue.
            requestTaskStop(context)
        } else {
            context.stopService(Intent(context, XrayVpnService::class.java))
            VpnController.state.value = VpnState.Idle
            VpnController.activeServer.value = null
            acknowledgeStopped(context)
        }
    }

    /** Android may destroy stopWithTask services without onTaskRemoved().
     * Never start a new service from inside the dying service's onDestroy().
     */
    fun taskGoneDuringServiceDestroy(context: Context) {
        TlsRiskStore.clearApprovals()
        VpnController.riskyCandidate.value = null
        openInProcess = false
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_OPEN, false).putBoolean(KEY_SHUTDOWN_PENDING, true)
            .putLong(KEY_LAST_TASK_DISMISSAL_MS, System.currentTimeMillis())
            .remove(KEY_TASK_ID).commit()
        context.getSharedPreferences("sc_vpn_service_session", Context.MODE_PRIVATE)
            .edit().clear().commit()
        ServerScanner.stopAll()
        VpnController.autoRecoveryEnabled = false
        context.stopService(Intent(context, ServerScanService::class.java))
    }

    private fun requestTaskStop(context: Context) {
        val delivered = runCatching {
            context.startService(Intent(context, XrayVpnService::class.java)
                .setAction(XrayVpnService.ACTION_STOP_FROM_TASK)) != null
        }.getOrDefault(false)
        if (!delivered) {
            context.stopService(Intent(context, XrayVpnService::class.java))
        }
    }

    /** Called only when the native TUN has closed or the service no longer exists. */
    fun acknowledgeStopped(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_SHUTDOWN_PENDING, false).commit()
    }
}
