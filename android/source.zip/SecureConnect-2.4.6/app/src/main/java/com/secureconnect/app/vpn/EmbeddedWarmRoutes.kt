package com.secureconnect.app.vpn

import com.secureconnect.app.data.model.Server
import com.secureconnect.app.data.model.ServerTransport
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * One Android TUN, one Xray core, a primary outbound and up to three preconfigured
 * alternate outbounds. Native Xray Observatory supplies health information to the
 * leastPing balancer for NEW flows. This is not a transferable TCP/QUIC session and
 * not a promise that an alternate is live just because its config was installed.
 */
object EmbeddedWarmRoutes {
    const val BALANCER_TAG = "sc-fast-route"
    const val MAX_HOT = 3
    // Short, lightweight 204 request; YouTube and bandwidth checks stay in admission.
    // Native observatory is used only on charging/unmetered networks in
    // this build. Reduce its synthetic HTTPS cadence even while charging.
    const val OBSERVE_INTERVAL_SECONDS = 60
    private const val HOT_PREFIX = "sc-hot-"

    @Volatile var installedRouteCount: Int = 0
        private set
    @Volatile var installedServers: String = ""
        private set
    @Volatile var installedIds: List<String> = emptyList()
        private set

    private fun networkGroup(host: String): String {
        val h = host.trim().lowercase(Locale.ROOT)
        val parts = h.split('.')
        if (parts.size == 4 && parts.all { (it.toIntOrNull() ?: -1) in 0..255 }) {
            return parts.take(3).joinToString(".") // best-effort IPv4 /24 diversity
        }
        // No invented ASN/ownership claims: for hostnames, only avoid exact host.
        return h
    }

    /**
     * Diversify source, apparent IP prefix and transport wherever available.
     * ASN diversity cannot be proven from config labels alone.
     */
    fun select(active: Server, qualified: List<Server>): List<Server> {
        val available = qualified.asSequence()
            .filter { it.id != active.id && it.rawLink.isNotBlank() &&
                WorkingPoolPolicy.eligible(it) && WorkingPoolPolicy.qualifiesRtt(it.ping) }
            .distinctBy { it.id }
            .distinctBy { it.host.lowercase(Locale.ROOT) + ":" + it.port }
            .toMutableList()
        val chosen = mutableListOf<Server>()
        val sources = mutableSetOf(active.source)
        val networkGroups = mutableSetOf(networkGroup(active.host))
        val families = mutableSetOf(ServerTransport.family(active))
        while (chosen.size < MAX_HOT && available.isNotEmpty()) {
            val best = available.maxWithOrNull(compareBy<Server> { if (it.source !in sources) 1 else 0 }
                .thenBy { if (networkGroup(it.host) !in networkGroups) 1 else 0 }
                .thenBy { if (ServerTransport.family(it) !in families) 1 else 0 }
                .thenBy { -it.ping }
                .thenBy { it.id }) ?: break
            available.remove(best)
            chosen += best
            sources += best.source
            networkGroups += networkGroup(best.host)
            families += ServerTransport.family(best)
        }
        return chosen
    }

    /** Enrich a valid single-server config or return it unchanged if not possible. */
    fun augment(base: String, candidates: List<Server>): String {
        return try {
        val root = JSONObject(base)
        val routing = root.optJSONObject("routing") ?: return base
        val outbounds = root.optJSONArray("outbounds") ?: return base
        if (outbounds.length() < 1 || outbounds.getJSONObject(0).optString("tag") != "proxy") return base
        if (routing.optJSONArray("balancers")?.toString()?.contains(BALANCER_TAG) == true) return base
        val tags = mutableListOf<String>()
        for ((index, server) in candidates.take(MAX_HOT).withIndex()) {
            val probe = XrayConfigBuilder.buildProbe(server) ?: continue
            val outbound = JSONObject(probe).getJSONArray("outbounds").getJSONObject(0)
            val tag = "$HOT_PREFIX${index + 1}"
            outbound.put("tag", tag)
            outbounds.put(outbound)
            tags += tag
        }
        if (tags.isEmpty()) return base
        routing.put("balancers", JSONArray().put(JSONObject()
            .put("tag", BALANCER_TAG)
            .put("selector", JSONArray().put("proxy").put(HOT_PREFIX))
            .put("fallbackTag", "proxy")
            .put("strategy", JSONObject().put("type", "leastPing"))))
        root.put("observatory", JSONObject()
            .put("subjectSelector", JSONArray().put("proxy").put(HOT_PREFIX))
            .put("probeUrl", "https://www.gstatic.com/generate_204")
            .put("probeInterval", "${OBSERVE_INTERVAL_SECONDS}s")
            .put("enableConcurrency", true))
        val rules = routing.optJSONArray("rules") ?: return base
        for (i in 0 until rules.length()) {
            val rule = rules.optJSONObject(i) ?: continue
            val inbound = rule.optJSONArray("inboundTag") ?: continue
            val names = (0 until inbound.length()).map { inbound.optString(it) }
            // Health, YouTube and throughput measurements must use the ACTUAL
            // selected primary. Balancing SOCKS tests across unrelated nodes
            // wrongly attributes a fast benchmark to the primary (seen in 2.3.0).
            // Keeping the watchdog pinned also detects a dead primary even if
            // the built-in observer can still reach a warm alternate.
            if ("health-socks" in names) continue
            // Internal DNS may follow a healthy alternate, but must stay proxied.
            if ("vpn-dns" in names ||
                ("tun" in names && rule.optString("outboundTag") == "proxy")) {
                rule.remove("outboundTag")
                rule.put("balancerTag", BALANCER_TAG)
            }
        }
        // Media sessions should not jump between distinct IP exit nodes on
        // new QUIC/TLS connections. Prefer the primary selected from the
        // video-qualified history for recognisable YouTube CDN domains.
        // Insert before the generic TUN balancer rule, AFTER TUN:53 -> DNS.
        val videoRule = JSONObject()
            .put("type", "field")
            .put("inboundTag", JSONArray().put("tun"))
            .put("domain", JSONArray()
                .put("domain:youtube.com")
                .put("domain:googlevideo.com")
                .put("domain:ytimg.com")
                .put("domain:youtube-nocookie.com")
                .put("full:youtubei.googleapis.com"))
            .put("outboundTag", "proxy")
        val reordered = JSONArray()
        var addedVideoRule = false
        for (i in 0 until rules.length()) {
            val rule = rules.getJSONObject(i)
            if (!addedVideoRule && rule.optString("balancerTag") == BALANCER_TAG &&
                rule.optJSONArray("inboundTag")?.let { arr ->
                    (0 until arr.length()).any { arr.optString(it) == "tun" }
                } == true) {
                reordered.put(videoRule)
                addedVideoRule = true
            }
            reordered.put(rule)
        }
        if (!addedVideoRule) return base
        routing.put("rules", reordered)
        // The old dns-outbound dialerProxy pinned DNS to the dead primary, even
        // when Xray's own DNS traffic had a routing rule for the balancer.
        for (i in 0 until outbounds.length()) {
            val outbound = outbounds.optJSONObject(i) ?: continue
            if (outbound.optString("tag") == "dns") {
                outbound.optJSONObject("streamSettings")?.optJSONObject("sockopt")
                    ?.remove("dialerProxy")
            }
        }
        root.toString()
        } catch (_: Exception) {
            base
        }
    }

    /** Revert ALL modifications when returning to manual single-server mode. */
    fun singleRoute(base: String): String {
        if (!base.contains(BALANCER_TAG)) return base
        return try {
            val root = JSONObject(base)
            val old = root.getJSONArray("outbounds")
            val outbounds = JSONArray()
            for (i in 0 until old.length()) {
                val outbound = old.getJSONObject(i)
                if (outbound.optString("tag").startsWith(HOT_PREFIX)) continue
                if (outbound.optString("tag") == "dns") {
                    val stream = outbound.optJSONObject("streamSettings") ?: JSONObject()
                    val sockopt = stream.optJSONObject("sockopt") ?: JSONObject()
                    sockopt.put("dialerProxy", "proxy")
                    stream.put("sockopt", sockopt)
                    outbound.put("streamSettings", stream)
                }
                outbounds.put(outbound)
            }
            root.put("outbounds", outbounds)
            val routing = root.getJSONObject("routing")
            val originalBalancers = routing.optJSONArray("balancers")
            if (originalBalancers != null) {
                val remaining = JSONArray()
                for (i in 0 until originalBalancers.length()) {
                    val balancer = originalBalancers.getJSONObject(i)
                    if (balancer.optString("tag") != BALANCER_TAG) remaining.put(balancer)
                }
                routing.put("balancers", remaining)
            }
            val rules = routing.getJSONArray("rules")
            val restoredRules = JSONArray()
            for (i in 0 until rules.length()) {
                val rule = rules.getJSONObject(i)
                // Auto-only video affinity is removed on a manual handover.
                val domains = rule.optJSONArray("domain")
                val isVideoAffinity = rule.optString("outboundTag") == "proxy" &&
                    domains != null && (0 until domains.length()).any {
                        domains.optString(it) == "domain:googlevideo.com"
                    }
                if (isVideoAffinity) continue
                if (rule.optString("balancerTag") == BALANCER_TAG) {
                    rule.remove("balancerTag")
                    rule.put("outboundTag", "proxy")
                }
                restoredRules.put(rule)
            }
            routing.put("rules", restoredRules)
            root.remove("observatory")
            root.toString()
        } catch (_: Exception) {
            throw IllegalStateException("Не могу отключить балансировщик для ручного режима")
        }
    }

    /** Count actually configured outbounds, not attempted candidate names. */
    fun configuredTags(config: String): Set<String> = try {
        val outbounds = JSONObject(config).getJSONArray("outbounds")
        (0 until outbounds.length()).mapNotNull {
            outbounds.optJSONObject(it)?.optString("tag")?.takeIf { tag ->
                tag.startsWith(HOT_PREFIX) && (tag.removePrefix(HOT_PREFIX).toIntOrNull() ?: 0) in 1..MAX_HOT
            }
        }.toSet()
    } catch (_: Exception) { emptySet() }

    fun activated(config: String, candidates: List<Server>) {
        val tags = configuredTags(config)
        installedRouteCount = tags.size
        installedIds = candidates.mapIndexedNotNull { index, server ->
            server.id.takeIf { "$HOT_PREFIX${index + 1}" in tags }
        }
        installedServers = candidates.mapIndexedNotNull { index, server ->
            if ("$HOT_PREFIX${index + 1}" in tags) "${server.country} / ${server.host}" else null
        }.joinToString(", ")
    }

    fun clear() {
        installedRouteCount = 0
        installedServers = ""
        installedIds = emptyList()
    }
}
