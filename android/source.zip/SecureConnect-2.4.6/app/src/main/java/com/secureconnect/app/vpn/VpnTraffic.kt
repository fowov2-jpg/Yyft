package com.secureconnect.app.vpn

import java.util.Locale

/** Rates are derived from Xray's interval counters, not from device-wide network usage. */
data class VpnTrafficRate(val downloadMbps: Float, val uploadMbps: Float) {
    companion object { val ZERO = VpnTrafficRate(0f, 0f) }
}

/** Pure helpers, kept outside Android services for regression testing. */
object VpnTrafficDisplay {
    fun calculate(downlinkBytes: Long, uplinkBytes: Long, elapsedNs: Long): VpnTrafficRate {
        if (elapsedNs <= 0L) return VpnTrafficRate.ZERO
        val divisor = elapsedNs.toDouble() / 1_000_000_000.0 * 1_000_000.0
        return VpnTrafficRate(
            ((downlinkBytes.coerceAtLeast(0L).toDouble() * 8.0) / divisor).toFloat().coerceAtLeast(0f),
            ((uplinkBytes.coerceAtLeast(0L).toDouble() * 8.0) / divisor).toFloat().coerceAtLeast(0f)
        )
    }

    fun speedLine(rate: VpnTrafficRate): String =
        "↓ ${formatRate(rate.downloadMbps)} Мбит/с   ↑ ${formatRate(rate.uploadMbps)} Мбит/с"

    fun formatRate(value: Float): String =
        String.format(Locale.US, "%.2f", value.takeIf { it.isFinite() && it >= 0f } ?: 0f)

    fun serverLabel(country: String?, city: String?, host: String?): String {
        val place = listOfNotNull(country?.trim()?.takeIf { it.isNotEmpty() },
            city?.trim()?.takeIf { it.isNotEmpty() }).distinct().joinToString(" · ")
        val destination = host?.trim().orEmpty()
        return (if (place.isNotEmpty()) place else destination.ifEmpty { "Сервер неизвестен" }).take(95)
    }
}
