package com.secureconnect.app.ui.components

/** Pure policy: motion never runs merely because a VPN is connected. */
object ConnectMotionPolicy {
    fun showSearchAnimation(connecting: Boolean, screenResumed: Boolean): Boolean =
        connecting && screenResumed

    fun showSuccessFlash(connected: Boolean, screenResumed: Boolean): Boolean =
        connected && screenResumed
}
