package com.secureconnect.app.ui.screens.home

/**
 * Display-only thresholds. This is a diagnostic index, NOT a measured
 * percentage probability of a data leak.
 */
enum class RiskTone { UNKNOWN, GREEN, YELLOW, RED }

object RiskTonePolicy {
    fun forIndex(index: Int?): RiskTone = when {
        index == null -> RiskTone.UNKNOWN
        index >= 60 -> RiskTone.RED
        index >= 33 -> RiskTone.YELLOW
        else -> RiskTone.GREEN
    }
}
