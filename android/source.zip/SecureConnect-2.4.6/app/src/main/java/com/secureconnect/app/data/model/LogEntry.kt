package com.secureconnect.app.data.model

/** Запись журнала подключения. */
data class LogEntry(val time: String, val level: String, val message: String)
