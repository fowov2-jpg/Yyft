package com.secureconnect.app

import com.secureconnect.app.vpn.BoundedServerScanner
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import java.util.concurrent.atomic.AtomicInteger

class BoundedServerScannerTest {
    @Test fun neverRunsMoreThanTwoChecksAndDoesNotLoseResults() = runBlocking {
        val active = AtomicInteger()
        val peak = AtomicInteger()
        val results = mutableListOf<Int>()
        BoundedServerScanner.scan((0 until 12).toList(), workers = 20, beforeEach = {},
            check = { item ->
                val count = active.incrementAndGet()
                peak.updateAndGet { maxOf(it, count) }
                try { delay(10); item } finally { active.decrementAndGet() }
            },
            onResult = { _, result -> results.add(result); true })
        assertEquals(2, peak.get())
        assertEquals((0 until 12).toList(), results.sorted())
    }

    @Test fun slowFirstItemDoesNotBlockNextItemsOnOtherLane() = runBlocking {
        val finished = mutableListOf<Int>()
        BoundedServerScanner.scan(listOf(0, 1, 2), 2, beforeEach = {},
            check = { item -> delay(if (item == 0) 200L else 10L); item },
            onResult = { _, result -> finished.add(result); true })
        assertTrue(finished.indexOf(2) < finished.indexOf(0))
    }

    @Test fun stoppingDoesNotStartTheRestOfTheCatalogue() = runBlocking {
        val started = mutableListOf<Int>()
        BoundedServerScanner.scan((0 until 100).toList(), 2, beforeEach = {},
            check = { item -> started.add(item); delay(10); item },
            onResult = { _, _ -> false })
        assertTrue(started.size <= 2)
    }
}
