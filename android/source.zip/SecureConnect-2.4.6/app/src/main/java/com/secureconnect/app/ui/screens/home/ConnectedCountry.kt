package com.secureconnect.app.ui.screens.home

import com.secureconnect.app.data.model.Server
import java.util.Locale

/** UI-only display of the selected primary outbound, not a claimed public exit IP.
 * The active Xray balancer may direct individual connections through warm reserves.
 */
data class ConnectedCountry(val name: String, val flag: String)

object ConnectedCountryFormatter {
    private val ru = Locale.forLanguageTag("ru")
    private val english = Locale.ENGLISH
    private val isoCodes = Locale.getISOCountries().toSet()
    private val codeByCountry = buildMap<String, String> {
        Locale.getISOCountries().forEach { code ->
            put(Locale.forLanguageTag("und-$code").getDisplayCountry(ru).lowercase(ru), code)
            put(Locale.forLanguageTag("und-$code").getDisplayCountry(english).lowercase(english), code)
        }
        put("сша", "US")
        put("соединенные штаты", "US")
        put("соединённые штаты", "US")
        put("америка", "US")
        put("usa", "US")
        put("united states of america", "US")
        put("великобритания", "GB")
        put("англия", "GB")
        put("uk", "GB")
        put("южная корея", "KR")
        put("корея", "KR")
        put("россия", "RU")
        put("турция", "TR")
        put("чехия", "CZ")
        put("оаэ", "AE")
    }

    fun fromServer(server: Server?): ConnectedCountry? {
        if (server == null) return null
        val country = server.country.trim().substringBefore('|').trim()
        if (country.isEmpty() || country.equals("неизвестно", ignoreCase = true) ||
            country.equals("unknown", ignoreCase = true)) return null

        val normalized = country.lowercase(ru)
        val code = when {
            country.uppercase(Locale.ROOT) in isoCodes -> country.uppercase(Locale.ROOT)
            else -> codeByCountry[normalized]
        }
        if (code != null) {
            val name = Locale.forLanguageTag("und-$code").getDisplayCountry(ru).ifBlank { country }
            val flag = codeToFlag(code)
            return ConnectedCountry(name, flag)
        }
        // If an unfamiliar country name was supplied, do not guess its flag.
        return ConnectedCountry(country.take(42), server.flagEmoji.takeIf(::isFlag) ?: "🌐")
    }

    /** Display aliases for one-line home card. Full country remains in diagnostics. */
    fun compactName(country: ConnectedCountry): String = when (country.name.lowercase(ru)) {
        "соединенные штаты", "соединённые штаты", "соединенные штаты америки" -> "США"
        "соединенное королевство", "соединённое королевство",
        "великобритания" -> "Великобритания"
        else -> country.name
    }

    private fun isFlag(text: String): Boolean {
        val points = text.codePoints().toArray()
        return points.size == 2 && points.all { it in 0x1F1E6..0x1F1FF }
    }

    private fun codeToFlag(code: String): String = buildString {
        code.forEach { appendCodePoint(0x1F1E6 + (it - 'A')) }
    }
}
