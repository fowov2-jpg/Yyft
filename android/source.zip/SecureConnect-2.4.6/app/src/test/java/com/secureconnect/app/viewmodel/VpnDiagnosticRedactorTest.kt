package com.secureconnect.app.viewmodel

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.assertEquals
import org.junit.Test

class VpnDiagnosticRedactorTest {
    @Test fun stripsSecretsAndRawVlessLinks() {
        val value = "token=private123 password:password42 vless://user:key@host:443#config"
        val result = VpnDiagnosticRedactor.sanitize(value)
        assertFalse(result.contains("private123"))
        assertFalse(result.contains("password42"))
        assertFalse(result.contains("vless://"))
        assertTrue(result.contains("<config-link-redacted>"))
    }

    @Test fun keepsSafeDetailsIntact() {
        val value = "Guardian: RTT=42ms; HTTPS=OK; Hot standby: 3/3"
        assertEquals(value, VpnDiagnosticRedactor.sanitize(value))
    }
}
