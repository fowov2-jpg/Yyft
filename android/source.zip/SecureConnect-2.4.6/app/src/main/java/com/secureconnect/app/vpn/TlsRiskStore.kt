package com.secureconnect.app.vpn

import android.content.Context
import java.util.concurrent.ConcurrentHashMap

/** Persist suspected certificate mismatches; approvals are memory-only for ONE session. */
object TlsRiskStore {
    private const val PREFS = "sc_tls_risk_v1"
    private const val KEY = "risky_server_ids"
    private val approvedSessionIds = ConcurrentHashMap.newKeySet<String>()

    fun isRisky(context: Context, serverId: String): Boolean = serverId.isNotBlank() &&
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getStringSet(KEY, emptySet()).orEmpty().contains(serverId)

    fun markRisk(context: Context, serverId: String) {
        if (serverId.isBlank()) return
        val preferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        synchronized(this) {
            val ids = preferences.getStringSet(KEY, emptySet()).orEmpty().toMutableSet()
            ids.add(serverId)
            preferences.edit().putStringSet(KEY, ids).apply()
        }
    }

    /** Clear only after a fresh certificate/hostname validation of THAT isolated route. */
    fun clearOnVerified(context: Context, serverId: String) {
        if (serverId.isBlank()) return
        val preferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        synchronized(this) {
            val ids = preferences.getStringSet(KEY, emptySet()).orEmpty().toMutableSet()
            if (ids.remove(serverId)) preferences.edit().putStringSet(KEY, ids).apply()
        }
    }

    fun approveForThisSession(serverId: String) {
        if (serverId.isNotBlank()) {
            approvedSessionIds.clear()
            approvedSessionIds.add(serverId)
        }
    }

    fun isExplicitlyApproved(serverId: String): Boolean = approvedSessionIds.contains(serverId)

    fun currentApprovedServerId(): String? = approvedSessionIds.firstOrNull()

    fun clearApprovals() = approvedSessionIds.clear()

    /** Unsafe servers must NEVER be automatically chosen for backup or auto-failover. */
    fun eligibleForAutomaticUse(context: Context, serverId: String): Boolean =
        !isRisky(context, serverId)
}
