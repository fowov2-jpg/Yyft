package com.secureconnect.app.vpn

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HotReserveSpeedPolicyTest {
    private val fast = VpnSpeedPolicy.Result(8.0, 2.0)
    private val downSlow = VpnSpeedPolicy.Result(3.2, 1.9)
    private val upSlow = VpnSpeedPolicy.Result(6.5, 0.6)
    private val unknown = VpnSpeedPolicy.Result(null, null, "HTTP timeout")

    @Test fun dueEveryFiveMinutes() {
        assertTrue(HotReserveSpeedPolicy.due(1_000L, 0L))
        assertFalse(HotReserveSpeedPolicy.due(299_999L, 1L))
        assertTrue(HotReserveSpeedPolicy.due(300_001L, 1L))
        assertTrue(HotReserveSpeedPolicy.due(10L, 99L))
    }

    @Test fun twoConfirmedSlowSamplesAreNeeded() {
        assertEquals(HotReserveSpeedPolicy.Decision.DEMOTE, HotReserveSpeedPolicy.decide(downSlow, downSlow))
        assertEquals(HotReserveSpeedPolicy.Decision.DEMOTE, HotReserveSpeedPolicy.decide(downSlow, upSlow))
        assertEquals(HotReserveSpeedPolicy.Decision.KEEP, HotReserveSpeedPolicy.decide(downSlow, fast))
        assertEquals(HotReserveSpeedPolicy.Decision.KEEP, HotReserveSpeedPolicy.decide(fast, null))
        assertEquals(HotReserveSpeedPolicy.Decision.UNKNOWN, HotReserveSpeedPolicy.decide(downSlow, unknown))
        assertEquals(HotReserveSpeedPolicy.Decision.UNKNOWN, HotReserveSpeedPolicy.decide(unknown, downSlow))
    }

    @Test fun onlyThreeQualifiedDistinctCandidatesNotActive() {
        assertEquals(listOf("a", "b", "c"), HotReserveSpeedPolicy.select(
            listOf("active", "a", "b", "c", "c"), listOf("b", "d"), "active", setOf("a", "b", "c", "d", "active")))
        assertEquals(listOf("b"), HotReserveSpeedPolicy.select(
            listOf("active", "a", "b"), emptyList(), "active", setOf("b")))
    }
}
