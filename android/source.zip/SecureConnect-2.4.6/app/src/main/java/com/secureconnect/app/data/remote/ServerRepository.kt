package com.secureconnect.app.data.remote

import android.os.SystemClock
import com.secureconnect.app.data.local.ServerStore
import com.secureconnect.app.vpn.ProbeStartBudget
import com.secureconnect.app.vpn.SourceHistoryPolicy
import kotlinx.coroutines.delay
import kotlinx.coroutines.Deferred
import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import com.secureconnect.app.BuildConfig
import com.secureconnect.app.data.model.Server
import com.secureconnect.app.data.model.ServerQualityHints
import com.secureconnect.app.data.model.ServerTransport
import com.secureconnect.app.data.source.ConfigSource
import com.secureconnect.app.data.source.SourceStatus
import com.secureconnect.app.vpn.XrayConfigBuilder
import com.secureconnect.app.util.ResourceGovernor
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

data class RefreshResult(val servers: List<Server>, val statuses: List<SourceStatus>)

/** Загружает все включённые источники параллельно, разбирает и проверяет доступность. */
object ServerRepository {

    @Volatile private var cooldowns: SharedPreferences? = null
    fun configure(context: Context) {
        cooldowns = context.getSharedPreferences("sc_source_cooldowns", Context.MODE_PRIVATE)
    }
    private class Restricted(message: String) : IOException(message)
    private data class Cached(val text: String, val etag: String?, val at: Long)
    private val httpCache = LinkedHashMap<String, Cached>()
    private fun origin(url: String): String = URL(url).let { "${it.protocol}://${it.host}:${it.port}" }
    private fun paused(url: String, now: Long) {
        val until = cooldowns?.getLong(origin(url), 0L) ?: 0L
        if (now < until) throw Restricted("Источник на паузе до ${java.util.Date(until)}")
    }
    @Synchronized private fun remember(url: String, entry: Cached) {
        httpCache.remove(url)
        httpCache[url] = entry
        while (httpCache.values.sumOf { it.text.length } > 1_000_000 || httpCache.size > 12) {
            httpCache.remove(httpCache.keys.first())
        }
    }

    private const val MAX_CHARS = 900_000
    private const val MAX_RESULT = ServerStore.MAX_CACHED_SERVERS
    private val tcpBudget = ProbeStartBudget(globalSpacingMs = 250L)
    private val udpBased = setOf("HYSTERIA", "HYSTERIA2", "TUIC")

    private val refreshMutex = Mutex()
    private val _latestStatuses = MutableStateFlow<List<SourceStatus>>(emptyList())
    val latestStatuses = _latestStatuses.asStateFlow()

    suspend fun refresh(
        sources: List<ConfigSource>,
        perSourceLimit: Int = 70,
        workDispatcher: CoroutineDispatcher = ResourceGovernor.dispatcher,
        probeBeforeScan: Boolean = true,
        sourcePage: Int = 0,
        preferredSources: List<String> = emptyList()
    ): RefreshResult = refreshMutex.withLock {
        coroutineScope {
            val sourceGate = Semaphore(3)
            val loaded = sources.filter { it.enabled }
                .sortedWith(compareBy<ConfigSource> {
                    SourceHistoryPolicy.rank(it.name, preferredSources)
                }.thenBy { it.id })
                .map { src -> async { sourceGate.withPermit { loadSource(src, perSourceLimit, workDispatcher, sourcePage) } } }
                .awaitAll()

            val bySourceId = loaded.associateBy({ it.first.sourceId }, { it.first })
            val statuses = sources.map { source ->
                bySourceId[source.id] ?: SourceStatus(
                    source.id,
                    0,
                    if (source.enabled) "Не загружен" else "Отключён"
                )
            }
            // Choose one balanced batch BEFORE probing: at most 240 candidates total.
            // A quick TCP failure is inconclusive and must not delete the candidate.
            val batch = buildColdStartPool(loaded.flatMap { it.second }, MAX_RESULT, preferredSources)
            val measured = if (probeBeforeScan) probe(batch, workDispatcher) else batch
            val result = measured.map { if (it.ping < 0) it.copy(ping = 0) else it }
            _latestStatuses.value = statuses
            RefreshResult(result, statuses)
        }
    }


    internal fun buildColdStartPool(servers: List<Server>, limit: Int,
        preferredSources: List<String> = emptyList()): List<Server> {
        if (limit <= 0 || servers.isEmpty()) return emptyList()

        val out = ArrayList<Server>(minOf(limit, servers.size))
        val tiers = servers.sortedBy { ServerQualityHints.importPriority(it) }.distinctBy { it.id }.groupBy { ServerQualityHints.importPriority(it) }.toSortedMap()
        for ((_, tier) in tiers) {
            val queues = LinkedHashMap<String, ArrayDeque<Server>>()
            tier.groupBy { it.source.ifBlank { "<unknown>" } }.entries
                .sortedWith(compareBy<Map.Entry<String, List<Server>>> {
                    SourceHistoryPolicy.rank(it.key, preferredSources)
                }.thenBy { it.key })
                .forEach { (source, items) ->
                queues[source] = ArrayDeque(items.sortedWith(
                    compareBy<Server> { ServerTransport.pingBucket(it) }
                        .thenBy { ServerTransport.coldStartRank(it) }
                        .thenBy { if (it.ping > 0) it.ping else Int.MAX_VALUE }
                        .thenBy { protocolRank(it.protocol) }))
            }
            while (out.size < limit && queues.isNotEmpty()) {
                val exhausted = ArrayList<String>()
                for ((source, queue) in queues) {
                    if (out.size >= limit) break
                    if (queue.isNotEmpty()) out += queue.removeFirst()
                    if (queue.isEmpty()) exhausted += source
                }
                exhausted.forEach(queues::remove)
            }
            if (out.size >= limit) break
        }
        return out
    }


    /** Меньше = лучше для обхода DPI в РФ. */
    private fun protocolRank(protocol: String): Int = when (protocol.uppercase()) {
        "VLESS" -> 0
        "HYSTERIA2" -> 1
        "TROJAN" -> 2
        "VMESS" -> 3
        "SHADOWSOCKS" -> 4
        else -> 4
    }

    private suspend fun loadSource(src: ConfigSource, limit: Int, workDispatcher: CoroutineDispatcher, sourcePage: Int): Pair<SourceStatus, List<Server>> = coroutineScope {
        val parts = src.urls.map { url ->
            currentCoroutineContext().ensureActive()
            try { Result.success(fetchText(url, workDispatcher)) }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { Result.failure<String>(e) }
        }

        // Не переносим тяжёлый парсинг подписок на Main. Некоторые публичные
        // подписки содержат десятки тысяч ссылок; старый код разбирал и
        // shuffled() весь список прямо из viewModelScope, из-за чего UI мог
        // зависнуть или процесс мог быть убит по памяти.
        val parsed = withContext(workDispatcher) {
            // Enumerate across the bounded source body, then rotate BEFORE
            // parsing; earlier code permanently hid every node after #500.
            // 5,000 is a memory cap, not an unbounded subscription parse.
            val allLinks = parts.asSequence()
                .mapNotNull { it.getOrNull() }
                .flatMap { ConfigParser.extractLinks(it, 5_000).asSequence() }
                .distinct()
                .take(5_000)
                .toList()
            val links = SourceWindowPolicy.page(allLinks, 500, sourcePage)

            // Rank parsed labels before per-source truncation; an eligible node
            // near the end of the bounded input must not lose to 50 earlier unknowns.
            val candidates = links.mapNotNull { ConfigParser.parse(it, src.name) }
                .filter { XrayConfigBuilder.build(it, null) != null }
                .distinctBy { it.id }
                .sortedWith(compareBy<Server> { ServerQualityHints.importPriority(it) }
                    .thenBy { protocolRank(it.protocol) })
            if (candidates.isEmpty() || limit <= 0) emptyList() else {
                // Pages wrap within each source. Keeping the same first 50 on every
                // refresh previously made a 100/100 catalogue permanently stagnant.
                candidates.take(limit)
            }

        }

        val error = if (parsed.isEmpty()) {
            parts.firstNotNullOfOrNull { it.exceptionOrNull() }?.message ?: "Нет поддерживаемых конфигов"
        } else null
        SourceStatus(src.id, parsed.size, error) to parsed
    }

    private suspend fun fetchText(url: String, workDispatcher: CoroutineDispatcher): String = withContext(workDispatcher) {
        val urls = buildList {
            add(url)
            githubCdnMirror(url)?.let { add(it) }
        }.distinct()
        var last: Throwable? = null
        for (candidate in urls) {
            try {
                return@withContext fetchHttp(candidate)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Restricted) {
                // Respect restrictions: never retry via another mirror.
                throw e
            } catch (e: Exception) {
                last = e
            }
        }
        throw IOException(last?.message ?: "Источник недоступен")
    }

    private fun githubCdnMirror(url: String): String? {
        val raw = Regex("^https://raw\\.githubusercontent\\.com/([^/]+)/([^/]+)/([^/]+)/(.*)$")
            .matchEntire(url)
        if (raw != null) {
            val (owner, repo, ref, path) = raw.destructured
            return "https://cdn.jsdelivr.net/gh/$owner/$repo@$ref/$path"
        }
        val gh = Regex("^https://github\\.com/([^/]+)/([^/]+)/raw/(?:refs/heads/)?([^/]+)/(.*)$")
            .matchEntire(url)
        if (gh != null) {
            val (owner, repo, ref, path) = gh.destructured
            return "https://cdn.jsdelivr.net/gh/$owner/$repo@$ref/$path"
        }
        return null
    }

    private fun fetchHttp(url: String): String {
        val now = System.currentTimeMillis()
        paused(url, now)
        val cached = synchronized(this) { httpCache[url] }
        if (cached != null && now - cached.at in 0L until 10L * 60L * 1000L) return cached.text
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 8_000
        conn.readTimeout = 12_000
        conn.instanceFollowRedirects = true
        conn.setRequestProperty("User-Agent", "SecureConnect/${BuildConfig.VERSION_NAME}")
        cached?.etag?.let { conn.setRequestProperty("If-None-Match", it) }
        return try {
            val code = conn.responseCode
            if (code == 304 && cached != null) {
                remember(url, cached.copy(at = now))
                return cached.text
            }
            if (code == 403 || code == 429 || code == 503) {
                val pause = SourceHttpPolicy.pauseMs(code, conn.getHeaderField("Retry-After"), now)
                val until = now + pause
                cooldowns?.edit()?.putLong(origin(url), until)?.apply()
                // A redirected provider can impose the restriction too.
                cooldowns?.edit()?.putLong(origin(conn.url.toString()), until)?.apply()
                throw Restricted("HTTP $code · пауза до ${java.util.Date(until)}")
            }
            if (code !in 200..299) throw IOException("HTTP $code")
            val text = conn.inputStream.bufferedReader().use { r ->
                val sb = StringBuilder()
                val buf = CharArray(8192)
                while (sb.length < MAX_CHARS) {
                    val toRead = minOf(buf.size, MAX_CHARS - sb.length)
                    val n = r.read(buf, 0, toRead)
                    if (n < 0) break
                    sb.append(buf, 0, n)
                }
                sb.toString()
            }
            remember(url, Cached(text, conn.getHeaderField("ETag"), now))
            text
        } finally {
            conn.disconnect()
        }
    }

    /** TCP-пинг. UDP-протоколы (Hysteria/TUIC) так не проверить — оставляем ping = 0 («—»). */
    private suspend fun probe(servers: List<Server>, workDispatcher: CoroutineDispatcher): List<Server> = coroutineScope {
        // Не больше 2 параллельных сокетов — публичные пулы не должны забивать NAT/радиомодуль.
        val gate = Semaphore(2)
        val jobs = LinkedHashMap<Pair<String, Int>, Deferred<Int>>()
        fun key(server: Server) = server.host.lowercase(java.util.Locale.ROOT) to server.port
        servers.filterNot { it.protocol.uppercase() in udpBased }.forEach { server ->
            // Several credentials on the same address/port need only one TCP hint.
            jobs.getOrPut(key(server)) {
                async {
                    gate.withPermit {
                        while (true) {
                            val wait = tcpBudget.reserve(key(server).first, SystemClock.elapsedRealtime())
                            if (wait == 0L) break
                            delay(wait)
                        }
                        currentCoroutineContext().ensureActive()
                        tcpPing(server.host, server.port, workDispatcher)
                    }
                }
            }
        }
        servers.map { server ->
            if (server.protocol.uppercase() in udpBased) server
            else server.copy(ping = jobs.getValue(key(server)).await())
        }
    }

    private suspend fun tcpPing(host: String, port: Int, workDispatcher: CoroutineDispatcher): Int = withContext(workDispatcher) {
        val address = resolveForProbe(host, 900L) ?: return@withContext -1
        val start = System.nanoTime()
        try {
            Socket().use { it.connect(InetSocketAddress(address, port), 1_500) }
            ((System.nanoTime() - start) / 1_000_000).toInt().coerceAtLeast(1)
        } catch (_: Exception) {
            -1
        }
    }

    /** DNS is not covered by Socket.connectTimeout; bound it separately. */
    private fun resolveForProbe(host: String, timeoutMs: Long): InetAddress? {
        if (host.isBlank()) return null
        if (host.contains(':') || host.matches(Regex("""\d{1,3}(?:\.\d{1,3}){3}"""))) {
            return runCatching { InetAddress.getByName(host) }.getOrNull()
        }

        // A native resolver can ignore cancellation: never queue arbitrary numbers
        // of pending DNS jobs behind a stuck resolver thread.
        val future = try {
            ResourceGovernor.dnsExecutor.submit<InetAddress?> {
                runCatching {
                    InetAddress.getAllByName(host).let { all ->
                        all.firstOrNull { it is Inet4Address } ?: all.firstOrNull()
                    }
                }.getOrNull()
            }
        } catch (_: java.util.concurrent.RejectedExecutionException) {
            return null
        }
        return try {
            future.get(timeoutMs.coerceAtLeast(200L), TimeUnit.MILLISECONDS)
        } catch (_: TimeoutException) {
            future.cancel(true)
            null
        } catch (_: Throwable) {
            future.cancel(true)
            null
        }
    }
}
