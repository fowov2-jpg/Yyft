package com.secureconnect.app.ui.components

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ConnectMotionPolicyTest {
    @Test fun searchMotionOnlyWhileVisibleAndConnecting() {
        assertTrue(ConnectMotionPolicy.showSearchAnimation(true, true))
        assertFalse(ConnectMotionPolicy.showSearchAnimation(true, false))
        assertFalse(ConnectMotionPolicy.showSearchAnimation(false, true))
        assertFalse(ConnectMotionPolicy.showSearchAnimation(false, false))
    }

    @Test fun successFlashOnlyWhileVisibleAndConnected() {
        assertTrue(ConnectMotionPolicy.showSuccessFlash(true, true))
        assertFalse(ConnectMotionPolicy.showSuccessFlash(true, false))
        assertFalse(ConnectMotionPolicy.showSuccessFlash(false, true))
    }
}
