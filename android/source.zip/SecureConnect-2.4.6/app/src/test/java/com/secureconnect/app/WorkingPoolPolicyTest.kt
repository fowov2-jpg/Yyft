package com.secureconnect.app

import com.secureconnect.app.data.model.Server
import com.secureconnect.app.vpn.WorkingPoolPolicy
import org.junit.Assert.*
import org.junit.Test

class WorkingPoolPolicyTest {
    private fun node(id: String = "a", country: String = "Эстония") = Server(
        id = id, country = country, city = "", flagEmoji = "",
        protocol = "VLESS", ping = 48, host = "test.example", port = 443,
        rawLink = "vless://uuid@test.example:443?security=reality&type=tcp")

    @Test fun rejectsRussiaAndUnknownCountryWithoutGuessingGeo() {
        listOf("Россия", "RU", "Russia", "Russian Federation", "🇷🇺 Россия", "Unknown", "Неизвестно", "")
            .forEach { assertFalse(it, WorkingPoolPolicy.eligible(node(country = it))) }
        listOf("Эстония", "Германия", "Netherlands", "🇫🇮 Финляндия")
            .forEach { assertTrue(it, WorkingPoolPolicy.eligible(node(country = it))) }
    }

    @Test fun refusesMalformedOrUnsupportedConfiguration() {
        assertFalse(WorkingPoolPolicy.eligible(node().copy(rawLink = "")))
        assertFalse(WorkingPoolPolicy.eligible(node().copy(host = "")))
        assertFalse(WorkingPoolPolicy.eligible(node().copy(port = 0)))
        assertFalse(WorkingPoolPolicy.eligible(node().copy(protocol = "UNKNOWN")))
    }

    @Test fun twentyBackupsStopDiscoveryAndOneFailureCreatesOneVacancy() {
        assertEquals(21, WorkingPoolPolicy.missing(0))
        assertEquals(1, WorkingPoolPolicy.missing(20))
        assertEquals(0, WorkingPoolPolicy.missing(21))
        assertEquals(12, WorkingPoolPolicy.missing(9))
        assertFalse(WorkingPoolPolicy.failedCoolingDown(3_599_999L, 0, 0))
        assertTrue(WorkingPoolPolicy.failedCoolingDown(3_599_999L, 1L, 1))
        assertFalse(WorkingPoolPolicy.failedCoolingDown(3_600_001L, 1L, 1))
    }
}
