package com.secureconnect.app.vpn

import java.util.concurrent.CancellationException
import java.util.concurrent.ExecutionException
import java.util.concurrent.Future
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

/** A slow primary must not hide an alternate result that has already completed. */
internal object ProbeAwaiter {
    fun <T> completedOrWithin(future: Future<T>, remainingNanos: Long): T? = try {
        when {
            future.isDone -> future.get()
            remainingNanos > 0L -> future.get(remainingNanos, TimeUnit.NANOSECONDS)
            else -> null
        }
    } catch (_: InterruptedException) {
        Thread.currentThread().interrupt()
        null
    } catch (_: ExecutionException) {
        null
    } catch (_: CancellationException) {
        null
    } catch (_: TimeoutException) {
        null
    }
}
