package com.secureconnect.app.vpn

/**
 * Keep working connectivity inexpensive, but do not let the verified reserve pool
 * run dry. Metadata refresh is separate from heavyweight standalone Xray probes.
 */
internal object ScannerDutyPolicy {
    const val QUIET_SLEEP_MS = 5L * 60_000L
    const val RESCUE_WINDOW_MS = 90_000L
    const val RESCUE_COOLDOWN_MS = 5L * 60_000L
    // One current exit and three possible recovery exits; no requirement for 21
    // battery-intensive fully benchmarked nodes.
    const val CONNECTED_POOL_TARGET = 4
    const val CONNECTED_REFILL_WINDOW_MS = 75_000L
    const val CONNECTED_REFILL_INTERVAL_MS = 15L * 60_000L

    fun allowDiscovery(
        state: VpnState,
        uiVisible: Boolean,
        rescueActive: Boolean,
        qualifiedCount: Int = CONNECTED_POOL_TARGET,
        refillWindowActive: Boolean = true
    ): Boolean = when (state) {
        VpnState.Connected -> rescueActive ||
            (refillWindowActive && qualifiedCount < CONNECTED_POOL_TARGET)
        VpnState.Idle -> uiVisible
        VpnState.Stopping -> false
        else -> true // Connecting/Blocked/Error: discover for recovery.
    }

    /**
     * Four servers from one subscription can fail together when that source
     * rotates its credentials. Build at least two independent source families,
     * but only during the existing bounded refill window (never continuous).
     */
    fun needsSourceDiversity(state: VpnState, qualifiedCount: Int, sourceCount: Int): Boolean =
        state == VpnState.Connected &&
            qualifiedCount >= CONNECTED_POOL_TARGET &&
            sourceCount < 2

    /** Fetching subscription text is cheap relative to native route probes. */
    fun allowCatalogue(
        state: VpnState,
        uiVisible: Boolean,
        rescueActive: Boolean = false,
        noCachedServers: Boolean = false
    ): Boolean = when (state) {
        VpnState.Connected -> true
        VpnState.Idle -> uiVisible
        VpnState.Connecting -> rescueActive || noCachedServers // Cold start or hard failover.
        VpnState.Validating, VpnState.Stopping -> false
        else -> true
    }

    /** No periodic synthetic video benchmarking of standby routes. */
    fun allowMaintenance(state: VpnState, uiVisible: Boolean): Boolean =
        state == VpnState.Idle && uiVisible

    fun targetCertifiedRoutes(state: VpnState, powerTarget: Int): Int =
        if (state == VpnState.Connected)
            maxOf(powerTarget, CONNECTED_POOL_TARGET)
        else powerTarget
}

/** UI visibility is pushed by Activity lifecycle, without polling. */
internal object ScannerUiVisibility {
    @Volatile var visible: Boolean = false
}
