package com.secureconnect.app.vpn

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ScannerDutyPolicyTest {
    @Test fun connectedTunnelSleepsWithoutRealRescue() {
        assertFalse(ScannerDutyPolicy.allowDiscovery(VpnState.Connected, true, false))
        assertFalse(ScannerDutyPolicy.allowDiscovery(VpnState.Connected, false, false))
        assertTrue(ScannerDutyPolicy.allowDiscovery(VpnState.Connected, false, true))
    }

    @Test fun depletedConnectedPoolTriggersBoundedDiscovery() {
        assertTrue(ScannerDutyPolicy.allowDiscovery(VpnState.Connected, false, false, 2))
        assertTrue(ScannerDutyPolicy.allowDiscovery(VpnState.Connected, false, false, 3))
        assertFalse(ScannerDutyPolicy.allowDiscovery(VpnState.Connected, false, false, 4))
        assertFalse(ScannerDutyPolicy.allowDiscovery(VpnState.Connected, false, false, 2,
            refillWindowActive = false))
        assertTrue(ScannerDutyPolicy.allowDiscovery(VpnState.Connected, false, true, 2,
            refillWindowActive = false))
        assertEquals(4, ScannerDutyPolicy.targetCertifiedRoutes(VpnState.Connected, 2))
        assertEquals(5, ScannerDutyPolicy.targetCertifiedRoutes(VpnState.Connected, 5))
    }

    @Test fun oneSuccessfulSourceIsNotEnoughForFailoverDiversity() {
        assertTrue(ScannerDutyPolicy.needsSourceDiversity(VpnState.Connected, 5, 1))
        assertTrue(ScannerDutyPolicy.needsSourceDiversity(VpnState.Connected, 4, 0))
        assertFalse(ScannerDutyPolicy.needsSourceDiversity(VpnState.Connected, 5, 2))
        assertFalse(ScannerDutyPolicy.needsSourceDiversity(VpnState.Connected, 2, 1))
        assertFalse(ScannerDutyPolicy.needsSourceDiversity(VpnState.Idle, 5, 1))
    }

    @Test fun connectedCatalogueCanRefreshWhileProbeWorkerSleeps() {
        assertTrue(ScannerDutyPolicy.allowCatalogue(VpnState.Connected, false))
        assertFalse(ScannerDutyPolicy.allowCatalogue(VpnState.Connecting, false))
        assertTrue(ScannerDutyPolicy.allowCatalogue(VpnState.Connecting, false, true))
        assertTrue(ScannerDutyPolicy.allowCatalogue(VpnState.Connecting, false,
            noCachedServers = true))
        assertFalse(ScannerDutyPolicy.allowCatalogue(VpnState.Idle, false))
    }

    @Test fun browsingSourcesWorksOnlyWhileAppIsOpen() {
        assertTrue(ScannerDutyPolicy.allowDiscovery(VpnState.Idle, true, false))
        assertFalse(ScannerDutyPolicy.allowDiscovery(VpnState.Idle, false, false))
        assertFalse(ScannerDutyPolicy.allowDiscovery(VpnState.Stopping, true, true))
    }

    @Test fun realFailureCanWakeScannerWithoutVisibleActivity() {
        assertTrue(ScannerDutyPolicy.allowDiscovery(VpnState.Blocked, false, false))
        assertTrue(ScannerDutyPolicy.allowDiscovery(VpnState.Connecting, false, false))
        assertTrue(ScannerDutyPolicy.allowDiscovery(VpnState.Validating, false, false))
        assertTrue(ScannerDutyPolicy.allowDiscovery(VpnState.Error("offline"), false, false))
    }

    @Test fun noPeriodicHotReserveMaintenanceWithActiveVpn() {
        assertFalse(ScannerDutyPolicy.allowMaintenance(VpnState.Connected, true))
        assertFalse(ScannerDutyPolicy.allowMaintenance(VpnState.Connected, false))
    }
}
