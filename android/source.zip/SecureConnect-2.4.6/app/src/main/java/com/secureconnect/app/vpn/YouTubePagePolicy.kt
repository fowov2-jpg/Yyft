package com.secureconnect.app.vpn

import java.net.URI
import java.util.Locale

/** Pure validation: HTTP redirects are navigation, not a failed YouTube test. */
object YouTubePagePolicy {
    private val youtubeHosts = setOf("www.youtube.com", "m.youtube.com", "youtube.com")
    private val rejectionMarkers = listOf(
        "before you continue to youtube", "consent.youtube.com", "access denied",
        "unusual traffic", "captcha", "robot check", "temporarily blocked"
    )

    /** Only navigate to HTTPS pages on exact YouTube hosts; never to arbitrary URLs. */
    fun nextPage(current: URI, location: String?): URI? {
        if (location.isNullOrBlank() || location.length > 4096) return null
        return try {
            val target = current.resolve(location.trim()).normalize()
            val host = target.host?.lowercase(Locale.ROOT)
            if (target.scheme?.lowercase(Locale.ROOT) != "https" ||
                host !in youtubeHosts || target.userInfo != null ||
                (target.port != -1 && target.port != 443) ||
                (target.rawPath?.length ?: 0) > 2048 ||
                (target.rawQuery?.length ?: 0) > 2048) null
            else target
        } catch (_: Exception) {
            null
        }
    }

    fun isHomePage(httpCode: Int, contentType: String, pageStart: String): Boolean {
        if (httpCode != 200 || !contentType.lowercase(Locale.ROOT).contains("text/html")) return false
        val content = pageStart.lowercase(Locale.ROOT)
        if (!content.contains("<html") && !content.contains("<!doctype html")) return false
        if (rejectionMarkers.any { it in content }) return false
        return "ytinitialdata" in content || "ytcfg.set" in content ||
            "innertube_api_key" in content || "<title>youtube" in content
    }
}
