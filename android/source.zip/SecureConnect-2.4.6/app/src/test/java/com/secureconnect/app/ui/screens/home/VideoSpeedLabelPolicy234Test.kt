package com.secureconnect.app.ui.screens.home

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class VideoSpeedLabelPolicy234Test {
    @Test fun extractsVideoDownloadWithoutWronglyShowingUpload() {
        assertEquals("9.28", VideoSpeedLabelPolicy.downloadMbps("↓9.28 Мбит/с · замер для видео"))
        assertEquals("11.13", VideoSpeedLabelPolicy.downloadMbps("↓11.13 ↑1.91 Мбит/с (ok)"))
    }

    @Test fun noFakeSpeedAfterFailedOrMissingBenchmark() {
        assertNull(VideoSpeedLabelPolicy.downloadMbps(null))
        assertNull(VideoSpeedLabelPolicy.downloadMbps("↓ не удалось измерить · тайм-аут"))
        assertNull(VideoSpeedLabelPolicy.downloadMbps("↑4.10 Мбит/с"))
    }

    @Test fun autoVideoTestDoesNotClaimPlaybackGuarantee() {
        val view = VideoQualityUiPolicy.resolve("Авто 720p · скорость подходит")
        assertEquals("Тест загрузки пройден", view.title)
        assertTrue(view.detail.contains("720p не гарантируется"))
    }
}
