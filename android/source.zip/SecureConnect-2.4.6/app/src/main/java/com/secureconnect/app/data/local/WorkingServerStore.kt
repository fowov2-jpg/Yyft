package com.secureconnect.app.data.local

import android.content.Context
import com.secureconnect.app.data.model.Server
import com.secureconnect.app.vpn.SourceHistoryPolicy
import com.secureconnect.app.vpn.WorkingPoolPolicy
import com.secureconnect.app.vpn.VpnSpeedPolicy
import com.secureconnect.app.vpn.RecoveryReservePolicy
import com.secureconnect.app.vpn.ServerStabilityPolicy
import com.secureconnect.app.vpn.TlsRiskStore
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.roundToInt
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Dedicated local "Рабочие" pool.
 *
 * Admission requires a positive measured SOCKS RTT, real YouTube HTML,
 * and TWO complete HTTPS throughput samples >=5/1 Mbps through the same Xray outbound. A later failed validation temporarily removes it
 * from the active working tier until it succeeds again.
 */
object WorkingServerStore {
    data class Record(
        val server: Server,
        val lastSuccessAtMs: Long,
        val lastFailureAtMs: Long = 0L,
        val ewmaHttpsMs: Double,
        val ewmaConnectMs: Double? = null,
        val successes: Int = 1,
        val failures: Int = 0,
        /** Lifetime failures; `failures` is the current consecutive failure streak. */
        val totalFailures: Int = 0,
        val youtubeVerifiedAtMs: Long = 0L,
        val speedVerifiedAtMs: Long = 0L,
        val verifiedDownloadMbps: Double = 0.0,
        val verifiedUploadMbps: Double = 0.0,
        val lastAuditAtMs: Long = 0L
    ) {
        fun isActive(nowMs: Long): Boolean =
            WorkingPoolPolicy.eligible(server) &&
            youtubeVerifiedAtMs > 0L && speedVerifiedAtMs > 0L &&
                nowMs - speedVerifiedAtMs in 0L..VpnSpeedPolicy.QUALITY_FRESHNESS_MS &&
                VpnSpeedPolicy.classify(verifiedDownloadMbps, verifiedUploadMbps) == VpnSpeedPolicy.Verdict.PASS &&
                WorkingPoolPolicy.qualifiesRtt(effectivePingMs()) &&
                ServerStabilityPolicy.remainsReady(failures) && nowMs >= lastSuccessAtMs

        /**
         * RTT used for auto-selection/UI. This is deliberately the SOCKS CONNECT
         * RTT through the active Xray path, not full TLS+HTTP wall-clock time.
         *
         * HTTPS latency remains a separate health/quality metric: on mobile networks
         * a perfectly good 40-80 ms tunnel can need 400-900 ms for a complete
         * TLS+HTTP probe, so conflating both metrics would incorrectly demote it.
         */
        fun stabilityScore(nowMs: Long): Double = ServerStabilityPolicy.score(
            effectivePingMs(), verifiedDownloadMbps, verifiedUploadMbps,
            successes, totalFailures, failures, lastSuccessAtMs, nowMs
        )

        fun effectivePingMs(): Int =
            ewmaConnectMs
                ?.takeIf { it.isFinite() && it > 0.0 }
                ?.roundToInt()
                ?.coerceAtLeast(1)
                ?: server.ping.takeIf { it > 0 }
                ?: ewmaHttpsMs
                    .takeIf { it.isFinite() && it > 0.0 }
                    ?.roundToInt()
                    ?.coerceAtLeast(1)
                ?: 0
    }

    private const val PREFS = "sc_working_servers"
    private const val KEY = "records_v1"
    // Encrypted, one-time pre-update snapshot. Never silently destroy the only
    // copy of a user's quality history when selection rules change.
    private const val RECOVERY_SNAPSHOT_KEY = "records_before_244"
    private const val RECOVERY_SNAPSHOT_DONE = "history_snapshot_244_done"
    private const val EWMA_ALPHA = 0.35
    private val lock = Any()
    private val _revision = MutableStateFlow(0L)
    val revision = _revision.asStateFlow()
    private var cachedRaw: String? = null
    private var cachedRecords: List<Record> = emptyList()

    /** Twenty independent reserves plus the active slot; bounded history keeps expired proofs. */
    fun savedRecords(context: Context): List<Record> = synchronized(lock) {
        loadLocked(context).sortedByDescending { it.lastSuccessAtMs }
    }

    fun savedServers(context: Context): List<Server> = savedRecords(context).map {
        it.server.copy(ping = it.effectivePingMs())
    }

    /** Learned source order, derived from saved successful video/throughput proofs. */
    fun preferredSourceNames(context: Context, nowMs: Long = System.currentTimeMillis()): List<String> =
        SourceHistoryPolicy.preferredSources(savedRecords(context)
            .filter { WorkingPoolPolicy.eligible(it.server) }
            .map { record ->
            SourceHistoryPolicy.Proof(
                source = record.server.source,
                lastSuccessAtMs = record.lastSuccessAtMs,
                youtubeVerifiedAtMs = record.youtubeVerifiedAtMs,
                speedVerifiedAtMs = record.speedVerifiedAtMs,
                lastFailureAtMs = record.lastFailureAtMs,
                consecutiveFailures = record.failures
            )
        }, nowMs)

    fun recordSuccess(
        context: Context,
        server: Server,
        connectMs: Int,
        httpsMs: Int,
        nowMs: Long = System.currentTimeMillis(),
        youtubeVerified: Boolean = false,
        speedVerified: Boolean = false,
        downloadMbps: Double? = null,
        uploadMbps: Double? = null
    ) {
        if (!WorkingPoolPolicy.eligible(server) || !WorkingPoolPolicy.qualifiesRtt(connectMs) || httpsMs <= 0) return
        synchronized(lock) {
            val records = loadLocked(context).associateByTo(LinkedHashMap()) { it.server.id }
            // Same ID can be reused by a subscription for DIFFERENT credentials
            // or endpoints. Historical YouTube/speed proofs must not survive this.
            val old = records[server.id]?.takeIf { it.server.rawLink == server.rawLink }
            // Normal Guardian HTTPS checks are evidence of recovery for a previously
            // certified server. They MUST clear a transient failure streak but MUST
            // NOT extend YouTube/throughput certification. Older implementations
            // ignored these successes, leaving healthy nodes indefinitely quarantined.
            if (old != null && !youtubeVerified && !speedVerified) {
                val httpEwma = EWMA_ALPHA * httpsMs + (1.0 - EWMA_ALPHA) * old.ewmaHttpsMs
                val pingEwma = EWMA_ALPHA * connectMs +
                    (1.0 - EWMA_ALPHA) * (old.ewmaConnectMs ?: connectMs.toDouble())
                records[server.id] = old.copy(
                    server = server.copy(ping = connectMs),
                    lastSuccessAtMs = nowMs,
                    ewmaHttpsMs = httpEwma,
                    ewmaConnectMs = pingEwma,
                    successes = (old.successes + 1).coerceAtMost(ServerStabilityPolicy.MAX_OBSERVATIONS),
                    failures = 0,
                    lastAuditAtMs = nowMs
                )
                saveLocked(context, records.values)
                return
            }
            // Generic HTTPS/Guardian pings never certify YouTube; old database entries
            // are unverified until an actual YouTube test completes.
            val confirmedAt = if (youtubeVerified) nowMs else old?.youtubeVerifiedAtMs ?: 0L
            if (confirmedAt <= 0L) return
            val speedValidNow = speedVerified &&
                VpnSpeedPolicy.classify(downloadMbps, uploadMbps) == VpnSpeedPolicy.Verdict.PASS
            val speedAt = if (speedValidNow) nowMs else old?.speedVerifiedAtMs ?: 0L
            // New nodes require DOUBLE-confirmed throughput; generic health pings
            // only refresh latency of a previously bandwidth-verified node.
            if (speedAt <= 0L ||
                nowMs - speedAt !in 0L..VpnSpeedPolicy.QUALITY_FRESHNESS_MS) return
            // Never exceed the verified pool capacity due to a late concurrent probe.
            if ((old == null || !old.isActive(nowMs)) &&
                records.values.count { it.isActive(nowMs) } >= WorkingPoolPolicy.MAX_VERIFIED) return
            val httpsSample = httpsMs.toDouble()
            val connectSample = connectMs.toDouble()
            val httpsEwma = old?.ewmaHttpsMs?.let {
                EWMA_ALPHA * httpsSample + (1.0 - EWMA_ALPHA) * it
            } ?: httpsSample
            val connectEwma = old?.ewmaConnectMs?.let {
                EWMA_ALPHA * connectSample + (1.0 - EWMA_ALPHA) * it
            } ?: connectSample
            records[server.id] = Record(
                server = server.copy(ping = connectMs),
                lastSuccessAtMs = nowMs,
                lastFailureAtMs = old?.lastFailureAtMs ?: 0L,
                ewmaHttpsMs = httpsEwma,
                ewmaConnectMs = connectEwma,
                successes = (old?.successes ?: 0).plus(1).coerceAtMost(ServerStabilityPolicy.MAX_OBSERVATIONS),
                failures = 0,
                totalFailures = old?.totalFailures ?: 0,
                youtubeVerifiedAtMs = confirmedAt,
                speedVerifiedAtMs = speedAt,
                verifiedDownloadMbps = if (speedValidNow) downloadMbps!! else old?.verifiedDownloadMbps ?: 0.0,
                verifiedUploadMbps = if (speedValidNow) uploadMbps!! else old?.verifiedUploadMbps ?: 0.0,
                lastAuditAtMs = nowMs
            )
            saveLocked(context, records.values)
        }
    }

    /** Cheap 45-minute reserve audit. Updates liveness only; never renews quality proofs. */
    fun recordAuditSuccess(context: Context, serverId: String, nowMs: Long = System.currentTimeMillis()) {
        synchronized(lock) {
            val records = loadLocked(context).associateByTo(LinkedHashMap()) { it.server.id }
            val old = records[serverId] ?: return
            records[serverId] = old.copy(lastAuditAtMs = nowMs,
                lastSuccessAtMs = nowMs,
                successes = (old.successes + 1).coerceAtMost(ServerStabilityPolicy.MAX_OBSERVATIONS),
                failures = 0)
            saveLocked(context, records.values)
        }
    }

    /** A speed slowdown is not a dead VPN server. Keep history, revoke only its quality badge.
     * Generic HTTPS health successes cannot resurrect this badge: fresh DOUBLE throughput
     * verification is required before the server can return to the strict полного резерва pool.
     */
    fun demoteSpeedQuality(context: Context, serverId: String) {
        if (serverId.isBlank()) return
        synchronized(lock) {
            val records = loadLocked(context).associateByTo(LinkedHashMap()) { it.server.id }
            val old = records[serverId] ?: return
            records[serverId] = old.copy(speedVerifiedAtMs = 0L,
                verifiedDownloadMbps = 0.0, verifiedUploadMbps = 0.0)
            saveLocked(context, records.values)
        }
    }

    fun recordFailure(context: Context, serverId: String, nowMs: Long = System.currentTimeMillis()) {
        if (serverId.isBlank()) return
        synchronized(lock) {
            val records = loadLocked(context).associateByTo(LinkedHashMap()) { it.server.id }
            val old = records[serverId] ?: return
            if (!ServerStabilityPolicy.countNewFailure(nowMs, old.lastFailureAtMs)) return
            records[serverId] = old.copy(
                lastFailureAtMs = nowMs,
                failures = old.failures.plus(1).coerceAtMost(999),
                totalFailures = old.totalFailures.plus(1)
                    .coerceAtMost(ServerStabilityPolicy.MAX_OBSERVATIONS)
            )
            saveLocked(context, records.values)
        }
    }

    fun activeRecords(context: Context, nowMs: Long = System.currentTimeMillis()): List<Record> =
        synchronized(lock) {
            loadLocked(context)
                .asSequence()
                .filter { it.isActive(nowMs) && TlsRiskStore.eligibleForAutomaticUse(context, it.server.id) }
                .sortedWith(compareByDescending<Record> { it.stabilityScore(nowMs) }
                    .thenBy { it.effectivePingMs() }
                    .thenByDescending { it.lastSuccessAtMs }
                    .thenBy { it.server.id })
                .take(WorkingPoolPolicy.MAX_VERIFIED)
                .toList()
        }

    /** Prior certified quality, but expired/revoked readiness. Never count as verified полного резерва. */
    fun historicalRecoveryRecords(context: Context, nowMs: Long = System.currentTimeMillis()): List<Record> =
        synchronized(lock) {
            loadLocked(context).asSequence()
                .filter { WorkingPoolPolicy.eligible(it.server) &&
                    !TlsRiskStore.isRisky(context, it.server.id) && !it.isActive(nowMs) && RecoveryReservePolicy.eligible(
                    nowMs, it.lastSuccessAtMs, it.speedVerifiedAtMs,
                    it.youtubeVerifiedAtMs, it.lastFailureAtMs, it.effectivePingMs(),
                    it.verifiedDownloadMbps, it.verifiedUploadMbps
                ) }
                .sortedWith(compareByDescending<Record> { it.lastSuccessAtMs }
                    .thenBy { it.effectivePingMs() })
                .take(WorkingPoolPolicy.MAX_VERIFIED)
                .toList()
        }

    fun activeServers(context: Context, nowMs: Long = System.currentTimeMillis()): List<Server> =
        activeRecords(context, nowMs).map { record ->
            record.server.copy(ping = record.effectivePingMs())
        }

    fun activeIds(context: Context, nowMs: Long = System.currentTimeMillis()): Set<String> =
        activeRecords(context, nowMs).mapTo(LinkedHashSet()) { it.server.id }

    fun activeRecord(
        context: Context,
        serverId: String,
        nowMs: Long = System.currentTimeMillis()
    ): Record? = synchronized(lock) {
        loadLocked(context).firstOrNull { it.server.id == serverId && it.isActive(nowMs) }
    }

    fun record(context: Context, serverId: String): Record? = synchronized(lock) {
        loadLocked(context).firstOrNull { it.server.id == serverId }
    }

    fun latencyMs(context: Context, serverId: String, nowMs: Long = System.currentTimeMillis()): Int? =
        activeRecords(context, nowMs)
            .firstOrNull { it.server.id == serverId }
            ?.effectivePingMs()
            ?.takeIf { it > 0 }

    private fun loadLocked(context: Context): List<Record> {
        val raw = SensitivePrefs.read(context, PREFS, KEY)
            ?: return emptyList()
        if (raw == cachedRaw) return cachedRecords
        cachedRaw = raw
        val parsed = decodeRecords(raw)
        // Read operations MUST NOT rewrite storage. In older releases a read
        // compacted history through the current eligibility filter, causing
        // formerly good nodes to disappear permanently after a policy update.
        cachedRecords = trimToPool(parsed, System.currentTimeMillis())
        return cachedRecords
    }

    internal fun decodeRecords(raw: String): List<Record> = runCatching {
        val arr = JSONArray(raw)
        buildList {
            for (i in 0 until arr.length()) {
                val j = arr.optJSONObject(i) ?: continue
                val serverObj = j.optJSONObject("server") ?: continue
                val serverJson = JSONArray().put(serverObj)
                val server = ServerStore.decodeServers(serverJson).firstOrNull() ?: continue
                val success = j.optLong("success", 0L)
                val ewma = j.optDouble("ewma", Double.NaN)
                if (success <= 0L || !ewma.isFinite() || ewma <= 0.0) continue
                add(
                    Record(
                        server = server,
                        lastSuccessAtMs = success,
                        lastFailureAtMs = j.optLong("failure", 0L),
                        ewmaHttpsMs = ewma,
                        // v1 records did not have a separate connect RTT. Prefer
                        // the stored server ping when available; otherwise the
                        // first post-migration successful probe will populate it.
                        ewmaConnectMs = j.optDouble("connectEwma", Double.NaN)
                            .takeIf { it.isFinite() && it > 0.0 }
                            ?: server.ping.takeIf { it > 0 }?.toDouble(),
                        successes = j.optInt("successes", 1).coerceAtLeast(1),
                        failures = j.optInt("failures", 0).coerceAtLeast(0),
                        totalFailures = j.optInt("totalFailures", 0).coerceIn(0, ServerStabilityPolicy.MAX_OBSERVATIONS),
                        youtubeVerifiedAtMs = j.optLong("youtubeVerifiedAt", 0L).coerceAtLeast(0L),
                        speedVerifiedAtMs = j.optLong("speedVerifiedAt", 0L).coerceAtLeast(0L),
                        verifiedDownloadMbps = j.optDouble("verifiedDownMbps", 0.0),
                        verifiedUploadMbps = j.optDouble("verifiedUpMbps", 0.0),
                        lastAuditAtMs = j.optLong("auditAt", success).coerceAtLeast(0L)
                    )
                )
            }
        }
    }.getOrDefault(emptyList()).distinctBy { it.server.id }


    private fun saveLocked(context: Context, records: Collection<Record>) {
        val retained = trimToPool(records, System.currentTimeMillis())
        val raw = encodeRecords(retained)
        if (raw == cachedRaw) return

        // Preserve a one-time encrypted snapshot before this version's first
        // successful write. It can be used for a manual recovery if a later
        // migration or quality-policy change loses history.
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(RECOVERY_SNAPSHOT_DONE, false)) {
            val previous = SensitivePrefs.read(context, PREFS, KEY)
            if (previous != null && decodeRecords(previous).isNotEmpty()) {
                SensitivePrefs.write(context, PREFS, RECOVERY_SNAPSHOT_KEY, previous)
            }
            // Mark only after the encrypted backup write has succeeded.
            check(prefs.edit().putBoolean(RECOVERY_SNAPSHOT_DONE, true).commit())
        }
        SensitivePrefs.write(context, PREFS, KEY, raw)
        cachedRaw = raw
        cachedRecords = retained
        _revision.value = _revision.value + 1L
    }

    internal fun trimToPool(records: Collection<Record>, nowMs: Long): List<Record> = records
        // Preserve historical entries even when a new transport/country policy
        // disqualifies them from AUTO today. Only selection is fail-closed.
        .filter { it.server.id.isNotBlank() && it.server.rawLink.isNotBlank() }
        .distinctBy { it.server.id }
        .sortedWith(compareByDescending<Record> { it.isActive(nowMs) }
            .thenByDescending { it.stabilityScore(nowMs) }
            .thenByDescending { it.lastSuccessAtMs }
            .thenBy { it.server.id })
        .take(WorkingPoolPolicy.MAX_HISTORY)

    internal fun encodeRecords(records: Collection<Record>): String {
        val arr = JSONArray()
        for (record in records.distinctBy { it.server.id }.take(WorkingPoolPolicy.MAX_HISTORY)) {
            val serverArray = JSONArray(ServerStore.encodeServers(listOf(record.server), limit = 1))
            val serverObj = serverArray.optJSONObject(0) ?: continue
            arr.put(
                JSONObject()
                    .put("server", serverObj)
                    .put("success", record.lastSuccessAtMs)
                    .put("failure", record.lastFailureAtMs)
                    .put("ewma", record.ewmaHttpsMs)
                    .put("connectEwma", record.ewmaConnectMs ?: JSONObject.NULL)
                    .put("successes", record.successes)
                    .put("failures", record.failures)
                    .put("totalFailures", record.totalFailures)
                    .put("youtubeVerifiedAt", record.youtubeVerifiedAtMs)
                    .put("speedVerifiedAt", record.speedVerifiedAtMs)
                    .put("verifiedDownMbps", record.verifiedDownloadMbps)
                    .put("verifiedUpMbps", record.verifiedUploadMbps)
                    .put("auditAt", record.lastAuditAtMs)
            )
        }
        return arr.toString()
    }
}
