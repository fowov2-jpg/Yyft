package com.secureconnect.app.vpn

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VpnPeriodicTasksTest {
    @Test fun stoppedSchedulerNeverRearms() {
        val posted = mutableListOf<Pair<Runnable, Long>>()
        val removed = mutableListOf<Runnable>()
        val task = Runnable { }
        val scheduler = VpnPeriodicTasks(
            schedule = { t, delay -> posted += t to delay },
            cancel = { removed += it }
        )
        scheduler.start(task to 120L)
        assertEquals(listOf(task to 120L), posted)
        scheduler.reschedule(task, 300L)
        assertEquals(2, posted.size)
        scheduler.stop()
        scheduler.reschedule(task, 400L)
        assertEquals(2, posted.size)
        assertEquals(listOf(task), removed)
    }

    @Test fun onlyRegisteredRunnablesAreAllowed() {
        val posted = mutableListOf<Runnable>()
        val valid = Runnable { }
        val rogue = Runnable { }
        val scheduler = VpnPeriodicTasks(
            schedule = { task, _ -> posted += task },
            cancel = { }
        )
        scheduler.start(valid to 1L)
        scheduler.reschedule(rogue, 1L)
        assertEquals(listOf(valid), posted)
        scheduler.reschedule(valid, 2L)
        assertEquals(listOf(valid, valid), posted)
    }
}
