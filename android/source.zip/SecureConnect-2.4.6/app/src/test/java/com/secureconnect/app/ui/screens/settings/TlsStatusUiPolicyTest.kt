package com.secureconnect.app.ui.screens.settings

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TlsStatusUiPolicyTest {
    @Test fun trustworthyOneDomainIsNotClaimedAsWholeVpn() {
        val item = TlsStatusUiPolicy.resolve("TLS-сертификат Android ChatGPT: доверенный")
        assertEquals(TlsStatusUiPolicy.Tone.GOOD, item.tone)
        assertTrue(item.detail.contains("один HTTPS-домен"))
    }
    @Test fun badCertificateIsVisible() {
        assertEquals(TlsStatusUiPolicy.Tone.DANGER, TlsStatusUiPolicy.resolve("ОПАСНО: mismatch").tone)
    }
    @Test fun missingCertificateTestIsUnknown() {
        assertEquals(TlsStatusUiPolicy.Tone.UNKNOWN, TlsStatusUiPolicy.resolve("TLS ChatGPT: ещё не проверялся").tone)
    }
}
