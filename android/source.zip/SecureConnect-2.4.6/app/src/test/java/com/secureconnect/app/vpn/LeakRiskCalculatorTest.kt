package com.secureconnect.app.vpn

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LeakRiskCalculatorTest {
    @Test fun connectedWithKillSwitchAndVerifiedProbeIsNotZeroRisk() {
        val result = LeakRiskCalculator.assess(
            VpnState.Connected, true,
            "TLS-сертификат Android ChatGPT: доверенный",
            AppVpnMode.EXCLUDE_SELECTED, true
        )
        assertNull(result.index)
        assertTrue(result.level.contains("Не проверено"))
        assertFalse(result.urgent)
        assertTrue(result.details.any { it.contains("Российские приложения") })
    }

    @Test fun disabledKillSwitchRaisesWarningWithoutConflatingTlsTimeoutWithMitm() {
        val result = LeakRiskCalculator.assess(
            VpnState.Connected, false, "TLS: не удалось проверить",
            AppVpnMode.EXCLUDE_SELECTED, true
        )
        assertNull(result.index)
        assertTrue(result.urgent)
        assertTrue(result.details.none { it.contains("Критично: TLS") })
    }

    @Test fun certificateFailureIsCriticalWithoutClaimingConfirmedLeak() {
        val result = LeakRiskCalculator.assess(
            VpnState.Connected, true,
            "ОПАСНО: сертификат Android ChatGPT не прошёл проверку",
            AppVpnMode.EXCLUDE_SELECTED, true
        )
        assertNull(result.index)
        assertTrue(result.urgent)
    }

    @Test fun blockedTunnelIsDistinguishedFromDisconnectedVpn() {
        val blocked = LeakRiskCalculator.assess(
            VpnState.Blocked, true, "", AppVpnMode.EXCLUDE_SELECTED, false
        )
        assertNull(blocked.index)
        assertTrue(blocked.urgent)
        val disconnected = LeakRiskCalculator.assess(
            VpnState.Idle, true, "", AppVpnMode.EXCLUDE_SELECTED, false
        )
        assertNull(disconnected.index)
        assertTrue(disconnected.urgent)
    }

    @Test fun riskAtSixtyIsHighAndUrgent() {
        val result = LeakRiskCalculator.assess(
            VpnState.Connected, false,
            "TLS-сертификат Android ChatGPT: доверенный",
            AppVpnMode.EXCLUDE_SELECTED, true
        )
        assertNull(result.index)
        assertTrue(result.urgent)
        assertTrue(result.level.contains("Требуется внимание"))
    }

    @Test fun selectedOnlyModeSignalsBroaderDirectRouting() {
        val result = LeakRiskCalculator.assess(
            VpnState.Connected, true, "доверенный",
            AppVpnMode.ONLY_SELECTED, true
        )
        assertNull(result.index)
        assertTrue(result.details.any { it.contains("Только выбранные") })
    }
}
