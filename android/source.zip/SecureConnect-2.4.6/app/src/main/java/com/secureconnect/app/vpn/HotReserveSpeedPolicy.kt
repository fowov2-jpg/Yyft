package com.secureconnect.app.vpn

/** Throughput checks for the three prepared alternatives (NOT the active proxy). */
object HotReserveSpeedPolicy {
    const val INTERVAL_MS = 5L * 60_000L
    const val RETEST_DELAY_MS = 45_000L
    const val TARGET = 3

    enum class Decision { KEEP, DEMOTE, UNKNOWN }

    fun due(now: Long, checkedAt: Long): Boolean =
        checkedAt <= 0 || now < checkedAt || now - checkedAt >= INTERVAL_MS

    /** Never remove a working reserve for a single CDN blip or unavailable test. */
    fun decide(first: VpnSpeedPolicy.Result, second: VpnSpeedPolicy.Result?): Decision = when {
        first.verdict == VpnSpeedPolicy.Verdict.SLOW &&
            second?.verdict == VpnSpeedPolicy.Verdict.SLOW -> Decision.DEMOTE
        first.verdict == VpnSpeedPolicy.Verdict.PASS -> Decision.KEEP
        first.verdict == VpnSpeedPolicy.Verdict.SLOW &&
            second?.verdict == VpnSpeedPolicy.Verdict.PASS -> Decision.KEEP
        else -> Decision.UNKNOWN
    }

    /** Only strictly verified, currently valid reserve records may be speed-audited. */
    fun select(embeddedIds: List<String>, hotIds: List<String>, activeId: String?,
               qualifiedIds: Set<String>): List<String> =
        (embeddedIds + hotIds).asSequence().filter { it != activeId && it in qualifiedIds }
            .distinct().take(TARGET).toList()
}
