package com.secureconnect.app.vpn

import android.content.Context
import android.os.SystemClock
import kotlinx.coroutines.delay
import com.secureconnect.app.data.model.Server
import com.secureconnect.app.util.ResourceGovernor
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

/** At most two isolated probes; cancellation never closes the live VPN core. */
object ServerPrechecker {
    private val budget = ProbeStartBudget()
    private fun hostKey(server: Server) = server.host.lowercase(java.util.Locale.ROOT)
    fun ready(server: Server): Boolean = budget.waitMs(hostKey(server), SystemClock.elapsedRealtime()) == 0L

    private suspend fun pace(server: Server) {
        while (true) {
            val wait = budget.reserve(hostKey(server), SystemClock.elapsedRealtime())
            if (wait == 0L) break
            delay(wait)
        }
        currentCoroutineContext().ensureActive()
    }

    private fun limited(server: Server, result: XrayCore.DelayResult): XrayCore.DelayResult {
        // The native API exposes the status in an error, but discards headers.
        // Therefore this is a conservative local pause, not parsed Retry-After.
        if (result.ms == null && ProbeStartBudget.isRestricted(result.error)) {
            budget.defer(hostKey(server), SystemClock.elapsedRealtime(), 60L * 60L * 1000L)
            return result.copy(retryAfterMs = 60L * 60L * 1000L)
        }
        return result
    }

    /** Guardian worker calls the same bounded standard gate before a live handover. */
    fun checkForGuardian(context: Context, server: Server): XrayCore.DelayResult {
        if (TlsRiskStore.isRisky(context, server.id))
            return XrayCore.DelayResult(null, "TLS_CERT_RISK: нужен явный выбор пользователя")
        val config = XrayConfigBuilder.buildProbe(server)
            ?: return XrayCore.DelayResult(null, "Несовместимый конфиг")
        val generic = XrayCore.measureStandalone(context, config, "https://www.gstatic.com/generate_204")
        if (generic.ms == null) return generic
        val quality = XrayCore.checkStandaloneQuality(context, config)
        val youtube = quality.youtube
        when (quality.tlsVerdict) {
            OpenAiTlsPolicy.Verdict.CERTIFICATE_ERROR -> {
                TlsRiskStore.markRisk(context, server.id)
                return XrayCore.DelayResult(null, "TLS_CERT_RISK: подозрительный сертификат")
            }
            OpenAiTlsPolicy.Verdict.VERIFIED -> TlsRiskStore.clearOnVerified(context, server.id)
            else -> Unit
        }
        if (!youtube.passed || !WorkingPoolPolicy.qualifiesRtt(youtube.connectMs) || !quality.speedVerified) {
            return XrayCore.DelayResult(null, "Guardian: YouTube/RTT/двойной speed-test не подтверждены",
                if (quality.deferred) 15L * 60_000L else 30L * 60_000L)
        }
        return generic.copy(connectMs = youtube.connectMs, youtubePassed = true,
            speedVerified = true, downloadMbps = quality.downloadMbps, uploadMbps = quality.uploadMbps)
    }

    private val gate = Semaphore(ResourceGovernor.MAX_APP_WORKERS.coerceIn(1, 2))
    private val targets = listOf("https://www.gstatic.com/generate_204", "https://cp.cloudflare.com/generate_204")

    suspend fun check(
        context: Context,
        server: Server,
        alternate: Boolean = false,
        allowAlternate: Boolean = true,
        finalAttempt: Boolean = true
    ): XrayCore.DelayResult = gate.withPermit {
        if (TlsRiskStore.isRisky(context, server.id))
            return@withPermit XrayCore.DelayResult(null, "TLS_CERT_RISK: исключён из автопроверок")
        val config = XrayConfigBuilder.buildProbe(server)
            ?: return@withPermit XrayCore.DelayResult(null, "Несовместимый конфиг")
        pace(server)
        withContext(ResourceGovernor.probeDispatcher) {
            currentCoroutineContext().ensureActive()
            // The fast gate is a scheduling hint only. DNS filtering, overloaded
            // resolvers or a slow TCP handshake must not veto the final native
            // HTTPS attempt. A first-pass rejection is retried by the scanner.
            if (!finalAttempt && server.ping <= 0 && !ServerReachability.reachable(server, config)) {
                return@withContext XrayCore.DelayResult(null, "Быстрая проверка: адрес/порт недоступен")
            }
            currentCoroutineContext().ensureActive()
            val index = if (alternate) 1 else 0
            var result = limited(server, XrayCore.measureStandalone(context, config, targets[index]))
            currentCoroutineContext().ensureActive()
            if (result.ms == null && result.retryAfterMs == null && allowAlternate) {
                pace(server)
                result = limited(server, XrayCore.measureStandalone(context, config, targets[1 - index]))
            }
            currentCoroutineContext().ensureActive()
            // The native delay API treats 302 as failure and never returns Location.
            // Verify final HTTPS HTML through an isolated SOCKS-only Xray instance.
            if (result.ms != null) {
                pace(server)
                val qualified = XrayCore.checkStandaloneQuality(context, config)
                val youtube = qualified.youtube
                currentCoroutineContext().ensureActive()
                if (qualified.tlsVerdict == OpenAiTlsPolicy.Verdict.CERTIFICATE_ERROR) {
                    TlsRiskStore.markRisk(context, server.id)
                        return@withContext XrayCore.DelayResult(null,
                        "TLS_CERT_RISK: сертификат/имя не подтверждены")
                }
                if (qualified.tlsVerdict == OpenAiTlsPolicy.Verdict.VERIFIED)
                    TlsRiskStore.clearOnVerified(context, server.id)
                result = if (youtube.passed && WorkingPoolPolicy.qualifiesRtt(youtube.connectMs) && qualified.speedVerified) {
                    result.copy(youtubePassed = true, connectMs = youtube.connectMs,
                        speedVerified = true, downloadMbps = qualified.downloadMbps,
                        uploadMbps = qualified.uploadMbps)
                } else if (youtube.passed && !WorkingPoolPolicy.qualifiesRtt(youtube.connectMs)) {
                    // Retain the successful HTTP result and measured RTT for the slow standby tier.
                    result.copy(youtubePassed = true, connectMs = youtube.connectMs,
                        error = "SOCKS-пинг ${youtube.connectMs ?: "неизвестен"} мс — ожидание")
                } else if (youtube.passed) {
                    XrayCore.DelayResult(null,
                        if (qualified.deferred) "Ожидаю бюджет тестов скорости" else
                            "Скорость резерва не подтверждена 2 раза подряд (нужно ≥5/1 Мбит/с)",
                        if (qualified.deferred) 15L * 60_000L else 30L * 60_000L)
                } else {
                    XrayCore.DelayResult(
                        null,
                        "YouTube HTML не подтверждён: ${youtube.error ?: "неизвестная причина"}",
                        // Redirects/consent or probe errors are inconclusive, not a dead server.
                        if (youtube.verdict == YouTubePageProbe.Verdict.INCONCLUSIVE)
                            10L * 60_000L else null
                    )
                }
            }
            result
        }
    }
}
