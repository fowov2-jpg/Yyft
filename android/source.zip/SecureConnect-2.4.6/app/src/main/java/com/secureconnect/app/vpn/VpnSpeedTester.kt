package com.secureconnect.app.vpn

import java.io.BufferedInputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

/**
 * Two small, bounded HTTPS transfers THROUGH the current Xray SOCKS outbound.
 * It never contacts the benchmark host directly, nor uses UI traffic counters.
 * Failures of the measurement provider are UNKNOWN, not proof the VPN is slow.
 */
object VpnSpeedTester {
    private const val HOST = "speed.cloudflare.com"
    private const val PORT = 443
    private const val SOCKS_PORT = XrayConfigBuilder.HEALTH_SOCKS_PORT
    private const val TIMEOUT_MS = 6_000
    private const val SOCKET_CONNECT_TIMEOUT_MS = 750
    private const val MAX_HEADER_BYTES = 8192
    private val running = AtomicBoolean(false)

    fun measure(socksPort: Int = SOCKS_PORT): VpnSpeedPolicy.Result {
        if (!running.compareAndSet(false, true)) {
            return VpnSpeedPolicy.Result(null, null, "Измерение уже выполняется")
        }
        try {
            val download = runCatching { downloadMbps(socksPort) }
            // Do not perform an upload against a provider that was already unreachable.
            if (download.isFailure) return VpnSpeedPolicy.Result(
                null, null, "Download: ${download.exceptionOrNull()?.message?.take(80)}")
            val upload = runCatching { uploadMbps(socksPort) }
            return VpnSpeedPolicy.Result(
                download.getOrNull(), upload.getOrNull(),
                upload.exceptionOrNull()?.let { "Upload: ${it.message?.take(80)}" }
            )
        } finally {
            running.set(false)
        }
    }

    /**
     * One download-only quality sample for automatic first-connect.
     * At most DOWNLOAD_BYTES of synthetic data; never tests upload on mobile.
     * No bypass: same Xray SOCKS outlet and TLS verification as full measure().
     */
    fun measureDownloadOnly(socksPort: Int = SOCKS_PORT): VpnSpeedPolicy.Result {
        if (!running.compareAndSet(false, true)) {
            return VpnSpeedPolicy.Result(null, null, "Другой тест уже выполняется")
        }
        return try {
            val download = runCatching { downloadMbps(socksPort) }
            VpnSpeedPolicy.Result(
                download.getOrNull(), null,
                download.exceptionOrNull()?.message?.take(80)
            )
        } finally {
            running.set(false)
        }
    }

    /** DNS for the public endpoint is resolved remotely by Xray, not Android. */
    private fun <T> overXray(socksPort: Int, block: (SSLSocket) -> T): T {
        Socket().use { raw ->
            raw.soTimeout = TIMEOUT_MS
            raw.connect(InetSocketAddress("127.0.0.1", socksPort), SOCKET_CONNECT_TIMEOUT_MS)
            XrayHealthChecker.performSocksConnect(
                DataInputStream(raw.getInputStream()), DataOutputStream(raw.getOutputStream()), HOST, PORT
            )
            val tls = (SSLSocketFactory.getDefault() as SSLSocketFactory)
                .createSocket(raw, HOST, PORT, false) as SSLSocket
            tls.use { ssl ->
                ssl.soTimeout = TIMEOUT_MS
                ssl.useClientMode = true
                ssl.sslParameters = ssl.sslParameters.apply {
                    endpointIdentificationAlgorithm = "HTTPS"
                }
                ssl.startHandshake()
                return block(ssl)
            }
        }
    }

    private fun downloadMbps(socksPort: Int): Double = overXray(socksPort) { tls ->
        val requested = VpnSpeedPolicy.DOWNLOAD_BYTES
        val request = "GET /__down?bytes=$requested HTTP/1.1\r\n" +
            "Host: $HOST\r\nAccept-Encoding: identity\r\nCache-Control: no-cache\r\nConnection: close\r\n\r\n"
        tls.outputStream.write(request.toByteArray(Charsets.US_ASCII))
        tls.outputStream.flush()
        val input = BufferedInputStream(tls.inputStream)
        val header = readHeaders(input)
        check(header.code == 200) { "HTTP ${header.code}" }
        check(header.chunked || header.contentLength == requested.toLong()) {
            "Unexpected test payload length"
        }

        val buffer = ByteArray(16 * 1024)
        var read = 0L
        val start = System.nanoTime()
        fun copyPayload(length: Long) {
            var pending = length
            while (pending > 0L) {
                if (Thread.currentThread().isInterrupted || elapsedMs(start) > VpnSpeedPolicy.MAX_TEST_DURATION_MS) {
                    error("download deadline")
                }
                val n = input.read(buffer, 0, minOf(buffer.size.toLong(), pending).toInt())
                check(n > 0) { "truncated download" }
                pending -= n
                read += n
                check(read <= requested) { "oversized download response" }
            }
        }
        if (header.chunked) {
            while (true) {
                val size = readAsciiLine(input).substringBefore(';').trim().toLongOrNull(16)
                    ?: error("invalid HTTP chunk length")
                check(size in 0L..(requested - read)) { "invalid HTTP chunk size" }
                if (size == 0L) break
                copyPayload(size)
                check(input.read() == 13 && input.read() == 10) { "invalid chunk terminator" }
            }
        } else copyPayload(requested.toLong())
        check(read == requested.toLong()) { "incomplete speed-test payload" }
        VpnSpeedPolicy.mbps(read, System.nanoTime() - start)
            ?: error("download elapsed time invalid")
    }

    private fun uploadMbps(socksPort: Int): Double = overXray(socksPort) { tls ->
        val total = VpnSpeedPolicy.UPLOAD_BYTES
        val request = "POST /__up HTTP/1.1\r\n" +
            "Host: $HOST\r\nContent-Type: application/octet-stream\r\n" +
            "Content-Length: $total\r\nConnection: close\r\n\r\n"
        val output = tls.outputStream
        output.write(request.toByteArray(Charsets.US_ASCII))
        val buffer = ByteArray(16 * 1024) // zero filled; no user data is transmitted
        val start = System.nanoTime()
        var sent = 0
        while (sent < total) {
            if (Thread.currentThread().isInterrupted || elapsedMs(start) > VpnSpeedPolicy.MAX_TEST_DURATION_MS) {
                error("upload deadline")
            }
            val len = minOf(buffer.size, total - sent)
            output.write(buffer, 0, len)
            sent += len
        }
        output.flush()
        val input = BufferedInputStream(tls.inputStream)
        val header = readHeaders(input)
        check(header.code in 200..299) { "HTTP ${header.code}" }
        // Wait for server confirmation that all bytes were received. Includes RTT,
        // so the conservative result may understate raw upstream bandwidth.
        VpnSpeedPolicy.mbps(sent.toLong(), System.nanoTime() - start)
            ?: error("upload elapsed time invalid")
    }

    private data class Headers(val code: Int, val contentLength: Long?, val chunked: Boolean)

    private fun readHeaders(input: BufferedInputStream): Headers {
        val bytes = java.io.ByteArrayOutputStream()
        var state = 0
        while (bytes.size() < MAX_HEADER_BYTES) {
            val ch = input.read()
            check(ch >= 0) { "Missing HTTPS response headers" }
            bytes.write(ch)
            state = when {
                state == 0 && ch == 13 -> 1
                state == 1 && ch == 10 -> 2
                state == 2 && ch == 13 -> 3
                state == 3 && ch == 10 -> 4
                ch == 13 -> 1
                else -> 0
            }
            if (state == 4) break
        }
        check(state == 4) { "HTTP headers too large" }
        val header = bytes.toString("US-ASCII")
        val status = header.substringBefore("\r\n").split(' ').getOrNull(1)?.toIntOrNull()
            ?: error("Invalid HTTP response")
        val contentLength = Regex("(?im)^content-length:\\s*(\\d+)\\s*$")
            .find(header)?.groupValues?.get(1)?.toLongOrNull()
        val chunked = Regex("(?im)^transfer-encoding:.*chunked").containsMatchIn(header)
        return Headers(status, contentLength, chunked)
    }

    private fun readAsciiLine(input: BufferedInputStream): String {
        val bytes = java.io.ByteArrayOutputStream()
        while (bytes.size() < 128) {
            val ch = input.read()
            check(ch >= 0) { "truncated chunk header" }
            if (ch == 13) {
                check(input.read() == 10) { "malformed chunk header" }
                return bytes.toString("US-ASCII")
            }
            bytes.write(ch)
        }
        error("chunk header too large")
    }

    private fun elapsedMs(startNs: Long): Long = (System.nanoTime() - startNs) / 1_000_000L

    /** Results from automatic video checks never imply that upload was measured. */
    fun formatVideoDownload(result: VpnSpeedPolicy.Result): String =
        result.downloadMbps?.let {
            "↓${String.format(Locale.US, "%.2f", it)} Мбит/с · замер для видео"
        } ?: "↓ не удалось измерить · ${result.error?.take(56) ?: "недоступен тестовый сайт"}"

    fun format(result: VpnSpeedPolicy.Result): String {
        fun part(value: Double?): String = value?.let { String.format(Locale.US, "%.2f", it) } ?: "—"
        return "↓${part(result.downloadMbps)} ↑${part(result.uploadMbps)} Мбит/с (${result.verdict})"
    }
}
