package com.secureconnect.app.ui.navigation

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object AppRouting : Screen("app_routing")
    object Diagnostics : Screen("diagnostics")
    object Servers : Screen("servers")
    object Settings : Screen("settings")
    object Technical : Screen("technical")
}
