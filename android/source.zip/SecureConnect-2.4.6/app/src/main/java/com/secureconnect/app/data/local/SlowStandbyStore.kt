package com.secureconnect.app.data.local

import android.content.Context
import com.secureconnect.app.data.model.Server
import com.secureconnect.app.vpn.SlowStandbyPolicy
import com.secureconnect.app.vpn.WorkingPoolPolicy
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

/** Separate bounded on-disk tier; a slow reachable node never occupies the verified pool. */
object SlowStandbyStore {
    data class Entry(val server: Server, val measuredPingMs: Int, val checkedAtMs: Long)
    private const val PREFS = "sc_slow_standby"
    private const val KEY = "standby_v1"
    private val guard = Any()
    private val _revision = MutableStateFlow(0L)
    val revision = _revision.asStateFlow()

    fun entries(context: Context): List<Entry> = synchronized(guard) { read(context) }
    fun get(context: Context, id: String): Entry? = entries(context).firstOrNull { it.server.id == id }
    fun park(context: Context, server: Server, ping: Int, now: Long = System.currentTimeMillis()) {
        if (!WorkingPoolPolicy.eligible(server) || ping <= WorkingPoolPolicy.TARGET_RTT_MS) return
        synchronized(guard) {
            val entries = read(context).filterNot { it.server.id == server.id } +
                Entry(server.copy(ping = ping), ping, now)
            write(context, entries.sortedByDescending { it.checkedAtMs }.take(SlowStandbyPolicy.MAX_STANDBY))
        }
    }
    fun remove(context: Context, id: String) = synchronized(guard) {
        val old = read(context)
        if (old.any { it.server.id == id }) write(context, old.filterNot { it.server.id == id })
    }
    private fun read(context: Context): List<Entry> = runCatching {
        val text = SensitivePrefs.read(context, PREFS, KEY) ?: "[]"
        val array = JSONArray(text)
        buildList {
            for (index in 0 until array.length()) {
                val item = array.optJSONObject(index) ?: continue
                val obj = item.optJSONObject("server") ?: continue
                val server = ServerStore.decodeServers(JSONArray().put(obj)).firstOrNull() ?: continue
                val ping = item.optInt("ping", 0)
                val time = item.optLong("time", 0)
                if (WorkingPoolPolicy.eligible(server) && ping > WorkingPoolPolicy.TARGET_RTT_MS && time > 0)
                    add(Entry(server.copy(ping = ping), ping, time))
            }
        }.distinctBy { it.server.id }.sortedByDescending { it.checkedAtMs }
            .take(SlowStandbyPolicy.MAX_STANDBY)
    }.getOrDefault(emptyList())
    private fun write(context: Context, entries: List<Entry>) {
        val array = JSONArray()
        entries.forEach { entry ->
            val server = JSONArray(ServerStore.encodeServers(listOf(entry.server), limit = 1)).optJSONObject(0)
            if (server != null) array.put(JSONObject().put("server", server)
                .put("ping", entry.measuredPingMs).put("time", entry.checkedAtMs))
        }
        SensitivePrefs.write(context, PREFS, KEY, array.toString())
        _revision.value = _revision.value + 1L
    }
}
