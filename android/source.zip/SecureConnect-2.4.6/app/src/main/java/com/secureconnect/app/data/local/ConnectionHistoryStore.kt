package com.secureconnect.app.data.local

import android.content.Context
import org.json.JSONArray

/** Only IDs of recent live HTTPS+YouTube connections. Never claim they are speed-certified. */
object ConnectionHistoryStore {
    private const val PREFS = "sc_recent_connections"
    private const val KEY = "connected_ids_v1"
    private const val LIMIT = 15

    fun recentIds(context: Context): List<String> = runCatching {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, "[]") ?: "[]"
        val array = JSONArray(raw)
        (0 until array.length()).mapNotNull { i ->
            array.optString(i).takeIf { it.isNotBlank() }
        }.distinct().take(LIMIT)
    }.getOrDefault(emptyList())

    fun recordConnected(context: Context, serverId: String) {
        if (serverId.isBlank()) return
        val ids = (listOf(serverId) + recentIds(context)).distinct().take(LIMIT)
        val array = JSONArray()
        ids.forEach { array.put(it) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY, array.toString()).apply()
    }
}
