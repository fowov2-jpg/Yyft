package com.secureconnect.app.vpn

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.secureconnect.app.AppRunController
import com.secureconnect.app.data.local.ServerStore
import com.secureconnect.app.data.local.WorkingServerStore
import com.secureconnect.app.data.local.SlowStandbyStore
import com.secureconnect.app.data.model.Server
import com.secureconnect.app.data.model.ServerQualityHints
import com.secureconnect.app.data.remote.ServerRepository
import com.secureconnect.app.data.source.ConfigSources
import com.secureconnect.app.util.ResourceGovernor
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.CoroutineScope

/** One process-wide scanner, leased by UI and by the foreground VPN service. */
object ServerScanner {
    data class Status(val running: Boolean = false, val message: String = "", val checked: Int = 0)
    private data class Attempt(val nextAt: Long, val failures: Int = 0, val pendingFinal: Boolean = false)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val owners = mutableSetOf<Any>()
    private val attempts = mutableMapOf<String, Attempt>()
    private val _status = MutableStateFlow(Status())
    val status = _status.asStateFlow()
    private val _catalogueStatus = MutableStateFlow("Ожидаю первоначальную загрузку…")
    val catalogueStatus = _catalogueStatus.asStateFlow()
    private val _hotSpeedStatus = MutableStateFlow("Отключено: поиск резерва по событию")
    val hotSpeedStatus = _hotSpeedStatus.asStateFlow()
    private var job: Job? = null
    private var cloudJob: Job? = null
    private var publicFeedJob: Job? = null
    private var generation = 0L
    private var requestGeneration = 0L
    private val scanWake = Channel<Unit>(Channel.CONFLATED)
    private val catalogueWake = Channel<Unit>(Channel.CONFLATED)
    private var lastHotSignalAtMs = 0L
    @Volatile private var rescueUntilMs = 0L
    @Volatile private var lastRescueAtMs = 0L
    private var lastRefillWindowAtMs = 0L
    private var refillUntilMs = 0L

    private fun discoveryAllowed(context: Context): Boolean {
        val state = VpnController.state.value
        val certified = WorkingServerStore.activeRecords(context)
        val ready = certified.size
        val differentSources = certified.map { it.server.source }.filter { it.isNotBlank() }.distinct().size
        val needsDiversity = ScannerDutyPolicy.needsSourceDiversity(state, ready, differentSources)
        val now = System.currentTimeMillis()
        // Never run continuous standalone Xray probes on a mobile battery.
        // Refill a depleted pool for 75 seconds, then cool down 15 minutes.
        if (state == VpnState.Connected &&
            (ready < ScannerDutyPolicy.CONNECTED_POOL_TARGET || needsDiversity) &&
            (lastRefillWindowAtMs == 0L || now < lastRefillWindowAtMs ||
                now - lastRefillWindowAtMs >= ScannerDutyPolicy.CONNECTED_REFILL_INTERVAL_MS)) {
            lastRefillWindowAtMs = now
            refillUntilMs = now + ScannerDutyPolicy.CONNECTED_REFILL_WINDOW_MS
        }
        return ScannerDutyPolicy.allowDiscovery(
            state,
            ScannerUiVisibility.visible,
            now < rescueUntilMs,
            if (needsDiversity) minOf(ready, ScannerDutyPolicy.CONNECTED_POOL_TARGET - 1) else ready,
            now < refillUntilMs
        )
    }

    /**
     * A failed video/route check may trigger one short rescue search.
     * Repeated CDN errors must not keep the phone scanning continuously.
     */
    fun requestRecoveryWindow(force: Boolean = false) {
        val now = System.currentTimeMillis()
        if (force || lastRescueAtMs == 0L || now < lastRescueAtMs ||
            now - lastRescueAtMs >= ScannerDutyPolicy.RESCUE_COOLDOWN_MS) {
            lastRescueAtMs = now
            rescueUntilMs = now + ScannerDutyPolicy.RESCUE_WINDOW_MS
        }
        request()
    }

    private suspend fun awaitScan(timeoutMs: Long) {
        withTimeoutOrNull(timeoutMs) { scanWake.receive() }
    }
    private suspend fun awaitCatalogue(timeoutMs: Long) {
        withTimeoutOrNull(timeoutMs) { catalogueWake.receive() }
    }

    // acquire/release/request are called from Activity/ViewModel/service main thread.
    fun acquire(owner: Any, context: Context) {
        ServerRepository.configure(context.applicationContext)
        val prefs = context.getSharedPreferences(ServerStore.SETTINGS_PREFS, Context.MODE_PRIVATE)
        if (prefs.getInt("source_catalogue_revision", 0) < ConfigSources.CATALOGUE_REVISION) {
            prefs.edit().putInt("source_catalogue_revision", ConfigSources.CATALOGUE_REVISION)
                .putLong(ServerStore.CATALOGUE_ATTEMPT_KEY, 0L).apply()
        }
        owners.add(owner)
        // One bounded public feed GET on launch; never wait for it before Xray.
        if (PublicRankingFeed.validEndpoint(PublicRankingFeed.endpoint(context)) &&
            publicFeedJob?.isActive != true) {
            publicFeedJob = scope.launch {
                if (PublicRankingFeed.refreshIfDue(context.applicationContext)) scanWake.trySend(Unit)
            }
        }
        if (job?.isActive == true) return
        val token = ++generation
        job = scope.launch {
            try {
                coroutineScope {
                    launch { refreshCatalogue(context.applicationContext) }
                    launch {
                        WorkingServerStore.revision.collect {
                            scanWake.trySend(Unit)
                            catalogueWake.trySend(Unit)
                        }
                    }
                    // A newly rotated catalogue must wake an exhausted scanner immediately.
                    launch { ServerStore.revision.collect { scanWake.trySend(Unit) } }
                    // State changes, not a timer, wake the scanner when a VPN
                    // falls into Blocked or returns to a healthy Connected state.
                    launch {
                        VpnController.state.collect {
                            scanWake.trySend(Unit)
                            catalogueWake.trySend(Unit)
                        }
                    }
                    // No permanently running secondary Xray probes or hot-reserve
                    // speed loops. Saved quality history drives failover; a real
                    // failure may request one bounded on-demand discovery window.
                    run(context.applicationContext)
                }
            } finally {
                if (generation == token) _status.value = Status(message = "Проверка остановлена")
            }
        }
    }

    fun stopAll() {
        owners.clear()
        generation++
        requestGeneration++
        rescueUntilMs = 0L
        lastRescueAtMs = 0L
        lastRefillWindowAtMs = 0L
        refillUntilMs = 0L
        cloudJob?.cancel()
        cloudJob = null
        publicFeedJob?.cancel()
        publicFeedJob = null
        job?.cancel()
        job = null
        attempts.clear()
        scanWake.trySend(Unit)
        catalogueWake.trySend(Unit)
        HotReserveTracker.reset()
        _hotSpeedStatus.value = "Остановлено"
        _status.value = Status(message = "Проверка остановлена: приложение закрыто")
        _catalogueStatus.value = "Загрузка остановлена: приложение закрыто"
    }

    fun release(owner: Any) {
        owners.remove(owner)
        if (owners.isEmpty()) {
            cloudJob?.cancel()
            cloudJob = null
            publicFeedJob?.cancel()
            publicFeedJob = null
            job?.cancel()
            job = null
        }
    }

    /** Called by Guardian on first poor health sample; no expensive quality sweep. */
    fun urgentHotRefresh() {
        val now = System.currentTimeMillis()
        if (now - lastHotSignalAtMs >= 30_000L || lastHotSignalAtMs > now) {
            lastHotSignalAtMs = now
            requestRecoveryWindow()
        }
    }

    /**
     * On returning to the app, refresh stale subscription metadata without
     * immediately launching 100 heavyweight native Xray probe instances.
     */
    fun requestUiRefresh(context: Context) {
        val prefs = context.getSharedPreferences(ServerStore.SETTINGS_PREFS, Context.MODE_PRIVATE)
        val last = prefs.getLong(ServerStore.CATALOGUE_ATTEMPT_KEY, 0L)
        val now = System.currentTimeMillis()
        if (last <= 0L || last > now || now - last >= 20L * 60_000L) {
            prefs.edit().putLong(ServerStore.CATALOGUE_ATTEMPT_KEY, 0L).apply()
        }
        if (PublicRankingFeed.validEndpoint(PublicRankingFeed.endpoint(context)) &&
            publicFeedJob?.isActive != true) {
            publicFeedJob = scope.launch {
                if (PublicRankingFeed.refreshIfDue(context.applicationContext)) scanWake.trySend(Unit)
            }
        }
        catalogueWake.trySend(Unit)
        scanWake.trySend(Unit)
    }

    fun request(force: Boolean = false) {
        if (force) {
            requestGeneration++
            attempts.clear()
            // Explicit refresh/search must bypass the passive eco sleep.
            rescueUntilMs = System.currentTimeMillis() + ScannerDutyPolicy.RESCUE_WINDOW_MS
        }
        scanWake.trySend(Unit)
        catalogueWake.trySend(Unit)
    }

    fun currentPhysicalNetworkKey(context: Context): String? = networkKey(context)

    private fun networkKey(context: Context): String? {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return null
        fun usable(network: android.net.Network): Boolean {
            val caps = cm.getNetworkCapabilities(network) ?: return false
            return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
        }
        val network = cm.activeNetwork?.takeIf(::usable) ?: cm.allNetworks.firstOrNull(::usable)
        return network?.toString()
    }

    private suspend fun refreshCatalogue(context: Context) {
        val prefs = context.getSharedPreferences(ServerStore.SETTINGS_PREFS, Context.MODE_PRIVATE)
        var previousVerifiedCount: Int? = null
        var failureCount = 0
        var lastFailureAtMs = 0L
        while (currentCoroutineContext().isActive && AppRunController.mayRun(context)) {
            try {
                if (!ScannerDutyPolicy.allowCatalogue(
                        VpnController.state.value, ScannerUiVisibility.visible,
                        System.currentTimeMillis() < rescueUntilMs,
                        ServerStore.loadCached(context).isEmpty())) {
                    _catalogueStatus.value = "Ожидаю завершения подключения · каталог сохранён"
                    awaitCatalogue(ScannerDutyPolicy.QUIET_SLEEP_MS)
                    continue
                }
                val state = VpnController.state.value
                val network = networkKey(context)
                if (network != null && !ResourceGovernor.isMemoryPressured(context) &&
                    (ReserveScanPolicy.canLaunch(state, true, false) ||
                        (state == VpnState.Connecting &&
                            (System.currentTimeMillis() < rescueUntilMs ||
                                ServerStore.loadCached(context).isEmpty())))) {
                    val cached = ServerStore.loadCached(context)
                    val lastSuccess = prefs.getLong(ServerStore.CATALOGUE_ATTEMPT_KEY, 0L)
                    val now = System.currentTimeMillis()
                    val verified = WorkingServerStore.activeIds(context).size
                    // A proven reserve disappearing is an event, not a reason to wait
                    // for the next 45-minute regular source rotation.
                    if (previousVerifiedCount != null && verified < previousVerifiedCount &&
                        verified < WorkingPoolPolicy.MAX_VERIFIED) {
                        prefs.edit().putLong(ServerStore.CATALOGUE_ATTEMPT_KEY, 0L).apply()
                    }
                    previousVerifiedCount = verified
                    val power = BatteryAwareRuntime.read(context)
                    val enoughForPower = verified >= BatteryAwarePolicy.discoveryTarget(
                        power.interactive, power.powerSave, power.charging, power.unmetered,
                        WorkingPoolPolicy.MAX_VERIFIED
                    )
                    if (CatalogueRefreshPolicy.isDue(now, cached.size, lastSuccess,
                            lastFailureAtMs, failureCount, verified,
                            adequateBackups = enoughForPower)) {
                        val disabled = prefs.getStringSet("disabled_sources", emptySet()).orEmpty()
                        val preferredSources = WorkingServerStore.preferredSourceNames(context)
                        val sources = ConfigSources.all.map { it.copy(enabled = it.id !in disabled) }
                            .sortedWith(compareBy<com.secureconnect.app.data.source.ConfigSource> {
                                SourceHistoryPolicy.rank(it.name, preferredSources)
                            }.thenBy { it.id })
                        if (sources.any { it.enabled }) {
                            _catalogueStatus.value = "Загружаю VPN-конфигурации: ${cached.size}/${ServerStore.MAX_CACHED_SERVERS}…"
                            // Fast first-install stage: sources with a single URL can
                            // populate the screen while the full catalogue is still loading.
                            // Never invent endpoints to satisfy the 240-slot upper bound.
                            if (cached.isEmpty()) {
                                val bootstrapSources = sources.filter {
                                    it.enabled && (it.urls.size == 1 || it.name in preferredSources)
                                }.sortedWith(compareBy<com.secureconnect.app.data.source.ConfigSource> {
                                    SourceHistoryPolicy.rank(it.name, preferredSources)
                                }.thenBy { if (it.id == "amir") 0 else 1 }).take(4)
                                if (bootstrapSources.isNotEmpty()) {
                                    val bootstrap = ServerRepository.refresh(bootstrapSources,
                                        perSourceLimit = ServerStore.MAX_CACHED_SERVERS,
                                        workDispatcher = ResourceGovernor.dispatcher,
                                        probeBeforeScan = false,
                                        preferredSources = preferredSources)
                                    currentCoroutineContext().ensureActive()
                                    if (bootstrap.servers.isNotEmpty()) {
                                        ServerStore.saveCached(context, bootstrap.servers)
                                        _catalogueStatus.value = "Первичная загрузка: ${bootstrap.servers.size}/${ServerStore.MAX_CACHED_SERVERS} · продолжаю пополнение"
                                    }
                                }
                            }
                            // Import first; independently test reachability in the ongoing scanner.
                            // Requiring Xray before importing would leave first-install users empty.
                            val sourcePage = prefs.getInt("catalogue_source_page_v1", 0).coerceAtLeast(0)
                            val result = ServerRepository.refresh(sources,
                                workDispatcher = ResourceGovernor.dispatcher,
                                probeBeforeScan = false,
                                sourcePage = sourcePage,
                                preferredSources = preferredSources)
                            currentCoroutineContext().ensureActive()
                            if (result.servers.isNotEmpty()) {
                                // Do not evict recently proven configs just because a
                                // public subscription rotates its first 100 entries.
                                val proven = WorkingServerStore.activeRecords(context).map { it.server } +
                                    WorkingServerStore.historicalRecoveryRecords(context).take(8).map { it.server }
                                val combined = (proven + result.servers + ServerStore.loadCached(context))
                                    .distinctBy { it.id }.take(ServerStore.MAX_CACHED_SERVERS)
                                ServerStore.saveCached(context, combined)
                                // Cloud verification is opt-in. Never transmit manually imported
                                // or private configurations; only items from public feeds.
                                // Backend results are priorities, NOT evidence of local reachability.
                                if (CloudVerifier.isConfigured(context)) {
                                    cloudJob?.cancel()
                                    cloudJob = CoroutineScope(currentCoroutineContext()).launch {
                                        val ids = CloudVerifier.verifyPublicCandidates(context, result.servers)
                                        if (ids.isNotEmpty()) {
                                            CloudVerifier.rememberPriorities(context, ids)
                                            scanWake.trySend(Unit)
                                        }
                                    }
                                }
                                // Static GitHub Pages GET is separate from the old opt-in
                                // POST/Bearer verifier. Never block catalogue or VPN start.
                                if (PublicRankingFeed.validEndpoint(PublicRankingFeed.endpoint(context)) &&
                                    publicFeedJob?.isActive != true) {
                                    publicFeedJob = CoroutineScope(currentCoroutineContext()).launch {
                                        if (PublicRankingFeed.refreshIfDue(context)) scanWake.trySend(Unit)
                                    }
                                }
                                prefs.edit().putInt("catalogue_source_page_v1", if (sourcePage >= 1_000_000) 0 else sourcePage + 1).apply()
                                failureCount = 0
                                lastFailureAtMs = 0L
                                _catalogueStatus.value = "Каталог обновлён: ${combined.size}/${ServerStore.MAX_CACHED_SERVERS} · отбор резервов по необходимости"
                            } else {
                                failureCount++
                                lastFailureAtMs = System.currentTimeMillis()
                                _catalogueStatus.value = "Источники временно недоступны · повторю загрузку"
                            }
                        } else {
                            _catalogueStatus.value = "Все источники отключены"
                        }
                    } else {
                        // A cached list is not an in-progress scan. Until the next
                        // network refresh report its actual state, not stale text.
                        _catalogueStatus.value = "Каталог актуален: ${cached.size}/${ServerStore.MAX_CACHED_SERVERS} · проверка резервов отдельно"
                    }
                } else if (network == null) {
                    _catalogueStatus.value = "Нет сети · загрузка продолжится автоматически"
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                failureCount++
                lastFailureAtMs = System.currentTimeMillis()
                _catalogueStatus.value = "Не удалось загрузить источники: ${e.message?.take(80) ?: "ошибка сети"} · повторю"
            }
            // No five-second polling when catalogue is full; wake immediately for a deficit.
            awaitCatalogue(if (ServerStore.loadCached(context).size >= ServerStore.MAX_CACHED_SERVERS)
                10L * 60_000L else 60_000L)
        }
    }

    // Background hot-reserve probes intentionally removed. Only the on-demand
    // scanner refills quality history after a connection failure or quality event.

    private suspend fun run(context: Context) = coroutineScope {
        val inFlight = mutableMapOf<String, Job>()
        var previousNetwork: String? = null
        var networkEpoch = 0L
        var handledRequest = requestGeneration
        var checked = 0
        val checkedInNetwork = mutableSetOf<String>()
        val forcedStandby = mutableSetOf<String>()
        var lastShortfallWake = 0L
        var lastUnderfilledAuditAtMs = 0L
        while (currentCoroutineContext().isActive && AppRunController.mayRun(context)) {
            try {
                if (!discoveryAllowed(context)) {
                    // Cancel even unfinished standalone Xray probes when an
                    // established VPN no longer needs discovery.
                    inFlight.values.forEach { it.cancel() }
                    inFlight.clear()
                    _status.value = Status(false, "Эко-режим · VPN работает, резервный поиск на паузе между окнами", checked)
                    awaitScan(ScannerDutyPolicy.QUIET_SLEEP_MS)
                    continue
                }
                if (handledRequest != requestGeneration) {
                    handledRequest = requestGeneration
                    attempts.clear()
                    checkedInNetwork.clear()
                    forcedStandby.clear()
                    forcedStandby.addAll(SlowStandbyStore.entries(context).map { it.server.id })
                }
                inFlight.entries.removeAll { it.value.isCompleted }
                val readyCount = WorkingServerStore.activeIds(context).size
                val stateForBudget = VpnController.state.value
                val power = BatteryAwareRuntime.read(context)
                val budgetedTarget = BatteryAwarePolicy.discoveryTarget(
                    power.interactive, power.powerSave, power.charging, power.unmetered,
                    WorkingPoolPolicy.MAX_VERIFIED)
                // Preserve immediate recovery and basic reserves. Once a small
                // verified pool exists on battery, expensive catalogue probing sleeps.
                val certifiedTarget = ScannerDutyPolicy.targetCertifiedRoutes(
                    stateForBudget, budgetedTarget)
                val certifiedSources = WorkingServerStore.activeRecords(context)
                    .map { it.server.source }.filter { it.isNotBlank() }.distinct().size
                val needsDiverseReserve = ScannerDutyPolicy.needsSourceDiversity(
                    stateForBudget, readyCount, certifiedSources)
                if ((stateForBudget == VpnState.Connected || stateForBudget == VpnState.Idle) &&
                    readyCount >= certifiedTarget && !needsDiverseReserve &&
                    System.currentTimeMillis() >= rescueUntilMs) {
                    _status.value = Status(false,
                        "Эко-режим · проверенных маршрутов: $readyCount · поиск резерва спит", checked)
                    awaitScan(BatteryAwarePolicy.DISCOVERY_PAUSE_MS)
                    continue
                }
                if (readyCount >= WorkingPoolPolicy.MAX_VERIFIED) {
                    // Full pool: STOP catalogue discovery, but audit one reserve at a
                    // time every 45 min. Renew full speed/YouTube quality before 12h TTL.
                    val stateNow = VpnController.state.value
                    val pressured = ResourceGovernor.isMemoryPressured(context)
                    val candidate = if (pressured || stateNow == VpnState.Connecting ||
                        stateNow == VpnState.Validating) null else {
                        val now = System.currentTimeMillis()
                        val liveId = VpnController.activeServer.value?.id
                        WorkingServerStore.activeRecords(context)
                            .filter { it.server.id != liveId &&
                                (WorkingPoolPolicy.backupAuditDue(now, it.lastAuditAtMs) ||
                                 WorkingPoolPolicy.qualityRenewalDue(now, it.speedVerifiedAtMs)) &&
                                (attempts[it.server.id]?.nextAt ?: 0L) <= now }
                            .minByOrNull { it.lastAuditAtMs.takeIf { at -> at > 0 } ?: 0L }
                    }
                    if (candidate == null || !XrayCore.isAvailable()) {
                        _status.value = Status(false,
                            "Резерв $readyCount/${WorkingPoolPolicy.MAX_VERIFIED} · аудит 45 мин · автопоиск спит", checked)
                        val nowSleep = System.currentTimeMillis()
                        val liveId = VpnController.activeServer.value?.id
                        val nextAuditMs = WorkingServerStore.activeRecords(context)
                            .filter { it.server.id != liveId }
                            .flatMap { listOf(
                                it.lastAuditAtMs + WorkingPoolPolicy.BACKUP_AUDIT_INTERVAL_MS,
                                it.speedVerifiedAtMs + WorkingPoolPolicy.QUALITY_RENEWAL_START_MS) }
                            .filter { it > nowSleep }.minOrNull()
                        awaitScan((nextAuditMs?.minus(nowSleep) ?: WorkingPoolPolicy.FULL_POOL_SLEEP_MS)
                            .coerceIn(10_000L, 45L * 60_000L))
                        continue
                    }
                    val networkBefore = networkKey(context)
                    if (networkBefore == null) {
                        awaitScan(WorkingPoolPolicy.FULL_POOL_SLEEP_MS)
                        continue
                    }
                    val atStart = System.currentTimeMillis()
                    val renew = WorkingPoolPolicy.qualityRenewalDue(atStart, candidate.speedVerifiedAtMs)
                    _status.value = Status(true,
                        "Аудит резерва · ${if (renew) "повторное качество" else "HTTPS"} · ${candidate.server.country}", checked)
                    val result = try {
                        if (renew) ServerPrechecker.check(context, candidate.server,
                            allowAlternate = true, finalAttempt = true)
                        else XrayCore.DelayResult(if (ReserveHealthProbe.check(context, candidate.server)) 1 else null)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (_: Exception) {
                        XrayCore.DelayResult(null, "Ошибка проверки")
                    }
                    currentCoroutineContext().ensureActive()
                    if (networkKey(context) == networkBefore) {
                        val at = System.currentTimeMillis()
                        val ok = if (renew) result.ms != null && result.youtubePassed &&
                            result.speedVerified && WorkingPoolPolicy.qualifiesRtt(result.connectMs)
                            else result.ms != null
                        if (ok) {
                            if (renew) WorkingServerStore.recordSuccess(context, candidate.server,
                                result.connectMs!!, result.ms!!, at, youtubeVerified = true,
                                speedVerified = true, downloadMbps = result.downloadMbps,
                                uploadMbps = result.uploadMbps)
                            else WorkingServerStore.recordAuditSuccess(context, candidate.server.id, at)
                            attempts.remove(candidate.server.id)
                        } else {
                            // Two independent audit failures before demotion.
                            val prior = attempts[candidate.server.id]?.failures ?: 0
                            if (prior >= 1 && result.retryAfterMs == null) {
                                WorkingServerStore.recordFailure(context, candidate.server.id, at)
                                catalogueWake.trySend(Unit)
                            }
                            attempts[candidate.server.id] = Attempt(at +
                                (result.retryAfterMs ?: 3L * 60_000L), prior + 1)
                        }
                    }
                    // Spread a 20-node audit across time. Do not launch a burst
                    // of 20 TLS checks in the same minute after app resume.
                    awaitScan(90_000L)
                    continue
                }
                val state = VpnController.state.value
                val network = networkKey(context)
                val pressure = ResourceGovernor.isMemoryPressured(context)
                val emergencySearch = state == VpnState.Connecting &&
                    System.currentTimeMillis() < rescueUntilMs
                if (!XrayCore.isAvailable() ||
                    (network == null || pressure ||
                        (!ReserveScanPolicy.canLaunch(state, true, false) && !emergencySearch))) {
                    _status.value = Status(true, when {
                        network == null -> "Ожидаю сеть · сохранённая база остаётся"
                        !XrayCore.isAvailable() -> "Ожидаю ядро Xray"
                        pressure -> "Пауза из-за памяти · продолжу автоматически"
                        else -> "Подключение/переключение · затем продолжу резерв"
                    }, checked)
                    awaitScan(30_000L)
                    continue
                }
                if (network != previousNetwork) {
                    if (network != null) DeadCandidateStore.syncNetwork(context, network)
                    previousNetwork = network
                    networkEpoch++
                    checkedInNetwork.clear()
                    attempts.clear() // Retry failures on the new underlay; do not recheck all healthy backups.
                }
                // A partial pool must also audit its existing reserves every 45 min.
                // Allocate at most one maintenance slot each 3 minutes while we
                // primarily focus on finding missing new candidates.
                val nowAudit = System.currentTimeMillis()
                if (readyCount < WorkingPoolPolicy.MAX_VERIFIED &&
                    nowAudit - lastUnderfilledAuditAtMs >= 3L * 60_000L) {
                    val currentId = VpnController.activeServer.value?.id
                    val dueAudit = WorkingServerStore.activeRecords(context)
                        .filter { it.server.id != currentId &&
                            (WorkingPoolPolicy.backupAuditDue(nowAudit, it.lastAuditAtMs) ||
                             WorkingPoolPolicy.qualityRenewalDue(nowAudit, it.speedVerifiedAtMs)) &&
                            (attempts[it.server.id]?.nextAt ?: 0L) <= nowAudit }
                        .minByOrNull { it.lastAuditAtMs }
                    if (dueAudit != null) {
                        lastUnderfilledAuditAtMs = nowAudit
                        val renew = WorkingPoolPolicy.qualityRenewalDue(nowAudit, dueAudit.speedVerifiedAtMs)
                        val audit = if (renew) ServerPrechecker.check(context, dueAudit.server,
                            allowAlternate = true, finalAttempt = true)
                            else XrayCore.DelayResult(if (ReserveHealthProbe.check(context, dueAudit.server)) 1 else null)
                        currentCoroutineContext().ensureActive()
                        if (networkKey(context) == network) {
                            val at = System.currentTimeMillis()
                            val success = if (renew) audit.ms != null && audit.youtubePassed &&
                                audit.speedVerified && WorkingPoolPolicy.qualifiesRtt(audit.connectMs)
                                else audit.ms != null
                            if (success) {
                                if (renew) WorkingServerStore.recordSuccess(context,
                                    dueAudit.server, audit.connectMs!!, audit.ms!!, at,
                                    youtubeVerified = true, speedVerified = true,
                                    downloadMbps = audit.downloadMbps, uploadMbps = audit.uploadMbps)
                                else WorkingServerStore.recordAuditSuccess(context, dueAudit.server.id, at)
                                attempts.remove(dueAudit.server.id)
                            } else {
                                val prior = attempts[dueAudit.server.id]?.failures ?: 0
                                if (prior >= 1 && audit.retryAfterMs == null) {
                                    WorkingServerStore.recordFailure(context, dueAudit.server.id, at)
                                    catalogueWake.trySend(Unit)
                                }
                                attempts[dueAudit.server.id] = Attempt(at +
                                    (audit.retryAfterMs ?: 3L * 60_000L), prior + 1)
                            }
                        }
                        awaitScan(2_000L)
                        continue
                    }
                }
                val records = WorkingServerStore.savedRecords(context).associateBy { it.server.id }
                val cached = ServerStore.loadCached(context)
                val latest = cached.associateBy { it.id }
                val standbyEntries = SlowStandbyStore.entries(context)
                val standbyById = standbyEntries.associateBy { it.server.id }
                val savedWithCurrentLabels = records.values.map { record ->
                    val fresh = latest[record.server.id]
                    if (fresh == null) record.server else record.server.copy(
                        reportedPingMs = fresh.reportedPingMs,
                        reportedLoadPercent = fresh.reportedLoadPercent,
                        rawLink = fresh.rawLink)
                }
                val catalogue = (savedWithCurrentLabels + standbyEntries.map { it.server } + cached)
                    .distinctBy { it.id }
                    .filter { WorkingPoolPolicy.eligible(it) && XrayConfigBuilder.buildProbe(it) != null }
                val ids = catalogue.mapTo(HashSet()) { it.id }
                attempts.keys.retainAll(ids)
                checkedInNetwork.retainAll(ids)
                val now = System.currentTimeMillis()
                val currentId = if (state == VpnState.Connected) VpnController.activeServer.value?.id else null
                val activeIds = WorkingServerStore.activeIds(context)
                val preferredForScan = WorkingServerStore.preferredSourceNames(context)
                val cloudSuggestedIds = CloudVerifier.recommendedIds(context)
                val publishedRanks = PublicRankingFeed.priorities(context, catalogue)
                val liveSourceSet = WorkingServerStore.activeRecords(context)
                    .map { it.server.source }.filter { it.isNotBlank() }.toSet()
                val prioritizeNewSource = ScannerDutyPolicy.needsSourceDiversity(
                    state, activeIds.size, liveSourceSet.size)
                val temporarilyRejected = DeadCandidateStore.coolingIds(context)
                val due = catalogue.filter { candidate ->
                    val record = records[candidate.id]
                    TlsRiskStore.eligibleForAutomaticUse(context, candidate.id) &&
                    candidate.id != currentId && candidate.id !in inFlight &&
                        candidate.id !in temporarilyRejected &&
                        !WorkingPoolPolicy.failedCoolingDown(now,
                            record?.lastFailureAtMs ?: 0L, record?.failures ?: 0) &&
                        // Never probe a verified member on a timer just to refresh the timestamp.
                        candidate.id !in activeIds &&
                        ServerPrechecker.ready(candidate) &&
                        ReserveScanPolicy.due(now,
                            records[candidate.id]?.lastSuccessAtMs?.takeIf { candidate.id in checkedInNetwork },
                            attempts[candidate.id]?.nextAt) &&
                        (candidate.id in forcedStandby || standbyById[candidate.id]?.let {
                            SlowStandbyPolicy.due(now, it.checkedAtMs)
                        } ?: true)
                }.sortedWith(compareBy<Server> {
                    ReserveScanPolicy.priority(it.id in records, attempts[it.id]?.pendingFinal == true)
                }.thenBy {
                    // When all verified nodes come from one source, test other
                    // source families first within the SAME saved/new tier.
                    if (prioritizeNewSource && it.source in liveSourceSet) 1 else 0
                }.thenBy {
                    // Fresh server-specific evidence first; never counts as locally proven.
                    if (it.id in publishedRanks) 0 else 1
                }.thenBy {
                    publishedRanks[it.id] ?: Int.MAX_VALUE
                }.thenBy {
                    if (it.id in cloudSuggestedIds) 0 else 1
                }.thenBy {
                    SourceHistoryPolicy.rank(it.source, preferredForScan)
                }.thenBy { ReserveScanPolicy.latencyPriority(it.ping) }
                    .thenBy { ServerQualityHints.loadPriority(it) }
                    .thenBy { if (it.ping > 0) it.ping else Int.MAX_VALUE }
                    .thenBy { attempts[it.id]?.nextAt ?: records[it.id]?.lastSuccessAtMs ?: 0L })
                    .let { ranked ->
                        // Preserve saved-before-new and fast-before-final tiers,
                        // then alternate sources to avoid scanning 50 dead configs
                        // from the same once-successful subscription in a row.
                        ranked.groupBy {
                            Triple(
                                ReserveScanPolicy.priority(it.id in records,
                                    attempts[it.id]?.pendingFinal == true),
                                if (prioritizeNewSource && it.source in liveSourceSet) 1 else 0,
                                if (it.id in publishedRanks) 0 else 1
                            )
                        }.values.flatMap { tier ->
                                SourceHistoryPolicy.interleave(tier) { it.source }
                            }
                    }

                if (due.isEmpty()) {
                    // Candidates may be exhausted or cooling down; don't claim there are
                    // no sources. Rotate the remote 240-slot window on the next due refresh.
                    if (inFlight.isEmpty() &&
                        (lastShortfallWake == 0L || now - lastShortfallWake >= 3L * 60_000L)) {
                        lastShortfallWake = now
                        // Exhausted this 100-config window: rotate sources now rather
                        // than waiting 45min for the normal maintenance refresh.
                        context.getSharedPreferences(ServerStore.SETTINGS_PREFS, Context.MODE_PRIVATE)
                            .edit().putLong(ServerStore.CATALOGUE_ATTEMPT_KEY, 0L).apply()
                        catalogueWake.trySend(Unit)
                    }
                    val paused = attempts.values.count { it.nextAt > now }
                    val nextDue = attempts.values.map { it.nextAt }.filter { it > now }.minOrNull()
                    val waitMs = nextDue?.let { (it - now).coerceIn(10_000L, 60_000L) } ?: 60_000L
                    _status.value = Status(false,
                        "Пул $readyCount/${WorkingPoolPolicy.MAX_VERIFIED} · кандидаты: ${catalogue.size}/${cached.size} · отложены: $paused · проверено: $checked · продолжаю", checked)
                    awaitScan(if (inFlight.isNotEmpty()) 5_000L else waitMs)
                    continue
                }
                // Connected VPN keeps its own live core and health workers.
                // Use one low-priority standalone probe while it is running.
                val workers = ReserveScanPolicy.workerCount(state, VpnController.activeServer.value != null)
                val token = requestGeneration
                val epoch = networkEpoch
                due.filter { TlsRiskStore.eligibleForAutomaticUse(context, it.id) }
                    .distinctBy { it.host.lowercase(java.util.Locale.ROOT) }.take((workers - inFlight.size).coerceAtLeast(0)).forEach { candidate ->
                    forcedStandby.remove(candidate.id) // a forced audit happens only once per request
                    inFlight[candidate.id] = launch {
                        try {
                            val saved = records[candidate.id]
                            val prior = attempts[candidate.id]
                            val finalAttempt = saved != null || prior?.pendingFinal == true
                            _status.value = Status(true,
                                "Проверка резерва · Кандидатов: ${catalogue.size} · Проверено: $checked · задержка влияет на рейтинг", checked)
                            val result = ServerPrechecker.check(context, candidate,
                                alternate = prior?.pendingFinal == true,
                                allowAlternate = saved != null,
                                finalAttempt = finalAttempt)
                            currentCoroutineContext().ensureActive()
                            // Loss/change of underlay is not evidence against a server.
                            if (networkKey(context) != network || token != requestGeneration || epoch != networkEpoch) return@launch
                            if (WorkingServerStore.activeIds(context).size >= WorkingPoolPolicy.MAX_VERIFIED) return@launch
                            val at = System.currentTimeMillis()
                            checked++
                            checkedInNetwork.add(candidate.id)
                            val ms = result.ms
                            if (ms != null && TlsRiskStore.eligibleForAutomaticUse(context, candidate.id) &&
                                WorkingPoolPolicy.qualifiesRtt(result.connectMs) &&
                                result.youtubePassed && result.speedVerified) {
                                WorkingServerStore.recordSuccess(context, candidate,
                                    result.connectMs!!, ms, at, youtubeVerified = true,
                                    speedVerified = result.speedVerified, downloadMbps = result.downloadMbps,
                                    uploadMbps = result.uploadMbps)
                                DeadCandidateStore.clear(context, candidate.id)
                                SlowStandbyStore.remove(context, candidate.id)
                                attempts[candidate.id] = Attempt(at + ReserveScanPolicy.RECHECK_MS)
                            } else if (SlowStandbyPolicy.shouldPark(ms, result.connectMs, result.youtubePassed)) {
                                SlowStandbyStore.park(context, candidate, result.connectMs!!, at)
                                WorkingServerStore.demoteSpeedQuality(context, candidate.id)
                                attempts[candidate.id] = Attempt(at + SlowStandbyPolicy.RECHECK_MS)
                            } else if (result.retryAfterMs != null) {
                                // A control site's restriction does not prove the VPN is dead.
                                attempts[candidate.id] = Attempt(at + result.retryAfterMs,
                                    prior?.failures ?: 0, prior?.pendingFinal == true)
                            } else if (!finalAttempt) {
                                attempts[candidate.id] = Attempt(at, pendingFinal = true)
                            } else {
                                WorkingServerStore.recordFailure(context, candidate.id, at)
                                // Only a full/repeated failure qualifies for temporary
                                // quarantine. No permanent ban on public nodes.
                                // Two full failures on this underlay, not a
                                // single timeout, are needed before deferring it.
                                if ((prior?.failures ?: 0) >= 1) {
                                    DeadCandidateStore.quarantine(context, candidate.id,
                                        videoOnly = DeadCandidateStore.videoOnlyFailure(result.error), nowMs = at)
                                }
                                val failures = (prior?.failures ?: 0) + 1
                                attempts[candidate.id] = Attempt(at + ReserveScanPolicy.retryDelayMs(failures), failures)
                            }
                        } catch (e: CancellationException) {
                            throw e
                        } catch (_: Exception) {
                            // Isolate one broken candidate without cancelling other slots.
                            if (token == requestGeneration && epoch == networkEpoch && networkKey(context) == network)
                                attempts[candidate.id] = Attempt(System.currentTimeMillis() + ReserveScanPolicy.RECHECK_MS)
                        }
                    }.also { probeJob ->
                        probeJob.invokeOnCompletion { scanWake.trySend(Unit) }
                    }
                }
                awaitScan(5_000L) // Wake early when a probe finishes or pool changes.
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _status.value = Status(true, "Повторю проверку после ошибки: ${e.message ?: e.javaClass.simpleName}", checked)
                delay(5_000)
            }
        }
    }
}
