package com.secureconnect.app.data.local

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Encrypts server configurations containing credentials using a non-exportable
 * AndroidKeyStore AES-GCM key. Existing plaintext preferences migrate atomically
 * on first read. No plaintext fallback is used for NEW writes.
 *
 * If the keystore is unavailable, existing plaintext is left untouched rather
 * than destroying a user's only working VPN configuration. New writes fail.
 * Android backup is already disabled for the application.
 */
internal object SensitivePrefs {
    sealed class ReadState {
        data class Value(val text: String) : ReadState()
        object Empty : ReadState()
        object DecryptionError : ReadState()
    }
    @Volatile var storageWarning: String? = null
        private set

    private const val ALIAS = "sc_server_configs_aes_v1"
    private const val SUFFIX = "_sealed_v1"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    private const val IV_BYTES = 12
    private val cache = HashMap<String, Pair<String, String>>()

    @Synchronized
    fun readState(context: Context, prefName: String, key: String): ReadState {
        val prefs = context.getSharedPreferences(prefName, Context.MODE_PRIVATE)
        val stored = prefs.getString(key + SUFFIX, null)
        if (stored != null) {
            val cached = cache["$prefName:$key"]
            if (cached?.first == stored) return ReadState.Value(cached.second)
            return try {
                val value = decrypt(stored)
                cache["$prefName:$key"] = stored to value
                ReadState.Value(value)
            } catch (_: Exception) {
                // Preserve ciphertext for recovery; never replace it with [].
                // No private data is included in this diagnostic flag.
                storageWarning = "Хранилище серверов не расшифровано: $prefName"
                ReadState.DecryptionError
            }
        }
        val legacy = prefs.getString(key, null) ?: return ReadState.Empty
        // Migration is atomic. A failed migration preserves the plaintext copy.
        runCatching { write(context, prefName, key, legacy) }
        return ReadState.Value(legacy)
    }

    @Synchronized
    fun read(context: Context, prefName: String, key: String): String? =
        when (val result = readState(context, prefName, key)) {
            is ReadState.Value -> result.text
            ReadState.Empty, ReadState.DecryptionError -> null
        }

    @Synchronized
    fun write(context: Context, prefName: String, key: String, value: String) {
        val prefs = context.getSharedPreferences(prefName, Context.MODE_PRIVATE)
        // Do not silently overwrite a vault we can no longer decrypt.
        if (prefs.contains(key + SUFFIX) && read(context, prefName, key) == null) {
            error("Existing encrypted configuration cannot be decrypted")
        }
        val ciphertext = encrypt(value)
        check(prefs.edit().putString(key + SUFFIX, ciphertext).remove(key).commit()) {
            "Failed to persist sealed server configuration"
        }
        cache["$prefName:$key"] = ciphertext to value
    }

    private fun secretKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val previous = store.getKey(ALIAS, null) as? SecretKey
        if (previous != null) return previous
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(KeyGenParameterSpec.Builder(ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setRandomizedEncryptionRequired(true)
            .build())
        return gen.generateKey()
    }

    private fun encrypt(text: String): String {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val iv = cipher.iv
        check(iv.size == IV_BYTES)
        return Base64.encodeToString(iv + cipher.doFinal(text.toByteArray(Charsets.UTF_8)),
            Base64.NO_WRAP)
    }

    private fun decrypt(text: String): String {
        val bytes = Base64.decode(text, Base64.NO_WRAP)
        require(bytes.size > IV_BYTES + 15)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, secretKey(),
            GCMParameterSpec(128, bytes.copyOfRange(0, IV_BYTES)))
        return String(cipher.doFinal(bytes.copyOfRange(IV_BYTES, bytes.size)), Charsets.UTF_8)
    }
}
