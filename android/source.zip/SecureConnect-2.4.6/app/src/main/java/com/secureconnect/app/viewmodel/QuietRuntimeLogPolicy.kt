package com.secureconnect.app.viewmodel

/**
 * Event-driven diagnostics rather than a continuous activity feed.
 *
 * INFO events, including routine probes, are intentionally not retained.
 * Relevant warnings/errors are deduplicated in memory and never written
 * to disk by this policy. Android's own logcat and the IDE's LogSender
 * cannot be controlled from an application's source code.
 */
internal class QuietRuntimeLogPolicy(
    private val repeatWindowMs: Long = 120_000L,
    private val maxDedupKeys: Int = 32
) {
    private val lastSeen = LinkedHashMap<String, Long>()

    companion object {
        /** Only actionable service alerts enter the in-memory diagnostic history. */
        fun classifyServiceEvent(message: String): String =
            if (message.contains("TLS риск", ignoreCase = true) ||
                message.contains("подмена HTTPS", ignoreCase = true) ||
                message.contains("Kill Switch активен", ignoreCase = true) ||
                message.startsWith("Автозащита:") ||
                message.startsWith("Guardian: ошибка")
            ) "WARN" else "INFO"
    }

    fun accept(level: String, sanitizedMessage: String, nowMs: Long): Boolean {
        if (level != "WARN" && level != "ERROR") return false
        val key = "$level:$sanitizedMessage"
        val previous = lastSeen[key]
        if (previous != null && nowMs >= previous && nowMs - previous < repeatWindowMs) return false
        lastSeen[key] = nowMs
        while (lastSeen.size > maxDedupKeys) {
            val iterator = lastSeen.keys.iterator()
            if (!iterator.hasNext()) break
            iterator.next()
            iterator.remove()
        }
        return true
    }
}
