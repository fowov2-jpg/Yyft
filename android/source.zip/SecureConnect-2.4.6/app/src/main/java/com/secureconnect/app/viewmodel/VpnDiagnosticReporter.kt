package com.secureconnect.app.viewmodel

import android.content.Context
import com.secureconnect.app.AppRunController
import com.secureconnect.app.data.local.ServerStore
import com.secureconnect.app.data.local.SensitivePrefs
import com.secureconnect.app.data.local.WorkingServerStore
import com.secureconnect.app.data.local.SlowStandbyStore
import com.secureconnect.app.data.model.LogEntry
import com.secureconnect.app.data.model.Server
import com.secureconnect.app.util.ResourceGovernor
import com.secureconnect.app.vpn.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Converts an immutable UI snapshot and current system diagnostics to an exportable text report. */
internal object VpnDiagnosticReporter {
    data class Snapshot(
        val selectedServer: Server?,
        val vpnState: VpnState,
        val connecting: Boolean,
        val connected: Boolean,
        val killSwitch: Boolean,
        val autoConnect: Boolean,
        val autoRecovery: Boolean,
        val readyWorkingCount: Int,
        val catalogueSize: Int,
        val scanStatus: String,
        val connectionMode: ConnectionMode,
        val selectedServerExplicit: Boolean,
        val healthMemory: String,
        val downloadMbps: Float,
        val uploadMbps: Float,
        val vpnError: String?,
        val logs: List<LogEntry>
    )

    fun render(app: Context, data: Snapshot): String {
        val routingStore = AppRoutingStore(app)
        val server = data.selectedServer
        val vpnState = when (val state = data.vpnState) {
            VpnState.Idle -> "Idle"
            VpnState.Connecting -> "Connecting"
            VpnState.Stopping -> "Stopping (waiting for Android TUN close)"
            VpnState.Validating -> "Validating"
            VpnState.Connected -> "Connected"
            VpnState.Blocked -> "Blocked"
            is VpnState.Error -> "Error: ${state.message}"
        }
        val logText = data.logs.joinToString("\n") { entry ->
            "${entry.time} [${entry.level}] ${VpnDiagnosticRedactor.sanitize(entry.message)}"
        }
        return buildString {
            appendLine("SecureConnect diagnostic report")
            appendLine("Generated: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss Z", Locale.US).format(Date())}")
            appendLine("App: ${app.packageName}")
            appendLine("App version: ${app.packageManager.getPackageInfo(app.packageName, 0).versionName}")
            appendLine("Android: ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT})")
            appendLine("Device: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")
            appendLine("ABI: ${android.os.Build.SUPPORTED_ABIS.joinToString(", ")}")
            appendLine("Xray available: ${XrayCore.isAvailable()}")
            appendLine("Xray version: ${XrayCore.versionInfo()}")
            appendLine("VPN state: $vpnState")
            appendLine("Connecting: ${data.connecting}")
            appendLine("Connected: ${data.connected}")
            val lastConnectMs = app.getSharedPreferences("sc_settings", Context.MODE_PRIVATE)
                .getLong("last_connect_elapsed_ms", -1L)
            appendLine("Last successful connect time: ${if (lastConnectMs >= 0L) "${lastConnectMs} ms" else "not measured"}")
            appendLine("Kill switch: ${data.killSwitch}")
            appendLine("Auto connect: ${data.autoConnect}")
            appendLine("Auto recovery: ${data.autoRecovery}")
            appendLine("Verified pool ready: ${data.readyWorkingCount}/${WorkingPoolPolicy.MAX_VERIFIED} (catalogue: ${data.catalogueSize}/${com.secureconnect.app.data.local.ServerStore.MAX_CACHED_SERVERS})")
            appendLine("Battery-first minimum: ${com.secureconnect.app.vpn.ScannerDutyPolicy.CONNECTED_POOL_TARGET} qualified routes including primary (maximum ${WorkingPoolPolicy.MAX_VERIFIED})")
            val qualifiedSources = WorkingServerStore.activeRecords(app)
                .map { it.server.source }.filter { it.isNotBlank() }.distinct()
            appendLine("Qualified source diversity: ${qualifiedSources.size} sources · ${qualifiedSources.joinToString(", ").take(240)}")
            appendLine("Public GitHub ranking URL configured: ${com.secureconnect.app.vpn.PublicRankingFeed.validEndpoint(com.secureconnect.app.vpn.PublicRankingFeed.endpoint(app))}")
            appendLine("Public GitHub feed published: ${com.secureconnect.app.vpn.PublicRankingFeed.lastPublished(app)}")
            appendLine("Public GitHub feed: ${com.secureconnect.app.vpn.PublicRankingFeed.status(app)}")
            appendLine("Cloud-ranked local public candidates (NOT Connected): ${com.secureconnect.app.vpn.PublicRankingFeed.matchedCount(app, com.secureconnect.app.data.local.ServerStore.loadCached(app))}")
            appendLine("Local confirmed routes (independent): ${WorkingServerStore.activeIds(app).size}")
            appendLine("Battery duty: bounded scans, no continuous CDN throughput loop")
            appendLine("Cloud checker configured: ${CloudVerifier.isConfigured(app)} (optional, no built-in third-party site)")
            appendLine("Cloud candidate hints (require local recheck): ${CloudVerifier.recommendedIds(app).size}")
            appendLine("Verified backup count: ${WorkingPoolPolicy.remainingBackups(WorkingServerStore.activeIds(app), VpnController.activeServer.value?.id)}")
            appendLine("Hot standby: ${com.secureconnect.app.vpn.HotReserveTracker.readyIds().size}/${com.secureconnect.app.vpn.HotReservePolicy.TARGET}")
            appendLine("Hot standby status: ${com.secureconnect.app.vpn.HotReserveTracker.status.value}")
            appendLine("Embedded Xray warm outbounds (configured, not guaranteed live): ${com.secureconnect.app.vpn.EmbeddedWarmRoutes.installedRouteCount}/${com.secureconnect.app.vpn.EmbeddedWarmRoutes.MAX_HOT}")
            appendLine("Embedded Xray route names: ${com.secureconnect.app.vpn.EmbeddedWarmRoutes.installedServers.ifBlank { "none" }}")
            appendLine("Hot reserve throughput audit: ${com.secureconnect.app.vpn.ServerScanner.hotSpeedStatus.value} (periodic heavy audit disabled)")
            appendLine("Note: replaced reserve enters scanner/storage now; embedded Xray outbounds refresh on next core rebuild")
            appendLine("Embedded Xray observer: ${if (com.secureconnect.app.vpn.EmbeddedWarmRoutes.installedRouteCount > 0) "${com.secureconnect.app.vpn.EmbeddedWarmRoutes.OBSERVE_INTERVAL_SECONDS}s, leastPing for new connections" else "inactive"}")
            appendLine("Reserve maintenance: on-demand discovery; bounded 75-second refill windows with 15-minute cooldown")
            appendLine("Catalogue: ${data.catalogueSize}/${ServerStore.MAX_CACHED_SERVERS}")
            appendLine("Catalogue status: ${ServerScanner.catalogueStatus.value}")
            appendLine("App task active: ${AppRunController.mayRun(app)}")
            appendLine("Android app task present: ${AppRunController.hasTask(app) ?: "unknown"}")
            appendLine("Task shutdown pending: ${AppRunController.shutdownPending(app)}")
            appendLine("Last task dismissal timestamp (ms): ${AppRunController.lastTaskDismissalAtMs(app)}")
            appendLine("VPN service/TUN live: ${XrayVpnService.hasLiveService()}/${XrayVpnService.hasLiveTunnel()}")
            appendLine("Recoverable VPN session stored: ${app.getSharedPreferences("sc_vpn_service_session", android.content.Context.MODE_PRIVATE).getBoolean("active", false)}")
            appendLine("Saved working history: ${WorkingServerStore.savedRecords(app).size}/${com.secureconnect.app.vpn.WorkingPoolPolicy.MAX_HISTORY}")
            appendLine("Preferred previously successful sources (video + speed): " +
                WorkingServerStore.preferredSourceNames(app).ifEmpty { listOf("none yet") }.joinToString(", "))
            appendLine("Temporarily deferred failed candidates: ${DeadCandidateStore.coolingIds(app).size} (not permanently blacklisted)")
            appendLine("Reserve ready: ${WorkingServerStore.activeIds(app).count { it != VpnController.activeServer.value?.id }}")
            appendLine("Historical emergency candidates (NOT verified): ${WorkingServerStore.historicalRecoveryRecords(app).count { it.server.id != VpnController.activeServer.value?.id }}")
            appendLine("YouTube-confirmed pool: ${WorkingServerStore.activeIds(app).size}/${WorkingPoolPolicy.MAX_VERIFIED}")
            appendLine("Precheck: ${data.scanStatus}")
            appendLine("Resource budget: ${ResourceGovernor.resourceSummary(app)}")
            appendLine("Selected server: ${server?.country ?: "-"} / ${server?.city ?: "-"}")
            if (com.secureconnect.app.vpn.EmbeddedWarmRoutes.installedRouteCount > 0) {
                appendLine("Media affinity: recognised YouTube/Googlevideo TLS/QUIC hostnames route to selected primary")
                appendLine("Active SOCKS health, YouTube HTML and CDN bandwidth tests: selected primary only")
                appendLine("Other new TUN flows: leastPing warm outbounds; actual exit may differ")
                appendLine("Limit: encrypted/unknown hostnames may not match the media rule")
            }
            appendLine("Protocol: ${server?.protocol ?: "-"}")
            appendLine("Host: ${server?.host ?: "-"}")
            appendLine("Port: ${server?.port ?: 0}")
            appendLine("Source: ${server?.source ?: "-"}")
            appendLine("Connection mode: ${data.connectionMode}")
            appendLine("Slow standby: ${SlowStandbyStore.entries(app).size}/${SlowStandbyPolicy.MAX_STANDBY}")
            appendLine("Selection origin: ${if (data.selectedServerExplicit) "explicit-user" else "automatic/adaptive"}")
            appendLine("Ping: ${server?.ping ?: 0} ms")
            appendLine("Measurements: SOCKS CONNECT latency; traffic rates are usage, benchmark is separate HTTPS payload test")
            appendLine("Last speed benchmark: ${VpnController.speedTestResult.value ?: "not yet measured"}")
            appendLine("Video quality status: ${VpnController.videoQualityStatus.value}")
            appendLine("Reminder: synthetic CDN bandwidth does not prove YouTube 720p playback")
            appendLine("ChatGPT TLS through active Xray SOCKS: ${VpnController.openAiTlsStatus.value}")
            appendLine("Note: this does NOT test ChatGPT certificate pinning or the Android TUN end-to-end")
            appendLine("Automatic speed upgrade: ${VpnController.qualityUpgradeStatus.value}")
            val qualified = WorkingServerStore.activeRecords(app)
            appendLine("720p-qualified pool (two speed tests >=5/1 Mbps): ${qualified.size}/${WorkingPoolPolicy.MAX_VERIFIED}")
            qualified.forEach { node ->
                appendLine("  ${node.server.country} ${node.effectivePingMs()}ms " +
                    "down=${String.format(Locale.US, "%.2f", node.verifiedDownloadMbps)} " +
                    "up=${String.format(Locale.US, "%.2f", node.verifiedUploadMbps)} Mbps " +
                    "stability=${String.format(Locale.US, "%.1f", node.stabilityScore(System.currentTimeMillis()))} " +
                    "success=${node.successes} failures=${node.totalFailures} streak=${node.failures}")
            }
            appendLine("Health memory: ${data.healthMemory}")
            appendLine("Download: ${String.format(Locale.US, "%.2f", data.downloadMbps)} Mbps")
            appendLine("Upload: ${String.format(Locale.US, "%.2f", data.uploadMbps)} Mbps")
            appendLine("VPN error: ${VpnDiagnosticRedactor.sanitize(data.vpnError ?: "-")}")
            val snapshot = routingStore.load()
            val allInstalled = routingStore.installedPackageNames()
            val ruInstalled = allInstalled.intersect(com.secureconnect.app.vpn.RussianApps.defaultDirectPackages)
            appendLine("App filter mode: ${snapshot.mode}")
            appendLine("Russian automatic bypass: ${snapshot.autoExcludeRussian}")
            appendLine("Russian preset catalog: ${com.secureconnect.app.vpn.RussianApps.defaultDirectPackages.size} package IDs")
            appendLine("Russian apps installed: ${ruInstalled.size}")
            appendLine("Russian apps on direct route (configured): ${ruInstalled.count { !snapshot.usesVpn(it) }}")
            appendLine("Total direct apps (configured): ${allInstalled.count { !snapshot.usesVpn(it) }}")
            val lastApplied = VpnController.appliedAppRouting.value
            appendLine("App filter applied in current process: ${if (VpnController.state.value == VpnState.Connected || VpnController.state.value is VpnState.Blocked) lastApplied?.toString() ?: "not reported" else "VPN inactive; will apply on next connect"}")
            appendLine()
            appendLine("Health / failover events:")
            data.logs.filter { it.message.contains("Попытка") || it.message.contains("health", true) || it.message.contains("DNS", true) || it.message.contains("HTTPS", true) || it.message.contains("Guardian", true) || it.message.contains("failover", true) }
                .forEach { appendLine("${it.time} [${it.level}] ${VpnDiagnosticRedactor.sanitize(it.message)}") }
            appendLine()
            appendLine("Encrypted storage: ${SensitivePrefs.storageWarning ?: "No decryption error detected"}")
        appendLine("Application log:")
            appendLine(logText.ifBlank { "(empty)" })
        }
    }

}
