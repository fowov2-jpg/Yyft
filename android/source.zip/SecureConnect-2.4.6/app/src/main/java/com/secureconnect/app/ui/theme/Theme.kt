package com.secureconnect.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColors = darkColorScheme(
    primary = ScPrimary,
    onPrimary = ScOnPrimary,
    primaryContainer = ScPrimarySoft,
    onPrimaryContainer = ScOnPrimary,
    secondary = ScTextSecondary,
    tertiary = ScSuccess,
    background = ScBackground,
    onBackground = ScTextPrimary,
    surface = ScSurface,
    onSurface = ScTextPrimary,
    surfaceVariant = ScCard,
    onSurfaceVariant = ScTextSecondary,
    error = ScError,
    outline = ScBorder
)

/** Тёмная тема приложения (всегда тёмная, как в ТЗ). */
@Composable
fun SecureConnectTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, typography = AppTypography, content = content)
}
