package com.secureconnect.app.vpn

/** An initial usable connection must not stop the search for a 720p-quality route.
 * This policy only consults previously double-verified reserve measurements. */
object AutoQualityUpgradePolicy {
    const val POLL_INTERVAL_MS = 45_000L
    const val ATTEMPT_COOLDOWN_MS = 2L * 60_000L

    data class Pending(
        val serverId: String,
        val downloadMbps: Double,
        val uploadMbps: Double?,
        val youtubeBlocked: Boolean = false
    )

    fun canAttempt(nowMs: Long, lastAttemptAtMs: Long): Boolean =
        lastAttemptAtMs <= 0L || nowMs < lastAttemptAtMs ||
            nowMs - lastAttemptAtMs >= ATTEMPT_COOLDOWN_MS

    /** Only a *certified* server with <=100ms measured SOCKS RTT and 5/1 bandwidth
     * may replace the current slow but usable tunnel. Avoid worse download rates
     * when only the upload direction is under target. */
    fun isWorthSwitching(pending: Pending, pingMs: Int,
                         candidateDown: Double, candidateUp: Double): Boolean {
        if (pingMs !in 1..100 ||
            VpnSpeedPolicy.classify(candidateDown, candidateUp) != VpnSpeedPolicy.Verdict.PASS) return false
        if (pending.youtubeBlocked) return true // candidate is from certified YouTube + speed pool
        val previousDown = pending.downloadMbps
        val previousUp = pending.uploadMbps
        if (!previousDown.isFinite() || (previousUp != null && !previousUp.isFinite())) return false
        return when {
            previousDown < VpnSpeedPolicy.MIN_DOWNLOAD_MBPS ->
                VpnSpeedPolicy.betterThanCurrent(candidateDown, previousDown)
            previousUp != null && previousUp < VpnSpeedPolicy.MIN_UPLOAD_MBPS ->
                candidateDown >= previousDown * 0.8 && candidateUp >= VpnSpeedPolicy.MIN_UPLOAD_MBPS
            else -> false
        }
    }
}
