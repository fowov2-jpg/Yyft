package com.secureconnect.app.viewmodel

import android.app.Application
import android.content.Intent
import android.net.VpnService
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.secureconnect.app.AppRunController
import com.secureconnect.app.data.local.ServerStore
import com.secureconnect.app.data.local.WorkingServerStore
import com.secureconnect.app.data.local.SlowStandbyStore
import com.secureconnect.app.data.model.LogEntry
import com.secureconnect.app.data.model.Server
import com.secureconnect.app.data.model.ServerTransport
import com.secureconnect.app.data.remote.ServerRepository
import com.secureconnect.app.data.source.ConfigSource
import com.secureconnect.app.data.source.ConfigSources
import com.secureconnect.app.data.source.SourceStatus
import com.secureconnect.app.vpn.AppRoutingStore
import com.secureconnect.app.vpn.AppRoutingSnapshot
import com.secureconnect.app.vpn.AppVpnMode
import com.secureconnect.app.vpn.InstalledVpnApp
import com.secureconnect.app.vpn.VpnController
import com.secureconnect.app.vpn.VpnState
import com.secureconnect.app.vpn.XrayConfigBuilder
import com.secureconnect.app.vpn.XrayCore
import com.secureconnect.app.vpn.XrayVpnService
import com.secureconnect.app.vpn.ServerPrechecker
import com.secureconnect.app.vpn.TlsRiskStore
import com.secureconnect.app.vpn.OpenAiTlsPolicy
import com.secureconnect.app.vpn.QuickConnectPolicy
import com.secureconnect.app.vpn.PublicRankingFeed
import com.secureconnect.app.vpn.DeadCandidateStore
import com.secureconnect.app.vpn.FastConnectPolicy
import com.secureconnect.app.data.local.ConnectionHistoryStore
import com.secureconnect.app.vpn.WorkingPoolPolicy
import com.secureconnect.app.vpn.ServerStabilityPolicy
import com.secureconnect.app.vpn.SlowStandbyPolicy
import com.secureconnect.app.vpn.ConnectionMode
import com.secureconnect.app.vpn.AutoServerRanking
import com.secureconnect.app.vpn.ServerScanner
import com.secureconnect.app.vpn.XrayHealthChecker
import com.secureconnect.app.vpn.VpnSpeedPolicy
import com.secureconnect.app.vpn.VpnSpeedTester
import com.secureconnect.app.vpn.YouTubePageProbe
import com.secureconnect.app.util.ResourceGovernor
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.net.Inet4Address
import java.net.InetAddress
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


/** Единственная ViewModel приложения. Подключение — настоящий VPN через VpnService + Xray-core. */
class MainViewModel(app: Application) : AndroidViewModel(app) {

    // ---- серверы ----
    private val _servers = MutableStateFlow<List<Server>>(emptyList())
    val servers: StateFlow<List<Server>> = _servers.asStateFlow()
    val catalogueStatus = ServerScanner.catalogueStatus

    private val _selectedServer = MutableStateFlow<Server?>(null)
    val selectedServer: StateFlow<Server?> = _selectedServer.asStateFlow()

    private val _recentIds = MutableStateFlow<List<String>>(emptyList())
    val recentIds: StateFlow<List<String>> = _recentIds.asStateFlow()

    private val _workingServers = MutableStateFlow<List<Server>>(emptyList())
    val workingServers: StateFlow<List<Server>> = _workingServers.asStateFlow()
    private val _workingStatuses = MutableStateFlow<Map<String, String>>(emptyMap())
    val workingStatuses = _workingStatuses.asStateFlow()
    private val _readyWorkingCount = MutableStateFlow(0)
    val readyWorkingCount = _readyWorkingCount.asStateFlow()
    private val _slowStandby = MutableStateFlow<List<Server>>(emptyList())
    val slowStandby = _slowStandby.asStateFlow()
    private val _connectionMode = MutableStateFlow(ConnectionMode.AUTO)
    val connectionMode = _connectionMode.asStateFlow()
    fun setConnectionMode(mode: ConnectionMode) {
        if (_connectionMode.value == mode) return
        _connectionMode.value = mode
        prefs.edit().putString("connection_mode_v1", mode.name).apply()
        if (mode == ConnectionMode.MANUAL) cancelAutoSelection()
        else automaticConnectSuppressed = false
    }

    private val favoriteIds = mutableSetOf<String>()

    // ---- состояние подключения ----
    private val _isConnected = MutableStateFlow(false)
    val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

    private val _isConnecting = MutableStateFlow(false)
    val isConnecting: StateFlow<Boolean> = _isConnecting.asStateFlow()

    private val _downloadMbps = MutableStateFlow(0f)
    val downloadMbps: StateFlow<Float> = _downloadMbps.asStateFlow()

    private val _uploadMbps = MutableStateFlow(0f)
    val uploadMbps: StateFlow<Float> = _uploadMbps.asStateFlow()

    private val _vpnError = MutableStateFlow<String?>(null)
    val vpnError: StateFlow<String?> = _vpnError.asStateFlow()

    private val scannerOwner = Any()
    private val _scanStatus = MutableStateFlow("")
    val scanStatus: StateFlow<String> = _scanStatus.asStateFlow()
    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val autoSelection = AutoSelectionRequest()
    val autoSelectionPending = autoSelection.pending
    private var automaticConnectSuppressed = false

    private var connectJob: Job? = null
    private var reconnectJob: Job? = null
    private var connectionGeneration = 0L
    private val healthLedger = ServerHealthLedger()

    /**
     * True only when the current server was explicitly chosen by the user.
     *
     * Automatic selections (refresh fallback, health
     * failover) must still pass through adaptive ranking. An explicit selection
     * is honored as the first candidate exactly once per connection attempt.
     */
    private var selectedServerExplicit = false

    // SharedPreferences MUST be initialized before init { loadPrefs() }.
    // Kotlin/JVM initializes properties in source order; a lazy property declared
    // after init is still null when init accesses it.
    private val prefs by lazy(LazyThreadSafetyMode.NONE) {
        getApplication<Application>().getSharedPreferences("sc_settings", android.content.Context.MODE_PRIVATE)
    }

    private val routingStore by lazy { AppRoutingStore(getApplication()) }
    private val _appRouting = MutableStateFlow(routingStore.load())
    val appRouting: StateFlow<AppRoutingSnapshot> = _appRouting.asStateFlow()

    fun installedVpnApps(): List<InstalledVpnApp> = routingStore.installedApps()

    fun setRussianAutoBypass(enabled: Boolean): String? = runCatching {
        val previous = _appRouting.value
        val updated = routingStore.setAutoExcludeRussian(enabled)
        _appRouting.value = updated
        if (previous != updated) applyAppRouting()
    }.exceptionOrNull()?.message

    fun setAppVpnEnabled(pkg: String, enabled: Boolean): String? = runCatching {
        val previous = _appRouting.value
        val updated = routingStore.setVpnEnabled(pkg, enabled)
        _appRouting.value = updated
        if (previous != updated) applyAppRouting()
    }.exceptionOrNull()?.message

    fun setAppRoutingMode(mode: AppVpnMode): String? = runCatching {
        val previous = _appRouting.value
        val updated = routingStore.setMode(mode)
        _appRouting.value = updated
        if (previous != updated) applyAppRouting()
    }.exceptionOrNull()?.message

    fun setPreparedAppIncluded(pkg: String, enabled: Boolean): String? = runCatching {
        _appRouting.value = routingStore.prepareIncluded(pkg, enabled)
    }.exceptionOrNull()?.message

    private var appRoutingUpdatePending = false

    private fun applyAppRouting() {
        val state = VpnController.state.value
        if (state != VpnState.Connected && state !is VpnState.Blocked) {
            // If the user changed settings during the initial handshake, apply them
            // on first Connected; otherwise the current TUN might keep old rules.
            appRoutingUpdatePending = state == VpnState.Connecting || state == VpnState.Validating
            return
        }
        appRoutingUpdatePending = false
        val context = getApplication<Application>()
        runCatching {
            // Existing foreground service: do not use startForegroundService for a dormant VPN.
            context.startService(
                Intent(context, XrayVpnService::class.java)
                    .setAction(XrayVpnService.ACTION_UPDATE_APP_ROUTING)
            )
        }.onFailure { log("WARN", "Не удалось обновить фильтр VPN: ${it.message}") }
    }

    // ---- настройки ----
    private val _autoConnect = MutableStateFlow(false)
    val autoConnect: StateFlow<Boolean> = _autoConnect.asStateFlow()
    private val _autoRecovery = MutableStateFlow(true)
    val autoRecovery: StateFlow<Boolean> = _autoRecovery.asStateFlow()
    private val _killSwitch = MutableStateFlow(false)
    val killSwitch: StateFlow<Boolean> = _killSwitch.asStateFlow()

    // ---- источники конфигов ----
    private val _sources = MutableStateFlow<List<ConfigSource>>(ConfigSources.all)
    val sources: StateFlow<List<ConfigSource>> = _sources.asStateFlow()
    private val _sourceStatuses = MutableStateFlow<List<SourceStatus>>(emptyList())
    val sourceStatuses: StateFlow<List<SourceStatus>> = _sourceStatuses.asStateFlow()
    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()
    private val _refreshError = MutableStateFlow<String?>(null)
    val refreshError: StateFlow<String?> = _refreshError.asStateFlow()
    private var refreshJob: Job? = null

    // ---- журнал ----
    private val _logs = MutableStateFlow<List<LogEntry>>(emptyList())
    val logs: StateFlow<List<LogEntry>> = _logs.asStateFlow()

    /**
     * Формирует безопасный отчёт для отправки разработчику.
     * Секреты (UUID/password/token/ключи/raw links) намеренно не попадают в отчёт.
     */
    /**
     * On-demand bounded CDN benchmark. Explicit tap may run on mobile data;
     * background traffic budgeting remains unchanged.
     */
    fun checkVideoNow() {
        if (VpnController.state.value != VpnState.Connected) return
        val app = getApplication<Application>()
        runCatching {
            app.startService(Intent(app, XrayVpnService::class.java)
                .setAction(XrayVpnService.ACTION_CHECK_VIDEO_NOW))
        }
    }

    fun diagnosticReport(): String = VpnDiagnosticReporter.render(
        app = getApplication<Application>(),
        data = VpnDiagnosticReporter.Snapshot(
            selectedServer = _selectedServer.value,
            vpnState = VpnController.state.value,
            connecting = _isConnecting.value,
            connected = _isConnected.value,
            killSwitch = _killSwitch.value,
            autoConnect = _autoConnect.value,
            autoRecovery = _autoRecovery.value,
            readyWorkingCount = _readyWorkingCount.value,
            catalogueSize = _servers.value.size,
            scanStatus = _scanStatus.value,
            connectionMode = _connectionMode.value,
            selectedServerExplicit = selectedServerExplicit,
            healthMemory = _selectedServer.value?.let { healthLedger.describe(it.id) } ?: "-",
            downloadMbps = _downloadMbps.value,
            uploadMbps = _uploadMbps.value,
            vpnError = _vpnError.value,
            logs = _logs.value.toList()
        )
    )

    init {
        loadPrefs()
        log("INFO", "Приложение запущено")
        observeVpn()
        observeServiceEvents()
        observeTrafficAndNotificationStop()
        ServerScanner.acquire(scannerOwner, getApplication<Application>())
        observeScanner()
        checkServers()
        // Автоподключение работает и после перезапуска приложения: сервер
        // восстанавливается из локального кэша, после чего подключаемся без
        // сетевого refresh. Если системное VPN-разрешение ещё не выдано,
        // пользователь получит стандартный запрос из UI.
        // Не показываем и не выбираем фиктивные узлы. На первом запуске
        // загружаем реальные конфиги, а автоподключение выполняем только
        // после появления валидного узла из кэша или источника.
        viewModelScope.launch {
            delay(250)
            val canAutoConnect =
                _autoConnect.value && _connectionMode.value == ConnectionMode.AUTO && !automaticConnectSuppressed &&
                    vpnPermissionIntent() == null &&
                    !_isConnected.value &&
                    !_isConnecting.value &&
                    (_servers.value.isNotEmpty() || _workingServers.value.isNotEmpty())

            if (canAutoConnect) {
                selectAutoServer()
            }

            // The shared scanner loads/refreshes selected sources automatically,
            // including while its foreground-service lease outlives this screen.
        }
    }

    private fun loadPrefs() {
        // One-tap product mode: a tap starts AUTO selection; Guardian always recovers.
        // Do not auto-start the VPN just because the UI was opened.
        _autoConnect.value = false
        _autoRecovery.value = true
        // Keep a pre-existing kill-switch preference; never silently weaken privacy.
        _killSwitch.value = prefs.getBoolean("kill_switch", true)
        _connectionMode.value = ConnectionMode.AUTO
        selectedServerExplicit = false
        // Restore users from older builds that saved MANUAL mode or disabled sources.
        // Preserve app-routing overrides in AppRoutingStore (a different section).
        prefs.edit().putBoolean("auto_connect", false)
            .putBoolean("auto_recovery", true)
            .putString("connection_mode_v1", ConnectionMode.AUTO.name)
            .putBoolean("selected_server_explicit", false)
            .remove("disabled_sources")
            .apply()
        VpnController.killSwitchEnabled = _killSwitch.value
        VpnController.autoRecoveryEnabled = _autoRecovery.value

        favoriteIds.clear()
        favoriteIds.addAll(prefs.getStringSet("favorites", emptySet()).orEmpty())
        _servers.value = _servers.value.map { it.copy(isFavorite = it.id in favoriteIds) }
        _selectedServer.value?.let { current ->
            _selectedServer.value = current.copy(isFavorite = current.id in favoriteIds)
        }

        prefs.getString("recent_ids", null)?.let { json ->
            runCatching {
                val arr = JSONArray(json)
                _recentIds.value = buildList {
                    for (i in 0 until arr.length()) {
                        arr.optString(i).takeIf { it.isNotBlank() }?.let(::add)
                    }
                }.take(10)
            }.onFailure { log("WARN", "Не удалось восстановить историю серверов: ${it.message}") }
        }

        val cached = ServerStore.loadCached(getApplication(), favoriteIds)
        if (cached.isNotEmpty()) {
            _servers.value = cached
            _selectedServer.value = cached.first()
        }

        prefs.getString("health_ledger_v1", null)?.let { json ->
            runCatching { restoreHealthLedger(JSONArray(json)) }
                .onFailure { log("WARN", "Не удалось восстановить health history: ${it.message}") }
        }

        prefs.getString("selected_server", null)?.let { id ->
            _servers.value.firstOrNull { it.id == id }?.let {
                _selectedServer.value = it
                selectedServerExplicit = false
            }
        }
        _sources.value = ConfigSources.all.map { it.copy(enabled = true) }
        refreshWorkingPool()
    }

    private fun savePref(key: String, value: Boolean) {
        prefs.edit().putBoolean(key, value).apply()
    }

    // ---------- подключение (настоящий VPN) ----------

    /** Состояние сервиса -> состояние UI. */
    private fun observeVpn() {
        viewModelScope.launch {
            VpnController.state.collect { st ->
                when (st) {
                    VpnState.Idle -> {
                        _isConnecting.value = false
                        _isConnected.value = false
                        stopStats()
                    }
                    VpnState.Connecting, VpnState.Validating, VpnState.Stopping -> {
                        _isConnecting.value = true
                        _isConnected.value = false
                    }
                    VpnState.Connected -> {
                        if (VpnController.activeServer.value?.id?.let {
                                TlsRiskStore.eligibleForAutomaticUse(getApplication(), it)
                            } == true) VpnController.riskyCandidate.value = null
                        if (appRoutingUpdatePending) applyAppRouting()
                        autoSelection.cancel()
                        _isConnecting.value = false
                        _isConnected.value = true
                        _vpnError.value = null
                        _selectedServer.value?.let { markRecent(it.id) }
                        log("INFO", "VPN подключён")
                    }
                    VpnState.Blocked -> {
                        _isConnecting.value = false
                        _isConnected.value = false
                        stopStats()
                        _vpnError.value = "Kill Switch: трафик заблокирован до ручного отключения"
                        log("WARN", "Kill Switch активен — интернет заблокирован")
                    }
                    is VpnState.Error -> {
                        _isConnecting.value = false
                        _isConnected.value = false
                        _vpnError.value = st.message
                        log("ERROR", "VPN: ${st.message}")
                        stopStats()
                    }
                }
            }
        }
    }

    private fun observeServiceEvents() {
        viewModelScope.launch {
            VpnController.activeServer.collect { server ->
                if (server == null || server.rawLink.isBlank()) return@collect
                val selected = server.copy(isFavorite = server.id in favoriteIds)
                if (_selectedServer.value?.id != selected.id || _selectedServer.value?.ping != selected.ping) {
                    _selectedServer.value = selected
                    selectedServerExplicit = false
                    prefs.edit()
                        .putString("selected_server", selected.id)
                        .putBoolean("selected_server_explicit", false)
                        .apply()
                    refreshWorkingPool()
                }
            }
        }
        viewModelScope.launch {
            VpnController.events.collect { event ->
                log(QuietRuntimeLogPolicy.classifyServiceEvent(event), event)
            }
        }
    }

    /** Нужно вызывать после того, как пользователь дал системное разрешение VPN. */
    fun connect() {
        if (_isConnecting.value || _isConnected.value) return
        autoSelection.cancel()
        automaticConnectSuppressed = false
        val server = _selectedServer.value ?: return
        if (_connectionMode.value == ConnectionMode.MANUAL &&
            (!WorkingPoolPolicy.eligible(server) || XrayConfigBuilder.build(server, null) == null)) {
            _vpnError.value = "Выбранный сервер не подходит для подключения или находится в России."
            return
        }
        _vpnError.value = null

        if (vpnPermissionIntent() != null) {
            _vpnError.value = "Нужно разрешение на VPN. Нажмите «Подключить» ещё раз после подтверждения системы."
            return
        }
        if (server.rawLink.isBlank()) {
            _vpnError.value = "Нет доступной конфигурации. Поиск и обновление выполняются автоматически."
            return
        }
        if (!XrayCore.isAvailable()) {
            _vpnError.value = "Ядро Xray (libv2ray.aar) не найдено в сборке. Положите файл в app/libs/ и пересоберите."
            return
        }

        // VPN is latency-sensitive. Stop subscription refresh/probing so one of
        // the two bounded app worker slots is immediately available to Xray/health.
        refreshJob?.cancel()
        connectJob?.cancel()
        val generation = ++connectionGeneration
        connectJob = viewModelScope.launch {
            try {
                connectInternal(server, generation, forcePrimary = selectedServerExplicit)
            } finally {
                if (generation == connectionGeneration) {
                    connectJob = null
                    checkServers()
                }
            }
        }
    }

    private suspend fun connectInternal(
        server: Server,
        generation: Long,
        forcePrimary: Boolean
    ) {
        if (!isGenerationCurrent(generation) || !currentCoroutineContext().isActive) return

        // Prefer the cached, independently YouTube-and-speed-certified working pool.
        // Never wait for the full 100-item catalogue or full video benchmarking.
        // New candidates need a genuine Xray HTTPS check; video tests run later
        // and never block safe basic connectivity.
        val connectStartedMs = android.os.SystemClock.elapsedRealtime()
        _isConnecting.value = true
        VpnController.state.value = VpnState.Connecting
        VpnController.videoQualityStatus.value = "Ожидание VPN"
        val ctx = getApplication<Application>()
        val workingSnapshot = WorkingServerStore.activeServers(ctx)
        val workingIds = workingSnapshot.mapTo(LinkedHashSet()) { it.id }
        val workingLatency = workingSnapshot.associate { it.id to it.ping }
        val riskApprovalId = TlsRiskStore.currentApprovedServerId()
        val deferredServerIds = DeadCandidateStore.coolingIds(ctx)
        val compatible = QuickConnectPolicy.order(
            selected = server,
            mode = _connectionMode.value,
            explicitSelection = forcePrimary,
            verified = workingSnapshot,
            historical = WorkingServerStore.historicalRecoveryRecords(ctx).map { it.server.copy(ping = it.effectivePingMs()) },
            recentlyConnectedIds = ConnectionHistoryStore.recentIds(ctx),
            catalogue = ServerStore.loadCached(ctx),
            isCoolingDown = { healthLedger.isCoolingDown(it.id) ||
                it.id in deferredServerIds },
            preferredSources = WorkingServerStore.preferredSourceNames(ctx),
            publicRanks = PublicRankingFeed.priorities(ctx, ServerStore.loadCached(ctx))
        ).filter { XrayConfigBuilder.build(it, null) != null &&
            (if (riskApprovalId != null) it.id == riskApprovalId
             else TlsRiskStore.eligibleForAutomaticUse(ctx, it.id)) }
        if (compatible.isEmpty()) {
            val message = "В каталоге пока нет совместимых конфигураций. Проверьте источники и сеть."
            _vpnError.value = message
            VpnController.state.value = VpnState.Error(message)
            _isConnecting.value = false
            log("ERROR", message)
            return
        }
        log("INFO", "Быстрое подключение: ${compatible.size} кандидатов; строгий пул ${workingSnapshot.size}/${WorkingPoolPolicy.MAX_VERIFIED} пополняется отдельно")

        var lastError = "Не найден рабочий сервер"
        val maxAttempts = minOf(QuickConnectPolicy.MAX_INITIAL_ATTEMPTS, compatible.size)
        val attemptedIds = LinkedHashSet<String>()
        val sourceFailures = LinkedHashMap<String, Int>()
        val familyFailures = LinkedHashMap<String, Int>()

        fun rememberSessionFailure(candidate: Server) {
            val sourceKey = candidate.source.ifBlank { "<unknown>" }
            val familyKey = ServerTransport.family(candidate)
            sourceFailures[sourceKey] = (sourceFailures[sourceKey] ?: 0) + 1
            familyFailures[familyKey] = (familyFailures[familyKey] ?: 0) + 1
        }

        for (index in 0 until maxAttempts) {
            if (!isGenerationCurrent(generation) || !currentCoroutineContext().isActive) return

            val remaining = compatible.filterNot { it.id in attemptedIds }
            if (remaining.isEmpty()) break

            val rankedRemaining = healthLedger.rank(remaining)
            // First connect to the highest-priority known endpoint, not to an
            // arbitrary selected catalogue card. Later attempts adapt to failures.
            val explicitPrimary = if (index == 0) remaining.firstOrNull() else null
            val candidate = explicitPrimary ?: ServerSelector.chooseAdaptive(
                ranked = rankedRemaining,
                sourceFailures = sourceFailures,
                familyFailures = familyFailures,
                isCoolingDown = { healthLedger.isCoolingDown(it.id) },
                hasSuccessfulHistory = { healthLedger.hasSuccessfulHistory(it.id) },
                isWorking = { it.id in workingIds },
                knownLatencyMs = {
                    workingLatency[it.id]
                        ?: it.ping.takeIf { ping -> ping > 0 }
                        ?: healthLedger.ewmaMs(it.id)
                }
            ) ?: break
            attemptedIds += candidate.id

            _isConnecting.value = true
            VpnController.state.value = VpnState.Connecting
            log(
                "INFO",
                buildString {
                    append("Попытка ${index + 1}/$maxAttempts: ${candidate.country} · ${candidate.city} (${candidate.protocol})")
                    append(" [${candidate.source.ifBlank { "unknown" }}; ${ServerTransport.family(candidate)}]")
                    if (index == 0) {
                        append(if (explicitPrimary != null) " [primary=explicit-user]" else " [primary=adaptive]")
                    }
                    val sourceFails = sourceFailures[candidate.source.ifBlank { "<unknown>" }] ?: 0
                    val familyFails = familyFailures[ServerTransport.family(candidate)] ?: 0
                    if (sourceFails > 0 || familyFails > 0) {
                        append(" [session sourceFails=$sourceFails familyFails=$familyFails]")
                    }
                    healthLedger.describe(candidate.id)?.let { append(" [$it]") }
                }
            )

            val config = withContext(ResourceGovernor.dispatcher) {
                val ip = resolveHostTimed(candidate.host, 3_000L)
                XrayConfigBuilder.build(candidate, ip)
            }
            if (!isGenerationCurrent(generation) || !currentCoroutineContext().isActive) return

            if (config == null) {
                lastError = "Конфигурация не поддерживается"
                healthLedger.recordFailure(candidate.id, "config")
                WorkingServerStore.recordFailure(ctx, candidate.id)
                rememberSessionFailure(candidate)
                persistHealthLedger()
                log("WARN", "Пропуск ${candidate.id}: $lastError")
                continue
            }

            // Before the TUN is established, test TLS trust and hostname through
            // this EXACT candidate, not through the existing Xray balancer.
            if (riskApprovalId != candidate.id) {
                val tls = withContext(ResourceGovernor.probeDispatcher) {
                    XrayConfigBuilder.buildProbe(candidate)?.let {
                        XrayCore.checkStandaloneTls(ctx, it)
                    } ?: OpenAiTlsPolicy.Verdict.UNAVAILABLE
                }
                if (!isGenerationCurrent(generation) || !currentCoroutineContext().isActive) return
                when (tls) {
                    OpenAiTlsPolicy.Verdict.CERTIFICATE_ERROR -> {
                        TlsRiskStore.markRisk(ctx, candidate.id)
                        lastError = "Риск перехвата HTTPS; сервер исключён из автоподбора"
                        log("WARN", "TLS risk: ${candidate.country} · ${candidate.host} — сертификат не проверен")
                        continue
                    }
                    OpenAiTlsPolicy.Verdict.VERIFIED -> TlsRiskStore.clearOnVerified(ctx, candidate.id)
                    OpenAiTlsPolicy.Verdict.UNAVAILABLE -> Unit // timeout does not prove interception
                }
            }

            val intent = Intent(ctx, XrayVpnService::class.java)
                .setAction(XrayVpnService.ACTION_START)
                .putExtra(XrayVpnService.EXTRA_CONFIG, config)
                .putExtra(XrayVpnService.EXTRA_RAW_LINK, candidate.rawLink)
                .putExtra(XrayVpnService.EXTRA_HOST, candidate.host)
                .putExtra(XrayVpnService.EXTRA_SERVER_ID, candidate.id)
                .putExtra(XrayVpnService.EXTRA_SERVER_COUNTRY, candidate.country)
                .putExtra(XrayVpnService.EXTRA_SERVER_CITY, candidate.city)
                .putExtra(XrayVpnService.EXTRA_SERVER_FLAG, candidate.flagEmoji)
                .putExtra(XrayVpnService.EXTRA_SERVER_PROTOCOL, candidate.protocol)
                .putExtra(XrayVpnService.EXTRA_SERVER_PORT, candidate.port)
                .putExtra(XrayVpnService.EXTRA_SERVER_PING, candidate.ping)
                .putExtra(XrayVpnService.EXTRA_SERVER_SOURCE, candidate.source)

            try {
                ContextCompat.startForegroundService(ctx, intent)
            } catch (e: Exception) {
                lastError = "Не удалось запустить VPN-сервис: ${e.message ?: e.javaClass.simpleName}"
                healthLedger.recordFailure(candidate.id, "service_start")
                WorkingServerStore.recordFailure(ctx, candidate.id)
                rememberSessionFailure(candidate)
                persistHealthLedger()
                log("WARN", "${candidate.id}: $lastError")
                continue
            }

            val stateReached = withTimeoutOrNull(15_000L) {
                while (currentCoroutineContext().isActive && isGenerationCurrent(generation)) {
                    when (VpnController.state.value) {
                        VpnState.Validating -> {
                            if (VpnController.validatingServerId == candidate.id) {
                                return@withTimeoutOrNull true
                            }
                            delay(100)
                        }
                        VpnState.Connected -> {
                            if (
                                VpnController.activeServer.value?.id == candidate.id ||
                                VpnController.validatingServerId == candidate.id
                            ) {
                                return@withTimeoutOrNull true
                            }
                            delay(100)
                        }
                        is VpnState.Error, VpnState.Idle, VpnState.Blocked ->
                            return@withTimeoutOrNull true
                        VpnState.Connecting, VpnState.Stopping ->
                            delay(100)
                    }
                }
                false
            } ?: false

            if (!isGenerationCurrent(generation) || !currentCoroutineContext().isActive) return

            when (val state = VpnController.state.value) {
                VpnState.Validating, VpnState.Connected -> {
                    val correlated =
                        VpnController.validatingServerId == candidate.id ||
                            VpnController.activeServer.value?.id == candidate.id
                    if (!correlated) {
                        lastError = "Service валидирует другой сервер; текущая попытка устарела"
                        log("INFO", "${candidate.country} · ${candidate.city}: $lastError")
                        continue
                    }
                    VpnController.state.value = VpnState.Validating
                    log("INFO", "Xray поднят, проверяю bounded SOCKS5→TLS→HTTPS через Xray + DNS/UDP диагностику…")

                    val health = try {
                        // Blocking Java socket/TLS work must not freeze the UI thread.
                        // The checker owns per-socket timeouts; cancellation alone does
                        // not interrupt every java.net operation on Android.
                        withContext(ResourceGovernor.dispatcher) { XrayHealthChecker.check(
                            serverProtocol = candidate.protocol,
                            isReality = candidate.protocol.equals("VLESS", true) &&
                                candidate.rawLink.contains("security=reality", true),
                            baselineHttpsMs = WorkingServerStore.activeRecord(ctx, candidate.id)?.ewmaHttpsMs
                                ?: healthLedger.ewmaMs(candidate.id)?.toDouble(),
                            fastConnect = true
                        ) }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (_: Throwable) {
                        null
                    }

                    if (!isGenerationCurrent(generation) || !currentCoroutineContext().isActive) return

                    // Re-correlate after blocking network I/O. A handover/recovery can
                    // replace Xray while this TLS socket is still finishing; a late
                    // PASS/FAIL from that old core must not mutate the new session.
                    val serviceStateAfterProbe = VpnController.state.value
                    val stillCorrelated =
                        VpnController.validatingServerId == candidate.id ||
                            (
                                serviceStateAfterProbe == VpnState.Connected &&
                                    VpnController.activeServer.value?.id == candidate.id
                            )
                    if (
                        !stillCorrelated &&
                        (
                            serviceStateAfterProbe == VpnState.Connecting ||
                                serviceStateAfterProbe == VpnState.Validating ||
                                serviceStateAfterProbe == VpnState.Connected
                            )
                    ) {
                        log(
                            "INFO",
                            "${candidate.country} · ${candidate.city}: поздний health-result отброшен после смены Xray"
                        )
                        return
                    }

                    // A physical-network loss/handover can move the foreground
                    // service back to Connecting while this blocking TLS probe is
                    // still finishing. Do not poison the server's health history for
                    // an underlay outage; the service-owned Guardian will restore or
                    // fail over as soon as Wi-Fi/LTE returns.
                    if (health?.passed != true && serviceStateAfterProbe == VpnState.Connecting) {
                        log("INFO", "Проверка прервана сменой физической сети; восстановление передано Guardian")
                        return
                    }

                    // 2.3.0: readiness and video quality are independent.
                    // Do NOT hold the Android VPN in Validating while performing large
                    // YouTube/Cloudflare transfers. HTTPS confirms usable Xray access.
                    // Existing certified quality is reusable only for an identical
                    // configuration; service-owned probes refresh it opportunistically.
                    val automaticMode = _connectionMode.value == ConnectionMode.AUTO
                    val certified = WorkingServerStore.activeRecord(ctx, candidate.id)
                    val recentVideoProof = certified != null &&
                        FastConnectPolicy.canReuseCertifiedQuality(
                            sameConfiguration = certified.server.rawLink == candidate.rawLink,
                            youtubeVerifiedAtMs = certified.youtubeVerifiedAtMs,
                            speedVerifiedAtMs = certified.speedVerifiedAtMs,
                            nowMs = System.currentTimeMillis()
                        )
                    val youtubePassedNow = false
                    val speedPassedNow = false

                    if (health != null && FastConnectPolicy.canPublishConnected(
                            httpsVerified = health.passed,
                            automaticMode = automaticMode,
                            hasRecentCertifiedQuality = recentVideoProof,
                            youtubeCheckedNow = youtubePassedNow,
                            measuredSpeedQualifiedNow = speedPassedNow
                        )) {
                        val connectPing = health.tcpMs?.takeIf { it > 0 }
                            ?: candidate.ping.takeIf { it > 0 }
                            ?: health.httpsMs?.takeIf { it > 0 }
                        val httpsLatency = health.httpsMs?.takeIf { it > 0 } ?: connectPing
                        val parkedForPing = SlowStandbyPolicy.shouldPark(
                            httpsLatency, health.tcpMs, true)
                        if (parkedForPing && connectPing != null) {
                            SlowStandbyStore.park(ctx, candidate, connectPing)
                            WorkingServerStore.demoteSpeedQuality(ctx, candidate.id)
                            log("INFO", "Сервер доступен, но пинг $connectPing мс выше цели; временное подключение, не строгий резерв")
                        }

                        if (httpsLatency != null) {
                            // Health history deliberately tracks complete HTTPS
                            // latency. The UI/<=100ms selector uses connectPing.
                            healthLedger.recordSuccess(candidate.id, httpsLatency)
                            persistHealthLedger()
                        }
                        val selected = if (connectPing != null) {
                            candidate.copy(ping = connectPing, isFavorite = candidate.id in favoriteIds)
                        } else {
                            candidate.copy(isFavorite = candidate.id in favoriteIds)
                        }
                        _selectedServer.value = selected
                        // Reuse existing quality certificate only while fresh;
                        // one startup measurement does NOT certify a strict backup.
                        if (!parkedForPing && connectPing != null)
                            SlowStandbyStore.remove(ctx, selected.id)
                        refreshWorkingPool()
                        VpnController.activeServer.value = selected
                        if (VpnController.validatingServerId == selected.id) {
                            VpnController.validatingServerId = null
                        }
                        selectedServerExplicit = forcePrimary && selected.id == server.id
                        prefs.edit()
                            .putString("selected_server", selected.id)
                            .putBoolean("selected_server_explicit", selectedServerExplicit)
                            .apply()
                        log(
                            "INFO",
                            buildString {
                                append("Health-check PASS: TCP=")
                                append(health.tcpMs ?: "—")
                                append("ms DNS=")
                                append(health.dnsMs ?: "—")
                                append(" HTTPS=")
                                append(health.httpsMs ?: "—")
                                append("ms UDP=")
                                append(health.udpOk?.let { if (it) "OK" else "FAIL" } ?: "—")
                                if (health.realityHandshakeOk != null) {
                                    append(" Reality=")
                                    append(if (health.realityHandshakeOk) "OK" else "FAIL")
                                }
                            }
                        )
                        health.detail?.let { log("INFO", "Health detail: $it") }
                        VpnController.state.value = VpnState.Connected
                        VpnController.videoQualityStatus.value =
                            if (recentVideoProof) "Подтверждено ранее"
                            else "Не проверено · фоновый тест по возможности"
                        ConnectionHistoryStore.recordConnected(ctx, selected.id)
                        // Monotonic elapsed time including TLS preflight + core startup.
                        // A measured figure helps compare Xray startup on the real device.
                        prefs.edit().putLong(
                            "last_connect_elapsed_ms",
                            (android.os.SystemClock.elapsedRealtime() - connectStartedMs).coerceAtLeast(0L)
                        ).apply()
                        // ChatGPT app pins certificates: perform an additional light
                        // TLS trust/hostname probe but do not block quick-connect.
                        runCatching {
                            ctx.startService(Intent(ctx, XrayVpnService::class.java)
                                .setAction(XrayVpnService.ACTION_CHECK_OPENAI_TLS))
                        }
                        // Service-owned certification survives Home/background UI.
                        if (automaticMode || (connectPing != null && httpsLatency != null)) {
                            runCatching {
                                ctx.startService(Intent(ctx, XrayVpnService::class.java)
                                    .setAction(XrayVpnService.ACTION_CERTIFY_QUALITY)
                                    .putExtra(XrayVpnService.EXTRA_SERVER_ID, selected.id)
                                    .putExtra(XrayVpnService.EXTRA_QUALITY_CONNECT_MS, connectPing ?: 0)
                                    .putExtra(XrayVpnService.EXTRA_QUALITY_HTTPS_MS, httpsLatency ?: 0)
                                    .putExtra(XrayVpnService.EXTRA_AUTO_VIDEO_CHECK, automaticMode))
                            }.onFailure { log("WARN", "Автопроверка качества не запустилась: ${it.message}") }
                        }
                        _isConnecting.value = false
                        return
                    }

                    lastError = health?.error ?: "Не удалось подтвердить реальный HTTPS-трафик"
                    healthLedger.recordFailure(candidate.id, health?.failureStage ?: "health_unknown")
                    WorkingServerStore.recordFailure(ctx, candidate.id)
                    persistHealthLedger()
                    log("WARN", "${candidate.country} · ${candidate.city}: $lastError")
                    health?.detail?.let { log("WARN", "Health detail: $it") }
                }

                is VpnState.Error -> {
                    lastError = state.message
                    healthLedger.recordFailure(candidate.id, "xray_start")
                WorkingServerStore.recordFailure(ctx, candidate.id)
                    persistHealthLedger()
                    log("WARN", "${candidate.country} · ${candidate.city}: Xray error: ${state.message}")
                }

                VpnState.Blocked -> {
                    lastError = "Xray остановился; Kill Switch удерживает блокирующий TUN"
                    healthLedger.recordFailure(candidate.id, "core_shutdown")
                WorkingServerStore.recordFailure(ctx, candidate.id)
                    persistHealthLedger()
                    log("WARN", "${candidate.country} · ${candidate.city}: $lastError; пробую следующий сервер")
                }

                VpnState.Idle -> {
                    lastError = "VPN неожиданно остановился"
                    healthLedger.recordFailure(candidate.id, "stopped")
                WorkingServerStore.recordFailure(ctx, candidate.id)
                    persistHealthLedger()
                    log("WARN", "${candidate.country} · ${candidate.city}: $lastError")
                }

                VpnState.Connecting, VpnState.Stopping -> {
                    lastError = if (stateReached) "Таймаут подключения (15 с)" else "Таймаут подключения"
                    healthLedger.recordFailure(candidate.id, "start_timeout")
                WorkingServerStore.recordFailure(ctx, candidate.id)
                    persistHealthLedger()
                    log("WARN", "${candidate.country} · ${candidate.city}: $lastError")
                }
            }

            rememberSessionFailure(candidate)

            // Keep the Android TUN alive between candidates. ACTION_START reloads
            // only Xray on the same TUN fd, avoiding a system-level VPN network flap.
            // If all candidates fail, the final block below either releases the TUN
            // or intentionally keeps it for Kill Switch.
            if (index + 1 < maxAttempts) {
                delay(100)
            }
        }

        if (isGenerationCurrent(generation)) {
            refreshWorkingPool()
            _isConnecting.value = false
            val message = "Быстрое подключение: проверено ${attemptedIds.size} серверов; последний отказ: $lastError. Остальные проверяются в фоне."
            _vpnError.value = message
            // Exhausted the bounded safe attempt list: only NOW offer a
            // separately quarantined candidate, never during the normal scan.
            val riskyFallback = (ServerStore.loadCached(getApplication()) + compatible)
                .firstOrNull { TlsRiskStore.isRisky(getApplication(), it.id) &&
                    XrayConfigBuilder.build(it, null) != null }
            if (riskyFallback != null) VpnController.riskyCandidate.value = riskyFallback
            if (VpnController.killSwitchEnabled) {
                val ctx = getApplication<Application>()
                runCatching {
                    ctx.startService(
                        Intent(ctx, XrayVpnService::class.java)
                            .setAction(XrayVpnService.ACTION_BLOCK)
                            .putExtra(XrayVpnService.EXTRA_ERROR, message)
                    )
                }.onFailure {
                    VpnController.state.value = VpnState.Error(message)
                }
            } else {
                requestStopAndWaitIdle(5_000L)
                VpnController.state.value = VpnState.Error(message)
            }
        }
    }

    private fun isGenerationCurrent(generation: Long): Boolean = generation == connectionGeneration

    /** Посылает STOP сервису и ждёт его фактического перехода в Idle. */
    private suspend fun requestStopAndWaitIdle(timeoutMs: Long): Boolean {
        val ctx = getApplication<Application>()
        runCatching {
            ctx.startService(Intent(ctx, XrayVpnService::class.java).setAction(XrayVpnService.ACTION_STOP))
        }.onFailure { log("WARN", "Не удалось отправить STOP сервису: ${it.message}") }

        val stopped = withTimeoutOrNull(timeoutMs) {
            while (VpnController.state.value != VpnState.Idle) {
                delay(50)
            }
            true
        } ?: false
        return stopped
    }

    /**
     * Bounded bootstrap DNS for the proxy server.
     *
     * withTimeout { InetAddress.getAllByName() } is not a real timeout: the JVM
     * resolver is a blocking call and ignores coroutine cancellation. Run it in a
     * daemon worker and wait with Future.get(timeout), so one broken DNS resolver
     * cannot stall the whole failover chain for tens of seconds.
     */
    private suspend fun resolveHostTimed(host: String, timeoutMs: Long): String? =
        withContext(ResourceGovernor.dispatcher) {
            if (host.isBlank()) return@withContext null
            if (host.contains(':') || host.matches(Regex("""\d{1,3}(?:\.\d{1,3}){3}"""))) {
                return@withContext host
            }

            val task = ResourceGovernor.dnsExecutor.submit<String?> {
                runCatching {
                    InetAddress.getAllByName(host).let { all ->
                        (all.firstOrNull { it is Inet4Address } ?: all.firstOrNull())?.hostAddress
                    }
                }.getOrNull()
            }

            try {
                task.get(timeoutMs.coerceAtLeast(250L), TimeUnit.MILLISECONDS)
            } catch (_: TimeoutException) {
                task.cancel(true)
                null
            } catch (_: Throwable) {
                task.cancel(true)
                null
            }
        }

    fun disconnect() {
        cancelAutoSelection()
        ++connectionGeneration
        connectJob?.cancel()
        connectJob = null
        reconnectJob?.cancel()
        reconnectJob = null
        // Cancellation invalidates the old generation, so its guarded finally
        // cannot reset these flags. Precheck may not have started a VPN service.
        _isConnecting.value = false
        _scanStatus.value = ""

        val ctx = getApplication<Application>()
        runCatching {
            ctx.startService(Intent(ctx, XrayVpnService::class.java).setAction(XrayVpnService.ACTION_STOP))
        }.onFailure {
            // If the service was never started, there is nothing to wait for.
            if (VpnController.state.value == VpnState.Connecting) {
                VpnController.state.value = VpnState.Idle
            }
            log("WARN", "Не удалось остановить VPN-сервис: ${it.message}")
        }
        log("INFO", "Отключение")
    }

    /** Есть ли у системы разрешение на VPN (null = есть, иначе Intent для запроса). */
    fun vpnPermissionIntent(): Intent? = VpnService.prepare(getApplication())

    /** Presentation only: XrayVpnService owns the destructive native traffic API. */
    private fun observeTrafficAndNotificationStop() {
        viewModelScope.launch {
            VpnController.trafficRate.collect { rate ->
                _downloadMbps.value = rate.downloadMbps
                _uploadMbps.value = rate.uploadMbps
            }
        }
        var lastHandled = VpnController.stopRequestSerial.value
        viewModelScope.launch {
            VpnController.stopRequestSerial.collect { serial ->
                if (serial == lastHandled) return@collect
                lastHandled = serial
                // A notification Stop must also cancel precheck and queued UI reconnection;
                // otherwise a delayed ACTION_START could turn VPN back on.
                cancelAutoSelection()
                ++connectionGeneration
                connectJob?.cancel()
                connectJob = null
                reconnectJob?.cancel()
                reconnectJob = null
                _isConnecting.value = false
                _isConnected.value = false
                _scanStatus.value = ""
            }
        }
    }

    private fun stopStats() {
        // The service zeros its shared counters at disconnect; ViewModel only presents them.
        _downloadMbps.value = 0f
        _uploadMbps.value = 0f
    }

    // ---------- серверы ----------
    private suspend fun precheckServer(server: Server, alternate: Boolean = false, finalAttempt: Boolean = true, allowAlternate: Boolean = true): Boolean {
        val ctx = getApplication<Application>()
        val result = ServerPrechecker.check(ctx, server, alternate = alternate, allowAlternate = allowAlternate, finalAttempt = finalAttempt)
        currentCoroutineContext().ensureActive()
        if (result.ms != null && result.youtubePassed && result.speedVerified &&
            WorkingPoolPolicy.qualifiesRtt(result.connectMs)) {
            // Only the live SOCKS CONNECT measurement can qualify a reserve.
            // Neither source-labelled ping nor full HTTPS wall time is valid RTT.
            WorkingServerStore.recordSuccess(ctx, server,
                connectMs = result.connectMs!!,
                httpsMs = result.ms,
                youtubeVerified = true,
                speedVerified = result.speedVerified,
                downloadMbps = result.downloadMbps,
                uploadMbps = result.uploadMbps)
            SlowStandbyStore.remove(ctx, server.id)
            refreshWorkingPool()
            return true
        }
        if (SlowStandbyPolicy.shouldPark(result.ms, result.connectMs, result.youtubePassed)) {
            SlowStandbyStore.park(ctx, server, result.connectMs!!)
            WorkingServerStore.demoteSpeedQuality(ctx, server.id)
            refreshWorkingPool()
            return false
        }
        if (finalAttempt && result.retryAfterMs == null) {
            WorkingServerStore.recordFailure(ctx, server.id)
            refreshWorkingPool()
        }
        return false
    }

    /** Request a recheck; the foreground service retains the scanner when UI closes. */
    fun checkServers(force: Boolean = false) {
        ServerScanner.request(force)
    }

    private fun observeScanner() {
        viewModelScope.launch {
            ServerStore.revision.collect {
                _servers.value = ServerStore.loadCached(getApplication(), favoriteIds)
                if (_selectedServer.value == null) {
                    _selectedServer.value = _servers.value.firstOrNull()
                }
                if (autoSelectionPending.value) completeAutoSelection()
            }
        }
        viewModelScope.launch {
            ServerRepository.latestStatuses.collect { statuses ->
                if (statuses.isNotEmpty()) _sourceStatuses.value = statuses
            }
        }
        viewModelScope.launch {
            while (isActive) {
                delay(30_000)
                refreshWorkingPool()
                completeAutoSelection()
            }
        }
        viewModelScope.launch {
            ServerScanner.status.collect { status ->
                _isScanning.value = status.running
                _scanStatus.value = status.message
                // Freshness changes with time even without a database write.
                refreshWorkingPool()
            }
        }
        viewModelScope.launch {
            SlowStandbyStore.revision.collect { refreshWorkingPool() }
        }
        viewModelScope.launch {
            WorkingServerStore.revision.collect {
                refreshWorkingPool()
                if (autoSelectionPending.value) {
                    completeAutoSelection()
                } else if (_autoConnect.value && _connectionMode.value == ConnectionMode.AUTO && !automaticConnectSuppressed &&
                    !_isConnected.value && !_isConnecting.value &&
                    _readyWorkingCount.value > 0 && vpnPermissionIntent() == null) {
                    selectAutoServer()
                }
            }
        }
    }

    private fun refreshWorkingPool() {
        val app = getApplication<Application>()
        val now = System.currentTimeMillis()
        val records = WorkingServerStore.savedRecords(app)
        _workingServers.value = records.filter { it.isActive(now) }.map {
            it.server.copy(ping = it.effectivePingMs(), isFavorite = it.server.id in favoriteIds)
        }
        val workingIds = _workingServers.value.mapTo(HashSet()) { it.id }
        _slowStandby.value = SlowStandbyStore.entries(app)
            .filterNot { it.server.id in workingIds }
            .map { it.server.copy(ping = it.measuredPingMs, isFavorite = it.server.id in favoriteIds) }
        _readyWorkingCount.value = workingIds.size
        _workingStatuses.value = (records.associate { record ->
            record.server.id to when {
                record.isActive(now) && record.failures == 1 -> "Готов условно · 1 неудачный аудит, перепроверю"
                record.isActive(now) -> "Готов · YouTube, скорость и RTT подтверждены"
                record.failures > 0 && record.lastFailureAtMs >= record.lastSuccessAtMs -> "Недоступен · перепроверяем"
                else -> "Сохранён · нужна свежая проверка"
            }
        } + _slowStandby.value.associate { it.id to "Ожидание · RTT >100 мс, периодически перепроверю" })
    }

    private fun chooseBestAutoServer(): Server? {
        val ctx = getApplication<Application>()
        val records = WorkingServerStore.activeRecords(ctx)
            .filter { XrayConfigBuilder.build(it.server, null) != null &&
                TlsRiskStore.eligibleForAutomaticUse(ctx, it.server.id) }
        // All scores come from actual successful paired throughput tests and SOCKS RTT.
        val metrics = records.map { rec ->
            AutoServerRanking.Metrics(rec.server.id, rec.effectivePingMs(),
                rec.verifiedDownloadMbps, rec.verifiedUploadMbps)
        }
        // Prefer stable device-observed quality rather than a one-off speed burst.
        // Respect transient/cooldown signals without discarding stored certificates.
        val ranked = records.filter { record ->
            metrics.firstOrNull { it.id == record.server.id }?.let(AutoServerRanking::eligible) == true
        }.sortedWith(compareByDescending<WorkingServerStore.Record> {
            it.stabilityScore(System.currentTimeMillis())
        }.thenBy { it.effectivePingMs() }.thenBy { it.server.id })
        val viable = ranked.filterNot { healthLedger.isCoolingDown(it.server.id) }
        val best = viable.firstOrNull() ?: ranked.firstOrNull()
        // Retain the previously selected working server unless the challenger
        // clearly wins: switching public egress IPs disrupts live video flows.
        val currentId = VpnController.activeServer.value?.id ?: _selectedServer.value?.id
        val current = viable.firstOrNull { it.server.id == currentId }
        val chosen = if (current != null && best != null &&
            ServerStabilityPolicy.shouldKeepCurrent(
                current.stabilityScore(System.currentTimeMillis()),
                best.stabilityScore(System.currentTimeMillis()))) current else best
        return chosen?.let {
            it.server.copy(ping = it.effectivePingMs(), isFavorite = it.server.id in favoriteIds)
        }
    }

    /**
     * Автовыбор среди проверенных рабочих серверов с приоритетом реального RTT.
     */
    private fun connectionInProgress(): Boolean =
        _isConnecting.value || connectJob?.isActive == true || reconnectJob?.isActive == true ||
            VpnController.state.value == VpnState.Connecting || VpnController.state.value == VpnState.Validating

    fun selectAutoServer() {
        setConnectionMode(ConnectionMode.AUTO)
        if (connectionInProgress() || autoSelectionPending.value) return
        _vpnError.value = null
        if (vpnPermissionIntent() != null) {
            _vpnError.value = "Нужно системное разрешение VPN. Нажмите «Подключить»."
            return
        }
        if (!XrayCore.isAvailable()) {
            _vpnError.value = "Ядро Xray отсутствует: проверить серверы пока невозможно."
            return
        }
        automaticConnectSuppressed = false
        autoSelection.request()
        refreshWorkingPool()
        if (completeAutoSelection()) return

        // Only an empty catalogue waits; strict полного резерва admission is never a prerequisite.
        checkServers()
        if (_servers.value.isEmpty()) {
            if (_sources.value.none { it.enabled } && _workingServers.value.isEmpty()) {
                cancelAutoSelection()
                _vpnError.value = "Источники временно недоступны. Каталог будет обновляться автоматически."
                return
            }
            prefs.edit().putLong(ServerStore.CATALOGUE_ATTEMPT_KEY, 0L).apply()
        }
        log("INFO", "Автовыбор: ожидаю первую реальную конфигурацию, затем подключусь без ожидания готового резерва")
    }

    fun cancelAutoSelection() {
        autoSelection.cancel()
        // Explicit cancellation/disconnection takes precedence over the startup setting.
        automaticConnectSuppressed = true
    }

    private fun completeAutoSelection(): Boolean {
        if (!autoSelectionPending.value) return false
        if (vpnPermissionIntent() != null) {
            cancelAutoSelection()
            _vpnError.value = "Разрешение VPN отозвано. Нажмите «Подключить» и подтвердите его."
            return true
        }
        // No strict backup ready? Try a recently reachable or compatible cached
        // server immediately; strict speed admission continues AFTER connecting.
        val candidate = chooseBestAutoServer() ?: chooseQuickAutoCandidate()
        if (candidate == null) {
            // Never pop warnings for each failed catalogue probe. Only ask for
            // consent when automatic selection has exhausted safe choices.
            val risky = (ServerStore.loadCached(getApplication()) +
                listOfNotNull(_selectedServer.value))
                .firstOrNull { TlsRiskStore.isRisky(getApplication(), it.id) &&
                    XrayConfigBuilder.build(it, null) != null }
            if (risky != null && !connectionInProgress()) {
                autoSelection.cancel()
                VpnController.riskyCandidate.value = risky
                _vpnError.value = "Безопасного сервера пока не найдено; рискованный доступен только по согласию"
                return true
            }
            return false
        }
        if (!autoSelection.consumeIf(true, connectionInProgress())) return false
        _selectedServer.value = candidate.copy(isFavorite = candidate.id in favoriteIds)
        selectedServerExplicit = false
        prefs.edit().putString("selected_server", candidate.id)
            .putBoolean("selected_server_explicit", false).apply()
        log("INFO", "Автовыбор: подключаю ${candidate.country} · ${candidate.city}; качество 720p проверю после подключения")
        if (_isConnected.value && VpnController.activeServer.value?.id == candidate.id) return true
        if (_isConnected.value || VpnController.state.value != VpnState.Idle) {
            reconnectTo(candidate, forcePrimary = false)
        } else {
            connect()
        }
        return true
    }

    private fun chooseQuickAutoCandidate(): Server? {
        val ctx = getApplication<Application>()
        val records = WorkingServerStore.activeServers(ctx)
            .filter { TlsRiskStore.eligibleForAutomaticUse(ctx, it.id) }
        val history = WorkingServerStore.historicalRecoveryRecords(ctx)
            .map { it.server.copy(ping = it.effectivePingMs()) }
        val catalog = ServerStore.loadCached(ctx)
            .filter { TlsRiskStore.eligibleForAutomaticUse(ctx, it.id) }
        val selected = _selectedServer.value?.takeIf { TlsRiskStore.eligibleForAutomaticUse(ctx, it.id) }
            ?: records.firstOrNull()
            ?: history.firstOrNull() ?: catalog.firstOrNull() ?: return null
        return QuickConnectPolicy.order(selected, ConnectionMode.AUTO, false,
            records, history, ConnectionHistoryStore.recentIds(ctx), catalog,
            isCoolingDown = { healthLedger.isCoolingDown(it.id) },
            publicRanks = PublicRankingFeed.priorities(ctx, catalog))
            .firstOrNull { XrayConfigBuilder.build(it, null) != null }
    }

    /** Only an explicit dialog click can temporarily use a quarantined free server. */
    fun connectRiskyOnce(server: Server) {
        val ctx = getApplication<Application>()
        if (!TlsRiskStore.isRisky(ctx, server.id)) return
        VpnController.riskyCandidate.value = null
        if (vpnPermissionIntent() != null) {
            _vpnError.value = "Сначала разрешите VPN в Android, затем подтвердите риск ещё раз."
            return
        }
        TlsRiskStore.approveForThisSession(server.id)
        setConnectionMode(ConnectionMode.AUTO)
        autoSelection.cancel()
        _selectedServer.value = server
        selectedServerExplicit = false
        _vpnError.value = null
        connect()
    }

    /** One tap: connect the selected compatible server even if 720p is not certified yet. */
    fun connectManualServer(server: Server) {
        if (!WorkingPoolPolicy.eligible(server) || XrayConfigBuilder.build(server, null) == null) {
            _vpnError.value = "Сервер несовместим или не отвечает требованиям страны."
            return
        }
        if (vpnPermissionIntent() != null) {
            _vpnError.value = "Подтвердите системное разрешение VPN."
            return
        }
        setConnectionMode(ConnectionMode.MANUAL)
        val available = WorkingServerStore.activeRecord(getApplication(), server.id)
        val chosen = available?.server?.copy(ping = available.effectivePingMs()) ?: server
        if (_isConnected.value && VpnController.activeServer.value?.id == chosen.id) {
            _selectedServer.value = chosen
            selectedServerExplicit = true
            prefs.edit().putString("selected_server", chosen.id)
                .putBoolean("selected_server_explicit", true).apply()
            return
        }
        selectServer(chosen) // while active it performs a core handover on the same TUN
        if (!connectionInProgress()) connect() // otherwise launch immediately
    }

    fun selectServer(server: Server) {
        setConnectionMode(ConnectionMode.MANUAL)
        cancelAutoSelection()
        val wasActive =
            _isConnected.value ||
                _isConnecting.value ||
                VpnController.state.value !is VpnState.Idle

        _selectedServer.value = server
        selectedServerExplicit = true
        prefs.edit()
            .putString("selected_server", server.id)
            .putBoolean("selected_server_explicit", true)
            .apply()
        log("INFO", "Выбран сервер: ${server.country} · ${server.city}")

        if (!wasActive) return

        reconnectTo(server, forcePrimary = true)
    }

    /**
     * Hot-reload the selected server without STOP -> Idle. XrayVpnService keeps the
     * existing TUN fd and swaps only the core, so Android apps do not see the VPN
     * network disappear/reappear during a manual server/profile change.
     */
    private fun reconnectTo(server: Server, forcePrimary: Boolean) {
        // Manual/adaptive reconnect always wins over background catalogue refresh.
        refreshJob?.cancel()
        connectJob?.cancel()
        connectJob = null
        reconnectJob?.cancel()

        val generation = ++connectionGeneration
        reconnectJob = viewModelScope.launch {
            try {
                connectInternal(server, generation, forcePrimary = forcePrimary)
            } finally {
                if (generation == connectionGeneration) {
                    reconnectJob = null
                    checkServers()
                }
            }
        }
    }

    fun toggleFavorite(serverId: String) {
        if (!favoriteIds.add(serverId)) favoriteIds.remove(serverId)
        prefs.edit().putStringSet("favorites", favoriteIds.toSet()).apply()
        _servers.value = _servers.value.map { if (it.id == serverId) it.copy(isFavorite = serverId in favoriteIds) else it }
        _workingServers.value = _workingServers.value.map {
            if (it.id == serverId) it.copy(isFavorite = serverId in favoriteIds) else it
        }
        _selectedServer.value?.let { sel ->
            if (sel.id == serverId) _selectedServer.value = sel.copy(isFavorite = serverId in favoriteIds)
        }
    }

    private fun markRecent(id: String) {
        _recentIds.value = (listOf(id) + _recentIds.value.filter { it != id }).take(10)
        prefs.edit().putString(
            "recent_ids",
            JSONArray(_recentIds.value).toString()
        ).apply()
    }

    // ---------- настройки ----------
    fun setAutoConnect(v: Boolean) {
        _autoConnect.value = v
        if (!v) cancelAutoSelection() else automaticConnectSuppressed = false
        savePref("auto_connect", v)
        log("INFO", "Автоподключение: ${if (v) "вкл" else "выкл"}")
        if (v && !_isConnected.value && !_isConnecting.value && vpnPermissionIntent() == null) {
            selectAutoServer()
        }
    }

    fun setAutoRecovery(v: Boolean) {
        _autoRecovery.value = v
        VpnController.autoRecoveryEnabled = v
        savePref("auto_recovery", v)
        log("INFO", "Автопереключение: ${if (v) "вкл" else "выкл"}")
    }

    fun setKillSwitch(v: Boolean) {
        _killSwitch.value = v
        VpnController.killSwitchEnabled = v
        savePref("kill_switch", v)
        log("INFO", "Kill Switch: ${if (v) "вкл" else "выкл"}")
        // Если выключили KS, а сейчас Blocked — полностью отпустить сеть
        if (!v && VpnController.state.value is VpnState.Blocked) {
            disconnect()
        }
    }

    // ---------- источники ----------
    fun toggleSource(id: String) {
        _sources.value = _sources.value.map { if (it.id == id) it.copy(enabled = !it.enabled) else it }
        prefs.edit().putStringSet(
            "disabled_sources",
            _sources.value.filterNot { it.enabled }.map { it.id }.toSet()
        ).putLong(ServerStore.CATALOGUE_ATTEMPT_KEY, 0L).apply()
    }

    fun refreshSources() {
        if (_isRefreshing.value) return
        if (ResourceGovernor.isMemoryPressured(getApplication())) {
            _refreshError.value = "Обновление отложено: устройство под давлением памяти. VPN продолжит работать на локальном кэше."
            log("WARN", "Refresh пропущен: ${ResourceGovernor.resourceSummary(getApplication())}")
            return
        }
        refreshJob?.cancel()
        refreshJob = viewModelScope.launch {
            _isRefreshing.value = true
            _refreshError.value = null
            val active = _sources.value.count { it.enabled }
            if (active == 0) {
                _refreshError.value = "Все источники отключены. Включите хотя бы один источник."
                _isRefreshing.value = false
                return@launch
            }
            log("INFO", "Загрузка конфигов из источников: $active")
            try {
                val ctx = getApplication<Application>()
                val page = prefs.getInt("catalogue_source_page_v1", 0).coerceAtLeast(0)
                // Import text first: probing 100 nodes before showing a refreshed
                // list blocked the UI on mobile data and made Refresh look broken.
                val result = ServerRepository.refresh(
                    _sources.value,
                    probeBeforeScan = false,
                    sourcePage = page,
                    preferredSources = WorkingServerStore.preferredSourceNames(ctx)
                )
                _sourceStatuses.value = result.statuses
                if (result.servers.isNotEmpty()) {
                    val proven = WorkingServerStore.activeRecords(ctx).map { it.server } +
                        WorkingServerStore.historicalRecoveryRecords(ctx).take(8).map { it.server }
                    _servers.value = (proven + result.servers + ServerStore.loadCached(ctx))
                        .distinctBy { it.id }.take(ServerStore.MAX_CACHED_SERVERS)
                        .map { it.copy(isFavorite = it.id in favoriteIds) }
                    ServerStore.saveCached(ctx, _servers.value)
                    prefs.edit().putInt("catalogue_source_page_v1", if (page >= 1_000_000) 0 else page + 1).apply()
                    val currentId = _selectedServer.value?.id
                    val preserved = _servers.value.firstOrNull { it.id == currentId }
                    _selectedServer.value = preserved ?: chooseBestAutoServer() ?: _servers.value.firstOrNull()
                    if (preserved == null) {
                        selectedServerExplicit = false
                    }
                    ResourceGovernor.clearTransientPressure()
                    _selectedServer.value?.let {
                        prefs.edit()
                            .putString("selected_server", it.id)
                            .putBoolean("selected_server_explicit", selectedServerExplicit)
                            .apply()
                    }
                    log("INFO", "Загружено серверов: ${result.servers.size}")
                    checkServers(force = true)
                    if (_readyWorkingCount.value > 0 && _autoConnect.value && !automaticConnectSuppressed &&
                        !_isConnected.value && !_isConnecting.value &&
                        vpnPermissionIntent() == null
                    ) {
                        selectAutoServer()
                    }
                } else {
                    val sourceError = result.statuses.firstOrNull { !it.error.isNullOrBlank() }?.error
                    _refreshError.value = sourceError ?: "Источники не вернули поддерживаемых серверов."
                    log("WARN", "Источники не вернули пригодных серверов")
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                // Не даём исключению из парсера/сети убить UI-корутину: ошибка
                // должна попасть на экран и в журнал, а не завершить приложение.
                val message = e.message?.takeIf { it.isNotBlank() } ?: e.javaClass.simpleName
                _refreshError.value = "Не удалось обновить серверы: $message"
                log("ERROR", "Ошибка загрузки: $message")
            } finally {
                _isRefreshing.value = false
                refreshJob = null
                checkServers()
            }
        }
    }

    private fun persistHealthLedger() {
        val arr = JSONArray()
        healthLedger.snapshot().forEach { e ->
            arr.put(
                JSONObject()
                    .put("id", e.serverId)
                    .put("success", e.lastSuccessAtMs)
                    .put("failure", e.lastFailureAtMs)
                    .put("fails", e.consecutiveFailures)
                    .put("cooldown", e.cooldownUntilMs)
                    .put("ewma", e.ewmaHttpsMs ?: JSONObject.NULL)
                    .put("stage", e.lastFailureStage ?: JSONObject.NULL)
            )
        }
        prefs.edit().putString("health_ledger_v1", arr.toString()).apply()
    }

    private fun restoreHealthLedger(arr: JSONArray) {
        val restored = buildList {
            for (i in 0 until arr.length()) {
                val j = arr.optJSONObject(i) ?: continue
                val id = j.optString("id")
                if (id.isBlank()) continue
                add(
                    ServerHealthLedger.Entry(
                        serverId = id,
                        lastSuccessAtMs = j.optLong("success", 0L),
                        lastFailureAtMs = j.optLong("failure", 0L),
                        consecutiveFailures = j.optInt("fails", 0),
                        cooldownUntilMs = j.optLong("cooldown", 0L),
                        ewmaHttpsMs = if (j.isNull("ewma")) null else j.optDouble("ewma").takeIf { it.isFinite() && it > 0.0 },
                        lastFailureStage = if (j.isNull("stage")) null else j.optString("stage").takeIf { it.isNotBlank() }
                    )
                )
            }
        }
        healthLedger.restore(restored)
    }

    private val quietLogPolicy = QuietRuntimeLogPolicy()

    private fun log(level: String, message: String) {
        // Background scans and successful probes update live state, not a rolling log.
        if (level != "WARN" && level != "ERROR") return
        val safeMessage = VpnDiagnosticRedactor.sanitize(message).take(240)
        if (!quietLogPolicy.accept(level, safeMessage, System.currentTimeMillis())) return
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        // In-memory only. Diagnostics are exported explicitly by the user.
        _logs.value = (listOf(LogEntry(time, level, safeMessage)) + _logs.value).take(24)
    }

    override fun onCleared() {
        ++connectionGeneration
        connectJob?.cancel()
        reconnectJob?.cancel()
        refreshJob?.cancel()
        ServerScanner.release(scannerOwner)
        super.onCleared()
    }
}
