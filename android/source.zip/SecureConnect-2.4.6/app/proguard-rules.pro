# AndroidLibXrayLite / gomobile. These classes and methods are accessed through
# reflection from XrayCore.kt and must survive R8 shrinking/obfuscation.
-keep class libv2ray.** { *; }
-keep class go.** { *; }
-dontwarn libv2ray.**
-dontwarn go.**

# Parcelable generated CREATOR fields.
-keepclassmembers class * implements android.os.Parcelable {
    public static final ** CREATOR;
}

# Coroutine service-loader implementations.
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
