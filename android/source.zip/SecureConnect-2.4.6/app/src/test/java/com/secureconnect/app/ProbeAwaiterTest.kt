package com.secureconnect.app

import com.secureconnect.app.vpn.ProbeAwaiter
import java.util.concurrent.CompletableFuture
import java.util.concurrent.TimeUnit
import org.junit.Assert.*
import org.junit.Test

class ProbeAwaiterTest {
    @Test fun completedAlternateSurvivesPrimaryExhaustingTheWaitBudget() {
        val alternate = CompletableFuture.completedFuture("HTTPS PASS")
        assertEquals("HTTPS PASS", ProbeAwaiter.completedOrWithin(alternate, -1L))
    }

    @Test fun unfinishedAlternateDoesNotBlockAfterDeadline() {
        val alternate = CompletableFuture<String>()
        assertNull(ProbeAwaiter.completedOrWithin(alternate, 0L))
        assertFalse(alternate.isDone)
    }

    @Test fun failedAndCancelledAlternatesCannotPassValidation() {
        val failed = CompletableFuture<String>()
        failed.completeExceptionally(IllegalStateException("TLS failed"))
        assertNull(ProbeAwaiter.completedOrWithin(failed, 0L))
        val cancelled = CompletableFuture<String>()
        cancelled.cancel(true)
        assertNull(ProbeAwaiter.completedOrWithin(cancelled, 0L))
    }

    @Test fun interruptionIsPreservedForCallerCancellation() {
        val pending = CompletableFuture<String>()
        Thread.currentThread().interrupt()
        try {
            assertNull(ProbeAwaiter.completedOrWithin(pending, TimeUnit.SECONDS.toNanos(1)))
            assertTrue(Thread.currentThread().isInterrupted)
        } finally {
            Thread.interrupted()
        }
    }
}
