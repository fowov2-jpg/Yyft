package com.secureconnect.app.ui.screens.settings

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.draw.clip
import androidx.core.graphics.drawable.toBitmap
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.secureconnect.app.ui.components.NativeGroup
import com.secureconnect.app.ui.components.NativeSectionTitle
import com.secureconnect.app.ui.components.ScreenTopBar
import com.secureconnect.app.ui.theme.ScCard
import com.secureconnect.app.ui.theme.ScError
import com.secureconnect.app.ui.theme.ScPrimary
import com.secureconnect.app.ui.theme.ScTextPrimary
import com.secureconnect.app.ui.theme.ScTextSecondary
import com.secureconnect.app.viewmodel.MainViewModel
import com.secureconnect.app.vpn.AppVpnMode
import com.secureconnect.app.vpn.InstalledVpnApp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** UI switches represent VPN participation. OFF = ordinary Wi-Fi/mobile data. */
@Composable
fun AppRoutingScreen(vm: MainViewModel) {
    val routing by vm.appRouting.collectAsStateWithLifecycle()
    // Loading hundreds of package labels on the UI thread can freeze navigation.
    var loadError by remember { mutableStateOf<String?>(null) }
    val installedState by produceState<List<InstalledVpnApp>?>(initialValue = null) {
        val loaded = withContext(Dispatchers.IO) { runCatching { vm.installedVpnApps() } }
        loadError = loaded.exceptionOrNull()?.message
        value = loaded.getOrDefault(emptyList())
    }
    val installed = installedState.orEmpty()
    var search by remember { mutableStateOf("") }
    var onlyRussian by remember { mutableStateOf(false) }
    var showSystemApps by remember { mutableStateOf(false) }
    var preparingWhitelist by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var showRoutingHelp by remember { mutableStateOf(false) }

    val whitelistView = preparingWhitelist || routing.mode == AppVpnMode.ONLY_SELECTED
    // Stable result while typing/scrolling; recompute only when inputs change.
    val shown = remember(installed, onlyRussian, showSystemApps, search) {
        installed.filter { app ->
            (!onlyRussian || app.russianPreset) &&
                (showSystemApps || !app.systemApp || app.russianPreset) &&
                (search.isBlank() || app.title.contains(search, ignoreCase = true) ||
                    app.packageName.contains(search, ignoreCase = true))
        }
    }
    val (vpnAppCount, russianDirectCount) = remember(installed, routing, whitelistView) {
        val usesVpn: (InstalledVpnApp) -> Boolean = { app ->
            if (whitelistView) app.packageName in routing.included
            else routing.usesVpn(app.packageName)
        }
        installed.count(usesVpn) to installed.count { it.russianPreset && !usesVpn(it) }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenTopBar("Приложения")
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                NativeGroup {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 17.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("МАРШРУТИЗАЦИЯ", color = ScTextSecondary,
                                style = MaterialTheme.typography.labelSmall)
                            Text("Управление доступом к VPN",
                                color = ScTextPrimary, style = MaterialTheme.typography.titleMedium)
                            Text("Для каждого приложения можно выбрать маршрут.",
                                color = ScTextSecondary, style = MaterialTheme.typography.bodySmall)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("$russianDirectCount", color = ScPrimary,
                                style = MaterialTheme.typography.headlineMedium)
                            Text("напрямую", color = ScTextSecondary,
                                style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
            item {
                NativeSectionTitle("Режим маршрутизации")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = !whitelistView,
                        onClick = {
                            preparingWhitelist = false
                            error = vm.setAppRoutingMode(AppVpnMode.EXCLUDE_SELECTED)
                        },
                        label = { Text("Все, кроме") }
                    )
                    FilterChip(
                        selected = whitelistView,
                        onClick = {
                            if (routing.mode != AppVpnMode.ONLY_SELECTED) {
                                if (routing.included.isEmpty()) {
                                    preparingWhitelist = true
                                    error = null
                                } else {
                                    error = vm.setAppRoutingMode(AppVpnMode.ONLY_SELECTED)
                                    preparingWhitelist = error != null
                                }
                            }
                        },
                        label = { Text("Только выбранные") }
                    )
                }
            }
            item {
                Text(
                    if (whitelistView) "Выбранные приложения — через VPN, остальные — напрямую."
                    else "Включено — через VPN. Выключено — напрямую.",
                    style = MaterialTheme.typography.bodySmall,
                    color = ScTextSecondary
                )
            }
            if (!whitelistView) item {
                NativeGroup {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 13.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("Российские приложения напрямую",
                                color = ScTextPrimary, style = MaterialTheme.typography.bodyLarge)
                            Text("Исключения применяются автоматически",
                                color = ScTextSecondary, style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(
                            checked = routing.autoExcludeRussian,
                            onCheckedChange = { error = vm.setRussianAutoBypass(it) }
                        )
                    }
                }
            }
            if (preparingWhitelist) {
                item {
                    Text(
                        "Отметьте ниже хотя бы одно приложение, затем нажмите «Применить режим». " +
                            "До применения текущий режим не изменится.",
                        color = ScPrimary,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                item {
                    Button(
                        onClick = {
                            error = vm.setAppRoutingMode(AppVpnMode.ONLY_SELECTED)
                            if (error == null) preparingWhitelist = false
                        },
                        enabled = routing.included.any { pkg -> installed.any { it.packageName == pkg } },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Применить режим") }
                }
            }
            error?.let { message ->
                item { Text(message, color = ScError, style = MaterialTheme.typography.bodyMedium) }
            }
            item {
                Column {
                    Text(
                        if (showRoutingHelp) "Как работает маршрутизация ▲" else "Как работает маршрутизация ▼",
                        color = ScPrimary,
                        style = MaterialTheme.typography.labelLarge,
                        modifier = Modifier.fillMaxWidth().clickable { showRoutingHelp = !showRoutingHelp }
                            .padding(vertical = 10.dp)
                    )
                    if (showRoutingHelp) {
                        Text(
                            "Изменение маршрута при активном VPN может вызвать короткий разрыв. " +
                                "Kill Switch не блокирует исключённые приложения, но системная настройка " +
                                "Android «Блокировать подключения без VPN» может блокировать их. " +
                                "Прямой маршрут не скрывает от приложения факт наличия VPN в Android.",
                            color = ScTextSecondary,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
            item {
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    label = { Text("Поиск по названию или пакету") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = !onlyRussian,
                        onClick = { onlyRussian = false },
                        label = { Text("Все приложения") }
                    )
                    FilterChip(
                        selected = onlyRussian,
                        onClick = { onlyRussian = true },
                        label = { Text("Российские") }
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Показывать системные приложения", color = ScTextSecondary,
                        style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                    Switch(checked = showSystemApps, onCheckedChange = { showSystemApps = it })
                }
                Text(
                    "Найдено: ${shown.size} · VPN: $vpnAppCount " +
                        "· Российских напрямую: $russianDirectCount",
                    color = ScTextSecondary,
                    style = MaterialTheme.typography.bodySmall
                )
            }
            if (installedState == null) {
                item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    CircularProgressIndicator(color = ScPrimary)
                } }
            } else if (loadError != null) {
                item { Text("Не удалось получить список приложений: $loadError", color = ScError) }
            } else if (shown.isEmpty()) {
                item {
                    Text(
                        "Не найдено установленных приложений. Проверьте поиск или снимите фильтр.",
                        color = ScTextSecondary
                    )
                }
            }
            items(shown, key = { it.packageName }) { app ->
                val enabled = if (whitelistView) app.packageName in routing.included
                    else routing.usesVpn(app.packageName)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(ScCard, RoundedCornerShape(14.dp))
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    InstalledAppIcon(app.packageName, app.title)
                    Column(Modifier.weight(1f)) {
                        Text(app.title, color = ScTextPrimary, style = MaterialTheme.typography.titleSmall)
                        Text(
                            if (enabled) "Через VPN" else "Напрямую без VPN",
                            color = if (enabled) ScPrimary else ScTextSecondary,
                            style = MaterialTheme.typography.bodySmall
                        )
                        if (app.russianPreset) {
                            Text("Российское приложение", color = ScTextSecondary,
                                style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    Switch(
                        checked = enabled,
                        onCheckedChange = { newValue ->
                            error = when {
                                preparingWhitelist -> vm.setPreparedAppIncluded(app.packageName, newValue)
                                else -> vm.setAppVpnEnabled(app.packageName, newValue)
                            }
                        }
                    )
                }
            }
            item {
                Text(
                    "Правила применяются Android к UID приложения. Изменение маршрута " +
                        "при работающем VPN может ненадолго прервать соединение.",
                    style = MaterialTheme.typography.bodySmall,
                    color = ScTextSecondary
                )
            }
        }
    }
}


/**
 * App icons load only for the visible LazyColumn rows, off the main thread.
 * Each icon is downscaled to 72 px to avoid keeping large launcher bitmaps in memory.
 */
@Composable
private fun InstalledAppIcon(packageName: String, title: String) {
    val context = LocalContext.current
    val iconBitmap by produceState<android.graphics.Bitmap?>(null, packageName) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                context.packageManager.getApplicationIcon(packageName)
                    .toBitmap(width = 72, height = 72)
            }.getOrNull()
        }
    }
    val bitmap = iconBitmap
    if (bitmap != null) {
        Image(
            bitmap = bitmap.asImageBitmap(),
            contentDescription = null,
            modifier = Modifier.size(38.dp).clip(RoundedCornerShape(10.dp))
        )
    } else {
        Box(
            Modifier.size(38.dp)
                .background(com.secureconnect.app.ui.theme.ScPrimarySoft, RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(title.take(1).uppercase(), color = ScTextPrimary,
                style = MaterialTheme.typography.titleSmall)
        }
    }
}
