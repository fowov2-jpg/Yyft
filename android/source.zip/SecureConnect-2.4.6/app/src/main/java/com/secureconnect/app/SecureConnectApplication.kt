package com.secureconnect.app

import android.app.Application
import android.content.Context
import android.util.Log
import com.secureconnect.app.util.ResourceGovernor

class SecureConnectApplication : Application() {
    override fun onCreate() {
        ResourceGovernor.configureRuntimeHints()
        super.onCreate()
        installCrashRecorder()
    }

    override fun onTrimMemory(level: Int) {
        ResourceGovernor.noteTrimMemory(level)
        super.onTrimMemory(level)
    }

    override fun onLowMemory() {
        ResourceGovernor.noteTrimMemory(android.content.ComponentCallbacks2.TRIM_MEMORY_COMPLETE)
        super.onLowMemory()
    }

    private fun installCrashRecorder() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            runCatching {
                getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .edit()
                    .putString(KEY_CRASH_THREAD, thread.name)
                    .putString(KEY_CRASH, Log.getStackTraceString(throwable))
                    .apply()
            }
            // Android logs uncaught exceptions itself. Avoid duplicate crash output.
            previous?.uncaughtException(thread, throwable)
        }
    }

    companion object {
        const val PREFS = "sc_crash"
        const val KEY_CRASH = "last_crash"
        const val KEY_CRASH_THREAD = "last_crash_thread"
        private const val TAG = "SecureConnect"
    }
}
