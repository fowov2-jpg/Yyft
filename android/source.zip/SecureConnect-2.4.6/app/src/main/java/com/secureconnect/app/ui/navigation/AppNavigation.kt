package com.secureconnect.app.ui.navigation

import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.List
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.secureconnect.app.ui.screens.home.HomeScreen
import com.secureconnect.app.ui.screens.settings.AppRoutingScreen
import com.secureconnect.app.ui.screens.settings.DiagnosticsScreen
import com.secureconnect.app.ui.screens.settings.PremiumSecurityScreen
import com.secureconnect.app.ui.screens.settings.PremiumServersScreen
import com.secureconnect.app.ui.screens.settings.PremiumSettingsScreen
import com.secureconnect.app.ui.theme.ScBackground
import com.secureconnect.app.ui.theme.ScPrimary
import com.secureconnect.app.ui.theme.ScSurface
import com.secureconnect.app.ui.theme.ScTextSecondary
import com.secureconnect.app.ui.theme.ScOnPrimary
import com.secureconnect.app.viewmodel.MainViewModel
import com.secureconnect.app.vpn.VpnController

/**
 * Compact three-tab navigation with an animated (non-looping) selection marker.
 * Navigation never restarts or changes the VPN service.
 */
@Composable
fun AppNavigation(vm: MainViewModel) {
    val nav = rememberNavController()
    val currentEntry by nav.currentBackStackEntryAsState()
    val selectedRoute = currentEntry?.destination?.route ?: Screen.Home.route
    val riskyCandidate by VpnController.riskyCandidate.collectAsStateWithLifecycle()

    fun selectTab(route: String) {
        if (selectedRoute == route) return
        nav.navigate(route) {
            popUpTo(Screen.Home.route) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    riskyCandidate?.let { candidate ->
        AlertDialog(
            onDismissRequest = {
                VpnController.riskyCandidate.value = null
                vm.cancelAutoSelection()
            },
            title = { Text("Сертификат не подтверждён") },
            text = {
                Text(
                    "Сервер ${candidate.country} (${candidate.host}) не прошёл проверку TLS. " +
                        "Он исключён из автоматического выбора. Разрешить рискованный маршрут " +
                        "только для этого сеанса?"
                )
            },
            confirmButton = {
                TextButton(onClick = { vm.connectRiskyOnce(candidate) }) {
                    Text("Разрешить один раз")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    VpnController.riskyCandidate.value = null
                    vm.cancelAutoSelection()
                }) { Text("Не подключаться") }
            }
        )
    }

    Scaffold(
        containerColor = ScBackground,
        bottomBar = {
            if (selectedRoute == Screen.Home.route ||
                selectedRoute == Screen.AppRouting.route ||
                selectedRoute == Screen.Diagnostics.route
            ) {
                NavigationBar(
                    containerColor = ScSurface,
                    tonalElevation = 0.dp
                ) {
                    BottomNavItem(selectedRoute == Screen.Home.route,
                        { selectTab(Screen.Home.route) }, "Главная", Icons.Filled.Home)
                    BottomNavItem(selectedRoute == Screen.AppRouting.route,
                        { selectTab(Screen.AppRouting.route) }, "Приложения", Icons.Filled.List)
                    BottomNavItem(selectedRoute == Screen.Diagnostics.route,
                        { selectTab(Screen.Diagnostics.route) }, "Защита", Icons.Filled.Info)
                }
            }
        }
    ) { insets ->
        NavHost(
            navController = nav,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(insets).clipToBounds()
        ) {
            composable(Screen.Home.route) {
                HomeScreen(
                    vm = vm,
                    onDiagnostics = { selectTab(Screen.Diagnostics.route) },
                    onServers = { nav.navigate(Screen.Servers.route) },
                    onSettings = { nav.navigate(Screen.Settings.route) }
                )
            }
            composable(Screen.AppRouting.route) { AppRoutingScreen(vm = vm) }
            composable(Screen.Diagnostics.route) {
                PremiumSecurityScreen(vm,
                    onDiagnostics = { nav.navigate(Screen.Technical.route) },
                    onSettings = { nav.navigate(Screen.Settings.route) })
            }
            composable(Screen.Servers.route) {
                PremiumServersScreen(vm, onBack = { nav.popBackStack() })
            }
            composable(Screen.Settings.route) {
                PremiumSettingsScreen(vm, onBack = { nav.popBackStack() })
            }
            composable(Screen.Technical.route) {
                DiagnosticsScreen(vm, onBack = { nav.popBackStack() })
            }
        }
    }
}

@Composable
private fun RowScope.BottomNavItem(
    selected: Boolean,
    onClick: () -> Unit,
    title: String,
    icon: ImageVector
) {
    NavigationBarItem(
        selected = selected,
        onClick = onClick,
        icon = { Icon(icon, contentDescription = null) },
        label = { Text(title, maxLines = 1) },
        alwaysShowLabel = true,
        colors = NavigationBarItemDefaults.colors(
            selectedIconColor = ScOnPrimary,
            selectedTextColor = ScPrimary,
            indicatorColor = ScPrimary,
            unselectedIconColor = ScTextSecondary,
            unselectedTextColor = ScTextSecondary
        )
    )
}
