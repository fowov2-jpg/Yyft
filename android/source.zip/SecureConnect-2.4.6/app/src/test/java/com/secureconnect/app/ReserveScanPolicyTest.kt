package com.secureconnect.app

import com.secureconnect.app.vpn.ReserveScanPolicy
import com.secureconnect.app.vpn.VpnState
import org.junit.Assert.*
import org.junit.Test

class ReserveScanPolicyTest {
    @Test fun connectingPausesButConnectedImmediatelyResumesReserveChecks() {
        assertFalse(ReserveScanPolicy.canLaunch(VpnState.Connecting, true, false))
        assertFalse(ReserveScanPolicy.canLaunch(VpnState.Validating, true, false))
        assertTrue(ReserveScanPolicy.canLaunch(VpnState.Connected, true, false))
        assertEquals(1, ReserveScanPolicy.workerCount(VpnState.Connected, true))
        assertEquals(2, ReserveScanPolicy.workerCount(VpnState.Idle, false))
    }

    @Test fun networkAndMemoryPausesDoNotLatchAfterRecovery() {
        assertFalse(ReserveScanPolicy.canLaunch(VpnState.Connected, false, false))
        assertFalse(ReserveScanPolicy.canLaunch(VpnState.Connected, true, true))
        assertTrue(ReserveScanPolicy.canLaunch(VpnState.Connected, true, false))
    }

    @Test fun verifiedSuccessIsNotRecheckedJustBecauseTimePassed() {
        val at = 1_000L
        assertFalse(ReserveScanPolicy.due(at + 60_000L, at, null))
        assertFalse(ReserveScanPolicy.due(at + ReserveScanPolicy.RECHECK_MS, at, null))
        assertTrue(ReserveScanPolicy.due(at + ReserveScanPolicy.RECHECK_MS, null, null))
        assertTrue(ReserveScanPolicy.priority(true, false) < ReserveScanPolicy.priority(false, false))
    }

    @Test fun failedNodesReturnToQueueWithBoundedBackoff() {
        assertEquals(300_000L, ReserveScanPolicy.retryDelayMs(1))
        assertEquals(600_000L, ReserveScanPolicy.retryDelayMs(2))
        assertEquals(1_800_000L, ReserveScanPolicy.retryDelayMs(100))
        assertFalse(ReserveScanPolicy.due(999L, 100L, 1_000L))
        assertTrue(ReserveScanPolicy.due(1_000L, 100L, 1_000L))
    }

    @Test fun latencyGoalPrefersConfirmedLowPingButKeepsSlowerAndUnknownCandidates() {
        val pings = listOf(0, 101, 100, -1, 40, 250)
        val ranked = pings.sortedWith(compareBy<Int> { ReserveScanPolicy.latencyPriority(it) }.thenBy { it })
        assertEquals(listOf(40, 100), ranked.take(2))
        assertEquals(6, ranked.size)
        assertEquals(1, ReserveScanPolicy.latencyPriority(101))
        assertEquals(2, ReserveScanPolicy.latencyPriority(0))
    }

    @Test fun aFullReserveStopsCatalogueRefresh() {
        assertEquals(6L * 60L * 60L * 1000L, ReserveScanPolicy.catalogueIntervalMs(0))
        assertEquals(Long.MAX_VALUE, ReserveScanPolicy.catalogueIntervalMs(5))
    }

}
