package com.secureconnect.app

import com.secureconnect.app.data.remote.ConfigParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class ConfigParserTest {
    @Test
    fun hysteria2KeepsExplicitPortWhenUriHasTrailingSlash() {
        val server = ConfigParser.parse(
            "hysteria2://secret@example.com:8443/?sni=example.com#Test",
            "test"
        )

        assertNotNull(server)
        assertEquals("example.com", server!!.host)
        assertEquals(8443, server.port)
        assertEquals("HYSTERIA2", server.protocol)
    }

    @Test
    fun hysteria2KeepsExplicitIpv6PortWhenUriHasTrailingSlash() {
        val server = ConfigParser.parse(
            "hy2://secret@[2001:db8::1]:7443/?sni=example.com#IPv6",
            "test"
        )

        assertNotNull(server)
        assertEquals("2001:db8::1", server!!.host)
        assertEquals(7443, server.port)
        assertEquals("HYSTERIA2", server.protocol)
    }
    @Test
    fun extractsBase64PayloadEvenWhenMetadataContainsHttpsUrl() {
        val payload = "vless://id@example.com:443?security=tls#Node\n" +
            "trojan://secret@example.net:443?security=tls#Node2"
        val encoded = java.util.Base64.getEncoder().encodeToString(payload.toByteArray())
        val body = "#support-url: https://github.com/example/sub\n$encoded"

        val links = ConfigParser.extractLinks(body)

        assertEquals(2, links.size)
        assertEquals(true, links[0].startsWith("vless://"))
        assertEquals(true, links[1].startsWith("trojan://"))
    }

}
