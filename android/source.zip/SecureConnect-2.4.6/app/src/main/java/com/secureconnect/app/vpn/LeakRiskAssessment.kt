package com.secureconnect.app.vpn

/**
 * A transparent, policy-based diagnostic INDEX, not a measured probability of
 * interception or a claim that DNS/IPv6 leaks have been tested.
 *
 * Only observable states are included. Intentional per-app VPN exclusions are
 * not counted as leaks: these apps are expected to use their direct network.
 */
data class LeakRiskAssessment(
    val index: Int?,
    val level: String,
    val details: List<String>,
    val urgent: Boolean
)

object LeakRiskCalculator {
    fun assess(
        state: VpnState,
        killSwitchEnabled: Boolean,
        tlsStatus: String,
        routingMode: AppVpnMode,
        hasActiveServer: Boolean
    ): LeakRiskAssessment {
        if (state is VpnState.Blocked) {
            return LeakRiskAssessment(
                index = null,
                level = if (killSwitchEnabled) "VPN прерван — блокирующий режим" else "Состояние защиты неясно",
                details = listOf(
                    "Защищаемые приложения не должны выходить напрямую, пока блокирующий TUN активен.",
                    "Российские и другие исключённые приложения по-прежнему используют обычную сеть.",
                    "Системные ограничения и перезапуск VPN требуют проверки на устройстве."
                ),
                urgent = true
            )
        }
        if (state != VpnState.Connected) {
            val description = when (state) {
                VpnState.Idle -> "VPN отключён: обычный трафик не защищён туннелем."
                VpnState.Connecting, VpnState.Validating ->
                    "Соединение устанавливается или проверяется. Безопасность ещё не подтверждена."
                VpnState.Stopping -> "VPN останавливается: защита не подтверждена."
                is VpnState.Error -> "Ошибка VPN: защита трафика не подтверждена."
                else -> "Состояние VPN неизвестно."
            }
            return LeakRiskAssessment(
                index = null,
                level = "Не проверено",
                details = listOf(
                    description,
                    "Российские приложения намеренно работают без VPN.",
                    "После отключения или завершения VPN-сервиса блокировка трафика может не действовать."
                ),
                urgent = state is VpnState.Error || state == VpnState.Idle
            )
        }

        var index = 20 // internal policy score only; no independent TUN/DNS/IPv6 measurement
        val details = mutableListOf<String>()
        if (!killSwitchEnabled) {
            index += 40
            details += "Kill Switch выключен: при обрыве VPN возможен прямой выход защищаемых приложений."
        } else {
            details += "Kill Switch включён: при сбое сервиса сохраняется блокирующий VPN-интерфейс, когда это допускает Android."
        }

        when {
            tlsStatus.startsWith("ОПАСНО:") -> {
                index += 55
                details += "Критично: TLS-сертификат проверяемого домена не подтверждён. Смените сервер."
            }
            tlsStatus.contains("доверенный", ignoreCase = true) -> {
                details += "TLS-проверка одного домена прошла; безопасность всех сайтов этим не доказана."
            }
            else -> {
                index += 10
                details += "TLS-проверка одного домена не завершилась или ещё не выполнялась."
            }
        }

        if (routingMode == AppVpnMode.ONLY_SELECTED) {
            index += 25
            details += "Режим «Только выбранные»: остальные приложения выходят в интернет напрямую."
        } else {
            details += "Российские приложения из списка исключений обходят VPN намеренно — это не ошибка маршрутизации."
        }

        if (!hasActiveServer) {
            index += 15
            details += "Подтверждённый активный сервер пока неизвестен."
        }

        details += "DNS-, IPv6- и IP-утечки отдельно не тестировались; индекс не является вероятностью утечки."
        // Policy scores must NOT be presented as verified leak-test results.
        // Until real DNS/IPv6/TUN checks are implemented, do not show a green
        // 20/100 badge that can be mistaken for a measurement.
        val warning = index >= 60 || tlsStatus.startsWith("ОПАСНО:")
        return LeakRiskAssessment(
            index = null,
            level = if (warning) "Требуется внимание · проверки утечек нет"
                    else "Не проверено · DNS/IPv6/TUN",
            details = details,
            urgent = warning
        )
    }
}
