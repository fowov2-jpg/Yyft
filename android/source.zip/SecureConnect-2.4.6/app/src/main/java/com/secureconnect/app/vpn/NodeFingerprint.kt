package com.secureconnect.app.vpn

import java.security.MessageDigest

/** Same cross-language contract as github-node-checker/checker.py::fingerprint. */
object NodeFingerprint {
    fun of(rawUri: String): String {
        val canonical = rawUri.trim().substringBefore('#')
        return MessageDigest.getInstance("SHA-256")
            .digest(canonical.toByteArray(Charsets.UTF_8))
            .joinToString("") { byte -> "%02x".format(byte.toInt() and 255) }
    }
}
