package com.secureconnect.app.vpn

import android.content.Context
import java.net.InetAddress
import java.net.ServerSocket
import java.lang.reflect.InvocationTargetException
import java.lang.reflect.Method
import java.lang.reflect.Proxy
import java.util.concurrent.TimeUnit
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/**
 * Обёртка над libv2ray.aar (AndroidLibXrayLite) через reflection.
 *
 * AAR версии v26.9.30 экспортирует QueryAllOutboundTrafficStats(): эта функция
 * возвращает счётчики за интервал и сразу сбрасывает их в ноль. Поэтому UI должен
 * трактовать результат как количество байт с предыдущего измерения, а не как
 * накопительный total.
 */
object XrayCore {
    private const val LIB = "libv2ray.Libv2ray"
    private const val HANDLER = "libv2ray.CoreCallbackHandler"
    private const val SEQ = "go.Seq"

    private val nativeStartLock = Any()
    private val standaloneYouTubeLock = ReentrantLock(true)
    @Volatile private var controller: Any? = null
    @Volatile private var activeGeneration: Long = -1L
    @Volatile private var initialized = false

    @Volatile private var cachedQueryAllTrafficMethod: Method? = null
    @Volatile private var queryAllTrafficLookupFailed = false

    fun isAvailable(): Boolean = runCatching {
        Class.forName(LIB)
        Class.forName(HANDLER)
        Class.forName(SEQ)
        true
    }.getOrDefault(false)

    /** Runtime lib/core version for diagnostics; never throws into UI. */
    fun versionInfo(): String = runCatching {
        val lib = Class.forName(LIB)
        val method = lib.methods.firstOrNull {
            it.name == "checkVersionX" && it.parameterCount == 0
        } ?: return@runCatching "unknown"
        method.invoke(null)?.toString()?.takeIf { it.isNotBlank() } ?: "unknown"
    }.getOrDefault("unavailable")

    /**
     * Ленивая инициализация gomobile. Вызывать только из рабочего потока перед start(),
     * не из Application.onCreate.
     */
    @Synchronized
    fun ensureInit(context: Context) {
        if (initialized) return

        val appCtx = context.applicationContext
        try {
            val seq = Class.forName(SEQ)
            val setContext = seq.methods.firstOrNull {
                it.name == "setContext" && it.parameterCount == 1 &&
                    Context::class.java.isAssignableFrom(it.parameterTypes[0])
            } ?: throw IllegalStateException("В go.Seq нет setContext(Context)")
            setContext.invoke(null, appCtx)

            val initCoreEnv = Class.forName(LIB).methods.firstOrNull {
                it.name == "initCoreEnv" && it.parameterCount == 2
            } ?: throw IllegalStateException("В libv2ray нет initCoreEnv(String, String)")
            initCoreEnv.invoke(null, appCtx.filesDir.absolutePath, "")
            initialized = true
        } catch (t: Throwable) {
            initialized = false
            val cause = if (t is InvocationTargetException) t.targetException ?: t else t
            throw IllegalStateException("Не удалось инициализировать Xray/gomobile: ${cause.message}", cause)
        }
    }

    @Synchronized
    fun start(config: String, tunFd: Int, service: XrayVpnService, generation: Long) {
        if (!isAvailable()) {
            throw IllegalStateException("Ядро Xray не найдено в сборке (libs/libv2ray.aar)")
        }
        ensureInit(service)

        val lib = Class.forName(LIB)
        val handlerCls = Class.forName(HANDLER)
        val handler = Proxy.newProxyInstance(handlerCls.classLoader, arrayOf(handlerCls)) { _, method, args ->
            val name = method.name.lowercase()
            if (name == "shutdown" || name == "onemitstatus") {
                val code = (args?.getOrNull(0) as? Number)?.toInt() ?: 0
                val message = args?.getOrNull(1)?.toString()
                service.onCoreCallback(generation, name, code, message)
            }
            when (method.returnType) {
                java.lang.Long.TYPE, java.lang.Long::class.javaObjectType -> 0L
                java.lang.Integer.TYPE, java.lang.Integer::class.javaObjectType -> 0
                java.lang.Boolean.TYPE, java.lang.Boolean::class.javaObjectType -> false
                else -> null
            }
        }

        var ctl: Any? = null
        try {
            val newController = lib.methods.firstOrNull {
                it.name == "newCoreController" && it.parameterCount == 1
            } ?: throw IllegalStateException("В libv2ray нет newCoreController(CoreCallbackHandler)")
            ctl = newController.invoke(null, handler)
                ?: throw IllegalStateException("newCoreController вернул null")
            // Publish the controller before startLoop(): a native callback can happen
            // synchronously during startup, and the callback path must be able to stop it.
            controller = ctl
            activeGeneration = generation

            val startLoop = ctl!!.javaClass.methods.firstOrNull {
                it.name == "startLoop" && it.parameterCount == 2
            } ?: throw IllegalStateException(
                "Нужна версия libv2ray с startLoop(config, tunFd) для Android TUN"
            )

            try {
                synchronized(nativeStartLock) { startLoop.invoke(ctl, config, tunFd) }
            } catch (e: InvocationTargetException) {
                val cause = e.targetException
                throw IllegalStateException(cause?.message ?: "Ошибка запуска ядра", cause)
            }

            val running = runCatching {
                ctl!!.javaClass.getField("IsRunning").getBoolean(ctl)
            }.getOrDefault(true)
            if (!running) {
                stopController(ctl)
                throw IllegalStateException("Xray запустился, но ядро не перешло в рабочее состояние")
            }
            resetStatsMethodCache()
        } catch (t: Throwable) {
            if (controller === ctl) {
                controller = null
                activeGeneration = -1L
            }
            stopController(ctl)
            throw t
        }
    }

    /** Serialize stop and traffic sampling against the active controller. */
    @Synchronized
    fun stop() {
        val ctl = controller ?: run {
            activeGeneration = -1L
            return
        }
        controller = null
        activeGeneration = -1L
        stopController(ctl)
    }

    fun currentGeneration(): Long = activeGeneration

    private fun stopController(ctl: Any?) {
        if (ctl == null) return
        runCatching {
            ctl.javaClass.methods.firstOrNull {
                it.name == "stopLoop" && it.parameterCount == 0
            }?.invoke(ctl)
        }
    }


    data class DelayResult(
        val ms: Int?,
        val error: String? = null,
        val retryAfterMs: Long? = null,
        val youtubePassed: Boolean = false,
        val connectMs: Int? = null,
        val speedVerified: Boolean = false,
        val downloadMbps: Double? = null,
        val uploadMbps: Double? = null
    )

    /** Creates its own native instance; never uses/stops the active VPN controller. */
    fun measureStandalone(context: Context, config: String, url: String): DelayResult {
        return try {
            ensureInit(context)
            val method = Class.forName(LIB).methods.firstOrNull {
                it.name == "measureOutboundDelay" && it.parameterCount == 2
            } ?: return DelayResult(null, "В ядре отсутствует отдельная проверка outbound")
            val value = (method.invoke(null, config, url) as? Number)?.toLong()
            if (value != null && value >= 0L) {
                DelayResult(value.coerceIn(1L, Int.MAX_VALUE.toLong()).toInt())
            } else DelayResult(null, "HTTPS через сервер не прошёл")
        } catch (e: Exception) {
            val cause = if (e is InvocationTargetException) e.targetException ?: e else e
            DelayResult(null, cause.message?.take(240) ?: "Ошибка отдельной проверки")
        }
    }

    /**
     * The native measureOutboundDelay API discards Location and response HTML.
     * Start a short-lived SOCKS-only Xray instance instead, perform the actual
     * HTTPS/redirect/content check through it, then release the instance.
     * Does not touch the live controller or TUN fd (0 = no TUN in libv2ray).
     */
    data class StandbyQuality(
        val youtube: YouTubePageProbe.Result,
        val speedFirst: VpnSpeedPolicy.Result? = null,
        val speedSecond: VpnSpeedPolicy.Result? = null,
        val deferred: Boolean = false,
        val tlsVerdict: OpenAiTlsPolicy.Verdict = OpenAiTlsPolicy.Verdict.UNAVAILABLE
    ) {
        val speedVerified: Boolean get() = VpnSpeedPolicy.qualifiesStandby(speedFirst, speedSecond)
        val downloadMbps: Double? get() = listOfNotNull(speedFirst?.downloadMbps, speedSecond?.downloadMbps).minOrNull()
        val uploadMbps: Double? get() = listOfNotNull(speedFirst?.uploadMbps, speedSecond?.uploadMbps).minOrNull()
    }

    // Bandwidth budget for admission. Rejected unfit candidates cannot drain hundreds
    // of MB when a public source lists thousands of dead/slow nodes.
    private const val MAX_STANDBY_TESTS_PER_HOUR = 18
    private var standbyWindowStartMs = 0L
    private var standbyTestsInWindow = 0
    private fun acquireStandbyTestBudget(): Boolean {
        val now = System.currentTimeMillis()
        if (now - standbyWindowStartMs >= 60L * 60_000L || now < standbyWindowStartMs) {
            standbyWindowStartMs = now
            standbyTestsInWindow = 0
        }
        if (standbyTestsInWindow >= MAX_STANDBY_TESTS_PER_HOUR) return false
        standbyTestsInWindow++
        return true
    }

    fun checkStandaloneYouTube(context: Context, outboundConfig: String): YouTubePageProbe.Result =
        checkStandaloneQuality(context, outboundConfig, measureSpeed = false).youtube

    fun checkStandaloneQuality(
        context: Context,
        outboundConfig: String,
        measureSpeed: Boolean = true
    ): StandbyQuality = standaloneYouTubeLock.withLock {
            var isolatedController: Any? = null
            try {
                ensureInit(context)
                val localPort = ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"))
                    .use { it.localPort }
                val config = XrayConfigBuilder.buildSocksProbe(outboundConfig, localPort)
                val lib = Class.forName(LIB)
                val handlerCls = Class.forName(HANDLER)
                val handler = Proxy.newProxyInstance(handlerCls.classLoader, arrayOf(handlerCls)) { _, method, _ ->
                    when (method.returnType) {
                        java.lang.Long.TYPE, java.lang.Long::class.javaObjectType -> 0L
                        java.lang.Integer.TYPE, java.lang.Integer::class.javaObjectType -> 0
                        java.lang.Boolean.TYPE, java.lang.Boolean::class.javaObjectType -> false
                        else -> null
                    }
                }
                isolatedController = lib.methods.first {
                    it.name == "newCoreController" && it.parameterCount == 1
                }.invoke(null, handler)
                val ctl = isolatedController ?: error("Не удалось создать отдельный Xray probe")
                val start = ctl.javaClass.methods.first {
                    it.name == "startLoop" && it.parameterCount == 2
                }
                // libv2ray uses process-wide tun.fd: serialize native startups.
                synchronized(nativeStartLock) { start.invoke(ctl, config, 0) }
                val youtube = YouTubePageProbe.checkViaSocks(localPort)
                // A single route-specific TLS certificate check, not a repeated YouTube request.
                // Treat only an actual certificate error as suspicious; timeout is inconclusive.
                val tlsVerdict = if (youtube.passed)
                    OpenAiTlsProbe.checkViaSocks(localPort).verdict
                else OpenAiTlsPolicy.Verdict.UNAVAILABLE
                if (tlsVerdict == OpenAiTlsPolicy.Verdict.CERTIFICATE_ERROR) {
                    return@withLock StandbyQuality(youtube, tlsVerdict = tlsVerdict)
                }
                // RTT is far cheaper than two real HTTPS payload transfers.
                // Do not consume speed-test budget on a node known to exceed 100ms.
                if (!youtube.passed || !measureSpeed ||
                    !WorkingPoolPolicy.qualifiesRtt(youtube.connectMs)) {
                    StandbyQuality(youtube, tlsVerdict = tlsVerdict)
                } else if (!acquireStandbyTestBudget()) {
                    StandbyQuality(youtube, deferred = true, tlsVerdict = tlsVerdict)
                } else {
                    val first = VpnSpeedTester.measure(localPort)
                    val second = if (first.verdict == VpnSpeedPolicy.Verdict.PASS) {
                        try { Thread.sleep(VpnSpeedPolicy.ADMISSION_PAUSE_MS) } catch (_: InterruptedException) {
                            Thread.currentThread().interrupt()
                        }
                        if (Thread.currentThread().isInterrupted) null else VpnSpeedTester.measure(localPort)
                    } else null
                    StandbyQuality(youtube, first, second, tlsVerdict = tlsVerdict)
                }
            } catch (e: Exception) {
                val cause = if (e is InvocationTargetException) e.targetException ?: e else e
                StandbyQuality(YouTubePageProbe.Result(false,
                    error = "YouTube SOCKS probe: ${cause.message?.take(130) ?: cause.javaClass.simpleName}"))
            } finally {
                stopController(isolatedController)
            }
        }

    /**
     * Single real download+upload test of ONE selected server. Unlike measuring the
     * live health SOCKS inbound (which can use the embedded leastPing balancer),
     * this uses an isolated one-outbound Xray controller. It cannot contaminate
     * or restart the active VPN and never fetches YouTube during routine audits.
     * UNKNOWN is returned on probe contention/network/provider failure.
     */
    fun measureStandaloneSpeed(context: Context, outboundConfig: String): VpnSpeedPolicy.Result =
        standaloneYouTubeLock.withLock {
            var ctl: Any? = null
            try {
                ensureInit(context)
                val port = ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"))
                    .use { it.localPort }
                val config = XrayConfigBuilder.buildSocksProbe(outboundConfig, port)
                val lib = Class.forName(LIB)
                val handlerCls = Class.forName(HANDLER)
                val handler = Proxy.newProxyInstance(handlerCls.classLoader, arrayOf(handlerCls)) { _, m, _ ->
                    when (m.returnType) {
                        java.lang.Long.TYPE, java.lang.Long::class.javaObjectType -> 0L
                        java.lang.Integer.TYPE, java.lang.Integer::class.javaObjectType -> 0
                        java.lang.Boolean.TYPE, java.lang.Boolean::class.javaObjectType -> false
                        else -> null
                    }
                }
                ctl = lib.methods.first { it.name == "newCoreController" && it.parameterCount == 1 }
                    .invoke(null, handler) ?: error("Cannot initialize speed probe")
                val start = ctl.javaClass.methods.first {
                    it.name == "startLoop" && it.parameterCount == 2
                }
                synchronized(nativeStartLock) { start.invoke(ctl, config, 0) }
                VpnSpeedTester.measure(port)
            } catch (e: Exception) {
                val cause = if (e is InvocationTargetException) e.targetException ?: e else e
                VpnSpeedPolicy.Result(null, null,
                    "Isolated speed probe: ${cause.message?.take(100) ?: cause.javaClass.simpleName}")
            } finally {
                stopController(ctl)
            }
        }

    /**
     * Best-effort route-specific TLS preflight. A long standalone quality scan must
     * not keep the Connect action waiting on the shared native probe controller.
     * Contention returns UNAVAILABLE (never VERIFIED). The live Xray path still
     * MUST pass certificate-validated HTTPS before Connected can be published.
     */
    fun checkStandaloneTls(context: Context, outboundConfig: String): OpenAiTlsPolicy.Verdict {
        val acquired = try {
            standaloneYouTubeLock.tryLock(250L, TimeUnit.MILLISECONDS)
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
            false
        }
        if (!acquired) return OpenAiTlsPolicy.Verdict.UNAVAILABLE
        return try {
            var ctl: Any? = null
            try {
                ensureInit(context)
                val port = ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"))
                    .use { it.localPort }
                val config = XrayConfigBuilder.buildSocksProbe(outboundConfig, port)
                val lib = Class.forName(LIB)
                val handlerCls = Class.forName(HANDLER)
                val handler = Proxy.newProxyInstance(handlerCls.classLoader, arrayOf(handlerCls)) { _, m, _ ->
                    when (m.returnType) {
                        java.lang.Long.TYPE, java.lang.Long::class.javaObjectType -> 0L
                        java.lang.Integer.TYPE, java.lang.Integer::class.javaObjectType -> 0
                        java.lang.Boolean.TYPE, java.lang.Boolean::class.javaObjectType -> false
                        else -> null
                    }
                }
                ctl = lib.methods.first { it.name == "newCoreController" && it.parameterCount == 1 }
                    .invoke(null, handler) ?: error("Cannot create isolated TLS preflight")
                val start = ctl.javaClass.methods.first {
                    it.name == "startLoop" && it.parameterCount == 2
                }
                synchronized(nativeStartLock) { start.invoke(ctl, config, 0) }
                OpenAiTlsProbe.checkViaSocks(port).verdict
            } catch (_: Exception) {
                OpenAiTlsPolicy.Verdict.UNAVAILABLE
            } finally {
                stopController(ctl)
            }
        } finally {
            standaloneYouTubeLock.unlock()
        }
    }

    data class TrafficSample(val downlinkBytes: Long, val uplinkBytes: Long)

    /**
     * Снимает один атомарный sample по tag.
     * AndroidLibXrayLite QueryAllOutboundTrafficStats() возвращает обе стороны
     * одновременно и затем сбрасывает native counters, поэтому download/upload
     * нельзя получать двумя последовательными вызовами этого API.
     */
    @Synchronized
    fun queryTrafficSample(tag: String): TrafficSample {
        val ctl = controller ?: return TrafficSample(0L, 0L)

        val queryAll = cachedQueryAllTrafficMethod ?: if (!queryAllTrafficLookupFailed) {
            val found = runCatching {
                ctl.javaClass.methods.firstOrNull {
                    it.name == "queryAllOutboundTrafficStats" && it.parameterCount == 0
                }
            }.getOrNull()
            if (found == null) queryAllTrafficLookupFailed = true else cachedQueryAllTrafficMethod = found
            found
        } else null

        if (queryAll != null) {
            return runCatching {
                val payload = queryAll.invoke(ctl)?.toString().orEmpty()
                TrafficSample(
                    parseTrafficStats(payload, tag, "downlink"),
                    parseTrafficStats(payload, tag, "uplink")
                )
            }.getOrDefault(TrafficSample(0L, 0L))
        }

        return TrafficSample(0L, 0L)
    }

    private fun parseTrafficStats(payload: String, tag: String, direction: String): Long {
        if (payload.isBlank()) return 0L
        val tags = tag.split(',').map { it.trim() }.toSet()
        return payload.split(';').sumOf { item ->
            val parts = item.trim().split(',', limit = 3)
            if (parts.size == 3 && parts[0] in tags && parts[1] == direction) {
                parts[2].trim().toLongOrNull()?.coerceAtLeast(0L) ?: 0L
            } else 0L
        }
    }

    private fun resetStatsMethodCache() {
        cachedQueryAllTrafficMethod = null
        queryAllTrafficLookupFailed = false
    }
}
