package com.secureconnect.app.ui.screens.home

/**
 * Only a completed video probe can certify quality.
 * A healthy VPN or an old Cloudflare test must never be labelled as live 720p.
 */
object VideoQualityUiPolicy {
    enum class Tone { GOOD, NOTICE, BAD, NEUTRAL }
    data class Presentation(val title: String, val detail: String, val tone: Tone)

    fun resolve(status: String): Presentation = when {
        status.startsWith("Авто 720p") -> Presentation(
            "Тест загрузки пройден",
            "YouTube доступен, загрузка прошла один тест через текущий Xray-маршрут; 720p не гарантируется",
            Tone.GOOD)
        status.contains("требуется повторный замер", ignoreCase = true) -> Presentation(
            "Нужна перепроверка", "Видео доступно, но скорость ещё не подтверждена", Tone.NOTICE)
        status == "Подтверждено" -> Presentation(
            "Видео проверено", "YouTube и два теста скорости прошли; это не гарантия 720p", Tone.GOOD)
        status == "Подтверждено ранее" -> Presentation(
            "Подтверждено ранее", "Сохранённый тест. Проверьте 720p на текущей сети", Tone.NOTICE)
        status == "Скорость подтверждена" -> Presentation(
            "Скорость проверяется", "Первый тест пройден; второй ещё не завершён", Tone.NOTICE)
        status == "Загрузка для видео подходит" -> Presentation(
            "Загрузка подходит", "Скорость загрузки достаточна по одному тесту; запас не подтверждён", Tone.NOTICE)
        status == "Скорость не подтверждена повторно" -> Presentation(
            "Тест не завершён", "Не хватает второго подтверждённого замера", Tone.NOTICE)
        status == "Тест не завершён" -> Presentation(
            "Ошибка измерения", "Не удалось завершить тест скорости. VPN остаётся подключён", Tone.NOTICE)
        status == "Скорость нестабильна" -> Presentation(
            "Нестабильная скорость", "Два замера расходятся; VPN остаётся подключён", Tone.NOTICE)
        status.startsWith("YouTube доступен") -> Presentation(
            "YouTube доступен", "Загрузка страницы прошла, скорость видео не измерена", Tone.NOTICE)
        status.contains("низкая скорость", ignoreCase = true) ||
            status.contains("недостаточно", ignoreCase = true) -> Presentation(
            "Скорость ниже цели", "VPN работает; ищем более подходящий сервер", Tone.BAD)
        status.contains("недоступен", ignoreCase = true) -> Presentation(
            "YouTube недоступен", "VPN может работать для других сайтов", Tone.BAD)
        status.startsWith("Проверя") -> Presentation(
            "Проверка YouTube", "Соединение активно; проверка идёт в фоне", Tone.NOTICE)
        else -> Presentation(
            "Качество пока неизвестно", "VPN работает, но просмотр 720p ещё не подтверждён", Tone.NEUTRAL)
    }
}
