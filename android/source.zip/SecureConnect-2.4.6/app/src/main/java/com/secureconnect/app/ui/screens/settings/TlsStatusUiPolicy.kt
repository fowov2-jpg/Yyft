package com.secureconnect.app.ui.screens.settings

/** Display the scoped check truthfully: this is NOT a test of Android-wide TUN or pinning. */
object TlsStatusUiPolicy {
    enum class Tone { GOOD, WARNING, DANGER, UNKNOWN }
    data class Display(val title: String, val detail: String, val tone: Tone)
    fun resolve(status: String): Display = when {
        status.startsWith("ОПАСНО:", ignoreCase = true) ->
            Display("Ошибка сертификата", "TLS-тест отдельного домена не прошёл. Проверьте маршрут.", Tone.DANGER)
        status.contains("доверенный", ignoreCase = true) ->
            Display("Сертификат доверенный", "Проверен один HTTPS-домен через Xray; защита всего TUN не доказана.", Tone.GOOD)
        status.contains("не провер", ignoreCase = true) || status.isBlank() ->
            Display("Ещё не проверено", "Проверка сертификата отдельного домена не выполнялась.", Tone.UNKNOWN)
        else ->
            Display("Нет подтверждения", "Проверка одного HTTPS-домена не завершилась успешно.", Tone.WARNING)
    }
}
