package com.secureconnect.app.vpn

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.PowerManager

/** Cheap, read-only power hints. Never uses wake locks or periodic listeners. */
internal object BatteryAwareRuntime {
    data class Snapshot(
        val interactive: Boolean,
        val powerSave: Boolean,
        val charging: Boolean,
        val unmetered: Boolean
    ) {
        val heavyTestsAllowed: Boolean
            get() = BatteryAwarePolicy.allowHeavyTests(interactive, powerSave, charging, unmetered)
    }

    fun read(context: Context): Snapshot {
        val pm = context.getSystemService(PowerManager::class.java)
        val interactive = pm?.isInteractive == true
        val powerSave = pm?.isPowerSaveMode != false
        val charging = context.getSystemService(BatteryManager::class.java)?.isCharging == true

        // No bandwidth-consuming diagnostics are permitted when any of these are
        // false. Avoid Binder calls enumerating networks on every background tick.
        if (!interactive || powerSave || !charging) {
            return Snapshot(interactive, powerSave, charging, unmetered = false)
        }

        val cm = context.getSystemService(ConnectivityManager::class.java)
        // A VPN network is not proof of an unmetered physical uplink. If the
        // physical transport is unclear, conservatively defer synthetic tests.
        val unmetered = runCatching {
            cm?.let { manager ->
                manager.allNetworks.any { network ->
                    val caps = manager.getNetworkCapabilities(network)
                    caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN) == true &&
                        caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                        caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
                }
            } == true
        }.getOrDefault(false)
        return Snapshot(interactive, powerSave, charging, unmetered)
    }
}
