package com.secureconnect.app.viewmodel

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/** A user request survives catalogue updates, but is consumed at most once. Main thread only. */
internal class AutoSelectionRequest {
    private val _pending = MutableStateFlow(false)
    val pending = _pending.asStateFlow()

    fun request() { _pending.value = true }
    fun cancel() { _pending.value = false }
    fun consumeIf(ready: Boolean, connecting: Boolean): Boolean {
        if (!_pending.value || !ready || connecting) return false
        _pending.value = false
        return true
    }
}
