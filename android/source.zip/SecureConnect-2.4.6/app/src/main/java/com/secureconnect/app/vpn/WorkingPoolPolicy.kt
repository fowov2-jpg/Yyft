package com.secureconnect.app.vpn

import com.secureconnect.app.data.model.Server
import com.secureconnect.app.data.model.ServerTransport
import java.util.Locale

/** Bounded verified pool. The 100-config catalogue is only a source of replacements. */
object WorkingPoolPolicy {
    // 20 independent backups plus one possible active member.
    const val MIN_BACKUPS = 20
    const val MAX_VERIFIED = MIN_BACKUPS + 1
    /** History is not the verified pool. Retain older proven configurations for recovery. */
    const val MAX_HISTORY = 60
    const val TARGET_RTT_MS = 100
    /** TARGET_RTT_MS is a ranking goal, not a hard 4G eligibility gate. */
    fun qualifiesRtt(ms: Int?): Boolean = ms != null && ms > 0
    const val FAILED_COOLDOWN_MS = 60L * 60L * 1000L
    const val FULL_POOL_SLEEP_MS = 60_000L
    // A rare standby audit can detect a dead reserve without searching public nodes.
    // Refresh individual reserves BEFORE the 12h qualification expires.
    const val BACKUP_AUDIT_INTERVAL_MS = 45L * 60_000L
    // Full YouTube+double-speed requalification starts before 12h expiration.
    const val QUALITY_RENEWAL_START_MS = 10L * 60L * 60_000L

    /** Fail closed on missing/untrusted country labels; labels alone cannot prove IP geolocation. */
    fun isForeignCountry(country: String): Boolean {
        val value = country.trim().lowercase(Locale.ROOT)
        if (value.isBlank() || value in setOf("неизвестно", "unknown", "other", "n/a", "🌐", "?") ||
            "unknown" in value || "неизвест" in value) return false
        if (value == "ru" || value == "rus" || "🇷🇺" in value || "росси" in value ||
            "russia" in value || "russian federation" in value) return false
        return true
    }

    fun eligible(server: Server): Boolean = isForeignCountry(server.country) &&
        server.id.isNotBlank() && server.host.isNotBlank() && server.port in 1..65535 &&
        server.rawLink.isNotBlank() && ServerTransport.coldStartRank(server) < 11

    fun missing(activeCount: Int): Int = (MAX_VERIFIED - activeCount).coerceIn(0, MAX_VERIFIED)

    fun backupAuditDue(now: Long, lastAudit: Long): Boolean =
        lastAudit <= 0L || (now >= lastAudit && now - lastAudit >= BACKUP_AUDIT_INTERVAL_MS)

    fun qualityRenewalDue(now: Long, lastVerified: Long): Boolean =
        lastVerified <= 0L || (now >= lastVerified && now - lastVerified >= QUALITY_RENEWAL_START_MS)

    fun remainingBackups(qualifiedIds: Set<String>, activeId: String?): Int =
        (qualifiedIds.size - if (activeId != null && activeId in qualifiedIds) 1 else 0).coerceAtLeast(0)

    fun failedCoolingDown(now: Long, lastFailure: Long, failures: Int): Boolean =
        failures > 0 && lastFailure > 0L && now - lastFailure in 0L until FAILED_COOLDOWN_MS
}
