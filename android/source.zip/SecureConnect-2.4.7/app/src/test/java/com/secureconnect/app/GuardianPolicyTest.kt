package com.secureconnect.app

import com.secureconnect.app.data.model.Server
import com.secureconnect.app.vpn.GuardianPolicy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GuardianPolicyTest {
    private fun server(
        id: String,
        source: String,
        host: String,
        ping: Int = 50,
        type: String = "tcp",
        security: String = "reality"
    ) = Server(
        id = id,
        country = "",
        city = "",
        flagEmoji = "",
        protocol = "VLESS",
        ping = ping,
        host = host,
        port = 443,
        source = source,
        rawLink = "vless://$id@$host:443?security=$security&type=$type"
    )

    @Test
    fun watchdogTimeoutExpandsForKnownSlowHealthyTunnel() {
        assertEquals(4_986, GuardianPolicy.watchdogIoTimeoutMs(2_770.0))
    }

    @Test
    fun watchdogTimeoutHasSafeLowerBound() {
        assertEquals(3_000, GuardianPolicy.watchdogIoTimeoutMs(400.0))
    }

    @Test
    fun watchdogTimeoutHasFiniteUpperBound() {
        assertEquals(6_000, GuardianPolicy.watchdogIoTimeoutMs(20_000.0))
    }

    @Test
    fun provenRemoteTlsFailureNeedsThreeSamples() {
        assertEquals(3, GuardianPolicy.requiredFailureSamples("tls", recentlyProven = true))
    }

    @Test
    fun unknownRemoteFailureNeedsTwoSamples() {
        assertEquals(2, GuardianPolicy.requiredFailureSamples("tls", recentlyProven = false))
    }

    @Test
    fun localSocksLossTriggersImmediateRecovery() {
        assertEquals(1, GuardianPolicy.requiredFailureSamples("socks_ready", recentlyProven = true))
    }

    @Test
    fun goodRttDoesNotBecomeBadOnlyBecauseHttpsIsModeratelySlow() {
        assertFalse(
            GuardianPolicy.isPoorQualitySample(
                connectMs = 47,
                httpsMs = 2_785,
                baselineHttpsMs = 2_600.0
            )
        )
    }

    @Test
    fun persistentlyBadRttIsPoorQuality() {
        assertTrue(
            GuardianPolicy.isPoorQualitySample(
                connectMs = 240,
                httpsMs = 900,
                baselineHttpsMs = 800.0
            )
        )
    }

    @Test
    fun extremeHttpsRegressionCanTriggerQualityRecovery() {
        assertTrue(
            GuardianPolicy.isPoorQualitySample(
                connectMs = 80,
                httpsMs = 7_000,
                baselineHttpsMs = 1_000.0
            )
        )
    }

    @Test
    fun diversificationAvoidsRepeatingSameRoute() {
        val a = server("a", "source-a", "1.1.1.1")
        val duplicateRoute = server("b", "source-b", "1.1.1.1")
        val c = server("c", "source-c", "2.2.2.2")

        val result = GuardianPolicy.diversify(listOf(a, duplicateRoute, c))

        assertEquals(2, result.size)
        assertEquals(setOf("1.1.1.1", "2.2.2.2"), result.map { it.host }.toSet())
    }

    @Test
    fun diversificationSpreadsSourcesBeforeRepeatingOne() {
        val candidates = listOf(
            server("a1", "a", "1.1.1.1"),
            server("a2", "a", "1.1.1.2"),
            server("b1", "b", "2.2.2.1"),
            server("c1", "c", "3.3.3.1")
        )

        val result = GuardianPolicy.diversify(candidates)

        assertEquals(listOf("a", "b", "c"), result.take(3).map { it.source })
    }

    @Test
    fun routeFingerprintSeparatesTransportFamilies() {
        val tcp = server("tcp", "a", "1.1.1.1", type = "tcp")
        val grpc = server("grpc", "a", "1.1.1.1", type = "grpc")

        assertTrue(GuardianPolicy.routeFingerprint(tcp) != GuardianPolicy.routeFingerprint(grpc))
    }

    @Test
    fun recoveryBackoffIsBoundedWhilePhysicalNetworkExists() {
        assertEquals(5_000L, GuardianPolicy.recoveryRetryDelayMs(1, hasPhysicalNetwork = true))
        assertEquals(10_000L, GuardianPolicy.recoveryRetryDelayMs(2, hasPhysicalNetwork = true))
        assertEquals(20_000L, GuardianPolicy.recoveryRetryDelayMs(3, hasPhysicalNetwork = true))
        assertEquals(40_000L, GuardianPolicy.recoveryRetryDelayMs(4, hasPhysicalNetwork = true))
        assertEquals(60_000L, GuardianPolicy.recoveryRetryDelayMs(20, hasPhysicalNetwork = true))
    }

    @Test
    fun recoveryBackoffPausesAggressiveRetryWhenPhysicalNetworkIsGone() {
        assertEquals(60_000L, GuardianPolicy.recoveryRetryDelayMs(1, hasPhysicalNetwork = false))
        assertEquals(60_000L, GuardianPolicy.recoveryRetryDelayMs(4, hasPhysicalNetwork = false))
    }

    @Test fun initialUnknownRouteGetsFiveSecondTlsBudget() {
        assertEquals(5_000, GuardianPolicy.initialConnectIoTimeoutMs(null))
        assertEquals(5_000, GuardianPolicy.initialConnectIoTimeoutMs(Double.NaN))
        assertEquals(5_000, GuardianPolicy.initialConnectIoTimeoutMs(0.0))
    }

    @Test fun historicalGoodRouteKeepsAdaptiveTimeout() {
        assertEquals(3_600, GuardianPolicy.initialConnectIoTimeoutMs(2_000.0))
        assertEquals(6_000, GuardianPolicy.initialConnectIoTimeoutMs(5_000.0))
    }

}
