package com.secureconnect.app.vpn

/**
 * A historical recovery candidate is NOT a currently quality-certified reserve.
 * It may only be tried during a hard outage and must pass a fresh live TLS check
 * before traffic is considered restored. In particular, cold catalogue entries
 * or servers that never passed double speed+YouTube checks are never candidates.
 */
object RecoveryReservePolicy {
    const val HISTORY_LIFETIME_MS = 48L * 60L * 60_000L
    const val FAILURE_RETRY_PAUSE_MS = 5L * 60_000L

    fun eligible(
        nowMs: Long,
        lastSuccessAtMs: Long,
        speedVerifiedAtMs: Long,
        youtubeVerifiedAtMs: Long,
        lastFailureAtMs: Long,
        pingMs: Int,
        downMbps: Double,
        upMbps: Double
    ): Boolean {
        if (!WorkingPoolPolicy.qualifiesRtt(pingMs) ||
            VpnSpeedPolicy.classify(downMbps, upMbps) != VpnSpeedPolicy.Verdict.PASS) return false
        if (lastSuccessAtMs <= 0L || speedVerifiedAtMs <= 0L || youtubeVerifiedAtMs <= 0L) return false
        if (listOf(lastSuccessAtMs, speedVerifiedAtMs, youtubeVerifiedAtMs).any {
            nowMs < it || nowMs - it > HISTORY_LIFETIME_MS
        }) return false
        // Avoid hammering a previously failed endpoint every 5 seconds.
        if (lastFailureAtMs > lastSuccessAtMs && nowMs >= lastFailureAtMs &&
            nowMs - lastFailureAtMs < FAILURE_RETRY_PAUSE_MS) return false
        return true
    }
}