package com.secureconnect.app

/** Debounces temporary empty Recent Tasks snapshots; Home/screen off keeps the task. */
class TaskPresencePolicy(
    private val missesRequired: Int = 2,
    priorTaskWasKnown: Boolean = false
) {
    private var hasObservedTask = priorTaskWasKnown
    private var misses = 0

    fun record(taskPresent: Boolean): Boolean {
        if (taskPresent) {
            hasObservedTask = true
            misses = 0
            return false
        }
        if (!hasObservedTask) return false
        misses++
        return misses >= missesRequired
    }
}
