package com.secureconnect.app.viewmodel

/** Redacts credentials and raw configuration links before sharing diagnostics. */
internal object VpnDiagnosticRedactor {
    fun sanitize(value: String): String = value
        .replace(Regex("(?i)(uuid|password|passwd|token|secret|privateKey|publicKey|shortId)\\s*[=:]\\s*[^,\\s]+"), "$1=<redacted>")
        .replace(Regex("(?i)(vless|vmess|trojan|hysteria2|hy2)://\\S+"), "<config-link-redacted>")

}
