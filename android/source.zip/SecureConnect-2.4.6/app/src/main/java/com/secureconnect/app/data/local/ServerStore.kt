package com.secureconnect.app.data.local

import android.content.Context
import com.secureconnect.app.data.model.Server
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Private, bounded persistence for the global subscription server cache. */
object ServerStore {
    const val SETTINGS_PREFS = "sc_settings"
    const val SERVERS_CACHE_KEY = "servers_cache"
    const val MAX_CACHED_SERVERS = 240
    const val CATALOGUE_ATTEMPT_KEY = "catalogue_attempt_at"
    private val _revision = MutableStateFlow(0L)
    val revision = _revision.asStateFlow()

    fun saveCached(context: Context, servers: List<Server>) {
        SensitivePrefs.write(context, SETTINGS_PREFS, SERVERS_CACHE_KEY, encodeServers(servers))
        context.getSharedPreferences(SETTINGS_PREFS, Context.MODE_PRIVATE).edit()
            .putLong(CATALOGUE_ATTEMPT_KEY, System.currentTimeMillis()).apply()
        _revision.value = _revision.value + 1L
    }

    fun loadCached(context: Context, favoriteIds: Set<String> = emptySet()): List<Server> {
        val raw = SensitivePrefs.read(context, SETTINGS_PREFS, SERVERS_CACHE_KEY)
            ?: return emptyList()
        return decodeServers(raw, favoriteIds)
    }

    fun encodeServers(servers: List<Server>, limit: Int = MAX_CACHED_SERVERS): String {
        val arr = JSONArray()
        servers.asSequence()
            .filter { it.id.isNotBlank() && it.rawLink.isNotBlank() }
            .distinctBy { it.id }
            .take(limit.coerceAtLeast(0))
            .forEach { s ->
                arr.put(
                    JSONObject()
                        .put("id", s.id)
                        .put("country", s.country)
                        .put("city", s.city)
                        .put("flag", s.flagEmoji)
                        .put("proto", s.protocol)
                        .put("ping", s.ping)
                        .put("reportedPingMs", s.reportedPingMs)
                        .put("reportedLoadPercent", s.reportedLoadPercent)
                        .put("host", s.host)
                        .put("port", s.port)
                        .put("src", s.source)
                        .put("link", s.rawLink)
                )
            }
        return arr.toString()
    }

    fun decodeServers(raw: String, favoriteIds: Set<String> = emptySet()): List<Server> =
        runCatching { decodeServers(JSONArray(raw), favoriteIds) }.getOrDefault(emptyList())

    fun decodeServers(arr: JSONArray, favoriteIds: Set<String> = emptySet()): List<Server> = buildList {
        val seen = HashSet<String>()
        for (i in 0 until minOf(arr.length(), MAX_CACHED_SERVERS)) {
            val j = arr.optJSONObject(i) ?: continue
            val id = j.optString("id").takeIf { it.isNotBlank() } ?: continue
            if (!seen.add(id)) continue
            val rawLink = j.optString("link")
            if (rawLink.isBlank()) continue
            add(
                Server(
                    id = id,
                    country = j.optString("country"),
                    city = j.optString("city"),
                    flagEmoji = j.optString("flag"),
                    protocol = j.optString("proto"),
                    ping = j.optInt("ping", 0).coerceAtLeast(0),
                    reportedPingMs = j.optInt("reportedPingMs", 0).takeIf { it in 1..60_000 },
                    reportedLoadPercent = j.optDouble("reportedLoadPercent", Double.NaN)
                        .takeIf { it.isFinite() && it in 0.0..100.0 },
                    isFavorite = id in favoriteIds,
                    host = j.optString("host"),
                    port = j.optInt("port", 0),
                    source = j.optString("src"),
                    rawLink = rawLink
                )
            )
        }
    }
}
