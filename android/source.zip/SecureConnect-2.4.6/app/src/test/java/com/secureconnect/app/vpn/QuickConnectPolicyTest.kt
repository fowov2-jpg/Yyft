package com.secureconnect.app.vpn

import com.secureconnect.app.data.model.Server
import org.junit.Assert.assertEquals
import org.junit.Test

class QuickConnectPolicyTest {
    private fun server(id: String) = Server(
        id = id, country = "Франция", city = "Париж", flagEmoji = "🇫🇷",
        protocol = "VLESS", ping = 42, host = "198.51.100.1", port = 443,
        rawLink = "vless://example"
    )

    @Test fun verifiedAutoSelectionIsAttemptedFirst() {
        val first = server("verified1")
        val best = server("verified2")
        val ordered = QuickConnectPolicy.order(
            selected = best, mode = ConnectionMode.AUTO, explicitSelection = false,
            verified = listOf(first, best), historical = emptyList(),
            recentlyConnectedIds = emptyList(), catalogue = emptyList()
        )
        assertEquals(listOf("verified2", "verified1"), ordered.map { it.id })
    }

    @Test fun unverifiedSelectionDoesNotJumpAheadOfKnownWorkingRoute() {
        val working = server("working")
        val unknown = server("unknown")
        val ordered = QuickConnectPolicy.order(
            selected = unknown, mode = ConnectionMode.AUTO, explicitSelection = false,
            verified = listOf(working), historical = emptyList(),
            recentlyConnectedIds = emptyList(), catalogue = listOf(unknown)
        )
        assertEquals("working", ordered.first().id)
    }

    @Test fun recentUnverifiedMustFollowVideoQualifiedPool() {
        val verified = server("quality")
        val recent = server("recent")
        val ordered = QuickConnectPolicy.order(
            selected = recent, mode = ConnectionMode.AUTO, explicitSelection = false,
            verified = listOf(verified), historical = listOf(recent),
            recentlyConnectedIds = listOf("recent"), catalogue = listOf(recent)
        )
        assertEquals("quality", ordered.first().id)
    }

    @Test fun recentServerUsesWorkingSnapshotRatherThanStaleCatalogue() {
        val observed = server("recent").copy(host = "198.51.100.18", ping = 34)
        val stale = server("recent").copy(host = "198.51.100.20", ping = 400)
        val other = server("other")
        val ordered = QuickConnectPolicy.order(
            selected = other, mode = ConnectionMode.AUTO, explicitSelection = false,
            verified = emptyList(), historical = listOf(observed),
            recentlyConnectedIds = listOf("recent"), catalogue = listOf(stale, other)
        )
        assertEquals("198.51.100.18", ordered.first().host)
    }

    @Test fun knownGoodSourceIsTriedBeforeUnknownWhenNoVerifiedServerExists() {
        val unknown = server("unknown").copy(source = "cold")
        val provenSourceCandidate = server("source-good").copy(source = "known-good")
        val result = QuickConnectPolicy.order(
            selected = unknown, mode = ConnectionMode.AUTO, explicitSelection = false,
            verified = emptyList(), historical = emptyList(),
            recentlyConnectedIds = emptyList(),
            catalogue = listOf(unknown, provenSourceCandidate),
            preferredSources = listOf("known-good")
        )
        assertEquals("source-good", result.first().id)
        assertEquals(2, result.size)
    }

    @Test fun explicitManualChoiceAlwaysWinsSourcePreference() {
        val manual = server("manual").copy(source = "cold")
        val proven = server("proven").copy(source = "known-good")
        val result = QuickConnectPolicy.order(
            selected = manual, mode = ConnectionMode.MANUAL, explicitSelection = true,
            verified = listOf(proven), historical = emptyList(),
            recentlyConnectedIds = emptyList(), catalogue = listOf(manual, proven),
            preferredSources = listOf("known-good"))
        assertEquals(listOf("manual"), result.map { it.id })
    }

    @Test fun quarantinedByCooldownIsMovedBehindReadyRoutes() {
        val working = server("working")
        val cooling = server("cooling")
        val ordered = QuickConnectPolicy.order(
            selected = cooling, mode = ConnectionMode.AUTO, explicitSelection = false,
            verified = listOf(working, cooling), historical = emptyList(),
            recentlyConnectedIds = emptyList(), catalogue = emptyList(),
            isCoolingDown = { it.id == "cooling" }
        )
        assertEquals("working", ordered.first().id)
    }
}
