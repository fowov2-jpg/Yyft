package com.secureconnect.app.vpn

import org.junit.Assert.*
import org.junit.Test

class VpnSpeedPolicyTest {
    @Test fun thresholdsAreInMegabitsPerSecond() {
        assertEquals(VpnSpeedPolicy.Verdict.PASS, VpnSpeedPolicy.classify(5.0, 1.0))
        assertEquals(VpnSpeedPolicy.Verdict.SLOW, VpnSpeedPolicy.classify(4.99, 5.0))
        assertEquals(VpnSpeedPolicy.Verdict.SLOW, VpnSpeedPolicy.classify(8.0, 0.99))
    }

    @Test fun providerFailureMustNotCauseFailover() {
        assertEquals(VpnSpeedPolicy.Verdict.UNKNOWN, VpnSpeedPolicy.classify(null, null))
        assertEquals(VpnSpeedPolicy.Verdict.UNKNOWN, VpnSpeedPolicy.classify(9.0, null))
        assertEquals(VpnSpeedPolicy.Verdict.UNKNOWN, VpnSpeedPolicy.classify(9.0, Double.NaN))
        assertEquals(VpnSpeedPolicy.Verdict.SLOW, VpnSpeedPolicy.classify(2.0, null))
        assertFalse(VpnSpeedPolicy.shouldFailover(VpnSpeedPolicy.Verdict.SLOW, VpnSpeedPolicy.Verdict.UNKNOWN))
        assertFalse(VpnSpeedPolicy.shouldFailover(VpnSpeedPolicy.Verdict.PASS, VpnSpeedPolicy.Verdict.SLOW))
    }

    @Test fun twoConfirmedFailuresTriggerRecovery() {
        assertTrue(VpnSpeedPolicy.shouldFailover(VpnSpeedPolicy.Verdict.SLOW, VpnSpeedPolicy.Verdict.SLOW))
        assertEquals(5L * 60_000L, VpnSpeedPolicy.PERIOD_MS)
    }

    @Test fun payloadRateConversion() {
        assertEquals(3.0, VpnSpeedPolicy.mbps(375_000, 1_000_000_000L)!!, 0.000001)
        assertNull(VpnSpeedPolicy.mbps(375_000, 0))
        assertNull(VpnSpeedPolicy.mbps(-2, 1_000_000_000L))
    }

    @Test fun twoRealSamplesRequiredForVerifiedStandby() {
        val good = VpnSpeedPolicy.Result(5.2, 1.1)
        val slow = VpnSpeedPolicy.Result(4.9, 1.1)
        val unknown = VpnSpeedPolicy.Result(null, null, "provider offline")
        assertTrue(VpnSpeedPolicy.qualifiesStandby(good, good))
        assertFalse(VpnSpeedPolicy.qualifiesStandby(good, slow))
        assertFalse(VpnSpeedPolicy.qualifiesStandby(good, unknown))
        assertFalse(VpnSpeedPolicy.qualifiesStandby(good, null))
    }

    @Test fun switchingRequiresRealImprovementToAvoidVideoRebuffer() {
        assertFalse(VpnSpeedPolicy.betterThanCurrent(5.1, 4.8))
        assertTrue(VpnSpeedPolicy.betterThanCurrent(6.0, 4.8))
        assertTrue(VpnSpeedPolicy.betterThanCurrent(5.0, 2.0))
        assertFalse(VpnSpeedPolicy.betterThanCurrent(null, 2.0))
        assertFalse(VpnSpeedPolicy.betterThanCurrent(4.9, 1.0))
        assertFalse(VpnSpeedPolicy.betterThanCurrent(10.0, null))
    }
}
