package com.secureconnect.app

import com.secureconnect.app.vpn.CatalogueRefreshPolicy
import org.junit.Assert.*
import org.junit.Test

class CatalogueRefreshPolicyTest {
    private val now = 3_000_000L

    @Test fun initialLaunchLoadsImmediatelyEvenIfOldAttemptWasRecorded() {
        assertTrue(CatalogueRefreshPolicy.isDue(now, 0, now - 10_000, 0, 0, 0))
        assertTrue(CatalogueRefreshPolicy.isDue(now, 0, 0, 0, 0, 0))
    }

    @Test fun partialListContinuesRefillingAndFullPoolRefreshesOnTtl() {
        assertFalse(CatalogueRefreshPolicy.isDue(now, 45, now - 1_199_999, 0, 0, 0))
        assertTrue(CatalogueRefreshPolicy.isDue(now, 45, now - 1_200_000, 0, 0, 0))
        // Missing successful refresh timestamp must not pretend the cache is fresh.
        assertTrue(CatalogueRefreshPolicy.isDue(now, 100, 0, 0, 0, 5))
        assertTrue(CatalogueRefreshPolicy.isDue(now, 100, now - 3_000_000, 0, 0, 4))
        assertTrue(CatalogueRefreshPolicy.isDue(30_000_000, 100,
            30_000_000 - 6L * 60 * 60 * 1000, 0, 0, 4))
    }

    @Test fun fullCatalogueWithFullVerifiedPoolStillExpires() {
        val moment = 100_000_000L
        assertFalse(CatalogueRefreshPolicy.isDue(moment, 100, moment - 59L * 60_000L,
            0L, 0, 21, adequateBackups = true))
        assertTrue(CatalogueRefreshPolicy.isDue(moment, 100, moment - 60L * 60_000L,
            0L, 0, 21, adequateBackups = true))
    }

    @Test fun networkFailuresUseBoundedBackoffInsteadOfMarkingSuccess() {
        assertEquals(30_000L, CatalogueRefreshPolicy.retryMs(1))
        assertEquals(60_000L, CatalogueRefreshPolicy.retryMs(2))
        assertEquals(300_000L, CatalogueRefreshPolicy.retryMs(100))
        assertFalse(CatalogueRefreshPolicy.isDue(now, 0, 0, now - 29_999, 1, 0))
        assertTrue(CatalogueRefreshPolicy.isDue(now, 0, 0, now - 30_000, 1, 0))
    }

    @Test fun adequateSmallPoolSlowsBackgroundCatalogueDownloads() {
        val nowLong = 100_000_000L
        val oneHour = 60L * 60 * 1000
        assertFalse(CatalogueRefreshPolicy.isDue(
            nowLong, 100, nowLong - 45L * 60_000L, 0, 0, 5, adequateBackups = true))
        assertFalse(CatalogueRefreshPolicy.isDue(
            nowLong, 100, nowLong - oneHour + 1, 0, 0, 5, adequateBackups = true))
        assertTrue(CatalogueRefreshPolicy.isDue(
            nowLong, 100, nowLong - oneHour, 0, 0, 5, adequateBackups = true))
        // If fewer than the eco target survive, refill promptly.
        assertTrue(CatalogueRefreshPolicy.isDue(
            nowLong, 100, nowLong - 20L * 60_000L, 0, 0, 2, adequateBackups = false))
    }
}
