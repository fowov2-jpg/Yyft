Android Xray AAR is downloaded and verified by Gradle at build time.
Expected upstream version: v26.9.30
Expected SHA-256:
cf71680b776b9ca583747ba652f816b047a655eab875d8951e6141636d88bbd6

For an offline build, put the matching libv2ray.aar into app/libs/.
See README.md in the project root for current build instructions.
