package com.secureconnect.app

import com.secureconnect.app.data.model.ServerQualityHints
import com.secureconnect.app.data.remote.ConfigParser
import com.secureconnect.app.data.remote.ServerRepository
import com.secureconnect.app.data.local.ServerStore
import org.junit.Assert.*
import org.junit.Test

class ServerQualityHintsTest {
    private val link = "vless://id@example.com:443?security=tls&type=tcp"
    @Test fun readsDecodedLabelsWithoutInventingMeasuredPing() {
        val server = ConfigParser.parse("$link#ping%3D100ms%20load%3D70%25", "test")!!
        assertEquals(100, server.reportedPingMs)
        assertEquals(70.0, server.reportedLoadPercent!!, 0.0)
        assertEquals(0, server.ping)
        assertEquals(0, ServerQualityHints.importPriority(server))
        val restored = ServerStore.decodeServers(ServerStore.encodeServers(listOf(server))).single()
        assertEquals(server, restored)
    }
    @Test fun bareNumbersAndInvalidPercentDoNotBecomeLoad() {
        assertNull(ServerQualityHints.parse("DE 443 70% users 100").loadPercent)
        assertNull(ServerQualityHints.parse("load=170% ping=-10ms").loadPercent)
        assertNull(ServerQualityHints.parse("load=170% ping=-10ms").pingMs)
        assertNull(ServerQualityHints.parse("download=60Mbps").pingMs)
    }
    @Test fun decimalAndConflictingLabelsDoNotRoundIntoPreferredTier() {
        val hints = ServerQualityHints.parse("пинг:100,1мс нагрузка:70,5%")
        assertEquals(101, hints.pingMs)
        assertEquals(70.5, hints.loadPercent!!, 0.0)
        assertEquals(90.0, ServerQualityHints.parse("load=10% load=90%").loadPercent!!, 0.0)
    }
    @Test fun preferredLabelsWinBeforeHundredCandidateLimitWhileFallbackRemains() {
        val unknown = (0 until 100).map { i -> ConfigParser.parse("vless://id$i@example.com:443?security=tls", "a")!! }
        val preferred = ConfigParser.parse("$link#latency=90ms load=60%", "b")!!
        val pool = ServerRepository.buildColdStartPool(unknown + preferred, 100)
        assertEquals(100, pool.size)
        assertEquals(preferred.id, pool.first().id)
        assertEquals(99, pool.count { it.reportedLoadPercent == null })
    }
    @Test fun extractionPreservesExplicitLabelsAfterUnescapedSpaces() {
        val raw = "$link#NL ping=80ms load=50%"
        val links = ConfigParser.extractLinks(raw)
        assertEquals(listOf(raw), links)
        assertEquals(50.0, ConfigParser.parse(links.single(), "test")!!.reportedLoadPercent!!, 0.0)
    }
}
