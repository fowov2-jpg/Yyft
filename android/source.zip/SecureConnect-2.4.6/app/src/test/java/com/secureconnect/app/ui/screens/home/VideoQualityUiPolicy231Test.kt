package com.secureconnect.app.ui.screens.home

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VideoQualityUiPolicy231Test {
    @Test fun previousProofIsNotCalledFresh720p() {
        val ui = VideoQualityUiPolicy.resolve("Подтверждено ранее")
        assertEquals(VideoQualityUiPolicy.Tone.NOTICE, ui.tone)
        assertTrue(ui.detail.contains("текущей сети"))
        assertFalse(ui.title.contains("720p"))
    }
    @Test fun failedUserBenchmarkCannotBeMarkedGood() {
        val ui = VideoQualityUiPolicy.resolve("Тест не завершён")
        assertEquals(VideoQualityUiPolicy.Tone.NOTICE, ui.tone)
        assertTrue(ui.detail.contains("VPN остаётся подключён"))
    }
    @Test fun youtubePageAloneNeverCertifiesSpeed() {
        val ui = VideoQualityUiPolicy.resolve("YouTube доступен · скорость не измерена")
        assertEquals(VideoQualityUiPolicy.Tone.NOTICE, ui.tone)
        assertTrue(ui.detail.contains("не измерена"))
    }
    @Test fun blockedVideoDoesNotClaimVpnBlocked() {
        val ui = VideoQualityUiPolicy.resolve("YouTube недоступен")
        assertEquals(VideoQualityUiPolicy.Tone.BAD, ui.tone)
        assertTrue(ui.detail.contains("VPN может работать"))
    }
    @Test fun lackOfFreshDataStaysUnknown() {
        assertEquals(VideoQualityUiPolicy.Tone.NEUTRAL,
            VideoQualityUiPolicy.resolve("Не проверено").tone)
    }

    @Test fun oneAutomaticThroughputTestIsNotPlaybackGuarantee() {
        val ui = VideoQualityUiPolicy.resolve("Авто 720p · скорость подходит")
        assertEquals(VideoQualityUiPolicy.Tone.GOOD, ui.tone)
        assertTrue(ui.detail.contains("не гарантируется"))
    }
}
