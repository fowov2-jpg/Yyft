package com.secureconnect.app.vpn

/** Severity is based on observable state, not an estimated probability of interception. */
internal enum class SecuritySeverity { NONE, WARNING, CRITICAL }

internal data class SecurityAlert(
    val id: String,
    val severity: SecuritySeverity,
    val title: String,
    val explanation: String
)

internal object SecurityAlertPolicy {
    fun classify(
        state: VpnState,
        tunPresent: Boolean,
        killSwitchEnabled: Boolean,
        tlsStatus: String,
        routingMode: AppVpnMode,
        hasActiveServer: Boolean
    ): SecurityAlert {
        if (state is VpnState.Error && !tunPresent)
            return SecurityAlert("vpn_unprotected", SecuritySeverity.CRITICAL,
                "Защита VPN не подтверждена",
                "VPN завершился без активного блокирующего интерфейса. Защищаемые приложения могут работать напрямую.")
        if (state == VpnState.Blocked)
            return SecurityAlert("vpn_blocked",
                if (tunPresent) SecuritySeverity.WARNING else SecuritySeverity.CRITICAL,
                "VPN прервался — Kill Switch активен",
                if (tunPresent) "Блокирующий TUN активен для защищаемых приложений. Исключения, включая российские приложения, продолжают работать напрямую."
                else "Блокирующий VPN-интерфейс не подтверждён; прямой выход может быть возможен.")
        if (state != VpnState.Connected) return none()
        if (!tunPresent)
            return SecurityAlert("tun_missing", SecuritySeverity.CRITICAL,
                "VPN-интерфейс отсутствует", "Состояние подключения не согласуется с наличием TUN. Защита не подтверждена.")
        if (tlsStatus.startsWith("ОПАСНО:", ignoreCase = true))
            return SecurityAlert("tls_certificate", SecuritySeverity.CRITICAL,
                "Обнаружена ошибка сертификата TLS",
                "Проверенный HTTPS-маршрут не прошёл проверку. Подозрительные серверы помещаются в карантин.")
        if (!killSwitchEnabled)
            return SecurityAlert("kill_switch_off", SecuritySeverity.WARNING,
                "Kill Switch отключён",
                "При обрыве VPN защищаемые приложения могут перейти на прямое соединение.")
        if (routingMode == AppVpnMode.ONLY_SELECTED)
            return SecurityAlert("only_selected", SecuritySeverity.WARNING,
                "Часть приложений подключается напрямую",
                "В режиме «Только выбранные» все остальные приложения не используют VPN.")
        if (!hasActiveServer)
            return SecurityAlert("server_unknown", SecuritySeverity.WARNING,
                "Не подтверждён активный сервер",
                "VPN сообщает о подключении, но выбранный выходной сервер не установлен.")
        return none()
    }

    private fun none() = SecurityAlert("ok", SecuritySeverity.NONE,
        "Критических событий не обнаружено",
        "DNS, IPv6 и IP-утечки не проверялись отдельным внешним тестом.")
}

/** Stateful throttle for incidents; recovered sessions reset deduplication. */
internal class SecurityAlertGate(
    private val repeatAfterMs: Long = 45L * 60_000L
) {
    private var currentId = "ok"
    private var lastAlertAt = -1L

    fun accept(alert: SecurityAlert, nowMs: Long): Boolean {
        if (alert.severity == SecuritySeverity.NONE) {
            currentId = "ok"
            lastAlertAt = -1L
            return false
        }
        val fresh = alert.id != currentId || lastAlertAt < 0L ||
            nowMs - lastAlertAt >= repeatAfterMs || nowMs < lastAlertAt
        currentId = alert.id
        if (fresh) lastAlertAt = nowMs
        return fresh
    }
}
