package com.secureconnect.app

import com.secureconnect.app.data.model.Server
import com.secureconnect.app.vpn.XrayConfigBuilder
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class ServerPrecheckConfigTest {
    private fun server() = Server(id = "probe", country = "", city = "", flagEmoji = "",
        protocol = "VLESS", ping = 0, host = "example.com", port = 443, source = "test",
        rawLink = "vless://00000000-0000-0000-0000-000000000001@example.com:443?security=tls&sni=cdn.example.com&type=ws&path=%2Fvpn")

    @Test fun isolatedProbeKeepsCredentialsAndTransportWithoutAnyListeners() {
        val candidate = server()
        val probe = JSONObject(XrayConfigBuilder.buildProbe(candidate)!!)
        val live = JSONObject(XrayConfigBuilder.build(candidate, null)!!)
        assertFalse(probe.has("inbounds"))
        assertFalse(probe.has("routing"))
        assertFalse(probe.has("dns"))
        assertEquals(1, probe.getJSONArray("outbounds").length())
        val outbound = probe.getJSONArray("outbounds").getJSONObject(0)
        assertEquals(live.getJSONArray("outbounds").getJSONObject(0).toString(), outbound.toString())
    }

    @Test fun dohAndTunHaveExplicitProxyRoutes() {
        val config = JSONObject(XrayConfigBuilder.build(server(), null)!!)
        assertEquals("vpn-dns", config.getJSONObject("dns").getString("tag"))
        val rules = config.getJSONObject("routing").getJSONArray("rules")
        val doh = (0 until rules.length()).map { rules.getJSONObject(it) }
            .first { it.getJSONArray("inboundTag").getString(0) == "vpn-dns" }
        assertEquals("proxy", doh.getString("outboundTag"))
        val tun = rules.getJSONObject(rules.length() - 1)
        assertEquals("tun", tun.getJSONArray("inboundTag").getString(0))
        assertEquals("proxy", tun.getString("outboundTag"))
    }
}
