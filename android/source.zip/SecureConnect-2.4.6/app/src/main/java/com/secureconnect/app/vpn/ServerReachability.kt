package com.secureconnect.app.vpn

import com.secureconnect.app.data.model.Server
import com.secureconnect.app.util.ResourceGovernor
import org.json.JSONObject
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/** First-pass scheduling hint; neither TCP success nor failure proves VPN health. */
object ServerReachability {
    private data class Cached(val addresses: List<InetAddress>, val at: Long)
    private val cache = ConcurrentHashMap<String, Cached>()
    private const val DNS_TIMEOUT_MS = 1_500L
    private const val TCP_BUDGET_MS = 1_800L

    fun usesTcp(config: String): Boolean {
        val outbound = JSONObject(config).getJSONArray("outbounds").getJSONObject(0)
        if (outbound.optString("protocol").lowercase() in setOf("hysteria2", "hysteria", "tuic")) return false
        val stream = outbound.optJSONObject("streamSettings")
        val network = (stream?.optString("method")?.takeIf { it.isNotBlank() }
            ?: stream?.optString("network")).orEmpty().lowercase()
        return network in setOf("", "tcp", "raw", "ws", "websocket", "grpc", "xhttp", "splithttp", "httpupgrade", "http")
    }

    fun reachable(server: Server, config: String): Boolean {
        if (!usesTcp(config)) return true // A closed TCP port says nothing about a UDP transport.
        val addresses = addresses(server.host) ?: return false
        val deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(TCP_BUDGET_MS)
        for (address in addresses.take(2)) {
            val remaining = TimeUnit.NANOSECONDS.toMillis(deadline - System.nanoTime())
            if (remaining <= 0L) break
            try {
                Socket().use { socket ->
                    socket.connect(InetSocketAddress(address, server.port), minOf(remaining, 900L).toInt().coerceAtLeast(1))
                    return true
                }
            } catch (_: Exception) { /* Try another address within the shared budget. */ }
        }
        return false
    }

    private fun addresses(host: String): List<InetAddress>? {
        val now = System.currentTimeMillis()
        cache[host]?.takeIf { now - it.at in 0L..60_000L }?.let { return it.addresses }
        val future = ResourceGovernor.dnsExecutor.submit<List<InetAddress>> {
            InetAddress.getAllByName(host).toList()
        }
        return try {
            future.get(DNS_TIMEOUT_MS, TimeUnit.MILLISECONDS).also {
                if (cache.size >= 128) cache.clear()
                cache[host] = Cached(it, now)
            }
        } catch (_: Exception) {
            null
        } finally {
            future.cancel(true)
        }
    }
}
