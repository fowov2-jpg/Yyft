package com.secureconnect.app.vpn

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FastFailoverPolicyTest {
    @Test fun onlyPreviouslyQualifiedIndependentReserveCanFastSwitch() {
        assertTrue(FastFailoverPolicy.canUseReadyReserve(true, false, false, true))
        assertFalse(FastFailoverPolicy.canUseReadyReserve(false, false, false, true))
        assertFalse(FastFailoverPolicy.canUseReadyReserve(true, true, false, true))
        assertFalse(FastFailoverPolicy.canUseReadyReserve(true, false, true, true))
        assertFalse(FastFailoverPolicy.canUseReadyReserve(true, false, false, false))
    }

    @Test fun fiveSecondTargetIsMeasuredNotAssumed() {
        assertTrue(FastFailoverPolicy.metGoal(0))
        assertTrue(FastFailoverPolicy.metGoal(5_000))
        assertFalse(FastFailoverPolicy.metGoal(5_001))
        assertFalse(FastFailoverPolicy.metGoal(-1))
    }
}
